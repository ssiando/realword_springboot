const config = require('../../craco.config');
module.exports = config;
