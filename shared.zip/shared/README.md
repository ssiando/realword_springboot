# Shared

## Mui theme customize

https://mui.com/customization/theme-components/

```
shared/
├─ src/
│  ├─ theme (mui theme customize)
│  │  ├─ components
│  │  │  ├─ MuiButton.ts
│  │  │  ├─ ...
│  │  ├─ index.ts
```