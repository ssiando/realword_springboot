export { default } from './Paper';
