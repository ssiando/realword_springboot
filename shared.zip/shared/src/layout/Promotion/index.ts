export { default } from './Promotion';
