function Mobile() {
  return <header>mobile</header>;
}
export default Mobile;
