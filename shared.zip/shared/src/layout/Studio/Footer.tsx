function Footer() {
  return <footer>©2022 인공지능산업융합사업단. ALL RIGHTS RESERVED</footer>;
}
export default Footer;
