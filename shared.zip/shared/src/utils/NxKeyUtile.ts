import axios from "axios";

export const keySecureDec = (id: string, callback: (decode: string) => void) => {
  //@ts-ignore
  const values = mtk.inputFillEncData(document.getElementById(id));
  //@ts-ignore
  const name = document.getElementById(id).name;
  const hidden = values.hidden;
  const hmac = values.hmac;
  //@ts-ignore
  const frmId = use_form_id ? "_" + document.getElementById("hidfrmId").value : "";

  let paramData = new URLSearchParams();
  paramData.append("id", id);
  paramData.append("name", name);
  paramData.append("transkey_" + id + "_" + frmId + "", hidden);
  paramData.append("transkey_HM_" + id + "_" + frmId + "", hmac);
  paramData.append("transkey_ExE2E_" + id + "_" + frmId + "", "raon");
  //@ts-ignore
  paramData.append("transkeyUuid_" + frmId + "", mtk.transkeyUuid);
  //@ts-ignore
  paramData.append("hidfrmId", frmId + tk_origin);

  axios({
    //@ts-ignore
    url: pki_protocol + '//' + pki_hostname + "/pki/transkey/mobileDec-sess.jsp",
    method: 'post',
    data: paramData,
    withCredentials: true
  }).then((response: any) => {
    let res = JSON.stringify(response.data, null, 4);
    let data = response.data;
    if (data.decode) {
      callback(data.decode)
      // $("#passwd").val(data.decode)
      // handleClickLogin()
    }
  })
    .catch((error: any) => {
      const json = JSON.stringify(error.response.data, null, 4);
      console.log("error=>" + json);
    });
}