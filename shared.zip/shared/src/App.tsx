function App() {
  return <div className="App">SHARED</div>;
}

export default App;
