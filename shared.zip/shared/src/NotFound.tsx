function NotFound() {
  return (
    <section>
      <div>페이지를 찾을 수 없습니다.</div>
    </section>
  );
}

export default NotFound;
