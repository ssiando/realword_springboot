import authentication from "../authentication";
import fetchRefreshToken from "../fetches/fetchRefreshToken"
import dayjs from "../libs/dayjs";
import axios from "../libs/axios";

export default async (req: any) => {
  // 토큰이 있다면..
  const certificate = authentication.get();
  const left = dayjs(certificate.accessTokenExpiresAt).diff(+new Date(), 's');

  if (
    //* 토큰이 유효하고,
    certificate.accessToken &&
    //* 남은 시간이 1초 이상이고,
    left > 0 &&
    //* 업데이트 한지 2초 이상이면,
    dayjs().diff(certificate.updateAt, 's') > 1
  ) {
    //* 토큰 갱신
    try {
      const res = await fetchRefreshToken();
      authentication.set(res.data);
    } catch (e:any) {
      console.log('anjsep catch')
      const {status, error} = e.response;
      if (status == 401 && error == "Unauthorized"){
        const domain = process.env.REACT_APP_SSO_CHECK_PATH
        window.location.href = `${domain}?nextUrl=${window.btoa(window.location.href)}`
      }
      return false;
    }
  }

  return req.responseType === 'blob'
    ? axios(req)
    : axios(req).then((res) => res.data);
};
