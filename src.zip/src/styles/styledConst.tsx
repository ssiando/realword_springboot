import styled from '@emotion/styled';
import { css } from '@emotion/react';
import { Box, Checkbox, FormControl, MenuItem } from '@mui/material';
import { Color } from '~/components/StyleUtils';

//상단배너공통
export const BennerCont = styled(Box)`
  width: 100%;
  z-index: 3;
  display: block;
  color: ${Color.white};
  background-color: ${Color.darkBg};
  transition: 0.25s;
  &.relative{
    position: relative;
  }
  &.scrollaction{
    .MuiStepLabel-label{
      display: none;
    }
    ol{
      top: 0;
    }
    .benner{
      min-height: 110px;
      .step02, .step03{
        margin: 12px auto 0;
      }
    }
    .content{
      padding: 20px 0 0;
    }
    .txtbox {
      margin: 30px auto 30px;
      &.tab{
        margin-bottom: 60px;
      }
      .tit{
        font-size: 40px;
      }
      p{
        display: none;
      }
    }
    .input_w{
      display: none;
    }
  }
  .inner_tab{
    position: relative;
    width: 100%;
    background: #fff;
    bottom: -60px;
    .detailtab_02{
      width: 1290px;
      margin: 0 auto;
      padding: 0 20px;
    }
  }
  .benner {
    position: relative;
    text-align: center;
    width: 100%;
    overflow: hidden;
    height: 100%;
    transition: 0.25s;
    &.pt60{padding-top:60px}
    &.pt120{padding-top:120px}
    .innerBox{
      max-width: 1290px;
      margin: 0 auto;
      padding: 0 15px;
      width: 100%;
    }
    .step02{
      max-width: 342px;
      margin: 30px auto 0;
      align-items: center;
      .MuiStepLabel-label{
        letter-spacing: -1.4px;
      }
      .MuiStep-root{
        padding: 0;
        width: 110px;
        .Mui-active{
          color: #1CCDCC;
          border: none;
        }
        .Mui-completed{
          color: #707070;
          border: none;
        }
        &.Mui-completed{
          &+.MuiStep-root{
            .MuiStepConnector-line{
              border-color: #0c101e;
            }
          }
        }
        .Mui-disabled{
          color: #ccc;
          .MuiStepIcon-root{
            border: 1px solid #fff;
            border-radius: 50px;
            color: rgba(0, 0, 0, 0);
          }
        }
      }
      .MuiStepConnector-root{
        left: calc(-50% + 17px);
        right: calc(50% + 17px);
        top: 17px;
      }
      .MuiStepIcon-root{
        width: 34px;
        height: 34px;
        &.Mui-completed{
          color: #0c101e;
        }
        &.Mui-active{
          color: #1CCDCC;
        }
      }
      .MuiStepIcon-text{
        font-size: 0.6rem;
      }
      @media (min-width: 320px) and (max-width: 768px) {
        max-width: 100%;
        .css-nen11g-MuiStack-root{
          flex-direction: column;
        }
      }
    }
  }
  .txtbox {
    margin: 50px auto 60px;
    max-width: 1080px;
    width: 100%;
    &.tab{
      margin-bottom: 108px;
    }
    .tit {
      transition: 0.25s;
      font-size: 48px;
      font-weight: 700;
      letter-spacing: -1.92px;
      text-align: center;
      margin-top: 0;
      line-height: 1.5;
    }
    p {
      font-size: 16px;
      font-weight: 300;
      line-height: 1.88;
      letter-spacing: -0.64px;
      margin-top: 10px;
      padding: 0;
    }
  }
  .bottom_card {
    height: 60px;
    max-width: 1260px;
    width: 100%;
    padding: 14px 18px 14px 20px;
    margin: 0 auto;
    border-radius: 15px 15px 0 0;
    background-color: ${Color.light_gray02};
    > p {
      line-height: 1.75;
      margin: 4px 0;
      font-weight: 700;
      color: #222;
      letter-spacing: -0.64px;
    }
    .tag {
      .MuiChip-root {
        border-radius: 5px;
        font-size: 14px;
        letter-spacing: -0.56px;
        font-weight: 300;
        &.blue {
          background-color: ${Color.azul};
          color: ${Color.white};
        }
        &.wh {
          background-color: ${Color.white};
          color: ${Color.warm_gray};
          border: 1px solid ${Color.gray};
        }
      }
    }
  }
  
  @media (min-width: 320px) and (max-width: 1200px) {
    .benner{
      padding-top: 0;
    }
    &.fixed{
      margin-top: 0;
      &.scrollaction{
        padding-top: 0;
        .benner{
          min-height: 57px;
        }
      }
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .inner_tab{
      bottom: 0px;
    }
    .benner{
      &.pt60{
        padding-top: 0;
      }
      &.pt120{
        margin-top: 60px;
        padding-top: 0;
      }
    }
    .txtbox {
      margin: 48px auto 48px;
      &.tab{
        margin-bottom: 88px;
      }
      .tit {
        font-size: 28px;
        letter-spacing: -1.12px;
      }
      p {
        font-size: 14px;
        line-height: 1.88;
        letter-spacing: -0.56px;
      }
    }
    .tab_wrap{
      .MuiTabs-root{
        min-height: 40px;
      }
      .MuiButtonBase-root{
        line-height: 1;
        padding: 12px 15px;
        min-height: 40px;
        width: max-content;
      }
    }
    &.scrollaction{
      padding-top: 0;
      .benner{
        min-height: 60px;
        .step02, .step03{
          margin: 10px auto;
        }
        .tit{
          padding-top: 12px;
          font-size: 20px;
        }
      }
      .content{
        padding: 0;
      }
      .txtbox {
        margin: 0;
        &.tab{
          margin: 0;
          .tit{
            padding: 6px 0;
            font-size: 0;
            margin: 0;
          }
        }
      }
    }
    .bottom_card {
      height: 48px;
      padding: 9px 15px 9px 15px;
      > p {
        margin: 4px 0;
        letter-spacing: -0.56px;
        font-size: 14px;
        line-height: 1.5;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
        margin-right: 10px;
      }
      .tag {
        .MuiChip-root {
          font-size: 12px;
          height: 30px;
        }
      }
    }
  }
`;

export const step02 = css`
  max-width: 342px;
  margin: 30px auto 0;
  align-items: center;
  .MuiStepLabel-label{
    letter-spacing: -1.4px;
  }
  .MuiStep-root{
    padding: 0;
    width: 110px;
    .Mui-active{
      color: #1CCDCC;
      border: none;
    }
    .Mui-completed{
      color: #707070;
      border: none;
    }
    &.Mui-completed{
      &+.MuiStep-root{
        .MuiStepConnector-line{
          border-color: #0c101e;
        }
      }
    }
    .Mui-disabled{
      color: #ccc;
      .MuiStepIcon-root{
        border: 1px solid #fff;
        border-radius: 50px;
        color: rgba(0, 0, 0, 0);
      }
    }
  }
  .MuiStepConnector-root{
    left: calc(-50% + 17px);
    right: calc(50% + 17px);
    top: 17px;
  }
  .MuiStepIcon-root{
    width: 34px;
    height: 34px;
    &.Mui-completed{
      color: #0c101e;
    }
    &.Mui-active{
      color: #1CCDCC;
    }
  }
  .MuiStepIcon-text{
    font-size: 0.6rem;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    max-width: 100%;
    .css-nen11g-MuiStack-root{
      flex-direction: column;
    }
  }
`;

export const CheckboxStyle = styled(Checkbox)`
  padding: 0;
  &.MuiCheckbox-root{
    padding: 0;
    margin-right: 10px;
    margin-left: 10px;
  }
  .MuiSvgIcon-root {
    width: 20px;
    height: 20px;
    background-color: #fff;
    border-radius: 4px;
    path {
      display: none;
    }
  }
  .MuiFormControlLabel-root{
    margin-left: -10px;
  }
  &:before {
    content: '';
    position: absolute;
    left: 50%;
    top: 50%;
    width: 20px;
    height: 20px;
    margin: -10px 0 0 -10px;
    border-radius: 3px;
    border: 1px solid #ccc;
  }
  &.Mui-checked {
    &:before {
      border: none;
      background-color: #4063ec;
      background:  url('/images/common/checkbox_active.png');
    }
    .MuiSvgIcon-root{
      background: none;
    }
  }
`;

//selectbox
export const MenuProps = {
  PaperProps: {
      style: {
          width: 'auto',
          marginTop: '4px',
          padding: '4px',
          boxShadow: 'none',
          border: '1px solid #ccc',
          borderRadius: '5px',
      },
  },
};

export const SelectItemStyle = styled(MenuItem)`
  font-size: 16px;
  letter-spacing: -0.64px;
  font-family: Noto Sans CJK KR;
  padding: 0 12px;
  min-height: 40px !important;
  border-radius: 3px;
  margin-bottom: 4px;
  height:44px;
  line-height: 2.2;
  &:first-of-type{
      margin-top: -8px;
  }
  &:last-of-type{
      margin-bottom: -8px;
  }
  &.Mui-selected{
      background-color: #f5f5f5;
      &:hover,  &:focus-visible{
          background-color: #f5f5f5;
      }
  }
`;

export const SelectStyle = styled(FormControl)`
  .MuiSelect-select{
      padding-top: 12px;
      padding-bottom: 13px;
  }
 .MuiOutlinedInput-root{
      border-color: #ccc;
      .MuiOutlinedInput-notchedOutline{
          border-color: #ccc;
          border-width: 1px;
      }
      &.Mui-focused, &:hover {
          .MuiOutlinedInput-notchedOutline{
              border-color: #ccc;
              border-width: 1px;
          }
      }
  }
`;