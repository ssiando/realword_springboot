import React from "react"
import Stack from '@mui/material/Stack';
import styled from '@emotion/styled';
// or import AdapterDateFns from "@mui/lab/AdapterDateFns";
import {NavLink, useLocation, useNavigate} from "react-router-dom";
// import dayjs from 'shared/libs/dayjs';

/* 
  작성일    :   2022/09/07
  화면명    :   공통 이전화면으로 돌아가기
  회면ID    :   common component
  화면/개발 :   seongeonjoo
*/
export const BackPass:React.FC<{
    color?: string;
}> = (props) => {
  const navigate = useNavigate()
  const location = useLocation()
  return(
    <PassStyle>
      <NavLink to={''} onClick={() => {
        let qs = new URLSearchParams(location.search)
        let preUrl = qs.get('preUrl')
        if (preUrl) {
          window.location.href = window.atob(preUrl).replace( window.location.origin, '')
        } else {
          navigate('/');
        }
      }}>
        이전 화면으로 돌아가기
      </NavLink>
    </PassStyle>
  );
}

const PassStyle = styled(Stack)`
  position: relative;
  > a {
    font-size: 16px;
    font-weight: 400;
    line-height: 2;
    letter-spacing: -0.64px;
    color: #222;
    display: flex;
    align-items: center;
      &:before{
        content:'';
        display: inline-block;
        background: url('/images/common/icon_side_arrow.png') no-repeat;
        width: 24px;
        height: 24px;
        margin-right: 7px;
        background-size: cover;
      }
    }
  @media (min-width: 320px) and (max-width: 768px) {
    display: none;
  }
`
