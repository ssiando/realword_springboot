import React, {ReactNode, useEffect, useState} from 'react';
import DatePicker from "~/components/DatePicker";
import {Box, Button, CircularProgress, Modal, styled, Typography} from "@mui/material";
import {CustomButton} from "~/../../shared/src/components/ButtonComponents";
import {CustomRadioButtons} from '~/components/NoticeCustomCheckBoxs';
import CloseIcon from '@mui/icons-material/Close';
import * as styles from '~/styles/styles';
import dayjs from '~/../../shared/src/libs/dayjs';
import {dayFormat} from "shared/utils/stringUtils";
/*
  공통컴포넌트 : 검색 모달 모바일
*/
export const SearchModal: React.FC<{
  handleSearch?: (searchInput: string | undefined, sdt: string, edt: string) => void
  assign_box?: any[]
  placehold?: string
  children?: ReactNode
  selectList?: { title: string, list: any[] }[]
  defaultBeginDay?: string
  defaultEndDay?: string
  hideDate?: boolean
  onSearch?: (date?: {beginDay: string, endDay: string}, selectedList?: { title: string, list: any[], value?: string }[]) => void
}> = (props) => {
  const today = new Date();
  const [modalOpen, setModalOpen] = useState(false);
  const [stsVal, setStsVal] = useState('');
  const [questBeginDay, setQuestBeginDay] = useState<string>(props.defaultBeginDay || '')
  const [questEndDay, setQuestEndDay] = useState<string>(props.defaultEndDay ||'')
  const [selectList, setSelectList] = useState<{ title: string, list: any[], value?: string }[]>(props.selectList || [])

  useEffect(() => {
    if (props.selectList) {
      setSelectList(props.selectList)
    }
  }, [props.selectList])

  const handleSearch = () => {
    if (!!props.handleSearch) {
      props.handleSearch(stsVal, questBeginDay, questEndDay)
    }
    if (props.onSearch){
      props.onSearch(props.hideDate? undefined : {
        beginDay:questBeginDay,
        endDay: questEndDay
      }, selectList)
    }
  }

  return (
    <DetalBtn>
      <Button type="button" onClick={() => {
        setModalOpen(true)
      }}>
        상세조건 열기
      </Button>
      <Modal
        keepMounted
        open={modalOpen}
        onClose={() => {
          setModalOpen(false)
        }}
      >
        <Box css={styles.modalpop} className="btntype_radio">
          <Typography id="keep-mounted-modal-title" component="h2">
            사유 확인
            <Button type="button" onClick={() => {
              setModalOpen(false)
            }}>
              <CloseIcon/>
            </Button>
          </Typography>
          <Box sx={{overflow:'scroll', height: '100%', maxHeight:'calc(100vh - 90px)'}}>
            <PickerCard>
              {
                props.hideDate || <dl>
                  <dt>접수일</dt>
                  <dd>
                    <DatePicker
                      pickerType='two'
                      questBeginDay={questBeginDay}
                      questEndDay={questEndDay}
                      changeStart={(startNewTime: Date | null) => {
                        setQuestBeginDay(dayjs(startNewTime).format('YYYY-MM-DD'))
                      }}
                      changeEnd={(endNewTime: Date | null) => {
                        setQuestEndDay(dayjs(endNewTime).format('YYYY-MM-DD'))
                      }}
                    />
                  </dd>
                </dl>
              }

              {props.assign_box && props.assign_box.length > 0 ?
                <dl>
                  <dt>상태</dt>
                  <dd>
                    <CustomRadioButtons
                      row
                      data={props.assign_box}
                      onClick={(s: string) => {
                        setStsVal(s)
                      }}
                    />
                  </dd>
                </dl>
                : null
              }

              {
                selectList.map((m,i) => {
                  return <dl>
                    <dt>{m.title}</dt>
                    {
                      m.list && m.list.length > 0 && <dd>
                        <CustomRadioButtons
                          row
                          data={m.list}
                          onClick={(s: string) => {
                            const update = [...selectList]
                            update[i].value = s
                            setSelectList(update)
                          }}
                        />
                      </dd>
                    }
                  </dl>
                })
              }
            </PickerCard>
            <CustomButton
              label={'검색'}
              type={'full'}
              color={'primary'}
              onClick={() => {
                handleSearch()
                setModalOpen(false)
              }}
            />
          </Box>
        </Box>
      </Modal>
    </DetalBtn>
  );
}

const PickerCard = styled(Box)`
  display: flex;
  max-width: 780px;
  margin: 20px auto;
  background-color: #fff;
  border-radius: 10px;
  border: solid 1px #e0e0e0;
  color: #333;
  text-align: center;

  dl {
    border-right: 1px solid #e0e0e0;
    width: 100%;

    &:last-of-type {
      border: none;

      dd {
        .MuiFormGroup-root {
          margin-bottom: -10px;
        }
      }
    }

    dt {
      border-bottom: 1px solid #e0e0e0;
      font-size: 18px;
      padding: 14px 0;
      font-weight: 700;
      letter-spacing: -0.72px;
    }

    dd {
      text-align: center;
      margin-left: 0;
      display: inline-block;
      padding: 6px;
      width: 100%;

      .box_scroll {
        padding: 14px;
        max-height: 120px;
        overflow-y: auto;

        &::-webkit-scrollbar {
          width: 5px;
          padding: 5px;
        }

        &::-webkit-scrollbar-thumb {
          background-color: #d7dae6;
          border-radius: 10px;
          width: 3px;
        }

        &::-webkit-scrollbar-track {
          background-color: #fff;
          border-radius: 10px;
          width: 10px;
        }
      }

      .MuiFormControl-root {
        width: 100%;

        .MuiFormControlLabel-root {
          flex: 0 0 48%;
          margin: 0;
          margin-bottom: 10px;

          &:nth-of-type(2n) {
            padding-left: 20px;
          }

          /* &:nth-last-of-type(-n + 2){
            margin-bottom: 0;
          } */
        }
      }
    }
  }

  @media (min-width: 320px) and (max-width: 768px) {
    border: none;
    flex-direction: column;
    .MuiInputBase-root {
      height: 46px;
    }

    dl {
      border: none;

      dt {
        border-bottom: none;
        font-size: 16px;
        padding: 10px 0;
        text-align: left;
      }

      dd {
        padding: 16px 0 0 !important;
        margin-bottom: 16px;

        .MuiFormControl-root {
          .MuiFormControlLabel-root {
            flex: 0 0 50%;

            &:nth-of-type(2n) {
              padding-left: 10px;
            }
          }
        }
      }
    }
  }
`;

const DetalBtn = styled(Box)`
  max-width: 780px;
  margin: 0 auto;
  text-align: center;

  button {
    margin-top: 20px;
    background-color: rgba(0 0 0 /0);
    color: #fff;
    border: none;
    font-size: 14px;
    border-radius: 0;
    line-height: 1;
    text-decoration: underline;
    font-weight: 400;
  }
`;