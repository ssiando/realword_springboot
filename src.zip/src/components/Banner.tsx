import {Box, Collapse, LinearProgress} from "@mui/material";
import BreadCrumb from "~/components/BreadCrumb";
import {BennerCont} from "~/styles/styledConst";
import React, {Fragment, useEffect, useRef, useState} from "react";
import {useScrollStore, useWindowDimensions} from "shared/store/ScrollStore";
import {Color} from "shared/components/StyleUtils";

export const Banner: React.FC<{
  title: string
  summary?: React.ReactNode
  summaryStep?: React.ReactNode
  loading?: boolean
  tabValue?: number
  searchContent?: React.ReactNode
  detailContent?: React.ReactNode
  tabContent?: React.ReactNode
  addictionContent?: React.ReactNode
  detailBottom?: React.ReactNode
}> = props => {
  const [height, setHeight] = useState(0)
  const [subheight, setSubheight] = useState(0);
  const scrollref = useRef<HTMLElement>(null)
  const contentRef = useRef<HTMLElement>(null)
  const {scrollDirection, isContraction} = useScrollStore()

  const listheight = () => {
    if (contentRef && contentRef.current) {
      setSubheight(contentRef.current.offsetHeight)
    }
  }
  //배너 scroll
  useEffect(() => {
    if (scrollref && scrollref.current) {
      setHeight(scrollref.current.offsetHeight)
      listheight();
    }
  }, [scrollref, props.loading, contentRef.current?.offsetHeight])

  useEffect(() => {
    const timer = setInterval(() => {
      if (!!scrollref && scrollref.current) {
        setHeight(scrollref.current.offsetHeight)
      }
    })
    setTimeout(() => {
      clearInterval(timer)
    }, 300)
  }, [isContraction])

  const {inheight} = useWindowDimensions();
  const minContaner = subheight < inheight;

  return <Fragment>
    <BennerCont ref={scrollref} sx={{position: minContaner ? 'relative' : 'fixed'}} className={minContaner ? '' : (isContraction ? 'scrollaction ' : '')}>
        <Box className={`benner ${scrollDirection == 'down' ? 'pt60' : 'pt120'} `}>
          {
            props.loading && <LinearProgress sx={{
              zIndex: 2, width: '100%',
              "& .MuiLinearProgress-bar": {
                backgroundColor: Color.topaz
              },
              position: 'absolute'
            }}/>
          }
          <Box className='innerBox'>
            <BreadCrumb/>
            <div className={`txtbox ${props.tabContent? 'tab' : ''}`}>
              <h2 className="tit">
                {props.title}
              </h2>
              <Collapse
                in={minContaner ? true : !isContraction}
                timeout={250} unmountOnExit
              >
                {props.summary && <p>{props.summary}</p>}
                {props.searchContent}
              </Collapse>
              {
                props.summaryStep && <>{props.summaryStep}</>
              }
              {
                props.detailContent && <Collapse
                  in={minContaner ? true : !isContraction}
                  timeout={250} unmountOnExit
                >
                  {props.detailContent}
                </Collapse>
              }
            </div>
            {
              props.detailBottom && <>{props.detailBottom}</>
            }
            {
              props.tabContent && <div className='tab_wrap'>
                {props.tabContent}
              </div>
            }
          </Box>
        </Box>
      {props.addictionContent}
    </BennerCont>
    <Box ref={contentRef} sx={{marginTop: minContaner ? '0' : (`${height}px`)}}>
      {props.children}
    </Box>
  </Fragment>
}