/* eslint-disable jsx-a11y/alt-text */
import * as React from 'react';
import {useEffect, useState} from 'react';
import {NavLink, useNavigate} from 'react-router-dom';

import {Box} from '@mui/material';
import styled from '@emotion/styled';
import {css} from '@emotion/react';
import {Color} from '~/components/StyleUtils';
import {breakpoint} from '../../styles/styleCommon';
import {screenOut} from '../styles';

import {mainKeyword, SearchParam} from '../Data/dataSearch';

import SearchBar from '../Components/SearchBar';
import SearchKeywordItemBtn from '../Components/SearchKeywordItemBtn';
import SearchFooter from '../Components/SearchFooter';
import {SearchService} from "~/pages/Home/SearchEngine/SearchService";
import {useQuery} from "react-query";
import {fetchCnvnCnclsDocInfo} from "~/fetches/biz/fetchContractMgt";

export default function SearchMain() {
  let windowInnerHeight = 0;
  let vh = 0;

  const isMobileCheck = /iPhone|iPad|iPod|Android/i.test(
    window.navigator.userAgent
  );
  const navigate = useNavigate()

  const [iptFocus, setIptFocus] = useState<boolean>(false);
  const [iptDisabled, setIptDisabled] = useState<boolean>(false);
  const [isKeywordOnAddClass, setIsKeywordOnAddClass] = useState<boolean>(true);
  const [searchValue, setSearchValue] = useState<string>('');
  const [isIptValue, setIsIptValue] = useState<boolean>(false);
  const [popWord, setPopWord] = useState<string[]>([])
  const [recommendList, setRecommendList] = useState<string[]>([])

  // 모바일 100vh 적용 관련
  const handleResize = () => {
    const currentInnerHeight = window.innerHeight;
    // console.log(`${currentInnerHeight}/${windowInnerHeight}`);
    if (currentInnerHeight !== windowInnerHeight) {
      windowInnerHeight = currentInnerHeight;
      vh = window.innerHeight * 0.01;
      document.documentElement.style.setProperty('--vh', `${vh}px`);
    }
  };

  const handleHashTagClick = async (e: any) => {
    setSearchValue(e.target.textContent)
    await Search(e.target.textContent)
    // console.dir(e.target.textContent);
  };

  useEffect(() => {
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  });

  const query = SearchService.GetSearchPopWord({
    target: 'popword',
    collection: '_ALL_',
    range: 'day',
    datatype: 'json'
  })

  const recommend = SearchService.GetSearchRecommend({
    target: 'recommend',
    label: '_ALL_',
    datatype: 'json',
    query: "인공지능"
  })

  useEffect(() => {
    if (!query.isLoading && !query.isFetching) {
      if (!!query.data) {
        const popword = query.data.result?.flatMap(m => m.content) || []
        setPopWord(popword.slice(0, 10))
      }
    }
  }, [query.data, query.isLoading, query.isFetching])

  useEffect(() => {
    if (!recommend.isLoading && !recommend.isFetching) {
      if (!!recommend.data) {
        console.log('recommend - ' + JSON.stringify(recommend.data))
        setRecommendList(recommend.data.result ? recommend.data.result : [])
      }
    }
  }, [recommend.data, recommend.isLoading, recommend.isFetching])

  const Search = async (searchWord: string) => {
    const res = await SearchService.GetSearch({searchFlag: 'search', query: searchWord})
    if (res.status == 'success' && !!res.result) {
      console.log('res - ' + JSON.stringify(res))
      navigate('/search/result', {
        state: {
          search: searchWord,
          result: res
        }
      })
    }
  }

  const handleKeywordList = (evt: any) => {
    if (evt.target.nodeName !== "BUTTON" && evt.target.nodeName !== "INPUT") {
      setIsKeywordOnAddClass(false);

      searchValue.length === 0
        ? setIsIptValue(false)
        : setIsIptValue(true)
    }
  }

  return (
    <SearchMainSection
      className={`${iptFocus ? 'is-focus' : ''} ${isIptValue ? 'ipt-value' : ''}`}
      onClick={handleKeywordList}>
      <SearchMainArea>
        <SearchMainForm
          // action="/search/result"
          className="search-main --keyword-absolute"
        >
          <SearchMainLogo>
            <NavLink to={''} onClick={() => {
              window.location.href = `${process.env.REACT_APP_DOMAIN}`
            }}>
              <span css={screenOut}>AICA 메인이동</span>
            </NavLink>
          </SearchMainLogo>
          <SearchBar
            iptFocus={iptFocus}
            setIptFocus={setIptFocus}
            searchValue={searchValue}
            setSearchValue={setSearchValue}
            iptDisabled={iptDisabled}
            isKeywordOnAddClass={isKeywordOnAddClass}
            setIsKeywordOnAddClass={setIsKeywordOnAddClass}
            setIsIptValue={setIsIptValue}
            searchHandler={async () => {
              await Search(searchValue)
            }}
          />

          {
            popWord && popWord.length > 0 &&
            <SearchMainKeyword>
              <h3>{'인기 검색어'}</h3>
              <ul>
                {popWord.map((tag: any, idx: number) => (
                  <li key={idx}>
                    <SearchKeywordItemBtn
                      type={'main'}
                      itemTxt={tag}
                      evtClick={handleHashTagClick}
                    />
                  </li>
                ))}
              </ul>
            </SearchMainKeyword>
          }

          {
            recommendList && recommendList.length > 0 &&
            <SearchMainKeyword>
              <h3>{'추천 검색어'}</h3>
              <ul>
                {recommendList.map((tag: any, idx: number) => (
                  <li key={idx}>
                    <SearchKeywordItemBtn
                      type={'main'}
                      itemTxt={tag}
                      evtClick={handleHashTagClick}
                    />
                  </li>
                ))}
              </ul>
            </SearchMainKeyword>
          }
        </SearchMainForm>
      </SearchMainArea>

      <SearchFooter/>
    </SearchMainSection>
  );
}

// 메인
const SearchMainSection = styled('div')`
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 100vh;
  height: calc(var(--vh, 1vh) * 100);
  padding: 200px 0 30px;
  letter-spacing: -0.06em;

  &.is-focus {
    background: ${Color.darkBg};
    overflow: hidden;
    touch-action: none;
  }

  @media (min-width: 768px) {
    transition: background 0.3s;
  }
  @media (max-width: ${breakpoint.mobile}) {
    padding: 64px 15px 12px;

    &.is-focus {
      padding-top: 15px;
    }
  }
`;
const SearchMainArea = styled('div')`
  display: flex;
  justify-content: center;
`;
const SearchMainForm = styled('div')`
  width: 620px;

  @media (max-width: ${breakpoint.mobile}) {
    width: 100%;
  }
`;
const SearchMainLogo = styled('h2')`
  display: flex;
  justify-content: center;
  margin-bottom: 30px;

  a {
    display: block;
    width: 200px;
    height: 45px;
    background: url('/images/logo-symbol.svg') no-repeat center / contain;

    @media (max-width: ${breakpoint.mobile}) {
      width: 134px;
      height: 30px;
    }
  }

  .is-focus & {
    a {
      background-image: url('/images/logo-symbol-topaz.svg');
    }

    @media (max-width: ${breakpoint.mobile}) {
      margin-bottom: 0;

      a {
        display: none;
      }
    }
  }
`;
const SearchMainKeyword = styled('div')`
  margin-top: 60px;
  padding-left: 10px;

  @media (max-width: ${breakpoint.mobile}) {
    margin-top: 56px;
    padding-left: 5px;
  }

  & + & {
    margin-top: 31px;

    @media (max-width: ${breakpoint.mobile}) {
      margin-top: 40px;
    }
  }

  h3 {
    margin-bottom: 20px;
    font-size: 18px;
    font-weight: 700;
    color: ${Color.black};
    line-height: 27px;

    @media (max-width: ${breakpoint.mobile}) {
      margin-bottom: 12px;
      font-size: 16px;
      font-weight: 500;
      line-height: 24px;
    }
  }

  ul {
    display: flex;
    flex-wrap: wrap;
    max-height: 50px;
    margin: -5px -3px;
    overflow: hidden;

    @media (max-width: ${breakpoint.mobile}) {
      max-height: 92px;
    }
  }

  li {
    height: 36px;
    margin: 5px 3px;
  }

  .is-focus & {
    h3 {
      color: ${Color.line};
    }
  }
`;
