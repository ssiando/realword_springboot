import {WisenutResponese} from "~/pages/Home/SearchEngine/SearchService";

export interface SearchParam {
  searchFlag: string
  system: string
  collection: string
  query: string
  requery: string
  startCount: number
  listCount: number
}

export type CountResult<T> = {
  cnt: number,
  collResult: T[]
}

export interface SearchResult {
  USP_PBLANC: CountResult<UspPblanc> // 모집공고
  USP_EVENT: CountResult<EventInfo> // 이벤트/행사
  USP_QESTN: CountResult<CommonListInfo> // 자주묻는 질문
  USP_NOTICE: CountResult<CommonListInfo> // 공지사항
  SAZ_QESTN: CountResult<CommonListInfo> // 자주묻는 질문
  SAZ_NOTICE: CountResult<CommonListInfo> // 공지사항
  TSP_QESTN: CountResult<CommonListInfo> // 자주묻는 질문
  TSP_NOTICE: CountResult<CommonListInfo> // 공지사항
  DXP_FAQ: CountResult<DxpFAQ> // 자주묻는질문
  DXP_NOTICE: CountResult<DxpNotice> // 공지사항
  DXP_PRMTNMV: CountResult<DxpPrmtnMV> // 홍보동영상
  DXP_DTSTRY: CountResult<DxpDtstry> // 데이터 활용 스토리
  DXP_CNTSTMNG: CountResult<DxpCntsTmng> // 공모전결과
  DXP_EVENTCATEGORY: CountResult<DxpEventCategory> // 이벤트
  DXP_DATAPRODUCT: CountResult<DxpDataProduct> // 유통 데이터 상품
  DXP_DATASET: CountResult<DxpDataSet> // 데이터셋
  LMS_COS: CountResult<LmsCos> //교육 과정
  LMS_LEC: CountResult<LmsLec> // 교육 강의
  totalCnt: number
}

export interface UspPblanc{
  DOCID: string // id값
  PBLANC_DAY: string
  FILE_CONTENT: string
  PBLANC_STTUS_CD: string
  ATTACHMENT_GROUP_ID: string
  FILE_NM: string
  ATTACHMENT_ID: string

  // PBLANC_ID: string //공고ID
  PBLANC_NM: string //공고명
  RCEPT_ENDDE: string //접수종료일
  // PBLANC_DE: string //공고일
  // PBLANC_STTUS_CODE: string //공고상태코드
  PBLANC_STTUS: string //공고상태
  RCEPT_PD: string //접수기간
  PBLANC_SUMRY: string //공고요약
  RDCNT: string //조회수
  RMNDR_DAY: string //마감남은일
  RECOMEND_CL: string //사업분야
  IS_NEW: string //신규여부 : string //Y/N))
  // ATCHMNFL_GROUP_ID : string //첨부파일그룹ID
}

export interface CommonListInfo{
  DOCID: string // id값
  FILE_NM: string
  FILE_EXTSN: string
  BBSCTT_ID: string
  FILE_CONTENT: string
  ATCHMNFL_ID: string
  CREATR_NM: string

  SJ_NM: string // 제목
  BBSCTT_CN: string // 내용
  CATEGORY_NM?: string // 카테고리
  URL?: string // 상위탭url
  BBS_ID?: string // 게시판ID
  BBS_NM: string // 게시판명
  LINK_URL: string // 이동링크
  ATCHMNFL_GROUP_ID: string // 첨부파일ID
  CREAT_DT: string // 생성일자
  RDCNT: string // 조회수
}

export interface EventInfo{
  DOCID: string // id값
  FILE_NM: string
  FILE_EXTSN: string
  BBSCTT_CN: string
  EVENT_ID: string
  FILE_CONTENT: string
  ATCHMNFL_ID: string
  LINK_URL: string
  EVENT_NM: string
  ATCHMNFL_GROUP_ID: string
  BGNDE: string // 시작일
  ENDDE: string // 종료일
  RDCNT: string // 조회수
  CREAT_DT: string // 작성일
}

export interface DxpDataProduct {
  DOCID: string // id값
  PRODUCT_DC:string // 상품설명
  PRODUCT_NM:string // 상품명
  SJ:string // 상품주제
  LCLAS_NM:string // 대분류명
  MLSFC_NM:string // 중분류명
  SCLAS_NM:string // 소분류명
  DTLCLFC_NM:string // 세분류명
  KWRD:string // 키워드
  PC_TY:string // 가격유형
  DSCNT_PC:string // 할인가격
  SBSCRB_CTRGY_NM:string // 구독카테고리명
  PRODUCT_ID: string // 상품 id
  LINK_URL: string // link url
  RDCNT: string // 조회수,
  STAR_SCORE: string // 평균별점
  CP_NM: string // 제공기관
}

export interface DxpInquiry{
  DOCID: string // id값
  NTT_SJ: string // 제목
  NTT_CN: string // 내용
  INQUIRY_CATEGORY: string // INQUIRY 카테고리
  BBS_NM: string // 게시판명
  LINK_URL: string // 이동링크
  ATCH_FILE_ID: string // 파일아이디
  ORIGNL_FILE_NM: string
  STRE_FILE_NM: string
  FILE_EXTSN: string // 확장자 종류
  FILE_CONTENT: string // 파일명
  FRST_REGIST_PNTTM: string // 작성일
}

export interface DxpNotice{
  DOCID: string // id값
  NTT_SJ: string // 제목
  NTT_CN: string // 내용
  NOTICE_CATEGORY: string // NOTICE 카테고리
  BBS_NM: string // 게시판명
  LINK_URL: string // 이동링크
  ATCH_FILE_ID: string // 파일아이디
  ORIGNL_FILE_NM: string
  STRE_FILE_NM: string
  FILE_EXTSN: string // 확장자 종류
  FILE_CONTENT: string // 파일명
  FRST_REGISTER_ID:string // 작성자
  RDCNT: string // 조회수
  FRST_REGIST_PNTTM: string // 작성일
}

export interface DxpDataSet{
  DOCID: string // id값
  DSET_DC: string // 데이터셋설명
  DSET_NM: string // 데이터셋명
  LCLAS_NM: string // 대분류명
  MLSFC_NM: string // 중분류명
  SCLAS_NM: string // 소분류명
  DTLCLFC_NM: string // 세분류명
  PROVD_INSTT_NM: string // 제공기관
  COLCT_INSTT_NM: string // 수집기관
  COLCT_PLACE_NM: string // 수집장소
  COLCT_EQPMN_NM: string // 수집장비
  KWRD: string // 키워드
  LINK_URL: string // 이동링크
  FRST_REGIST_PNTTM: string // 작성일
}

export interface DxpCntsTmng {
  DOCID: string // id값
  NTT_SJ: string // 제목
  NTT_CN: string // 내용
  BBS_NM: string // 게시판명
  LINK_URL: string // 이동링크
  ATCH_FILE_ID: string // 파일아이디
  ORIGNL_FILE_NM: string
  STRE_FILE_NM: string
  FILE_EXTSN: string // 확장자 종류
  FILE_CONTENT: string // 파일명
  CONTEST_BGNDE: string //시작일
  CONTEST_ENDDE: string //종료일
  RDCNT: string //조회수
}

export interface DxpFAQ {
  DOCID: string // id값
  NTT_SJ: string // 제목
  NTT_CN: string // 내용
  FAQ_CATEGORY: string // FAQ 카테고리
  BBS_NM: string // 게시판명
  ORIGNL_FILE_NM: string // 첨부파일명
  LINK_URL: string // 이동링크
  ATCH_FILE_ID: string // 파일아이디
  STRE_FILE_NM: string
  FILE_EXTSN: string // 확장자 종류
  FILE_CONTENT: string // 파일명
}

export interface DxpEventCategory {
  DOCID: string // id값
  EVENT_NM: string // 제목
  EVENT_CN: string // 내용
  ORIGNL_FILE_NM: string // 첨부파일명
  LINK_URL: string // 이동링크
  EVENT_BGNDE: string // 행사 시작일
  EVENT_ENDDE: string // 행사 종료일
  ATCH_FILE_ID: string // 파일아이디
  EVENT_CATEGORY: string // 이벤트 카테고리
  STRE_FILE_NM: string
  FILE_EXTSN: string // 파일 확장자
  FILE_CONTENT: string // 파일명
  STTUS: string // 상태
}

export interface DxpDtstry{
  DOCID: string // id값
  NTT_SJ: string // 제목
  NTT_CN: string // 내용
  BBS_NM: string // 게시판명
  LINK_URL: string // 이동링크
  ATCH_FILE_ID: string // 파일아이디
  ORIGNL_FILE_NM: string
  STRE_FILE_NM: string // 스토리명
  FILE_EXTSN: string // 파일 확장자
  FILE_CONTENT: string // 파일명
  FRST_REGIST_PNTTM: string // 등록일
  FRST_REGISTER_ID: string // 등록자
  RDCNT: string // 조회수
  PRODUCT_NM: string // 상품명
}

export interface DxpPrmtnMV{
  DOCID: string // id값
  NTT_SJ: string // 제목
  NTT_CN: string // 내용
  BBS_NM: string // 게시판명
  FILE_CONTENT: string // 첨부파일명
  LINK_URL: string // 이동링크
  ATCH_FILE_ID: string // 파일아이디
  ORIGNL_FILE_NM: string
  STRE_FILE_NM: string
  FILE_EXTSN: string // 파일 확장자
  FRST_REGIST_PNTTM: string // 등록일
  RDCNT: string //조회수
}

export interface LmsCos{
  OCOS_ID: string // id값
  COS_NM: string // 과정명
  COS_INTRO: string // 과정내용
}

export interface LmsLec{
  OLEC_ID: string // id값
  LEC_NM:string // 강의명
  LEC_SMM:string // 강의내용
}

export interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

export const mainKeyword = [
  {
    id: 0,
    keyword: [
      'AI융합프로젝트',
      '데이터바우처 지원사업',
      '혁신창업리그',
      '광주AI창업캠프',
      'AI융합프로젝트',
      '데이터바우처 지원사업',
      '혁신창업리그',
      '광주AI창업캠프',
      '혁신창업리그',
      '광주AI창업캠프',
    ],
  },
  {
    id: 1,
    keyword: [
      '실증장비',
      '장비사용 견적요청',
      '장비사용신청',
      '장비사용신청',
      '장비사용신청',
      '실증장비',
      '장비사용 견적요청',
      '장비사용신청',
      '장비사용신청',
      '장비사용신청',
    ],
  },
];

// 최신검색어 (최대 5개)
export const searchKeywordsNew = [
  '장비사용신청',
  '장비사용견적요청',
  '장비사용관리',
  '자원 할당 관리',
  '자주 묻는 질문',
];

// 연관 검색어
export const searchKeywordsRelation = [
  '장비사용신청',
  '장비사용견적요청',
  '장비사용관리',
  '장비안내',
  '통합관리 장비',
  '건강관리 키트 장비',
];

// 인기 검색어
export const searchKeywordsPopular = [
  'AI융합프로젝트',
  '데이터바우처 지원사업',
  '혁신창업리그',
  '광주AI창업캠프',
];

export const searchResultInfo = {
  keyword: ['장비', '글로벌'],
  total: 35,
};

export const filterKeywords1 = [
  { code: 'filter1-1', codeNm: '전체' },
  { code: 'filter1-2', codeNm: '제목' },
  { code: 'filter1-3', codeNm: '내용' },
];
export const filterKeywords2 = [
  { code: 'filter2-1', codeNm: '정확도순' },
  { code: 'filter2-2', codeNm: '최신순' },
];
export const filterKeywords3 = [
  { code: 'filter3-1', codeNm: '전체' },
  { code: 'filter3-2', codeNm: '오늘' },
  { code: 'filter3-3', codeNm: '한달' },
  { code: 'filter3-4', codeNm: '일년' },
];

export const searchResultData = [
  {
    cate: 'recruit',
    name: '모집 공고',
    result: [
      {
        id: '0',
        image: '/images/main/cont02_01.png',
        pblancNm:
          '2021년도 글로벌 AI 제품·서비스 고도화 장비 지원기업 모집공고 장비 지원기업 모집공고',
        recomendCl: ['사업화'],
        rmndrDay: 30,
        rceptPd: '2021-11-21 ~ 2021-12-11 18:00',
        pblancSttus: '모집중',
        link: '/',
      },
      {
        id: '1',
        image: '/images/main/cont02_02.png',
        pblancNm:
          '11 2021년도 글로벌 AI 제품·서비스 고도화 장비 지원기업 모집공고',
        recomendCl: ['사업화'],
        rmndrDay: 30,
        rceptPd: '2021-11-21 ~ 2021-12-11 18:00',
        pblancSttus: '모집중',
        link: '/',
      },
      {
        id: '2',
        image: '/images/main/cont02_03.png',
        pblancNm:
          '22 2021년도 글로벌 AI 제품·서비스 고도화 장비 지원기업 모집공고',
        recomendCl: ['사업화'],
        rmndrDay: 30,
        rceptPd: '2021-11-21 ~ 2021-12-11 18:00',
        pblancSttus: '모집중',
        link: '/',
      },
      {
        id: '3',
        image: '/images/main/cont02_01.png',
        pblancNm:
          '2021년도 글로벌 AI 제품·서비스 고도화 장비 지원기업 모집공고 333',
        recomendCl: ['사업화'],
        rmndrDay: 30,
        rceptPd: '2021-11-21 ~ 2021-12-11 18:00',
        pblancSttus: '모집중',
        link: '/',
      },
      {
        id: '4',
        image: '/images/main/cont02_02.png',
        pblancNm:
          '2021년도 글로벌 AI 제품·서비스 고도화 장비 지원기업 모집공고 444',
        recomendCl: ['사업화'],
        rmndrDay: 30,
        rceptPd: '2021-11-21 ~ 2021-12-11 18:00',
        pblancSttus: '모집중',
        link: '/',
      },
      {
        id: '5',
        image: '/images/main/cont02_03.png',
        pblancNm:
          '2021년도 글로벌 AI 제품·서비스 고도화 장비 지원기업 모집공고',
        recomendCl: ['사업화'],
        rmndrDay: 30,
        rceptPd: '2021-11-21 ~ 2021-12-11 18:00',
        pblancSttus: '모집중',
        link: '/',
      },
      {
        id: '6',
        image: '/images/main/cont02_01.png',
        pblancNm:
          '2021년도 글로벌 AI 제품·서비스 고도화 장비 지원기업 모집공고2021년도 글로벌 AI 제품·서비스 고도화 장비 지원기업 모집공고',
        recomendCl: ['사업화'],
        rmndrDay: 30,
        rceptPd: '2021-11-21 ~ 2021-12-11 18:00',
        pblancSttus: '모집중',
        link: '/',
      },
      {
        id: '7',
        image: '/images/main/cont02_02.png',
        pblancNm:
          '2021년도 글로벌 AI 제품·서비스 고도화 장비 지원기업 모집공고 772021년도 글로벌 AI 제품·서비스 고도화 장비 지원기업 모집공고',
        recomendCl: ['사업화'],
        rmndrDay: 30,
        rceptPd: '2021-11-21 ~ 2021-12-11 18:00',
        pblancSttus: '모집중',
        link: '/',
      },
      {
        id: '8',
        image: '/images/main/cont02_03.png',
        pblancNm:
          '2021년도 글로벌 AI 제품·서비스 고도화 장비 지원기업 모집공고 88',
        recomendCl: ['사업화'],
        rmndrDay: 30,
        rceptPd: '2021-11-21 ~ 2021-12-11 18:00',
        pblancSttus: '모집중',
        link: '/',
      },
      {
        id: '9',
        image: '/images/main/cont02_01.png',
        pblancNm:
          '99 2021년도 글로벌 AI 제품·서비스 고도화 장비 지원기업 모집공고',
        recomendCl: ['사업화'],
        rmndrDay: 30,
        rceptPd: '2021-11-21 ~ 2021-12-11 18:00',
        pblancSttus: '모집중',
        link: '/',
      },
      {
        id: '10',
        image: '/images/main/cont02_02.png',
        pblancNm:
          '2021년도 글로벌 AI 제품·서비스 고도화 장비 지원기업 모집공고',
        recomendCl: ['사업화'],
        rmndrDay: 30,
        rceptPd: '2021-11-21 ~ 2021-12-11 18:00',
        pblancSttus: '모집중',
        link: '/',
      },
      {
        id: '11',
        image: '/images/main/cont02_03.png',
        pblancNm:
          '11 2021년도 글로벌 AI 제품·서비스 고도화 장비 지원기업 모집공고',
        recomendCl: ['사업화'],
        rmndrDay: 30,
        rceptPd: '2021-11-21 ~ 2021-12-11 18:00',
        pblancSttus: '모집중',
        link: '/',
      },
    ],
  },
  {
    cate: 'event',
    name: '행사/이벤트',
    result: [
      {
        eventNm:
          '장비기술혁신형 중소기업에 날개를 달다! 이노비즈 인증 기술혁신형 중소기업에 날개를 달다!',
        eventId: '0',
        eventImg: '/images/main/cont02_01.png',
        eventLink: '/',
        fmtBeginDay: '2021-11-21',
        fmtEndDay: '2021-12-11 18:00',
        readCnt: '192',
        fmtCreatedDay: '2021-11-21',
      },
      {
        eventNm:
          '기술혁신형 중소기업에 날개를 달다! 이노비즈 인증 기술혁신형 중소기업에 날개를 달다!기술혁신형 중소기업에 날개를 달다! 이노비즈 인증 기술혁신형 중소기업에 날개를 달다!',
        eventId: '1',
        eventImg: '/images/main/cont02_02.png',
        eventLink: '/',
        fmtBeginDay: '2021-11-21',
        fmtEndDay: '2021-12-11 18:00',
        readCnt: '192',
        fmtCreatedDay: '2021-11-21',
      },
      {
        eventNm:
          '기술혁신형 중소기업에 날개를 달다! 이노비즈 인증 기술혁신형 중소기업에 날개를 달다!',
        eventId: '2',
        eventImg: '/images/main/cont02_03.png',
        eventLink: '/',
        fmtBeginDay: '2021-11-21',
        fmtEndDay: '2021-12-11 18:00',
        readCnt: '192',
        fmtCreatedDay: '2021-11-21',
      },
    ],
  },
  {
    cate: 'qna',
    name: '자주묻는 질문',
    result: [
      {
        categoryCd: '지원/신청',
        title: '장비신청은 어떻게 하는 건가요?',
        link: '/',
      },
      {
        categoryCd: '장비/시설',
        title: '시설 예약과 장비 사용 신청 횟수 제한이 각각인가요?',
        link: '/',
      },
      {
        categoryCd: '가입/ 변경',
        title:
          '장비견적신청 하려면 가입을 해야지 할 수 있나요?장비견적신청 하려면 가입을 해야지 할 수 있나요?장비견적신청 하려면 가입을 해야지 할 수 있나요?장비견적신청 하려면 가입을 해야지 할 수 있나요?장비견적신청 하려면 가입을 해야지 할 수 있나요?',
        link: '/',
      },
    ],
  },
  {
    cate: 'notice',
    name: '공지사항',
    result: [
      {
        title:
          'AI 기반의 헬스케어 웨어러블 기기 관련한 업계 소식AI 기반의 헬스케어 웨어러블 기기 관련한 업계 소식AI 기반의 헬스케어 웨어러블 기기 관련한 업계 소식AI 기반의 헬스케어 웨어러블 기기 관련한 업계 소식AI 기반의 헬스케어 웨어러블 기기 관련한 업계 소식',
        article:
          '인공지능산업융합사업단에서는 인공지능 중심 산업융합 집적단지 조성사업의 일환으로 AI 직무능력 고도화 및 문제해결 능력을 갖춘 AI 실무인재 육성을 인공지능산업융합사업단에서는 인공지능 중심 산업융합 집적단지 조성사업의 일환으로 AI 직무능력 고도화 및 문제해결 능력을 갖춘 AI 실무인재 내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용인공지능산업융합사업단에서는 인공지능 중심 산업융합 집적단지 조성사업의 일환으로 AI 직무능력 고도화 및 문제해결 능력을 갖춘 AI 실무인재 육성을 인공지능산업융합사업단에서는 인공지능 중심 산업융합 집적단지 조성사업의 일환으로 AI 직무능력 고도화 및 문제해결 능력을 갖춘 AI 실무인재 내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용',
        date: '2021-12-02',
        readCnt: 192,
        write: 'Bluelemon',
        link: '/',
      },
      {
        title: 'OOOO 프로젝트에 함께 할 소프트엔지니어를 찾고 있습니다',
        article:
          '인공지능산업융합사업단에서는 인공지능 중심 산업융합 집적단지 조성사업의 일환으로 AI 직무능력 고도화 및 문제해결 능력을 갖춘 AI 실무인재 육성을 인공지능산업융합사업단에서는 인공지능 중심 산업융합 집적단지 조성사업의 일환으로 AI 직무능력 고도화 및 문제해결 능력을 갖춘 AI 실무인재 내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용인공지능산업융합사업단에서는 인공지능 중심 산업융합 집적단지 조성사업의 일환으로 AI 직무능력 고도화 및 문제해결 능력을 갖춘 AI 실무인재 육성을 인공지능산업융합사업단에서는 인공지능 중심 산업융합 집적단지 조성사업의 일환으로 AI 직무능력 고도화 및 문제해결 능력을 갖춘 AI 실무인재 내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용',
        date: '2021-12-02',
        readCnt: 192,
        write: 'Bluelemon',
        link: '/',
      },
      {
        title: '2021년도 글로벌 AI 제품·서비스고도화 지원기업 모집공고',
        article:
          '인공지능산업융합사업단에서는 인공지능 중심 산업융합 집적단지 조성사업의 일환으로 AI 직무능력 고도화 및 문제해결 능력을 갖춘 AI 실무인재 육성을 인공지능산업융합사업단에서는 인공지능 중심 산업융합 집적단지 조성사업의 일환으로 AI 직무능력 고도화 및 문제해결 능력을 갖춘 AI 실무인재 내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용인공지능산업융합사업단에서는 인공지능 중심 산업융합 집적단지 조성사업의 일환으로 AI 직무능력 고도화 및 문제해결 능력을 갖춘 AI 실무인재 육성을 인공지능산업융합사업단에서는 인공지능 중심 산업융합 집적단지 조성사업의 일환으로 AI 직무능력 고도화 및 문제해결 능력을 갖춘 AI 실무인재 내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용',
        date: '2021-12-02',
        readCnt: 192,
        write: 'Bluelemon',
        link: '/',
      },
    ],
  },
];




// export const testSearchRestult: WisenutResponese<SearchResult> = {
//   result: {
//     totalCnt: 10,
//     USP_PBLANC: {
//       cnt: 1,
//       collResult: [{
//         IS_NEW: "N",
//         PBLANC_DAY: "20221110",
//         RECOMEND_CL: "멘토링/컨설팅,창업교육",
//         FILE_CONTENT: "",
//         DOCID: "pblanc-432e98ace209477d96a4e5a8d0723aff",
//         RDCNT: "12",
//         PBLANC_STTUS: "접수중",
//         RCEPT_PD: "2022-11-10 ~ 2022-11-26 18:00",
//         PBLANC_SUMRY: "통합테스트 교육사업 공고입니다.",
//         PBLANC_STTUS_CD: "ING",
//         RCEPT_ENDDE: "20221126",
//         ATTACHMENT_GROUP_ID: "",
//         FILE_NM: "",
//         ATTACHMENT_ID: "",
//         RMNDR_DAY: "12",
//         PBLANC_NM: "통합테스트 <!HS>교육<!HE>사업 공고"
//       }]
//     },
//     USP_NOTICE: {
//       cnt: 2,
//       collResult: [{
//         DOCID: "article-2497bbcdaf8a4430ad429627c9c90a22",
//         BBS_NM: "공지사항",
//         SJ_NM: "<!HS>공지<!HE>사항",
//         FILE_NM: "",
//         FILE_EXTSN: "",
//         BBSCTT_ID: "article-2497bbcdaf8a4430ad429627c9c90a22",
//         BBSCTT_CN: "<!HS>공지<!HE>사항 <!HS>공지<!HE>사항입니다.",
//         FILE_CONTENT: "",
//         ATCHMNFL_ID: "",
//         LINK_URL: "/Notice/Announcement/article-2497bbcdaf8a4430ad429627c9c90a22",
//         CREATR_NM: "김효현(hhkim)",
//         ATCHMNFL_GROUP_ID: ""
//       }, {
//         DOCID: "article-599500a83b9b4399a11879cbcce51a51",
//         BBS_NM: "공지사항",
//         SJ_NM: "임시 <!HS>공지<!HE>사항",
//         FILE_NM: "test.xlsx",
//         FILE_EXTSN: "xlsx",
//         BBSCTT_ID: "article-599500a83b9b4399a11879cbcce51a51",
//         BBSCTT_CN: "임시 <!HS>공지<!HE>사항 임시 <!HS>공지<!HE>사항입니다.",
//         FILE_CONTENT: "..SHEET:1\ntest\n..SHEET:2\n..SHEET:3\n||",
//         ATCHMNFL_ID: "att-354c082ca32e422dbc99a83ab1a2b51c",
//         LINK_URL: "/Notice/Announcement/article-599500a83b9b4399a11879cbcce51a51",
//         CREATR_NM: "김효현(hhkim)",
//         ATCHMNFL_GROUP_ID: "attg-9c0692da4d364f40ada84be7a9a0cc8d"
//       }]
//     },
//     TSP_NOTICE: {
//       cnt: 2,
//       collResult: [{
//         DOCID: "article-18509394e0354695856d7f1a28641f2f",
//         BBS_NM: "공지사항",
//         SJ_NM: "<!HS>공지<!HE>사항 제목",
//         FILE_NM: "",
//         FILE_EXTSN: "",
//         BBSCTT_ID: "article-18509394e0354695856d7f1a28641f2f",
//         BBSCTT_CN: "상세 <!HS>공지<!HE>사항상세",
//         FILE_CONTENT: "",
//         ATCHMNFL_ID: "",
//         LINK_URL: "/tsp//About/Notice/article-18509394e0354695856d7f1a28641f2f",
//         CREATR_NM: "배정주(jjbae)",
//         ATCHMNFL_GROUP_ID: ""
//       }, {
//         DOCID: "article-2f5b149cd533473d8909670380d3bd22",
//         BBS_NM: "공지사항",
//         SJ_NM: "<!HS>공지<!HE>사항",
//         FILE_NM: "",
//         FILE_EXTSN: "",
//         BBSCTT_ID: "article-2f5b149cd533473d8909670380d3bd22",
//         BBSCTT_CN: "제목 내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용\n내용 내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용내용",
//         FILE_CONTENT: "",
//         ATCHMNFL_ID: "",
//         LINK_URL: "/tsp//About/Notice/article-2f5b149cd533473d8909670380d3bd22",
//         CREATR_NM: "배정주(jjbae)",
//         ATCHMNFL_GROUP_ID: ""
//       }]
//     },
//     SAZ_NOTICE: {
//       cnt: 1,
//       collResult: [{
//         BBS_NM: "공지사항",
//         FILE_EXTSN: "",
//         BBSCTT_CN: "<p><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span><span style=\"font-size: 32px;\">﻿고정공지 사항 <!HS>등록<!HE> 테스트&nbsp;</span>&nbsp;</p>",
//         FILE_CONTENT: "",
//         LINK_URL: "/saz/component/bbs/notice/detail.do?articleId=BbsArticle06407ca5ce354559806449aff49f9918",
//         URL: "/saz/component/bbs/notice/index.do",
//         BBS_ID: "notice",
//         DOCID: "BbsArticle06407ca5ce354559806449aff49f9918",
//         SJ_NM: "2022.10.25 공지사항 - 공지 <!HS>등록<!HE>",
//         FILE_NM: "",
//         BBSCTT_ID: "BbsArticle06407ca5ce354559806449aff49f9918",
//         ATCHMNFL_ID: "",
//         CREATR_NM: "user_patrick",
//         ATCHMNFL_GROUP_ID: ""
//       }]
//     },
//     USP_QESTN: {
//       cnt: 4,
//       collResult: [{
//         DOCID: "article-185915b0ab11410cae556dfde1be0907",
//         BBS_NM: "자주묻는질문",
//         SJ_NM: "<!HS>첨부파일<!HE> 테스트",
//         FILE_NM: "",
//         FILE_EXTSN: "",
//         BBSCTT_ID: "article-185915b0ab11410cae556dfde1be0907",
//         BBSCTT_CN: "<!HS>첨부파일<!HE>",
//         FILE_CONTENT: "",
//         ATCHMNFL_ID: "",
//         LINK_URL: "/SupportForUse/FrequentlyAskedQuestions/article-185915b0ab11410cae556dfde1be0907",
//         CREATR_NM: "윤여택(ytyoon)",
//         ATCHMNFL_GROUP_ID: "",
//         CATEGORY_NM: '가입/변경'
//       },
//       {
//         DOCID: "article-185915b0ab11410cae556dfde1be0907",
//         BBS_NM: "자주묻는질문",
//         SJ_NM: "<!HS>첨부파일<!HE> 테스트",
//         FILE_NM: "",
//         FILE_EXTSN: "",
//         BBSCTT_ID: "article-185915b0ab11410cae556dfde1be0907",
//         BBSCTT_CN: "<!HS>첨부파일<!HE>",
//         FILE_CONTENT: "",
//         ATCHMNFL_ID: "",
//         LINK_URL: "/SupportForUse/FrequentlyAskedQuestions/article-185915b0ab11410cae556dfde1be0907",
//         CREATR_NM: "윤여택(ytyoon)",
//         ATCHMNFL_GROUP_ID: "",
//         CATEGORY_NM: '시설/운영'
//       },
//       {
//         DOCID: "article-185915b0ab11410cae556dfde1be0907",
//         BBS_NM: "자주묻는질문",
//         SJ_NM: "<!HS>첨부파일<!HE> 테스트",
//         FILE_NM: "",
//         FILE_EXTSN: "",
//         BBSCTT_ID: "article-185915b0ab11410cae556dfde1be0907",
//         BBSCTT_CN: "<!HS>첨부파일<!HE>",
//         FILE_CONTENT: "",
//         ATCHMNFL_ID: "",
//         LINK_URL: "/SupportForUse/FrequentlyAskedQuestions/article-185915b0ab11410cae556dfde1be0907",
//         CREATR_NM: "윤여택(ytyoon)",
//         ATCHMNFL_GROUP_ID: "",
//         CATEGORY_NM: '지원/신청'
//       },
//       {
//         DOCID: "article-185915b0ab11410cae556dfde1be0907",
//         BBS_NM: "자주묻는질문",
//         SJ_NM: "<!HS>첨부파일<!HE> 테스트",
//         FILE_NM: "",
//         FILE_EXTSN: "",
//         BBSCTT_ID: "article-185915b0ab11410cae556dfde1be0907",
//         BBSCTT_CN: "<!HS>첨부파일<!HE>",
//         FILE_CONTENT: "",
//         ATCHMNFL_ID: "",
//         LINK_URL: "/SupportForUse/FrequentlyAskedQuestions/article-185915b0ab11410cae556dfde1be0907",
//         CREATR_NM: "윤여택(ytyoon)",
//         ATCHMNFL_GROUP_ID: "",
//         CATEGORY_NM: '가입/변경'
//       },
//     ]
//     },
//     TSP_QESTN: {
//       cnt: 2,
//       collResult: [{
//         DOCID: "article-5e44a3e0eb2447679c04921666633929",
//         BBS_NM: "자주묻는질문",
//         SJ_NM: "<!HS>첨부파일<!HE>",
//         FILE_NM: "",
//         FILE_EXTSN: "",
//         BBSCTT_ID: "article-5e44a3e0eb2447679c04921666633929",
//         BBSCTT_CN: "<!HS>첨부파일<!HE>",
//         FILE_CONTENT: "",
//         ATCHMNFL_ID: "",
//         LINK_URL: "/tsp//About/FAQ/article-5e44a3e0eb2447679c04921666633929",
//         CREATR_NM: "윤여택(ytyoon)",
//         ATCHMNFL_GROUP_ID: "",
//         CATEGORY_NM: '가입/변경'
//       }, {
//         DOCID: "article-c2213127541547bbabaf68ede237bf6f",
//         BBS_NM: "자주묻는질문",
//         SJ_NM: "<!HS>첨부파일<!HE>",
//         FILE_NM: "",
//         FILE_EXTSN: "",
//         BBSCTT_ID: "article-c2213127541547bbabaf68ede237bf6f",
//         BBSCTT_CN: "<!HS>첨부파일<!HE>",
//         FILE_CONTENT: "",
//         ATCHMNFL_ID: "",
//         LINK_URL: "/tsp//About/FAQ/article-c2213127541547bbabaf68ede237bf6f",
//         CREATR_NM: "윤여택(ytyoon)",
//         ATCHMNFL_GROUP_ID: "",
//         CATEGORY_NM: '지원/신청'
//       }]
//     },
//     SAZ_QESTN: {
//       cnt: 1,
//       collResult: [{
//         BBS_NM: "FAQ",
//         FILE_EXTSN: "",
//         BBSCTT_CN: "<p>안심구역 관리자가 어드민에서 직접 등록해 드릴 수 있습니다.\r\n고객센터로 문의해 주시기 바랍니다.</p><p>안심구역 관리자가 어드민에서 직접 등록해 드릴 수 있습니다. 고객센터로 문의해 주시기 바랍니다.<br></p>",
//         FILE_CONTENT: "",
//         LINK_URL: "/saz/component/bbs/faq/detail.do?articleId=BbsArticled7d5350b3e584f228ed418e9a9a0764e",
//         URL: "/saz/component/bbs/faq/index.do",
//         BBS_ID: "faq",
//         DOCID: "BbsArticled7d5350b3e584f228ed418e9a9a0764e",
//         SJ_NM: "반입 자료 용량이 너무 커서 <!HS>파일<!HE> <!HS>첨부<!HE>가 어렵습니다.  어떻게 해야 하나요?",
//         FILE_NM: "",
//         BBSCTT_ID: "BbsArticled7d5350b3e584f228ed418e9a9a0764e",
//         ATCHMNFL_ID: "",
//         CREATR_NM: "user_patrick",
//         ATCHMNFL_GROUP_ID: "",
//         CATEGORY_NM: '안심구역 이용신청'
//       }]
//     },
//     USP_EVENT: {
//       cnt: 2,
//       collResult: [{
//         DOCID: "event-49be312852064e029f3fa01f24f4a718",
//         FILE_NM: "AICA-AISP-USP-단위테스트케이스로그_UI-USP-ADM-0740101.xlsx|AICA-AISP-USP-단위테스트케이스로그_UI-USP-ADM-0700101.xlsx",
//         FILE_EXTSN: "xlsx|xlsx",
//         BBSCTT_CN: "<!HS>이벤트<!HE> 안내됩니다.\n소제목을 주제로 상세한 내용이 출력되어야합니다.,ㅁㄴㅇㄻㄴㅇㄹ,ㅁㄴㅇㄻㄴㅇㄻㄴㅇㄹ",
//         EVENT_ID: "event-49be312852064e029f3fa01f24f4a718",
//         FILE_CONTENT: "",
//         ATCHMNFL_ID: "att-b6de7419cf624d04935b9218d0472232|att-f4011607ca4e49fc879defec5c2f5d00",
//         LINK_URL: "/EventNews/HonsaEvent/event-49be312852064e029f3fa01f24f4a718",
//         EVENT_NM: "<!HS>이벤트<!HE> 테스트011",
//         ATCHMNFL_GROUP_ID: "attg-95e5c41396b64f83bc4b00f912bca286",
//         BGNDE: "2022-10-01",
//         ENDDE: "2022-11-31",
//         RDCNT: "330",
//         CREAT_DT: "2022-10-01"
//       }, {
//         DOCID: "event-1dcf162669cd45abaf8dac084a616f6a",
//         FILE_NM: "Word 서식 002.docx",
//         FILE_EXTSN: "docx",
//         BBSCTT_CN: "<!HS>이벤트<!HE> 안내됩니다.\n소제목을 주제로 상세한 내용이 출력되어야합니다.,소제목02을 주제로 상세한 내용이 출력되어야합니다.",
//         EVENT_ID: "event-1dcf162669cd45abaf8dac084a616f6a",
//         FILE_CONTENT: "",
//         ATCHMNFL_ID: "att-f65052c297754903a2a0163ba5fa1f6c",
//         LINK_URL: "/EventNews/HonsaEvent/event-1dcf162669cd45abaf8dac084a616f6a",
//         EVENT_NM: "<!HS>이벤트<!HE> 테스트002",
//         ATCHMNFL_GROUP_ID: "attg-78089796bfe647d09ec00e12a49c5418",
//         BGNDE: "2022-10-01",
//         ENDDE: "2022-11-31",
//         RDCNT: "330",
//         CREAT_DT: "2022-10-01"
//       }]
//     },
//     DXP_DATAPRODUCT: {
//       cnt: 2,
//       collResult: [{
//         SBSCRB_CTRGY_NM: "",
//         DSCNT_PC: "0",
//         DTLCLFC_NM: "",
//         PRODUCT_DC: "설명",
//         PRODUCT_NM: "상품기본정보 <!HS>등록<!HE> <!HS>등록<!HE> <!HS>등록<!HE>",
//         PRODUCT_ID: "productid0000000341",
//         LINK_URL: "/dxp/data/productDtl/productid0000000341",
//         DOCID: "productid0000000341",
//         LCLAS_NM: "자동차",
//         PC_TY: "01",
//         SJ: "",
//         MLSFC_NM: "자율주행환경인지",
//         KWRD: "",
//         SCLAS_NM: "",
//         RDCNT: '10',
//         STAR_SCORE: '4.5',
//         CP_NM: '문화체육관광부'
//       }, {
//         SBSCRB_CTRGY_NM: "",
//         DSCNT_PC: "0",
//         DTLCLFC_NM: "",
//         PRODUCT_DC: "cp 상품 <!HS>등록<!HE>합니다.....",
//         PRODUCT_NM: "cp 상품 <!HS>등록<!HE>",
//         PRODUCT_ID: "PRD_0000000000000421",
//         LINK_URL: "/dxp/data/productDtl/PRD_0000000000000421",
//         DOCID: "PRD_0000000000000421",
//         LCLAS_NM: "문화콘텐츠",
//         PC_TY: "02",
//         SJ: "",
//         MLSFC_NM: "언어",
//         KWRD: "",
//         SCLAS_NM: "말뭉치",
//         RDCNT: '10',
//         STAR_SCORE: '3',
//         CP_NM: '문화체육관광부'
//       }]
//     },
//     DXP_NOTICE: {
//       cnt: 4,
//       collResult: [{
//         DOCID: "NOTICE_662",
//         BBS_NM: "공지 게시판",
//         NOTICE_CATEGORY: "자료",
//         ATCH_FILE_ID: "",
//         ORIGNL_FILE_NM: "",
//         STRE_FILE_NM: "",
//         FILE_EXTSN: "",
//         NTT_SJ: "신규 <!HS>등록<!HE> 확인",
//         FILE_CONTENT: "",
//         LINK_URL: "/dxp/community/noticeDtl/662",
//         NTT_CN: "신규 <!HS>등록<!HE> 확인",
//         FRST_REGISTER_ID: 'yhkim',
//         RDCNT: '10',
//         FRST_REGIST_PNTTM: '2022-11-28',
//       }, {
//         DOCID: "NOTICE_1124",
//         BBS_NM: "공지 게시판",
//         NOTICE_CATEGORY: "이벤트",
//         ATCH_FILE_ID: "FILE_000000000002483",
//         ORIGNL_FILE_NM: "기계.jpg",
//         STRE_FILE_NM: "noticeAtchFile_202210210150222720",
//         FILE_EXTSN: "jpg",
//         NTT_SJ: "2022.10.21 공지사항 <!HS>등록<!HE> 테스트",
//         FILE_CONTENT: "FILE_000000000002483",
//         LINK_URL: "/dxp/community/noticeDtl/1124",
//         NTT_CN: "<p>내용이 출력됩니다.&nbsp;</p><p>&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>&nbsp;</p>",
//         FRST_REGISTER_ID: 'yhkim',
//         RDCNT: '10',
//         FRST_REGIST_PNTTM: '2022-11-28',
//       }, {
//         DOCID: "NOTICE_1126",
//         BBS_NM: "공지 게시판",
//         NOTICE_CATEGORY: "일반",
//         ATCH_FILE_ID: "FILE_000000000002485",
//         ORIGNL_FILE_NM: "자동차.jpg",
//         STRE_FILE_NM: "noticeAtchFile_202210210158253860",
//         FILE_EXTSN: "jpg",
//         NTT_SJ: "2022.10.21 공지사항 <!HS>등록<!HE> 테스트",
//         FILE_CONTENT: "FILE_000000000002485",
//         LINK_URL: "/dxp/community/noticeDtl/1126",
//         NTT_CN: "<p>내용이 출력됩니다.&nbsp;</p>",
//         FRST_REGISTER_ID: 'yhkim1',
//         RDCNT: '25',
//         FRST_REGIST_PNTTM: '2022-11-20',
//       }, {
//         DOCID: "NOTICE_1284",
//         BBS_NM: "공지 게시판",
//         NOTICE_CATEGORY: "보도자료",
//         ATCH_FILE_ID: "",
//         ORIGNL_FILE_NM: "",
//         STRE_FILE_NM: "",
//         FILE_EXTSN: "",
//         NTT_SJ: "공지사항-이벤트 <!HS>등록<!HE>입니다 -> 보도자료로 수정합니다.",
//         FILE_CONTENT: "",
//         LINK_URL: "/dxp/community/noticeDtl/1284",
//         NTT_CN: "<p>공지사항 - 이벤트 입력 테스트 중입니다.</p><p>&nbsp;</p><p>공지사항 - 이벤트에서 보도자료로 주정 합니다.</p>",
//
//         FRST_REGISTER_ID: 'yhkim2',
//         RDCNT: '33',
//         FRST_REGIST_PNTTM: '2022-11-15',
//       }]
//     },
//     DXP_DATASET: {
//       cnt: 2,
//       collResult: [{
//         COLCT_PLACE_NM: "NH네트웍스",
//         DTLCLFC_NM: "",
//         COLCT_EQPMN_NM: "1234567",
//         COLCT_INSTT_NM: "1234567",
//         LINK_URL: "/dxp/data/datasetDtl/ac108bd8-7b87-4b3c-9467-556872d89b25",
//         PROVD_INSTT_NM: "1234567",
//         DOCID: "ac108bd8-7b87-4b3c-9467-556872d89b25",
//         LCLAS_NM: "",
//         DSET_NM: "NH네트웍스 소비전력/발전량 <!HS>데이터<!HE>수집 센서 <!HS>데이터<!HE>셋",
//         DSET_DC: "NH네트웍스 건물의 소비전력/발전량 <!HS>데이터<!HE>를 수집하는 센서에서 취득한 <!HS>데이터<!HE>임",
//         MLSFC_NM: "",
//         KWRD: "소비전력, 발전량, 센서, NH네트웍스",
//         SCLAS_NM: "",
//         FRST_REGIST_PNTTM: '2022-11-15',
//       }, {
//         COLCT_PLACE_NM: "장덕도서관",
//         DTLCLFC_NM: "",
//         COLCT_EQPMN_NM: "1234567",
//         COLCT_INSTT_NM: "1234567",
//         LINK_URL: "/dxp/data/datasetDtl/f558694c-a6b5-400c-8f94-d49c09d9492e",
//         PROVD_INSTT_NM: "1234567",
//         DOCID: "f558694c-a6b5-400c-8f94-d49c09d9492e",
//         LCLAS_NM: "",
//         DSET_NM: "장덕도서관 소비전력/발전량 <!HS>데이터<!HE>수집 센서 <!HS>데이터<!HE>셋",
//         DSET_DC: "장덕도서관 건물의 소비전력/발전량 <!HS>데이터<!HE>를 수집하는 센서에서 취득한 <!HS>데이터<!HE>임",
//         MLSFC_NM: "",
//         KWRD: "소비전력, 발전량, 센서, 장덕도서관",
//         SCLAS_NM: "",
//         FRST_REGIST_PNTTM: '2022-11-15',
//       }]
//     },
//     DXP_CNTSTMNG: {
//       cnt: 3,
//       collResult: [{
//         DOCID: "CNTSTMNG_1062",
//         BBS_NM: "공모전 결과",
//         ATCH_FILE_ID: "FILE_000000000002342",
//         ORIGNL_FILE_NM: "sample_1280x720.mp4|캡처.PNG|통합 문서1.xlsx",
//         STRE_FILE_NM: "ContestMng_202210190828420580|ContestMng_202210190828421111|ContestMng_202210190828421162",
//         FILE_EXTSN: "mp4|PNG|xlsx",
//         NTT_SJ: "서버에서 <!HS>등록<!HE>",
//         FILE_CONTENT: "FILE_000000000002342",
//         LINK_URL: "/dxp/datause/contestResultDtl/1062",
//         NTT_CN: "<p>&nbsp;</p><p>설명글 이미지 삽입</p><p><img src=\"/dxp/cmmn/getImage/FILE_000000000002341/0\" title=\"캡처.PNG\">&nbsp;</p>",
//         CONTEST_BGNDE: "2022-10-04",
//         CONTEST_ENDDE: "2022-12-04",
//         RDCNT: '10'
//       }, {
//         DOCID: "CNTSTMNG_1106",
//         BBS_NM: "공모전 결과",
//         ATCH_FILE_ID: "FILE_000000000002434",
//         ORIGNL_FILE_NM: "test동영상.mp4|기계.jpg|기계.jpg",
//         STRE_FILE_NM: "ContestMng_202210210921149480|ContestMng_202210210921149541|ContestMng_202210210921149582",
//         FILE_EXTSN: "mp4|jpg|jpg",
//         NTT_SJ: "2022.10.21 공모전 자료 <!HS>등록<!HE> 테스트2",
//         FILE_CONTENT: "FILE_000000000002434",
//         LINK_URL: "/dxp/datause/contestResultDtl/1106",
//         NTT_CN: "<p>내용이 출력됩니다.&nbsp;</p>",
//         CONTEST_BGNDE: "2022-10-04",
//         CONTEST_ENDDE: "2022-12-04",
//         RDCNT: '10'
//       }, {
//         DOCID: "CNTSTMNG_1104",
//         BBS_NM: "공모전 결과",
//         ATCH_FILE_ID: "FILE_000000000002433",
//         ORIGNL_FILE_NM: "test동영상.mp4|자동차2.jpg|test데이터.docx",
//         STRE_FILE_NM: "ContestMng_202210210918412500|ContestMng_202210210918412571|ContestMng_202210210918412642",
//         FILE_EXTSN: "mp4|jpg|docx",
//         NTT_SJ: "2022.10.21 공모전 자료 <!HS>등록<!HE> 테스트",
//         FILE_CONTENT: "FILE_000000000002433",
//         LINK_URL: "/dxp/datause/contestResultDtl/1104",
//         NTT_CN: "<p>내용이 출력됩니다.&nbsp;&nbsp;</p><p>&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p>",
//         CONTEST_BGNDE: "2022-10-04",
//         CONTEST_ENDDE: "2022-12-04",
//         RDCNT: '10'
//       }]
//     },
//     DXP_FAQ: {
//       cnt: 2,
//       collResult: [{
//         DOCID: "FAQ_1272",
//         BBS_NM: "FAQ 게시판",
//         ATCH_FILE_ID: "",
//         ORIGNL_FILE_NM: "",
//         STRE_FILE_NM: "",
//         FAQ_CATEGORY: "기타",
//         FILE_EXTSN: "",
//         NTT_SJ: "faq <!HS>등록<!HE><!HS>등록<!HE> 확인확인 테스트",
//         FILE_CONTENT: "",
//         LINK_URL: "/dxp/community/faqDtl/1272",
//         NTT_CN: "faq <!HS>등록<!HE>"
//       }, {
//         DOCID: "FAQ_1286",
//         BBS_NM: "FAQ 게시판",
//         ATCH_FILE_ID: "",
//         ORIGNL_FILE_NM: "",
//         STRE_FILE_NM: "",
//         FAQ_CATEGORY: "주문/결제",
//         FILE_EXTSN: "",
//         NTT_SJ: "FAQ 주문/결제 <!HS>등록<!HE>테스트입니다.",
//         FILE_CONTENT: "",
//         LINK_URL: "/dxp/community/faqDtl/1286",
//         NTT_CN: "<p>FAQ 주문/결제 <!HS>등록<!HE> 테스트 입니다.</p><p>수정 확인입니다.</p><p>개발 서버 테스트입니다.</p>"
//       }]
//     },
//     DXP_EVENTCATEGORY: {
//       cnt: 2,
//       collResult: [{
//         DOCID: "null00000000000000000311",
//         EVENT_CATEGORY: "기타",
//         EVENT_ENDDE: "2022-12-31",
//         ATCH_FILE_ID: "FILE_000000000000801",
//         ORIGNL_FILE_NM: "images.png|mark-43913_1280.png|test-13394_640.jpg",
//         STRE_FILE_NM: "eventAtchFile_202205270941537930.png|eventAtchFile_202205270941537941.png|eventAtchFile_202205270941537942.jpg",
//         FILE_EXTSN: "C:/egovframework/upload/|C:/egovframework/upload/|C:/egovframework/upload/",
//         EVENT_CN: "<!HS>첨부파일<!HE> 테스트",
//         FILE_CONTENT: "FILE_000000000000801",
//         EVENT_BGNDE: "2022-01-01",
//         LINK_URL: "/dxp/community/eventDtl/null00000000000000000311",
//         EVENT_NM: "<!HS>첨부파일<!HE> 테스트",
//         STTUS: '접수중'
//       }, {
//         DOCID: "null00000000000000000781",
//         EVENT_CATEGORY: "발표회",
//         EVENT_ENDDE: "2022-12-31",
//         ATCH_FILE_ID: "FILE_000000000001701",
//         ORIGNL_FILE_NM: "test-13394_640.jpg|23569861-ìí-ì§-ë¹¨ê°ì-ë¼ì´ë-ì¤í¬í.jpg|캡처 (2).PNG",
//         STRE_FILE_NM: "eventAtchFile_202208100612216813|eventAtchFile_202208161147067021|eventAtchFile_202210200127551730",
//         FILE_EXTSN: "C:/egovframework/upload/|C:/egovframework/upload/|C:/egovframework/upload/",
//         EVENT_CN: "<p><!HS>첨부파일<!HE> 등록  수정 확인</p><p>&nbsp;</p><p>ㅇㅇ</p>",
//         FILE_CONTENT: "FILE_000000000001701",
//         EVENT_BGNDE: "2022-01-01",
//         LINK_URL: "/dxp/community/eventDtl/null00000000000000000781",
//         EVENT_NM: "<!HS>첨부파일<!HE> 등록  수정 확인",
//         STTUS: '접수마감'
//       }]
//     },
//     DXP_DTSTRY: {
//       cnt: 3,
//       collResult: [{
//         DOCID: "DTSTRY_911",
//         BBS_NM: "데이터 활용 스토리",
//         ATCH_FILE_ID: "",
//         ORIGNL_FILE_NM: "",
//         STRE_FILE_NM: "",
//         FILE_EXTSN: "",
//         NTT_SJ: "내용 <!HS>등록<!HE> 테스트",
//         FILE_CONTENT: "",
//         LINK_URL: "/dxp/datause/useStoryDtl/911",
//         NTT_CN: "<p>ë±ë¡ íì¤í¸ìëë¤</p><p>&nbsp;</p><p>ìì  ê²°ê³¼ íì¸</p><p>&nbsp;</p><p>ãããããããããããããã</p>",
//         FRST_REGIST_PNTTM: '2022-11-28',
//         FRST_REGISTER_ID: 'yhkim',
//         RDCNT: '10',
//         PRODUCT_NM: '상품명'
//       }, {
//         DOCID: "DTSTRY_1091",
//         BBS_NM: "데이터 활용 스토리",
//         ATCH_FILE_ID: "FILE_000000000002398",
//         ORIGNL_FILE_NM: "test데이터.docx",
//         STRE_FILE_NM: "DataStory_202210200544130840",
//         FILE_EXTSN: "docx",
//         NTT_SJ: "10.20  데이터 활용 스토리 <!HS>등록<!HE> /상세/수정 테스트",
//         FILE_CONTENT: "FILE_000000000002398",
//         LINK_URL: "/dxp/datause/useStoryDtl/1091",
//         NTT_CN: "<p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p><p>&nbsp;</p><p>내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;&nbsp;</p>",
//         FRST_REGIST_PNTTM: '2022-11-28',
//         FRST_REGISTER_ID: 'yhkim',
//         RDCNT: '10',
//         PRODUCT_NM: '상품명'
//       }, {
//         DOCID: "DTSTRY_1522",
//         BBS_NM: "데이터 활용 스토리",
//         ATCH_FILE_ID: "FILE_000000000003581",
//         ORIGNL_FILE_NM: "기계.jpg",
//         STRE_FILE_NM: "DataStory_202211030344446110",
//         FILE_EXTSN: "jpg",
//         NTT_SJ: "2022.11.03 데이터 활용 스토리 <!HS>등록<!HE>",
//         FILE_CONTENT: "FILE_000000000003581",
//         LINK_URL: "/dxp/datause/useStoryDtl/1522",
//         NTT_CN: "<p><span style=\"font-size: 36pt;\">내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다. 내용이 출력됩니다.&nbsp;</span>&nbsp;</p>",
//         FRST_REGIST_PNTTM: '2022-11-28',
//         FRST_REGISTER_ID: 'yhkim',
//         RDCNT: '10',
//         PRODUCT_NM: '상품명'
//       }]
//     },
//     DXP_PRMTNMV: {
//       cnt: 4,
//       collResult: [{
//         DOCID: "PRMTNMV_930",
//         BBS_NM: "홍보 동영상",
//         ATCH_FILE_ID: "FILE_000000000002025",
//         ORIGNL_FILE_NM: "Mountains - 81945.mp4|mark-43913_1280.png",
//         STRE_FILE_NM: "PromoMovie_202209260513227000|PromoMovie_202209260513227011",
//         FILE_EXTSN: "mp4|png",
//         NTT_SJ: "<!HS>등록<!HE>~~~~~`",
//         FILE_CONTENT: "FILE_000000000002025",
//         LINK_URL: "/dxp/introduce/promotionVideoDtl/930",
//         NTT_CN: "",
//         FRST_REGIST_PNTTM: '2022-11-28',
//         RDCNT: '10'
//       }, {
//         DOCID: "PRMTNMV_1112",
//         BBS_NM: "홍보 동영상",
//         ATCH_FILE_ID: "FILE_000000000002438",
//         ORIGNL_FILE_NM: "test동영상.mp4|시험용 (1).png",
//         STRE_FILE_NM: "PromoMovie_202210260454361770|PromoMovie_202210260454361871",
//         FILE_EXTSN: "mp4|png",
//         NTT_SJ: "2022.10.21 홍보 동영상 <!HS>등록<!HE> 테스트2333333333333333333333333",
//         FILE_CONTENT: "FILE_000000000002438",
//         LINK_URL: "/dxp/introduce/promotionVideoDtl/1112",
//         NTT_CN: "",
//         FRST_REGIST_PNTTM: '2022-11-28',
//         RDCNT: '10'
//       }, {
//         DOCID: "PRMTNMV_1110",
//         BBS_NM: "홍보 동영상",
//         ATCH_FILE_ID: "FILE_000000000002437",
//         ORIGNL_FILE_NM: "test동영상.mp4|기계.jpg",
//         STRE_FILE_NM: "PromoMovie_202210211009496230|PromoMovie_202210211009496271",
//         FILE_EXTSN: "mp4|jpg",
//         NTT_SJ: "2022.10.21 홍보 동영상 <!HS>등록<!HE>",
//         FILE_CONTENT: "FILE_000000000002437",
//         LINK_URL: "/dxp/introduce/promotionVideoDtl/1110",
//         NTT_CN: "",
//         FRST_REGIST_PNTTM: '2022-11-28',
//         RDCNT: '10'
//       }, {
//         DOCID: "PRMTNMV_1293",
//         BBS_NM: "홍보 동영상",
//         ATCH_FILE_ID: "FILE_000000000002795",
//         ORIGNL_FILE_NM: "test동영상.mp4|자동차.jpg",
//         STRE_FILE_NM: "PromoMovie_202210260453036480|PromoMovie_202210260453036511",
//         FILE_EXTSN: "mp4|jpg",
//         NTT_SJ: "홍보동영상<!HS>등록<!HE> 화면 테스트1026",
//         FILE_CONTENT: "FILE_000000000002795",
//         LINK_URL: "/dxp/introduce/promotionVideoDtl/1293",
//         NTT_CN: "",
//         FRST_REGIST_PNTTM: '2022-11-28',
//         RDCNT: '10'
//       }]
//     },
//     LMS_LEC: {
//       cnt: 0,
//       collResult: []
//     },
//     LMS_COS: {
//       cnt: 0,
//       collResult: []
//     },
//   },
//   totalCnt: 10,
//   errorCode: 0,
//   status: 'success',
//   errorMsg: ''
// }