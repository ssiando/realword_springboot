import { Color } from '~/components/StyleUtils';
import { breakpoint } from '~/pages/Home/styles/styleCommon';
import { css } from '@emotion/react';

export const CardMediaThumb = css`
  border-radius: 15px 15px 10px 10px;
  overflow: hidden;
`;

export const eventTitle = css`
  height: 64px;
  margin: 20px 0 15px;
  font-size: 20px;
  font-weight: 700;
  color: ${Color.black};
  line-height: 32px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;

  > b {
    color: ${Color.topaz};
  }

  @media (max-width: ${breakpoint.mobile}) {
    height: 60px;
    margin-bottom: 10px;
    font-size: 18px;
    line-height: 30px;
  }
`;