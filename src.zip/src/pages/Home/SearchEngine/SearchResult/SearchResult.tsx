/* eslint-disable jsx-a11y/alt-text */
import * as React from 'react';
import {useEffect, useState, useRef, useCallback} from 'react';

import {useGlobalConfigStore} from '../../../../../../shared/src/store/GlobalConfigStore';
import {useScroll} from '../../../../../../shared/src/components/useScroll';
import {useScrollStore} from '../../../../../../shared/src/store/ScrollStore';

import styled from '@emotion/styled';
import {Color} from '~/components/StyleUtils';
import {breakpoint} from '../../styles/styleCommon';

import {SearchParam, SearchResult, searchResultInfo} from '../Data/dataSearch';

import SearchResultHeader from '../Components/SearchResultHeader';
import SearchResultTabPanel from '../Components/SearchResultTabPanel';
import SearchResultNotConts from '../Components/SearchResultNotConts';
import SearchQuickBanner from '../Components/SearchQuickBanner';
import SearchFooter from '../Components/SearchFooter';
import {useLocation} from "react-router-dom";
import {SearchService, WisenutResponese} from "~/pages/Home/SearchEngine/SearchService";

function SearchResultTest() {
  let windowInnerHeight = 0;
  let vh = 0;

  const isMobileCheck = /iPhone|iPad|iPod|Android/i.test(
    window.navigator.userAgent
  );

  const scrollStore = useScrollStore();
  const [touchClientY, setTouchClientY] = useState(0)
  const [touchDirection, setTouchDirection] = useState<'up' | 'down'>('up')
  const searchResultRef = useRef<any>();
  const [iptFocus, setIptFocus] = useState<boolean>(false);
  const [iptDisabled, setIptDisabled] = useState<boolean>(false);

  const [isKeywordOnAddClass, setIsKeywordOnAddClass] = useState<boolean>(true);
  const [isIptValue, setIsIptValue] = useState<boolean>(true);

  const [searchValue, setSearchValue] = useState<string>('');
  const [tabsIdx, setTabsidx] = useState<number>(0);

  const receive: any = useLocation();
  const [keyword, setKeyword] = useState<string>('');
  const [searchResult, setSearchResult] = useState<Partial<WisenutResponese<SearchResult>>>({})
  const [searchParam, setSearchParam] = useState<Partial<SearchParam>>({
    searchFlag: 'search',
    startCount: 0,
    listCount: 9
  })
  const [hashValue, setHashValue] = useState('')

  // 모바일 100vh 적용 관련
  const handleResize = () => {
    const currentInnerHeight = window.innerHeight;
    // console.log(`${currentInnerHeight}/${windowInnerHeight}`);
    if (currentInnerHeight !== windowInnerHeight) {
      windowInnerHeight = currentInnerHeight;
      vh = window.innerHeight * 0.01;
      document.documentElement.style.setProperty('--vh', `${vh}px`);
    }
  };

  // 탭 변경
  const handleTabsChange = (evt: React.SyntheticEvent, currIdx: number) => {
    setTabsidx(currIdx);
  };

  const handleHashTagClick = async (e: any) => {
    setHashValue(e.target.textContent)
    setSearchValue(e.target.textContent)
    await OnSearch(e.target.textContent)
  };

  const handleKeywordList = (evt :any) => {
    if (evt.target.nodeName !== "BUTTON" && evt.target.nodeName !== "INPUT") { 
      setIsKeywordOnAddClass(false);

      searchValue.length === 0
        ? setIsIptValue(false) 
        : setIsIptValue(true)
    }
  }

  useEffect(() => {
    handleResize();
    if (receive.state) {
      if (receive.state.search) {
        setSearchValue(receive.state.search)
        setKeyword(receive.state.search)
      }
      if (receive.state.result) setSearchResult(receive.state.result)
    }
  }, []);

  useEffect(() => {
    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  });

  const TouchMove = useCallback((e) => {
    const clientY = e.changedTouches[0].clientY
    if (isMobileCheck) {
      if (touchClientY < clientY) {
        setTouchDirection("up")
      } else {
        setTouchDirection("down")
      }
      setTouchClientY(clientY)
    }
  }, [touchClientY])

  const OnSearch = async (searchWord: string) => {

    setHashValue(searchValue)
    setTabsidx(0)
    setIptFocus(false)

    const res = await SearchService.GetSearch({...searchParam, query: searchWord})
    if (res.status == 'success' && !!res.result) {
      setKeyword(searchWord)
      setSearchResult(res)

      searchWord.length > 0 ? setIsIptValue(true) : setIsIptValue(false)
      // TODO: TEST value
      // setSearchResult(testSearchRestult)
    }
  }

  const onAdditionList = async (collection: keyof SearchResult) => {

    function getProperty<T, K extends keyof T>(obj: T, key: K): T[K] {
      return obj[key];
    }

    const collectionObj: any = getProperty(searchResult.result, collection as never)

    const res = await SearchService.GetSearch({
      ...searchParam,
      query: keyword,
      collection: collection,
      listCount: (collectionObj.collResult?.length || 0) + 3
    })

    if (res.status == 'success' && !!res.result) {
      setSearchResult({
        ...searchResult,
        result: {
          ...searchResult.result,
          ...res.result
        }
      })
    }
  }

  return (
    <SearchResultSection
      ref={searchResultRef}
      // className={iptFocus ? 'is-focus' : ''}
      className={`${iptFocus ? 'is-focus' : ''} ${isIptValue ? 'ipt-value' : ''}`} 
      onClick={handleKeywordList}
      onWheel={(e) => {
        if (!scrollStore.isLocking)
          scrollStore.setScrollDirection(e.deltaY > 0 ? "down" : "up")
      }}
      onTouchMove={TouchMove}
      onTouchEnd={() => {
        scrollStore.setScrollDirection(touchDirection)
      }}
    >
      <SearchResultHeader
        searchResult={searchResult}
        iptFocus={iptFocus}
        setIptFocus={setIptFocus}
        searchValue={searchValue}
        setSearchValue={setSearchValue}
        iptDisabled={iptDisabled}
        tabsIdx={tabsIdx}
        hashValue={hashValue}
        evtTabsChange={handleTabsChange}
        evtHashClick={handleHashTagClick}
        scrollDirection={scrollStore.scrollDirection}
        searchResultRef={searchResultRef}
        searchResultInfo={{keyword: keyword, total: searchResult.totalCnt || 0}}
        isKeywordOnAddClass={isKeywordOnAddClass}
        setIsKeywordOnAddClass={setIsKeywordOnAddClass}
        setIsIptValue={setIsIptValue}
        searchHandler={async (value: string) => {
          setSearchValue(value)
          await OnSearch(value)
        }}
      />

      <SearchResultConts>
        {
          (searchResult.totalCnt || 0) > 0 ? (
            <SearchResultTabPanel tabsIdx={tabsIdx} result={searchResult.result} onAdditionList={onAdditionList}/>
          ) : (
            <SearchResultNotConts evtHashClick={handleHashTagClick}/>
          )}
      </SearchResultConts>
      {/*<SearchQuickBanner/>*/}
      <SearchFooter/>
    </SearchResultSection>
  );
}

// 메인
const SearchResultSection = styled('div')`
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  min-height: calc(var(--vh, 1vh) * 100);
  letter-spacing: -0.06em;
  word-break: keep-all;
  word-wrap: break-word;

  footer {
    display: flex;
    align-items: center;
    height: 60px;
    border-top: 1px solid #d7dae6;
    color: ${Color.warm_gray};

    @media (min-width: 1201px) {
      justify-content: flex-end;
      padding-right: 20px;
      font-size: 14px;
    }
    @media (max-width: ${breakpoint.desk1200}) {
      justify-content: flex-start;
      padding-left: 15px;
    }
  }
`;
const SearchResultConts = styled('div')``;

export default SearchResultTest