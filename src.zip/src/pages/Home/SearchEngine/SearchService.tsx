import {AxiosGet, AxiosPost, GetQuery} from "shared/libs/axios";
import {BaseResponse, WithListResponse, WithResponse} from "shared/utils/Model";
import {SearchResult} from "~/pages/Home/SearchEngine/Data/dataSearch";
import {UseQueryResult} from "react-query";

export class SearchService {
  static async GetSearch(data: any): Promise<WisenutResponese<SearchResult>> {
    return await AxiosGet('/common/api/search', data)
  }

  // 자동완성
  static GetSearchArk(data: any): UseQueryResult<WisenutResponese<Ark>, any> {
    return GetQuery('/common/api/ark', data)
  }

  // 인기검색
  static GetSearchPopWord(data: any): UseQueryResult<WisenutResponese<Popword[]>, any> {
    return GetQuery('/common/api/popword', data)
  }

  // 추천검색
  static GetSearchRecommend(data: any): UseQueryResult<any, any> {
    return GetQuery('/common/api/recommend', data)
  }
}

export type WisenutResponese<T> = {
  totalCnt: number
  errorCode: number
  status: string
  errorMsg: string
  result: T
}

export interface Popword {
  querycount: number
  count: number
  id: number
  updown: string
  content: string
}

export interface Ark {
  fw: ArkItem
  rw: ArkItem
}

export interface ArkItem {
  totalcount: number
  items: {
    count: number
    linkurl: string
    keyword: string
    type: number
    linkname: string
    hkeyword: string
  }[]
}