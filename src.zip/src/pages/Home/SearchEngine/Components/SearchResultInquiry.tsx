/* eslint-disable jsx-a11y/alt-text */
import React, { useState, useEffect } from 'react';
import * as styles from '~/styles/styles';

import {
  Box, 
  Stack, 
  List, 
  ListItem, 
  Typography 
} from '@mui/material';
import { CustomButton } from '~/components/ButtonComponents';

import styled from '@emotion/styled';
import {
  CommonInner,
  TabPanelTitle,
  TabPanelConts,
  searchMoreBtn,
  searchCommonInner,
  searchListType1,
} from '../styles';

export default function SearchResultInquiry(props: any) {
  const { result } = props;

  const [moreCount, setMoreCount] = useState<number>(0);

  const moreInfo = () => {
    moreCount <= 3 ? setMoreCount(0) : setMoreCount(moreCount - 3);
    console.log('더보기 버튼');
  };

  useEffect(() => {
    setMoreCount(result.cnt);
  }, [])

  return (
    <CommonInner>
      <TabPanelTitle>
        <Box component={'a'} onClick={() => {
          window.open(`${process.env.REACT_APP_DOMAIN}/dxp/community/inquiry`, "_blank")
        }}>
          {'문의사항'}
        </Box>
        {
          result?.cnt && <Typography component={'p'}>
            <span className="point">{result?.cnt}</span>
            <span>건</span>
          </Typography>
        }
      </TabPanelTitle>
   
      <TabPanelConts css={searchCommonInner}>
        <List css={searchListType1} className={moreCount > 3 ? 'is-more' : ''}>
          {/* 기본 3개 노출 */}
          {/* TODO
              1. 더보기 없을 경우 is-more 클래스 미노출 (border선 삭제) 
              2. 데이터 불러오는 부분 기능 개발 요청
              3. 정보 필요 : 접수일, 답변유무 상태, 비밀글 유무
           */}
          {
            result.collResult.map((item: any, i:number) => {
              if (i >= 3) return false;
              return (
                <ListItem>
                  <Box component={'a'} onClick={() => { window.open(`${item.LINK_URL}`, "_blank")}}>
                    <Box className='left'>
                      <Box className='title'>
                        <Box component={'p'} className='tag'>
                          <Box component={'i'}>
                            <Box component={'span'}>{item.INQUIRY_CATEGORY}</Box>
                          </Box>
                        </Box>
                        <Box className='name'>
                          <h3 dangerouslySetInnerHTML={{
                            __html: item.NTT_SJ?.replaceAll('<!HS>','<b>').replaceAll('<!HE>','</b>')
                          }}/>
                          
                          {/* 비밀글 유무에 따라 노출 */}
                          <IcoLock />
                        </Box>
                      </Box>
                      <Typography component={'p'} className='info'>
                        <Typography component={'span'}>접수일</Typography>
                        <Typography component={'span'}>{item.FRST_REGIST_PNTTM || ''}</Typography>
                      </Typography>
                    </Box>
                    <Box className='right'>
                      {
                        i % 2 
                          ? <Typography component={'p'} className='completion'>답변완료</Typography> 
                          : <Typography component={'p'}>답변대기</Typography>
                      }
                    </Box>
                  </Box>
                </ListItem>
              );
            })
          }
        </List>

        {/* 
          1. 4개 이상일 때 더보기 버튼 노출 
          2. 더 보여줘야 할 정보 없을 때는 미노출
         */}
        {
          moreCount > 3 && (
            <Stack css={(styles.bottom_btn, searchMoreBtn)}>
              <CustomButton
                label={'더보기'}
                type={'full'}
                color={'item'}
                onClick={() => moreInfo()}
              />
            </Stack>
          )
        }
      </TabPanelConts>
    </CommonInner>
  );
}

const IcoLock = styled('i')`
  flex-shrink: 0;
  width: 24px;
  height: 24px;
  margin-left: 8px;
  background: url('/images/search/ico_lock.svg') no-repeat center / contain;
`;
