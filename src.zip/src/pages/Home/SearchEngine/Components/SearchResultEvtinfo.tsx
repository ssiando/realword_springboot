/* eslint-disable jsx-a11y/alt-text */
import React, {useState, useEffect, Fragment} from 'react';
import * as styles from '~/styles/styles';

import {
  Box,
  Stack,
  List,
  ListItem,
  Typography
} from '@mui/material';
import {CustomButton} from '~/components/ButtonComponents';

import {
  CommonInner,
  TabPanelTitle,
  TabPanelConts,
  searchMoreBtn,
  searchCommonInner,
  searchListType1,
} from '../styles';
import {CountResult, DxpDtstry, DxpEventCategory} from "~/pages/Home/SearchEngine/Data/dataSearch";
import {SearchPortalType} from "~/pages/Home/SearchEngine/Components/SearchResultTabPanel";

export default function SearchResultEvtinfo(props: {
  type: SearchPortalType
  result?: CountResult<DxpEventCategory>
  onAdditionList: () => void
}) {
  const {result} = props;

  const [lookCount, setLookCount] = useState<number>(0);

  const moreInfo = () => {
    if (props.result?.collResult && props.result.collResult.length > lookCount + 3){
      setLookCount(lookCount + 3)
    }else {
      props.onAdditionList()
    }
    // if (props.result?.cnt && props.result?.cnt <= lookCount + 3) {
    //   props.onAdditionList()
    // }else if (props.result?.cnt) {
    //   setLookCount(lookCount + 3 < props.result.cnt ? lookCount + 3 : props.result.cnt)
    // }
  }

  useEffect(() => {
    setLookCount(3)
  }, [props.type])

  return <Fragment>
    {
      result && result.cnt > 0 && <CommonInner>
        <TabPanelTitle>
          <Box component={'a'} onClick={() => {
            window.open(`${process.env.REACT_APP_DOMAIN}/dxp/community/event`, "_blank")
          }}>
            {'행사안내'}
          </Box>
          {
            result?.cnt && <Typography component={'p'}>
              <span className="point">{result?.cnt}</span>
              <span>건</span>
            </Typography>
          }
        </TabPanelTitle>

        <TabPanelConts css={searchCommonInner}>
          <List css={searchListType1} className={lookCount < result.cnt ? 'is-more' : ''}>
            {
              result.collResult.map((item: any, i: number) => {
                if (i >= lookCount) return false;
                return (
                  <ListItem>
                    <Box component={'a'} onClick={() => {
                      window.open(`${item.LINK_URL}`, "_blank")
                    }}>
                      <Box className='left'>
                        <Box className='title'>
                          <Box component={'p'} className='tag'>
                            <Box component={'i'}>
                              <Box component={'span'}>{item.EVENT_CATEGORY}</Box>
                            </Box>
                          </Box>
                          <Box className='name'>
                            <h3 dangerouslySetInnerHTML={{
                              __html: item.EVENT_NM?.replaceAll('<!HS>', '<b>').replaceAll('<!HE>', '</b>')
                            }}/>
                          </Box>
                        </Box>
                        <Typography component={'p'} className='info'>
                          <Typography component={'span'}>접수기간</Typography>
                          <Typography component={'span'}>{item.EVENT_BGNDE} ~ {item.EVENT_ENDDE}</Typography>
                        </Typography>
                      </Box>
                      <Box className='right'>
                        <Typography component={'p'} className={`${item.STTUS == '접수마감' ? 'completion' : ''}`}>
                          {item.STTUS}
                        </Typography>
                      </Box>
                    </Box>
                  </ListItem>
                );
              })
            }
          </List>

          {
            lookCount < result.cnt &&
            <Stack css={(styles.bottom_btn, searchMoreBtn)}>
              <CustomButton
                label={'더보기'}
                type={'full'}
                color={'item'}
                onClick={() => moreInfo()}
              />
            </Stack>
          }
        </TabPanelConts>
      </CommonInner>
    }
  </Fragment>
}