/* eslint-disable jsx-a11y/alt-text */
import React, {useState, useEffect, Fragment} from 'react';
import * as styles from '~/styles/styles';
import { css } from '@emotion/react';

import {
  Box, 
  Stack, 
  List, 
  ListItem, 
  Typography 
} from '@mui/material';
import { CustomButton } from '~/components/ButtonComponents';

import {
  CommonInner,
  TabPanelTitle,
  TabPanelConts,
  searchMoreBtn,
  searchCommonInner,
} from '../styles';
import { breakpoint } from '../../styles/styleCommon';
import { Color } from '~/components/StyleUtils';
import {CountResult, DxpDataProduct, DxpDtstry} from "~/pages/Home/SearchEngine/Data/dataSearch";
import {SearchPortalType} from "~/pages/Home/SearchEngine/Components/SearchResultTabPanel";

export default function SearchResultProduct(props: {
  type: SearchPortalType
  result?: CountResult<DxpDataProduct>
  onAdditionList: () => void
}) {
  const { result } = props;

  const [lookCount, setLookCount] = useState<number>(0);

  const moreInfo = () => {
    if (props.result?.collResult && props.result.collResult.length > lookCount + 3){
      setLookCount(lookCount + 3)
    }else {
      props.onAdditionList()
    }
    // if (props.result?.cnt && props.result?.cnt <= lookCount + 3) {
    //   props.onAdditionList()
    // }else if (props.result?.cnt) {
    //   setLookCount(lookCount + 3 < props.result.cnt ? lookCount + 3 : props.result.cnt)
    // }
  };

  useEffect(() => {
    setLookCount(3)
  }, [props.type])

  return <Fragment>
    {
      result && result.cnt > 0 && <CommonInner>
      <TabPanelTitle>
        <Box component={'a'} onClick={() => {
          window.open(`${process.env.REACT_APP_DOMAIN}/dxp/data/searchProduct`, "_blank")
        }}>
          {'상품 목록'}
        </Box>
        {
          result?.cnt && <Typography component={'p'}>
            <span className="point">{result?.cnt}</span>
            <span>건</span>
          </Typography>
        }
      </TabPanelTitle>
   
      <TabPanelConts css={searchCommonInner} className={ lookCount < result.cnt  ? 'is-more-type' : ''}>
        <Box css={procuctGroupCss}>
          <List css={searchListType1} className={lookCount < result.cnt  ? 'is-more' : ''}>
            {
              result.collResult.map((item: any, i:number) => {
                if (i >= lookCount) return false;
                return (
                  <ListItem>
                    <Box component={'a'} 
                      css={productElemCss} 
                      onClick={() => { window.open(`${item.LINK_URL}`, "_blank")}}>
                      <figure className="thumbnail"
                        style={{
                          backgroundImage: `url('/images/main/cont02_01.png')` 
                          // backgroundImage: `${process.env.REACT_APP_DOMAIN}/dxp/cmmn/getImage/${item.ATCH_FILE_ID}/1`
                        }}></figure>

                      <Box className='conts'>
                        <List className='bbsIco'>
                          <ListItem>
                            <Box component={'i'} className='cate'>
                              <Typography component={'span'}>{item.LCLAS_NM}</Typography>
                            </Box>
                          </ListItem>
                          <ListItem>
                            <Box component={'i'} className={`${(item.SBSCRB_CTRGY_NM &&  item.SBSCRB_CTRGY_NM != '')? 'bgBL' : 'lineGY'}`}>
                              <Typography component={'span'}>{`${(item.SBSCRB_CTRGY_NM &&  item.SBSCRB_CTRGY_NM != '')? '구독' : '일반'}`}</Typography>
                            </Box>
                          </ListItem>
                        </List>

                        <Box className='rate'>
                          <Box component={'span'} className='ico' />
                          <Box component={'span'} className='num'>{item.STAR_SCORE}</Box>
                        </Box>

                        <Typography component={'p'} className="txt">{item.CP_NM}</Typography>

                        {/* 관련 검색어 있을 경우, 포인트 컬러 적용 */}
                        <p className='tit' dangerouslySetInnerHTML={{
                          __html: item.PRODUCT_NM?.replaceAll('<!HS>','<b>').replaceAll('<!HE>','</b>')
                        }}/>

                        <List className='info'>
                          <ListItem>
                            <Typography component={'p'}>조회수</Typography>
                            <Typography component={'p'}>{item.RDCNT}</Typography>
                          </ListItem>
                          <ListItem>
                            <Typography component={'p'}>2021-07-01</Typography>
                          </ListItem>
                        </List>

                        <Box className='price'>
                          <Typography component={'p'} className='cate'>
                            { item.PC_TY === '01' && '무료'}
                            { item.PC_TY === '02' && '조건부무료'}
                            { item.PC_TY === '03' && '유료'}
                            { item.PC_TY === '04' && '가격협의'}
                          </Typography>
                          <Box component={'p'}>
                            <Typography component={'span'} className='num'>{item.DSCNT_PC}</Typography>
                            <Typography component={'span'} className='won'>원</Typography>
                          </Box>
                        </Box>
                      </Box>
                    </Box>
                  </ListItem>
                );
              })
            }
          </List>
        </Box>

        {
          lookCount < result.cnt &&
            <Stack css={(styles.bottom_btn, searchMoreBtn)}>
              <CustomButton
                label={'더보기'}
                type={'full'}
                color={'item'}
                onClick={() => moreInfo()}
              />
            </Stack>
        }
      </TabPanelConts>
    </CommonInner>
    }
  </Fragment>
}

const procuctGroupCss = css`
  .is-more-type & {
    margin-bottom: 40px;
  }

  @media (min-width: ${breakpoint.minMobile}) and (max-width: ${breakpoint.desk1280}) {
    padding: 0 20px;
  }

  @media (max-width: ${breakpoint.mobile}) {
    padding: 0 15px;
  }
`;

const productElemCss = css`
  display: block;
  width: 100%;
  border-radius: 15px 15px 10px 10px;
  box-shadow: inset 0 0 0 1px ${Color.line};

  @media (max-width: ${breakpoint.mobile}) {
    position: relative;
  }

  .thumbnail {
    width: 100%;
    height: 240px;
    margin: 0;
    padding: 0;
    border-radius: 10px 10px 0 0;
    background: no-repeat center/cover;

    @media (max-width: ${breakpoint.mobile}) {
      height: 180px;
    }
  }

  .conts {
    padding: 24px 30px;
    
    @media (min-width: ${breakpoint.minMobile}) {
      position: relative;
    }

    @media (max-width: ${breakpoint.mobile}) {
      padding: 16px 20px 20px;
    }

    ul {
      display: flex;
      align-items: center;
      padding: 0;

      > li {
        display: flex;
        align-items: center;
        width: auto;
        padding: 0;
      }
    }

    .bbsIco {
      @media (max-width: ${breakpoint.mobile}) {
        position: absolute;
        top: 10px;
        left: 10px;
        justify-content: space-between;
        width: calc(100% - 20px);
      }

      > li {
        i {
          display: flex;
          align-items: center;
          flex-shrink: 0;
          height: 30px;
          padding: 0 10px;
          background: ${Color.white};
          border-radius: 5px;

          > span {
            font-size: 14px;
            font-weight: 400;
            color: ${Color.black};
            line-height: 20px;
            letter-spacing: -0.06em;
          }
          
          &.cate {
            background: ${Color.bg_grey};
          }

          &.lineGY {
            border: 1px solid ${Color.gray};

            > span {
              color: ${Color.warm_grey};
            }
          }

          &.bgBL {
            background: ${Color.azul};

            > span {
              color: ${Color.white};
            }
          }
        }

        & + li {
          margin-left: 4px;
        }
      }
    }

    .rate {
      position: absolute;
      display: flex;
      align-items: center;

      .ico {
        width: 22px;
        height: 21px;
        background: url('/images/search/ico_rate.svg') no-repeat center/contain;
      }
      
      .num {
        margin-left: 4px;
        font-size: 15px;
        font-weight: 400;
        color: ${Color.black};
        line-height: 18px;
      }

      @media (min-width: ${breakpoint.minMobile}) {
        top: 30px;
        right: 30px;
      }

      @media (max-width: ${breakpoint.mobile}) {
        bottom: 64px;
        right: 20px;
      }
    }

    .info {
      > li {
        &:not(:last-of-type) {
          &::after {
            content: "";
            width: 1px;
            height: 12px;
            margin: 0 8px;
            background: ${Color.gray};
          }
        }
      }

      p {
        font-size: 14px;
        font-weight: 400;
        color: ${Color.black};
        line-height: 20px;
        letter-spacing: -0.06em;

        &:not(:only-of-type):first-of-type {
          margin-right: 6px;
          color: ${Color.warm_grey};
        }
      }
    }

    .price {
      display: flex;
      align-items: flex-end;
      justify-content: space-between;
      margin-top: 24px;
      min-height: 29px;

      @media (max-width: ${breakpoint.mobile}) {
        min-height: 24px;
        margin-top: 20px;
      }
    }

    p {
      letter-spacing: -0.06em;
      
      &.txt {
        font-size: 16px;
        font-weight: 400;
        color: ${Color.warm_grey};
        line-height: 24px;
        margin: 12px 0 8px;

        @media (max-width: ${breakpoint.mobile}) {
          margin-top: 0;
        }
      }
  
      &.tit {
        display: -webkit-box;
        max-height: 60px;
        margin-bottom: 12px;
        font-size: 20px;
        font-weight: 700;
        color: ${Color.black};
        line-height: 30px;
        overflow: hidden;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;

        > b {
          color: ${Color.topaz};
        }

        @media (min-width: ${breakpoint.minMobile}) {
          height: 60px;
        }

        @media (max-width: ${breakpoint.mobile}) {
          font-size: 18px;
          max-height: 56px;
          line-height: 28px;
        }
      }

      &.cate {
        font-size: 18px;
        font-weight: 700;
        color: ${Color.navy};
        line-height: 27px;

        @media (max-width: ${breakpoint.mobile}) {
          font-size: 16px;
          line-height: 24px;
        }

        & + p {
          display: flex;
          align-items: flex-end;

          > span {
            font-weight: 500;
            color: ${Color.black};
            letter-spacing: -0.06em;

            &.num {
              font-size: 24px;
              line-height: 29px;

              @media (max-width: ${breakpoint.mobile}) {
                font-size: 20px;
                line-height: 24px;
              }
            }

            &.won {
              font-size: 18px;
              line-height: 27px;
              padding-left: 4px;

              @media (max-width: ${breakpoint.mobile}) {
                padding-bottom: 2px;
                font-size: 14px;
                line-height: 20px;
              }
            }
          }
        }
      }
    }
  }
`;

const searchListType1 = css`
    display: flex;
    flex-wrap: wrap;
    padding: 0;
    border-top: 0;

    > li {
      width: calc((100% - 120px) / 3);
      padding: 0;

      @media (min-width: 1201px) {
        &:not(:nth-of-type(3n + 1)) {
          margin-left: 60px;
        }
        &:nth-of-type(n + 4) {
          margin-top: 60px;
        }
      }

      @media (min-width: ${breakpoint.minMobile}) and (max-width: ${breakpoint.desk1200}) {
        width: calc((100% - 60px) / 2);

        &:nth-of-type(even) {
          margin-left: 60px;
        }
        &:nth-of-type(n + 3) {
          margin-top: 60px;
        }
      }
      @media (max-width: ${breakpoint.mobile}) {
        width: 100%;

        &:not(:first-of-type) {
          margin-top: 40px;
        }
      }
    }
  `