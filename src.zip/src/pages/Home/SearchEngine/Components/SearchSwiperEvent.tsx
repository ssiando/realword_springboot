/* eslint-disable jsx-a11y/alt-text */
import * as React from 'react';
import { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';

import {CardMedia, Typography} from '@mui/material';

import { Swiper, SwiperSlide } from 'swiper/react';
import SwiperCore, { Pagination, Autoplay } from "swiper";

import 'swiper/swiper.scss';

import styled from '@emotion/styled';
import { Color } from '~/components/StyleUtils';
import { breakpoint } from '../../styles/styleCommon';
import {
  searchThumbIcon,
  SearchIconEventIng,
  SearchIconRecruit01,
  SearchIconRecruit02,
} from '../styles';

import { CardMediaThumb, eventTitle } from '../styleCssCommon';

import { EventInfo, DxpPrmtnMV } from "~/pages/Home/SearchEngine/Data/dataSearch";
import * as common from "~/CommonFunction";

SwiperCore.use([Pagination, Autoplay])

export default function SearchSwiperEvent(props: any) {
  const { data, type } = props;
  const [swiper, setSwiper] = useState<any | null>(null);
  const [slidesOffset, setSlidesOffset] = useState<number>(0);

  const handleSlidesOffset = () => {
    const offset = (window.innerWidth - 1260) / 2;
    window.innerWidth < 1260 ? setSlidesOffset(0) : setSlidesOffset(offset);

    if (swiper) swiper.updateSlides();
  };

  useEffect(() => {
    handleSlidesOffset();
  }, []);

  useEffect(() => {
    window.addEventListener('resize', handleSlidesOffset);
    return () => {
      window.removeEventListener('resize', handleSlidesOffset);
    };
  });

  return (
    <SwiperSection
      slidesPerView={'auto'}
      slidesPerGroup={1}
      spaceBetween={0}
      breakpoints={{
        1281: {
          slidesPerGroup: 3,
          spaceBetween: 60,
        },
      }}
      watchOverflow ={true}
      observer={true}
      observeParents={true}
      pagination={{
        el: '.swiper-pagination',
        clickable: true,
        type: 'bullets',
      }}
      // slidesOffsetBefore={slidesOffset}
      // slidesOffsetAfter={slidesOffset}
      onSwiper={(swiper) => setSwiper(swiper)}
    >
      { type === "event" && (
        data.map((item: any, i: number) => (
          <SwiperSlide key={i}>
            <NavLink to={''} onClick={() => {
              window.open(`${process.env.REACT_APP_DOMAIN}${item.LINK_URL}`, "_blank")
            }}>
              <SwiperThumb>
                <CardMedia
                  component="img"
                  height="200"
                  image={`${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/bsns-pblanc/${item.DOCID}/thumbnail`}
                  onError={(e: any) => common.handleImgError(e)}
                  alt={item.EVENT_NM?.replace("<!HS>", "").replace("<!HE>", "")}
                  css={CardMediaThumb}
                />
                
                {/* 진행중일 경우에만 아이콘 노출 */}
                <SearchIconEventIng css={searchThumbIcon} />
              </SwiperThumb>
              
              {/* 관련 검색어 있을 경우, 포인트 컬러 적용 */}
              <h3 css={eventTitle} dangerouslySetInnerHTML={{
                __html: item.EVENT_NM?.replaceAll('<!HS>','<b>').replaceAll('<!HE>','</b>')
              }}/>
  
              {/* 테스트 노출 :: 데이터불러와야함. */}
              <EventInfoDiv>
                <Typography component={'p'}>
                 <span>진행기간</span>
                  {
                    item.BGNDE && item.ENDDE &&
                    <span className="point">{item.BGNDE} ~ {item.ENDDE}</span>
                  }
                  {
                    item.CONTEST_BGNDE && item.CONTEST_ENDDE &&
                    <span className="point">{item.CONTEST_BGNDE} ~ {item.CONTEST_ENDDE}</span>
                  }
                </Typography>
              </EventInfoDiv>
              <EventInfoDiv>
                <Typography component={'p'}>
                 <span>조회</span>
                 <span className="point">{item.RDCNT}</span>
                </Typography>
                <Typography component={'p'}>
                 <span>작성일</span>
                 <span className="point">{item.CREAT_DT || item.FRST_REGIST_PNTTM || ''}</span>
                </Typography>
              </EventInfoDiv>
            </NavLink>
          </SwiperSlide>
        ))
      )}

      {/* 
        TODO
        1. CardMedia image 경로 확인
        2. 정보 필요 : 등록일자, 조회수 
       */}
      { type === "movie" && (
        data.map((item: DxpPrmtnMV, i: number) => (
          <SwiperSlide key={i}>
            <NavLink to={''} onClick={() => {
              window.open(`${process.env.REACT_APP_DOMAIN}${item.LINK_URL}`, "_blank")
            }}>
              <SwiperThumb>
                <CardMedia
                  component="img"
                  height="200"
                  image={`${process.env.REACT_APP_DOMAIN}/dxp/cmmn/getImage/${item.ATCH_FILE_ID}/1`}
                  onError={(e: any) => common.handleImgError(e)}
                  alt={item.NTT_SJ?.replace("<!HS>", "").replace("<!HE>", "")}
                  css={CardMediaThumb}
                />
              </SwiperThumb>
              
              {/* 관련 검색어 있을 경우, 포인트 컬러 적용 */}
              <h3 css={eventTitle} dangerouslySetInnerHTML={{
                __html: item.NTT_SJ?.replaceAll('<!HS>','<b>').replaceAll('<!HE>','</b>')
              }}/>
  
              {/* 테스트 노출 :: 데이터불러와야함. */}
              <EventInfoDiv>
                <Typography component={'p'}>
                 <span>등록일자</span>
                 <span className="point">2022-01-01</span>
                </Typography>
                <Typography component={'p'}>
                 <span>조회수</span>
                 <span className="point">99</span>
                </Typography>
              </EventInfoDiv>
            </NavLink>
          </SwiperSlide>
        ))
      )}

      {/* 
        TODO
        1. CardMedia image 경로 확인
        2. 정보 필요 : 진행기간, 조회수 
       */}
      { type === "award" && (
        data.map((item: DxpPrmtnMV, i: number) => (
          <SwiperSlide key={i}>
            <NavLink to={''} onClick={() => {
              window.open(`${process.env.REACT_APP_DOMAIN}${item.LINK_URL}`, "_blank")
            }}>
              <SwiperThumb>
                <CardMedia
                  component="img"
                  height="200"
                  image={`${process.env.REACT_APP_DOMAIN}/dxp/cmmn/getImage/${item.ATCH_FILE_ID}/1`}
                  onError={(e: any) => common.handleImgError(e)}
                  alt={item.NTT_SJ?.replace("<!HS>", "").replace("<!HE>", "")}
                  css={CardMediaThumb}
                />
              </SwiperThumb>
              
              {/* 관련 검색어 있을 경우, 포인트 컬러 적용 */}
              <h3 css={eventTitle} dangerouslySetInnerHTML={{
                __html: item.NTT_SJ?.replaceAll('<!HS>','<b>').replaceAll('<!HE>','</b>')
              }}/>
  
              {/* 테스트 노출 :: 데이터불러와야함. */}
              <EventInfoDiv>
                <Typography component={'p'}>
                 <span>진행기간</span>
                 <span className="point">2022-01-01 ~ 2022-12-31</span>
                </Typography>
              </EventInfoDiv>
              <EventInfoDiv>
                <Typography component={'p'}>
                 <span>조회수</span>
                 <span className="point">99</span>
                </Typography>
              </EventInfoDiv>
            </NavLink>
          </SwiperSlide>
        ))
      )}
      <SwiperControllerGroup>
        <div className="swiper-pagination"></div>
      </SwiperControllerGroup>
    </SwiperSection>
  );
}
const SwiperSection = styled(Swiper)`
  .swiper {
    @media (max-width: ${breakpoint.desk1280}) {
      &-wrapper {
        /* padding: 0 15px; */
      }
    }
    &-slide {
      width: 380px;

      @media (max-width: ${breakpoint.desk1280}) {
        width: 285px;
        margin-left: 15px;

        /* &:first-of-type {
          margin-left: 15px;
        } */

        &:last-of-type {
          margin-right: 15px;
        }
      }

      a {
        display: block;
        width: 100%;
      }

      /* @media (min-width: 1281px) {
        opacity: 0.4;

        &-active,
        &-next {
          opacity: 1;
        }
        &-next {
          & + .swiper-slide {
            opacity: 1;
          }
        }
      } */
    }
  }
`;

const SwiperThumb = styled('div')`
  figure {
    width: 100%;
    height: 200px;
    margin: 0;
    padding: 0;
    background: no-repeat center / cover;
    border-radius: 15px 15px 10px 10px;
  }
`;
const SlideContsTitle = styled('h3')`
  height: 60px;
  margin: 20px 0 16px;
  font-size: 20px;
  font-weight: 700;
  color: ${Color.black};
  line-height: 30px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;

  @media (max-width: ${breakpoint.desk1280}) {
    margin: 12px 0 6px;
    font-size: 18px;
  }
`;
const SlideContsDate = styled('div')`
  p {
    font-size: 14px;
    font-weight: 400;
    color: ${Color.warm_gray};
    line-height: 20px;
    letter-spacing: -0.06em;

    & + p {
      margin-top: 5px;
    }
  }
`;
const SwiperControllerGroup = styled('div')`
  position: relative;
  display: flex;
  justify-content: center;
  padding-bottom: 60px;

  .swiper-pagination {
    position: static;
    display: flex;

    &-bullet {
      display: block;
      width: 60px;
      height: 2px;
      margin: 44px 5px 0;
      background: ${Color.gray};
      border-radius: 0;
      opacity: 1;

      &-active {
        background: ${Color.topaz};
      }
    }

    @media (max-width: ${breakpoint.desk1280}) {
      display: none;
    }
  }

  @media (max-width: ${breakpoint.desk1280}) {
    padding-bottom: 40px;
  }
`;

const EventInfoDiv = styled('div')`
  display: flex;
  align-items: center;

  > p {
    display: flex;
    align-items: center;

    &:not(:first-of-type) {
      &::before {
        content: '';
        display: block;
        width: 1px;
        height: 12px;
        margin: 0 8px;
        background: ${Color.gray};
      }
    }

    span {
      font-size: 14px;
      font-weight: 400;
      color: ${Color.warm_gray};
      line-height: 20px;
      letter-spacing: -0.06em;

      &.point {
        color: ${Color.black};
      }

      &:not(:only-child):first-of-type {
        margin-right: 6px;
      }
    }
  }

  & + & {
    margin-top: 5px;

    @media (max-width: ${breakpoint.mobile}) {
      margin-top: 4px;
    }
  }
`;
