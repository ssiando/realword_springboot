/* eslint-disable jsx-a11y/alt-text */
import * as React from 'react';
import SearchSwiper from './SearchSwiper';
import {Box, Typography} from "@mui/material";
import {
  CommonInner,
  TabPanelGroup,
  TabPanelTitle,
  TabPanelConts,
} from "~/pages/Home/SearchEngine/styles";
import {Fragment} from "react";

export default function SearchResultRecruit(props: any) {
  const {result} = props;

  return <Fragment>
    {
      result && result.cnt > 0 && <TabPanelGroup key={'recruit'}>
        <CommonInner>
          <TabPanelTitle>
            <Box component={'a'} onClick={() => {
              window.open(`${process.env.REACT_APP_DOMAIN}/Notice/Notice`, "_blank")
            }}>
              {'모집 공고'}
            </Box>
            {
              result?.cnt && <Typography component={'p'}>
                <span className="point">{result?.cnt}</span>
                <span>건</span>
              </Typography>
            }
          </TabPanelTitle>
        </CommonInner>

        <TabPanelConts>
          <CommonInner>
            <SearchSwiper data={result?.collResult || []}/>
          </CommonInner>
        </TabPanelConts>
      </TabPanelGroup>
    }
  </Fragment>
}
