/* eslint-disable jsx-a11y/alt-text */
import React, {useState, useEffect, Fragment} from 'react';
import * as styles from '~/styles/styles';
import {NavLink} from 'react-router-dom';

import {Stack, Box, Typography, List, ListItem} from '@mui/material';
import {CustomButton} from '~/components/ButtonComponents';

import styled from '@emotion/styled';
import {css} from '@emotion/react';
import {Color} from '~/components/StyleUtils';
import {breakpoint} from '../../styles/styleCommon';
import {
  CommonInner,
  SearchResultNoticeSection,
  SearchIconNew,
  searchMoreBtn,
} from '../styles';
import {CommonListInfo, CountResult, DxpNotice} from "~/pages/Home/SearchEngine/Data/dataSearch";
import {SearchPortalType, subTitleCss} from "~/pages/Home/SearchEngine/Components/SearchResultTabPanel";

export default function SearchResultNotice(props: {
  dxp?: boolean
  type: SearchPortalType
  title: string
  titleLink: string
  result?: CountResult<CommonListInfo | DxpNotice>
  onAdditionList: () => void
}) {
  const {result, dxp, title, titleLink} = props;
  const extractTextPattern = /(<([^>]+)>)/gi;
  const [lookCount, setLookCount] = useState<number>(0);

  const moreInfo = () => {
    if (props.result?.collResult && props.result.collResult.length > lookCount + 3) {
      setLookCount(lookCount + 3)
    } else {
      props.onAdditionList()
    }

    // if (props.result?.cnt && props.result?.cnt <= lookCount + 3) {
    //   props.onAdditionList()
    // }else if (props.result?.cnt) {
    //   setLookCount(lookCount + 3 < props.result.cnt ? lookCount + 3 : props.result.cnt)
    // }
  };

  useEffect(() => {
    setLookCount(3)
  }, [props.type])

  return <Fragment>
    {
      result && result.cnt > 0 && <Fragment>
        <Typography component={'h4'} css={subTitleCss}>
          <Box
            component={'a'}
            onClick={() => {
              window.open(titleLink, '_blank')
            }}
          >
            {title}
          </Box>
          <Typography component={'span'}>
            <Typography component={'b'}>
              {result.cnt}
            </Typography>
            건
          </Typography>
        </Typography>
        <CommonInner>
          <SearchResultNoticeSection className="--type-list">
            <List className={lookCount < result.cnt ? 'is-more' : ''}>
              {
                result.collResult.map((item: any, i: number) => {
                  if (i >= lookCount) return false;
                  const title = (dxp ? item.NTT_SJ : item.SJ_NM) || ''
                  const cn = (dxp ? item.NTT_CN : item.BBSCTT_CN) || ''
                  const nm = (dxp ? item.FRST_REGISTER_ID : item.CREATR_NM) || ''

                  return (
                    <ListItem key={i}>
                      <Box component={'a'} onClick={() => window.open(`${item.LINK_URL}`, "_blank")}>
                        <NoticeTitle>
                          <p dangerouslySetInnerHTML={{
                            __html: title.replaceAll('<!HS>', '<b>').replaceAll('<!HE>', '</b>')
                          }}/>
                          {/* 24시간 기준 아이콘 유무? */}
                          {/*<SearchIconNew/>*/}

                        </NoticeTitle>
                        <NoticeArticle dangerouslySetInnerHTML={{
                          __html: cn.replaceAll('<!HS>', '<b>').replaceAll('<!HE>', '</b>')
                        }}/>

                        <NoticeInfoGroup>
                          <Typography component={'p'}>
                            <span>조회</span>
                            <span className="point">{item.RDCNT}</span>
                          </Typography>
                          <Typography component={'p'}>
                            <span
                              className="point">{(dxp ? item.FRST_REGIST_PNTTM : item.CREAT_DT)?.split(' ').at(0)}</span>
                          </Typography>
                          <Typography component={'p'}>
                            <span>작성자</span>
                            <span className="point" dangerouslySetInnerHTML={{
                              __html: nm.replaceAll('<!HS>', '<b>')
                                .replaceAll('<!HE>', '</b>')
                            }}/>
                          </Typography>
                        </NoticeInfoGroup>
                      </Box>
                    </ListItem>
                  )
                })}
            </List>

            {
              lookCount < result.cnt &&
              <Stack css={(styles.bottom_btn, searchMoreBtn)}>
                <CustomButton
                  label={'더보기'}
                  type={'full'}
                  color={'item'}
                  onClick={() => moreInfo()}
                />
              </Stack>
            }
          </SearchResultNoticeSection>
        </CommonInner>
      </Fragment>
    }
  </Fragment>
}

const NoticeTitle = styled('div')`
  display: flex;
  align-items: center;
  margin-bottom: 10px;

  @media (max-width: ${breakpoint.mobile}) {
    margin-bottom: 12px;
  }

  p {
    max-width: 100%;
    font-size: 20px;
    font-weight: 700;
    color: ${Color.black};
    line-height: 1.5;
    letter-spacing: -0.06em;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;

    b {
      color: ${Color.topaz};
    }

    @media (max-width: ${breakpoint.mobile}) {
      font-size: 16px;
    }
  }
`;
const NoticeArticle = styled('p')`
  max-height: 56px;
  font-size: 16px;
  font-weight: 400;
  color: ${Color.warm_gray};
  line-height: 28px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;

  b {
    color: ${Color.black};
    font-weight: 500;
  }

  @media (max-width: ${breakpoint.mobile}) {
    font-size: 14px;
  }
`;
const NoticeInfoGroup = styled('div')`
  display: flex;
  align-items: center;
  margin-top: 20px;

  @media (max-width: ${breakpoint.mobile}) {
    margin-top: 16px;
  }

  p {
    display: flex;
    align-items: center;
    letter-spacing: -0.06em;

    &:not(:last-of-type) {
      &::after {
        content: '';
        width: 1px;
        height: 12px;
        margin: 0 8px;
        background: ${Color.gray};
      }
    }
  }

  span {
    font-size: 14px;
    font-weight: 400;
    color: ${Color.warm_gray};
    line-height: 1;

    &:not(:only-of-type):first-of-type {
      margin-right: 6px;
    }

    &.point {
      color: ${Color.black};

      > b {
        font-weight: 400;
        color: ${Color.topaz};
      }
    }
  }
`;