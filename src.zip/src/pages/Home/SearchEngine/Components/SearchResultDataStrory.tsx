/* eslint-disable jsx-a11y/alt-text */
import React, {useState, useEffect, Fragment} from 'react';
import * as styles from '~/styles/styles';
import {NavLink} from 'react-router-dom';

import {
  Box,
  Chip,
  Stack,
  useMediaQuery,
  List,
  ListItem,
  ListItemText,
  Typography
} from '@mui/material';
import {CustomButton} from '~/components/ButtonComponents';

import styled from '@emotion/styled';
import {css} from '@emotion/react';
import {Color} from '~/components/StyleUtils';
import {breakpoint} from '../../styles/styleCommon';
import {
  CommonInner,
  TabPanelTitle,
  TabPanelConts,
  SearchResultNoticeSection,
  SearchIconNew,
  searchMoreBtn,
  searchCommonInner,
  searchListType2,
} from '../styles';
import {CommonListInfo, CountResult, DxpDtstry, DxpNotice} from "~/pages/Home/SearchEngine/Data/dataSearch";
import {SearchPortalType} from "~/pages/Home/SearchEngine/Components/SearchResultTabPanel";

export default function SearchResultDataStrory(props: {
  type: SearchPortalType
  result?: CountResult<DxpDtstry>
  onAdditionList: () => void
}) {
  const {result} = props;

  const [lookCount, setLookCount] = useState<number>(0);

  const moreInfo = () => {
    if (props.result?.collResult && props.result.collResult.length > lookCount + 3){
      setLookCount(lookCount + 3)
    }else {
      props.onAdditionList()
    }

    // if (props.result?.cnt && props.result?.cnt <= lookCount + 3) {
    //   props.onAdditionList()
    // }else if (props.result?.cnt) {
    //   setLookCount(lookCount + 3 < props.result.cnt ? lookCount + 3 : props.result.cnt)
    // }
  }

  useEffect(() => {
    setLookCount(3)
  }, [props.type])

  return <Fragment>
    {
      result && result.cnt > 0 && <CommonInner>
        <TabPanelTitle>
          <Box component={'a'} onClick={() => {
            window.open(`${process.env.REACT_APP_DOMAIN}/dxp/datause/useStory`, "_blank")
          }}>
            {'데이터 활용 스토리'}
          </Box>
          {
            result?.cnt && <Typography component={'p'}>
              <span className="point">{result?.cnt}</span>
              <span>건</span>
            </Typography>
          }
        </TabPanelTitle>

        <TabPanelConts css={searchCommonInner}>
          <List css={searchListType2} className={lookCount < result.cnt ? 'is-more' : ''}>
            {
              result.collResult.map((item: any, i: number) => {
                if (i >= lookCount) return false;
                return (
                  <ListItem>
                    <Box component={'a'} onClick={() => {
                      window.open(`${item.LINK_URL}`, "_blank")
                    }}>
                      <Box className='left'>
                        <Box className='title'>
                          <Box component={'p'} className='tag'>
                            <Box component={'i'}>
                              <Box component={'span'}>{item.PRODUCT_NM}</Box>
                            </Box>
                          </Box>
                          <Box className='name'>
                            <h3 dangerouslySetInnerHTML={{
                              __html: item.NTT_SJ?.replaceAll('<!HS>', '<b>').replaceAll('<!HE>', '</b>')
                            }}/>
                          </Box>
                        </Box>
                        <Box className='info__box'>
                          <Typography component={'p'} className='info'>
                            <Typography component={'span'}>조회수</Typography>
                            <Typography component={'span'}>{item.RDCNT}</Typography>
                          </Typography>
                          <Typography component={'p'} className='info'>
                            <Typography component={'span'}>{item.FRST_REGIST_PNTTM}</Typography>
                          </Typography>
                        </Box>
                      </Box>
                      <Box className='right'>
                        <Typography component={'p'}>{item.FRST_REGISTER_ID}</Typography>
                      </Box>
                    </Box>
                  </ListItem>
                );
              })
            }
          </List>
          {
            lookCount < result.cnt &&
            <Stack css={(styles.bottom_btn, searchMoreBtn)}>
              <CustomButton
                label={'더보기'}
                type={'full'}
                color={'item'}
                onClick={() => moreInfo()}
              />
            </Stack>
          }
        </TabPanelConts>
      </CommonInner>
    }
  </Fragment>
}

const IcoLock = styled('i')`
  flex-shrink: 0;
  width: 24px;
  height: 24px;
  margin-left: 8px;
  background: url('/images/search/ico_lock.svg') no-repeat center / contain;
`;