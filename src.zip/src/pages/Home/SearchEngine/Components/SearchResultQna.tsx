/* eslint-disable jsx-a11y/alt-text */
import React, {useState, useEffect, Fragment} from 'react';
import * as styles from '~/styles/styles';
import {NavLink} from 'react-router-dom';

import {Stack, Box, Typography, List, ListItem} from '@mui/material';
import {CustomButton} from '~/components/ButtonComponents';

import styled from '@emotion/styled';
import {Color} from '~/components/StyleUtils';
import {breakpoint} from '../../styles/styleCommon';
import {CommonInner, SearchResultQnaSection, searchMoreBtn} from '../styles';
import {CommonListInfo, CountResult} from "~/pages/Home/SearchEngine/Data/dataSearch";
import {css} from "@emotion/react";
import {SearchPortalType, subTitleCss} from "~/pages/Home/SearchEngine/Components/SearchResultTabPanel";

export default function SearchResultQna(props: {
  type: SearchPortalType
  title: string
  titleLink: string
  result?: CountResult<CommonListInfo>
  onAdditionList: () => void
}) {
  const [lookCount, setLookCount] = useState<number>(0);

  const moreInfo = () => {
    if (props.result?.collResult && props.result.collResult.length > lookCount + 3){
      setLookCount(lookCount + 3)
    }else {
      props.onAdditionList()
    }

    // if (props.result?.collResult && props.result?.cnt <= lookCount + 3) {
    //   props.onAdditionList()
    // }else if (props.result?.cnt) {
    //   setLookCount(lookCount + 3 < props.result.cnt ? lookCount + 3 : props.result.cnt)
    // }
  };

  useEffect(() => {
    setLookCount(3)
  }, [props.type])

  return <Fragment>
    {
      props.result && props.result.cnt > 0 && <Fragment>
        <Typography component={'h4'} css={subTitleCss}>
          <Box
            component={'a'}
            onClick={() => {
              window.open(`${props.titleLink}`,'_blank');
            }}
          >
            {props.title}
          </Box>
          <Typography component={'span'}>
            <Typography component={'b'}>
              {props.result.cnt}
            </Typography>
            건
          </Typography>
        </Typography>
        <CommonInner>
          <SearchResultQnaSection>
            <List className={lookCount < props.result.cnt ? 'is-more' : ''}>
              {props.result.collResult.map((item: any, i: number) => {
                if (i >= lookCount) return false;
                return (
                  <ListItem key={i}>
                    <QnaCate>
                      <Typography component={'p'}>{item.CATEGORY_NM}</Typography>
                    </QnaCate>
                    <QnaTitle>
                      {/* 포인트 문구 컬러값 변경해야 함. */}
                      <Box component={'a'} onClick={() => window.open(`${item.LINK_URL}`, "_blank")}>
                        <p dangerouslySetInnerHTML={{
                          __html: item.SJ_NM?.replaceAll('<!HS>', '<b>').replaceAll('<!HE>', '</b>')
                        }}/>
                      </Box>
                    </QnaTitle>
                  </ListItem>
                )
              })}
            </List>
            {
              lookCount < props.result.cnt &&
                <Stack css={(styles.bottom_btn, searchMoreBtn)}>
                  <CustomButton
                    label={'더보기'}
                    type={'full'}
                    color={'item'}
                    onClick={() => moreInfo()}
                  />
                </Stack>
            }
          </SearchResultQnaSection>
        </CommonInner>
      </Fragment>
    }
  </Fragment>
}

const QnaCate = styled('div')`
  flex-shrink: 0;
  width: 20%;
  min-width: 130px;
  padding: 3px 0 0 30px;

  @media (max-width: ${breakpoint.mobile}) {
    width: 100%;
    min-width: auto;
    padding: 0 0 0 15px;
  }

  p {
    font-size: 16px;
    font-weight: 500;
    color: ${Color.black};
    letter-spacing: -0.06em;

    @media (max-width: ${breakpoint.mobile}) {
      margin-bottom: 12px;
      font-size: 14px;
      line-height: 20px;
    }
  }
`;
const QnaTitle = styled('div')`
  @media (min-width: ${breakpoint.minMobile}) and (max-width: ${breakpoint.desk1280}) {
    padding-left: 20px;
  }

  @media (max-width: ${breakpoint.mobile}) {
    padding-left: 15px;
  }

  a {
    display: inline-flex;

    &::before {
      content: 'Q';
      flex-shrink: 0;
      font-weight: 700;
      color: ${Color.azul};

      @media (min-width: ${breakpoint.minMobile}) {
        margin-right: 10px;
        font-size: 22px;
        line-height: 28px;
      }

      @media (max-width: ${breakpoint.mobile}) {
        margin-right: 8px;
        font-size: 18px;
        line-height: 20px;
      }
    }

    p {
      display: -webkit-box;
      max-width: 100%;
      font-weight: 700;
      color: ${Color.black};
      letter-spacing: -0.06em;
      text-overflow: ellipsis;
      overflow: hidden;
      -webkit-box-orient: vertical;

      @media (min-width: ${breakpoint.minMobile}) {
        max-height: 28px;
        padding-right: 30px;
        font-size: 18px;
        line-height: 28px;
        -webkit-line-clamp: 1;
      }

      @media (max-width: ${breakpoint.mobile}) {
        max-height: 48px;
        padding-right: 15px;
        font-size: 16px;
        line-height: 24px;
        -webkit-line-clamp: 2;
      }

      b {
        color: ${Color.topaz};
      }
    }
  }


`;