/* eslint-disable jsx-a11y/alt-text */
import * as React from 'react';

import {Box, Typography, Tabs, Tab} from '@mui/material';
import styled from '@emotion/styled';
import {css} from '@emotion/react';
import {Color} from '~/components/StyleUtils';
import {breakpoint} from '../../styles/styleCommon';

import {SearchResult} from '../Data/dataSearch';
import SearchA11yProps from './SearchA11yProps';
import {useEffect, useState} from "react";
import {WisenutResponese} from "~/pages/Home/SearchEngine/SearchService";

export default function SearchResultTab(props: {
  data: WisenutResponese<SearchResult>
  tabsIdx: number
  evtTabsChange: (evt: React.SyntheticEvent, currIdx: number) => void
}) {
  const [data, setData] = useState(initData)
  const TabCount = (tabName: string) => {
    let count = 0;
    switch (tabName) {
      case '전체':
        count =  props.data?.totalCnt || 0
        break
      case '사용자지원':
        count = props.data.result?.USP_PBLANC?.cnt || 0
        count += props.data.result?.USP_EVENT?.cnt || 0
        count += props.data.result?.USP_QESTN?.cnt || 0
        count += props.data.result?.USP_NOTICE?.cnt || 0
        break
      case '실증지원':
        count = props.data.result?.TSP_QESTN?.cnt || 0
        count += props.data.result?.TSP_NOTICE?.cnt || 0
        break
      case '안심구역':
        count = props.data.result?.SAZ_QESTN?.cnt || 0
        count += props.data.result?.SAZ_NOTICE?.cnt || 0
        break
      case '데이터유통':
        count = props.data.result?.DXP_FAQ?.cnt || 0
        count += props.data.result?.DXP_NOTICE?.cnt || 0
        count += props.data.result?.DXP_PRMTNMV?.cnt || 0
        count += props.data.result?.DXP_DTSTRY?.cnt || 0
        count += props.data.result?.DXP_CNTSTMNG?.cnt || 0
        count += props.data.result?.DXP_EVENTCATEGORY?.cnt || 0
        count += props.data.result?.DXP_DATAPRODUCT?.cnt || 0
        count += props.data.result?.DXP_DATASET?.cnt || 0
    }

    return count
  }

  useEffect(() => {
    setData(data.map(m => {
      return {
        ...m,
        count: TabCount(m.name)
      }
    }))
  }, [props.data])

  return (
    <Box>
      <Tabs
        value={props.tabsIdx}
        onChange={props.evtTabsChange}
        variant="scrollable"
        scrollButtons={false}
        aria-label="검색 구분"
        css={resultTabsCss}
      >
        {data.map((data, i) => {
          return (
            <Tab
              key={i}
              css={resultTabBtnCss}
              wrapped={true}
              label={
                <b>
                  <span className={'name'}>{data.name}</span>
                  <span className={'total'}>{data.count}</span>
                </b>
              }
              {...SearchA11yProps(i)}
            />
          );
        })}
      </Tabs>
    </Box>
  );
}

const initData = [
  {name: '전체', count: 0},
  {name: '사용자지원', count: 0},
  {name: '실증지원', count: 0},
  {name: '안심구역', count: 0},
  {name: '데이터유통', count: 0},
  {name: 'AI교육', count: 0}
]

const resultTabsCss = css`
  position: relative;
  width: 100%;
  min-height: auto;
  overflow: hidden;
  transition: padding 0.3s;

  button {
    min-width: auto;
    max-width: none;
    height: auto;
    min-height: auto;
    padding: 0;
    font-size: 0;

    @media (max-width: ${breakpoint.desk1280}) {
      &:first-of-type {
        padding-left: 20px;
      }

      &:last-of-type {
        padding-right: 20px;
      }
    }
    @media (max-width: ${breakpoint.mobile}) {
      &:first-of-type {
        padding-left: 15px;
      }

      &:last-of-type {
        padding-right: 15px;
      }
    }
  }

  .MuiTabs-indicator {
    display: none;
  }

  @media (min-width: 1201px) {
    .is-scroll-dw &,
    .is-scroll-up & {
      padding-top: 32px;
    }
  }
  @media (max-width: 1200px) {
    .is-scroll-dw & {
      padding-top: 15px;
    }

    .is-scroll-up & {
      padding-top: 30px;
    }
  }
`;
const resultTabBtnCss = css`
  > b {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 48px;
    padding: 0 32px;
    background: ${Color.line};
    border-radius: 10px 10px 0 0;

    .name,
    .total {
      font-weight: 400;
      color: ${Color.warm_gray};
      letter-spacing: -0.06em;
    }

    .name {
      font-size: 16px;
      line-height: 24px;
    }

    .total {
      margin-left: 4px;
      font-size: 14px;
      line-height: 17px;
    }

    @media (max-width: ${breakpoint.mobile}) {
      height: 40px;
      padding: 0 24px;

      .name {
        font-size: 14px;
        line-height: 20px;
      }

      .total {
        font-size: 12px;
        line-height: 14px;
      }
    }
  }

  .MuiTouchRipple-root {
    display: none;
  }

  &.Mui-selected {
    color: transparent;

    > b {
      background: ${Color.white};

      .name,
      .total {
        font-weight: 500;
      }

      .name {
        color: ${Color.black};
      }

      .total {
        color: ${Color.azul};
      }
    }
  }

  & + button {
    margin-left: 1px;
  }
`;