/* eslint-disable jsx-a11y/alt-text */
import * as React from 'react';
import {useState, useEffect, useRef, Fragment} from 'react';
import {NavLink} from 'react-router-dom';

import {Box, Typography} from '@mui/material';
import styled from '@emotion/styled';
import {css} from '@emotion/react';
import {Color} from '~/components/StyleUtils';
import {breakpoint} from '../../styles/styleCommon';
import {
  CommonInner,
  TabPanelGroup,
  TabPanelTitle,
  TabPanelConts,
} from '../styles';

import {
  TabPanelProps,
  searchResultData,
  SearchResult,
} from '../Data/dataSearch';
import SearchResultRecruit from './SearchResultRecruit';
import SearchResultEvent from './SearchResultEvent';
import SearchResultQna from './SearchResultQna';
import SearchResultNotice from './SearchResultNotice';
import SearchResultInquiry from './SearchResultInquiry';
import SearchResultMovie from './SearchResultMovie';
import SearchResultDataStrory from './SearchResultDataStrory';
import SearchResultAward from './SearchResultAward';
import SearchResultEvtinfo from './SearchResultEvtinfo';
import SearchResultProduct from './SearchResultProduct';
import SearchResultDataset from './SearchResultDataset';

export default function SearchResultTabPanel(props: {
  tabsIdx: number
  result?: Partial<SearchResult>
  onAdditionList: (collection: keyof SearchResult) => Promise<void>
}) {
  const PortalType = () => {
    switch (props.tabsIdx){
      case 0: return 'ALL'
      case 1: return 'USP'
      case 2: return 'TSP'
      case 3: return 'SAZ'
      case 4: return 'DXP'
      case 5: return 'LMS'
    }
    return 'ALL'
  }
  return (
    <Box css={containerCss}>
      <TabPanel value={props.tabsIdx} index={0}>
        <TabContoller type={PortalType()} {...props}/>
      </TabPanel>
      <TabPanel value={props.tabsIdx} index={1}>
        <TabContoller type={PortalType()} {...props}/>
      </TabPanel>
      <TabPanel value={props.tabsIdx} index={2}>
        <TabContoller type={PortalType()} {...props}/>
      </TabPanel>
      <TabPanel value={props.tabsIdx} index={3}>
        <TabContoller type={PortalType()} {...props}/>
      </TabPanel>
      <TabPanel value={props.tabsIdx} index={4}>
        <TabContoller type={PortalType()} {...props}/>
      </TabPanel>
      <TabPanel value={props.tabsIdx} index={5}>
        <TabContoller type={PortalType()} {...props}/>
      </TabPanel>
    </Box>
  );
}

export type SearchPortalType = 'ALL' | 'USP' | 'TSP' | 'SAZ' | 'DXP' | 'LMS'

function TabContoller(props: {
  type: SearchPortalType
  result?: Partial<SearchResult>
  onAdditionList: (collection: keyof SearchResult) => Promise<void>
}) {
  const [qestnCount, setQestnCount] = useState<number>(0);
  const [noticeCount, setNoticeCount] = useState<number>(0);
  const [changeNotice, setChangeNotice] = useState<never[]>([])
  useEffect(() => {
    let noticeCount = 0
    let qestCount = 0
    if (props.type == 'ALL' || props.type == 'USP') {
      noticeCount += Number(props.result?.USP_NOTICE?.cnt)
      qestCount += Number(props.result?.USP_QESTN?.cnt)
    }
    if (props.type == 'ALL' || props.type == 'TSP') {
      noticeCount += Number(props.result?.TSP_NOTICE?.cnt)
      qestCount += Number(props.result?.TSP_QESTN?.cnt)
    }
    if (props.type == 'ALL' || props.type == 'SAZ') {
      noticeCount += Number(props.result?.SAZ_NOTICE?.cnt)
      qestCount +=  Number(props.result?.SAZ_QESTN?.cnt)
    }
    if (props.type == 'ALL' || props.type == 'DXP') {
      noticeCount += Number(props.result?.DXP_NOTICE?.cnt)
    }

    setNoticeCount(noticeCount)
    setQestnCount(qestCount)

    return () => {
      setQestnCount(0);
      setNoticeCount(0);
    };
  }, [props.result, props.type]);

  return <Fragment>

    {
      (props.type == 'ALL' || props.type == 'USP') && <Fragment>
        {/* 모집공고 */}
        <SearchResultRecruit type={props.type} result={props.result?.USP_PBLANC}/>
        {/* 행사/이벤트 */}
        <SearchResultEvent type={props.type} result={props.result?.USP_EVENT}/>
      </Fragment>
    }

    {/* 자주믇는질문 */}
    {
      qestnCount > 0 && <CommonInner css={commonInnerPb}>
        <Typography component={'h3'} css={mainTitleCss}>
          자주묻는질문
        </Typography>

        {
          (props.type == 'ALL' || props.type == 'USP') &&
          <SearchResultQna
            type={props.type}
            title={'사용자지원'}
            titleLink={`${process.env.REACT_APP_DOMAIN}/SupportForUse/FrequentlyAskedQuestions`}
            result={props.result?.USP_QESTN}
            onAdditionList={() => props.onAdditionList('USP_QESTN')}
          />
        }

        {
          (props.type == 'ALL' || props.type == 'TSP') &&
          <SearchResultQna
            type={props.type}
            title={'실증지원'}
            titleLink={`${process.env.REACT_APP_DOMAIN}/tsp/About/FAQ`}
            result={props.result?.TSP_QESTN}
            onAdditionList={() => props.onAdditionList('TSP_QESTN')}
          />
        }

        {
          (props.type == 'ALL' || props.type == 'SAZ') &&
          <SearchResultQna
            type={props.type}
            title={'안심구역'}
            titleLink={`${process.env.REACT_APP_DOMAIN}/saz/component/bbs/faq/index.do`}
            result={props.result?.SAZ_QESTN}
            onAdditionList={() => props.onAdditionList('SAZ_QESTN')}
          />
        }
      </CommonInner>
    }

    {/* 공지사항 */}
    {noticeCount > 0 && (
      <CommonInner css={commonInnerPb}>
        <Typography component={'h3'} css={mainTitleCss}>
          공지사항
        </Typography>

        {
          (props.type == 'ALL' || props.type == 'USP') &&
          <SearchResultNotice
            title={'사용자지원'}
            type={props.type}
            titleLink={`${process.env.REACT_APP_DOMAIN}/Notice/Announcement`}
            result={props.result?.USP_NOTICE}
            onAdditionList={() => props.onAdditionList('USP_NOTICE')}
          />
        }

        {
          (props.type == 'ALL' || props.type == 'TSP') &&
          <SearchResultNotice
            title={'실증지원'}
            type={props.type}
            titleLink={`${process.env.REACT_APP_DOMAIN}/tsp/About/Notice`}
            result={props.result?.TSP_NOTICE}
            onAdditionList={() => props.onAdditionList('TSP_NOTICE')}
          />
        }

        {
          (props.type == 'ALL' || props.type == 'SAZ') &&
          <SearchResultNotice
            title={'안심구역'}
            type={props.type}
            titleLink={`${process.env.REACT_APP_DOMAIN}/saz/component/bbs/notice/index.do`}
            result={props.result?.SAZ_NOTICE}
            onAdditionList={() => props.onAdditionList('SAZ_NOTICE')}
          />
        }

        {
          (props.type == 'ALL' || props.type == 'DXP') &&
          <SearchResultNotice
            dxp title={'데이터유통포털'}
            type={props.type}
            titleLink={`${process.env.REACT_APP_DOMAIN}/dxp/community/notice`}
            result={props.result?.DXP_NOTICE}
            onAdditionList={() => props.onAdditionList('DXP_NOTICE')}
          />
        }
      </CommonInner>
    )}

    {
      (props.type == 'ALL' || props.type == 'DXP') && <Fragment>
        {/* 홍보 동영상 */}
        <SearchResultMovie type={props.type} result={props.result?.DXP_PRMTNMV}/>

        {/* 데이터 활용 스토리 */}
        <SearchResultDataStrory
          type={props.type}
          result={props.result?.DXP_DTSTRY}
          onAdditionList={() => props.onAdditionList('DXP_DTSTRY')}
        />

        {/* 공모전 결과 */}
        <SearchResultAward type={props.type} result={props.result?.DXP_CNTSTMNG}/>

        {/* 이벤트 (유통 - 행사안내) */}
        <SearchResultEvtinfo
          type={props.type}
          result={props.result?.DXP_EVENTCATEGORY}
          onAdditionList={() => props.onAdditionList('DXP_EVENTCATEGORY')}
        />

        {/* 유통 데이터 상품 */}
        <SearchResultProduct
          type={props.type}
          result={props.result?.DXP_DATAPRODUCT}
          onAdditionList={() => props.onAdditionList('DXP_DATAPRODUCT')}
        />

        {/* 데이터셋 */}
        <SearchResultDataset
          type={props.type}
          result={props.result?.DXP_DATASET}
          onAdditionList={() => props.onAdditionList('DXP_DATASET')}
        />
      </Fragment>
    }
  </Fragment>
}

function TabPanel(props: TabPanelProps) {
  const {children, value, index, ...other} = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`searchResult-tabpanel-${index}`}
      aria-labelledby={`searchResult-tab-${index}`}
      {...other}
    >
      {children}
    </div>
  );
}

const containerCss = css`
  margin-top: 60px;

  @media (max-width: ${breakpoint.mobile}) {
    margin-top: 40px;
  }
`;

const mainTitleCss = css`
  font-size: 28px;
  font-weight: 700;
  color: ${Color.black};
  letter-spacing: -0.06em;

  @media (min-width: ${breakpoint.minMobile}) and (max-width: ${breakpoint.desk1280}) {
    padding: 0 20px;
  }

  @media (max-width: ${breakpoint.mobile}) {
    padding: 0 15px;
    font-size: 22px;
  }
`;
export const subTitleCss = css`
  display: flex;
  align-items: flex-end;
  margin-top: 20px;
  color: ${Color.black};
  letter-spacing: -0.06em;

  @media (min-width: ${breakpoint.minMobile}) and (max-width: ${breakpoint.desk1280}) {
    padding: 0 20px;
  }

  @media (max-width: ${breakpoint.mobile}) {
    padding: 0 15px;
  }

  a {
    display: flex;
    font-size: 20px;
    font-weight: 700;
    line-height: 30px;

    @media (max-width: ${breakpoint.mobile}) {
      font-size: 18px;
      line-height: 28px;
    }

    &::after {
      content: '';
      width: 24px;
      height: 24px;
      margin-top: 4px;
      background: url('/images/search/ico_search_arr_right.svg') no-repeat
        center / contain;

      @media (max-width: ${breakpoint.mobile}) {
        margin-top: 3px;
      }
    }
  }

  span {
    padding-bottom: 2px;
    font-size: 16px;
    font-weight: 400;

    b {
      padding-left: 2px;
      font-weight: 700;
      color: ${Color.azul};
    }
  }
`;
const commonInnerPb = css`
  padding-bottom: 50px;

  @media (max-width: ${breakpoint.mobile}) {
    padding-bottom: 30px;
  }
`;
