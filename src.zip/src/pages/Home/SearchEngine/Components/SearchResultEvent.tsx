/* eslint-disable jsx-a11y/alt-text */
import * as React from 'react';
import {useEffect, useState, useRef, Fragment} from 'react';
import {NavLink} from 'react-router-dom';

import SearchSwiperEvent from './SearchSwiperEvent';

import {Box, Typography, List, ListItem, CardMedia} from '@mui/material';

import styled from '@emotion/styled';
import {css} from '@emotion/react';
import {Color} from '~/components/StyleUtils';
import {breakpoint} from '../../styles/styleCommon';
import {
  TabPanelGroup,
  CommonInner,
  SearchResultEventSection,
  SearchIconEventIng,
  TabPanelConts,
  searchThumbIcon, TabPanelTitle,
} from '../styles';
import {eventTitle} from '../styleCssCommon';

import {EventInfo} from "~/pages/Home/SearchEngine/Data/dataSearch";
import * as common from "~/CommonFunction";

export default function SearchResultEvent(props: any) {
  const {result} = props;

  return <Fragment>
    {
      result && result.cnt > 0&& <TabPanelGroup key={'event'}>
        <CommonInner>
          <TabPanelTitle>
            <Box component={'a'} onClick={() => {
              window.open(`${process.env.REACT_APP_DOMAIN}/EventNews/HonsaEvent`, "_blank")
            }}>
              {'행사/이벤트'}
            </Box>
            {
              result?.cnt && <Typography component={'p'}>
                <span className="point">{result?.cnt}</span>
                <span>건</span>
              </Typography>
            }
          </TabPanelTitle>
        </CommonInner>

        <TabPanelConts>
          <CommonInner>
            <SearchResultEventSection>
              <SearchSwiperEvent data={result?.collResult || []} type="event"/>
            </SearchResultEventSection>
          </CommonInner>
        </TabPanelConts>
      </TabPanelGroup>
    }
  </Fragment>
}

const EventThumb = styled('div')`
  position: relative;
  height: 200px;
  margin: 0;
  padding: 0;
  border-radius: 15px 15px 10px 10px;
  overflow: hidden;

  > img {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    margin: auto;
  }

  @media (max-width: 1260px) {
    height: 0;
    padding-bottom: 66.66%;
  }

  /* figure {
    height: 200px;
    margin: 0;
    padding: 0;
    background: no-repeat center / cover;
    border-radius: 15px 15px 10px 10px;

    @media (max-width: 1260px) {
      height: 0;
      padding-bottom: 66.66%;
    }
  } */
`;
const EventTitle = styled('h3')`
  height: 64px;
  margin: 20px 0 15px;
  font-size: 20px;
  font-weight: 700;
  color: ${Color.black};
  line-height: 32px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;

  @media (max-width: ${breakpoint.mobile}) {
    height: 60px;
    margin-bottom: 10px;
    font-size: 18px;
    line-height: 30px;
  }
`;
const EventInfoDiv = styled('div')`
  display: flex;
  align-items: center;

  > p {
    display: flex;
    align-items: center;

    &:not(:first-of-type) {
      &::before {
        content: '';
        display: block;
        width: 1px;
        height: 12px;
        margin: 0 8px;
        background: ${Color.gray};
      }
    }

    span {
      font-size: 14px;
      font-weight: 400;
      color: ${Color.warm_gray};
      line-height: 20px;
      letter-spacing: -0.06em;

      &.point {
        color: ${Color.black};
      }

      &:not(:only-child):first-of-type {
        margin-right: 6px;
      }
    }
  }

  & + & {
    margin-top: 5px;

    @media (max-width: ${breakpoint.mobile}) {
      margin-top: 4px;
    }
  }
`;
