/* eslint-disable jsx-a11y/alt-text */
import * as React from 'react';

import {Box} from '@mui/material';
import styled from '@emotion/styled';
import {SearchKeywordContainer} from '../styles';
import {breakpoint} from '../../styles/styleCommon';

import SearchKeywordItemBtn from './SearchKeywordItemBtn';
import {SearchService} from "~/pages/Home/SearchEngine/SearchService";
import {useEffect, useState} from "react";

export default function SearchKeywordRelation(props: any) {
  const [keywordsRelation, setKeywordsRelation] = useState<string[]>([])
  // const query = SearchService.GetSearchArk({
  //   target: 'common',
  //   convert: 'fw',
  //   charset: 'utf8',
  //   datatype: 'json',
  //   query: props.searchValue?.replace(/ /g, '')
  // })
  const query = SearchService.GetSearchRecommend({
    target: 'recommend',
    label: '_ALL_',
    datatype: 'json',
    query: props.searchValue?.replace(/ /g, '')
  })

  useEffect(() => {
    if (!query.isLoading && !query.isFetching) {
      if (!!query.data) {
        // const keywords = query.data.result?.fw?.items?.flatMap(m => m.keyword) || []
        const keywords = query.data.result || []
        setKeywordsRelation(keywords.slice(0,5))
        if (props.onSearchComplete) props.onSearchComplete()
      }
    }
  }, [query.data, query.isLoading, query.isFetching])

  useEffect(() => {
    if (props.onCahngeRelation){
      props.onCahngeRelation(keywordsRelation)
    }
  },[keywordsRelation])

  return (
    <Box css={SearchKeywordContainer}>
      {
        keywordsRelation.length > 0 && (
          <KeywordItemList>
            {keywordsRelation.map((item, i) => (
              <li key={i}>
                <SearchKeywordItemBtn
                  type={'relation'}
                  itemTxt={item}
                  evtClick={props.evtHashClick}
                />
              </li>
            ))}
          </KeywordItemList>
        )
      }
    </Box>
  )
}

const KeywordItemList = styled('ul')`
  .search-result.--keyword-absolute + .--keyword-flex & {
    height: 66px;
    padding-top: 30px;
    transition: height 0.3s, padding 0.3s;

    @media (max-width: ${breakpoint.mobile}) {
      height: 52px;
      padding-top: 16px;
    }

    @media (min-width: 1201px) {
      .is-scroll-dw &,
      .is-scroll-up & {
        height: 0;
        padding-top: 0;
      }
    }
    @media (max-width: 1200px) {
      .is-scroll-dw &,
      .is-scroll-up & {
        height: 0;
        padding-top: 0;
      }
    }
  }
  .--keyword-absolute & {
    /* padding-bottom: 10px; */
  }

  /* margin-top: 30px;
  transition: margin 0.3s;

  @media (max-width: ${breakpoint.mobile}) {
    margin-top: 16px;
  }

  @media (min-width: 1201px) {
    .is-scroll-dw &,
    .is-scroll-up & {
      margin-top: 0;
    }
  }
  @media (max-width: 1200px) {
    .is-scroll-dw &,
    .is-scroll-up & {
      margin-top: 0;
    }
  } */
`;
