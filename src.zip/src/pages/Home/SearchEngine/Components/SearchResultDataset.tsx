/* eslint-disable jsx-a11y/alt-text */
import React, {useState, useEffect, Fragment} from 'react';
import * as styles from '~/styles/styles';
import {css} from '@emotion/react';

import {
  Box,
  Stack,
  List,
  ListItem,
  Typography
} from '@mui/material';
import {Color} from '~/components/StyleUtils';
import {breakpoint} from '../../styles/styleCommon';
import {CustomButton} from '~/components/ButtonComponents';

import styled from '@emotion/styled';
import {
  CommonInner,
  TabPanelTitle,
  TabPanelConts,
  searchMoreBtn,
  searchCommonInner,
  searchListType1,
} from '../styles';
import {CountResult, DxpDataSet, DxpDtstry} from "~/pages/Home/SearchEngine/Data/dataSearch";
import {SearchPortalType} from "~/pages/Home/SearchEngine/Components/SearchResultTabPanel";

export default function SearchResultDataset(props: {
  type: SearchPortalType
  result?: CountResult<DxpDataSet>
  onAdditionList: () => Promise<void>
}) {
  const {result} = props;

  const [lookCount, setLookCount] = useState<number>(0);

  const moreInfo = async () => {
    if (props.result && props.result.collResult.length > lookCount + 3){
      setLookCount(lookCount + 3)
    }else {
      if (props.result && props.result.cnt > props.result.collResult.length + 3){
        await props.onAdditionList()
        setLookCount(lookCount + 3)
      } else if (props.result?.cnt){
        setLookCount(props.result.cnt)
      }
    }

    // if (props.result?.cnt && props.result?.cnt <= lookCount + 3) {
    //   props.onAdditionList()
    // }else if (props.result?.cnt) {
    //   setLookCount(lookCount + 3 < props.result.cnt ? lookCount + 3 : props.result.cnt)
    // }
  };

  useEffect(() => {
    setLookCount(3)
  }, [props.type])

  return <Fragment>
    {
      result && result.cnt > 0 && <CommonInner>
        <TabPanelTitle>
          <Box component={'a'} onClick={() => {
            window.open(`${process.env.REACT_APP_DOMAIN}/dxp/data/searchProduct`, "_blank")
          }}>
            {'데이터셋'}
          </Box>
          {
            result?.cnt && <Typography component={'p'}>
              <span className="point">{result?.cnt}</span>
              <span>건</span>
            </Typography>
          }
        </TabPanelTitle>

        <TabPanelConts css={searchCommonInner}>
          <List css={searchListType1} className={lookCount < result.cnt ? 'is-more' : ''}>
            {
              result.collResult.map((item: any, i: number) => {
                
                const cateDepthArr = [item.LCLAS_NM.length, item.MLSFC_NM.length, item.SCLAS_NM.length, item.DTLCLFC_NM.length]
                let cateDapthNum = cateDepthArr.indexOf(0);

                if (i >= lookCount) return false;
                
                return (
                  <ListItem>
                    <Box component={'a'} css={dataSetElem}
                         onClick={() => {
                           window.open(`${item.LINK_URL}`, "_blank")
                         }}>

                      <List>
                        <ListItem className='left'>
                          <Box className='flag-cate'>
                            <Box className='flag'>
                              <Box component={'i'}>
                                <Typography component={'span'}>카테고리</Typography>
                              </Box>
                            </Box>
                            <Box className='cate'>
                              <Box className='list'>
                                <Box className={`item ${(cateDapthNum === 0 || cateDapthNum === 1) && "cate0"}`}>
                                  {/* <Typography component={'p'}>{item.LCLAS_NM}</Typography> */}
                                  <p dangerouslySetInnerHTML={{
                                    __html: item.LCLAS_NM?.replaceAll('<!HS>', '<b>').replaceAll('<!HE>', '</b>')
                                  }}/>
                                </Box>
                                <Box className={`item ${cateDapthNum === 2 && "cate1"}`}>
                                  {/* <Typography component={'p'}>{item.MLSFC_NM}</Typography> */}
                                  <p dangerouslySetInnerHTML={{
                                    __html: item.MLSFC_NM?.replaceAll('<!HS>', '<b>').replaceAll('<!HE>', '</b>')
                                  }}/>
                                </Box>
                                <Box className={`item ${cateDapthNum === 3 && "cate2"}`}>
                                  {/* <Typography component={'p'}>{item.SCLAS_NM}</Typography> */}
                                  <p dangerouslySetInnerHTML={{
                                    __html: item.SCLAS_NM?.replaceAll('<!HS>', '<b>').replaceAll('<!HE>', '</b>')
                                  }}/>
                                </Box>
                                <Box className='item'>
                                  {/* <Typography component={'p'}>{item.DTLCLFC_NM}</Typography> */}
                                  <p dangerouslySetInnerHTML={{
                                    __html: item.DTLCLFC_NM?.replaceAll('<!HS>', '<b>').replaceAll('<!HE>', '</b>')
                                  }}/>
                                </Box>
                              </Box>
                            </Box>
                          </Box>

                          <Box className='title'>
                            <h3 dangerouslySetInnerHTML={{
                              __html: item.DSET_NM?.replaceAll('<!HS>', '<b>').replaceAll('<!HE>', '</b>')
                            }}/>
                          </Box>

                          <List className='info'>
                            <ListItem>
                              <Typography component={'p'}>등록일</Typography>
                              <Typography component={'p'}>{item.FRST_REGIST_PNTTM}</Typography>
                            </ListItem>
                          </List>

                        </ListItem>
                        <ListItem className='right'>
                          <Typography component={'p'} dangerouslySetInnerHTML={{
                            __html: item.PROVD_INSTT_NM?.replaceAll('<!HS>', '<b>').replaceAll('<!HE>', '</b>')
                          }}/>
                        </ListItem>
                      </List>
                    </Box>
                  </ListItem>
                );
              })
            }
          </List>

          {/*
          1. 4개 이상일 때 더보기 버튼 노출 
          2. 더 보여줘야 할 정보 없을 때는 미노출
         */}
          {
            lookCount < result.cnt &&
            <Stack css={(styles.bottom_btn, searchMoreBtn)}>
              <CustomButton
                label={'더보기'}
                type={'full'}
                color={'item'}
                onClick={() => moreInfo()}
              />
            </Stack>
          }
        </TabPanelConts>
      </CommonInner>
    }
  </Fragment>
}

const dataSetElem = css`
  display: block !important;

  ul,
  li {
    display: flex;
    margin: 0;
    padding: 0;
  }

  @media (max-width: ${breakpoint.mobile}) {
    > ul {
      flex-direction: column;
    }
  }

  p,
  span {
    color: ${Color.black};
    letter-spacing: -0.06em;
  }

  li {
    width: auto;

    &.left {
      align-items: flex-start;
      flex-direction: column;
      max-width: none;

      .title {
        max-width: 100%;
        padding: 8px 0;

        @media (max-width: ${breakpoint.mobile}) {
          padding-top: 6px;
        }

        h3 {
          font-size: 20px;
          font-weight: 700;
          color: #222;
          line-height: 30px;
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;

          > b {
            color: ${Color.topaz};
          }

          @media (max-width: ${breakpoint.mobile}) {
            font-size: 16px;
            line-height: 24px;
          }
        }
      }

      .info {
        margin-top: 0;

        > li {
          p {
            font-size: 14px;
            font-weight: 400;
            line-height: 20px;

            &:not(:only-of-type):first-of-type {
              margin-right: 6px;
              color: ${Color.warm_gray};
            }
          }
        }
      }

      .flag {
        @media (min-width: ${breakpoint.minMobile}) {
          flex-shrink: 0;
        }

        @media (max-width: ${breakpoint.mobile}) {
          display: flex;
        }

        > i {
          display: flex;
          align-items: center;
          height: 30px;
          background: #f5f5f5;
          padding: 0 10px;
          border-radius: 5px;

          span {
            font-size: 14px;
            font-weight: 400;
            line-height: 20px;
          }
        }

        &-cate {
          width: 100%;
          overflow: hidden;

          @media (min-width: ${breakpoint.minMobile}) {
            display: flex;
            align-items: center;
          }
        }
      }

      .cate {
        overflow: hidden;

        @media (min-width: ${breakpoint.minMobile}) {
          flex-grow: 1;
          margin-left: 12px;
        }

        @media (max-width: ${breakpoint.mobile}) {
          margin-top: 12px;
        }

        .list {
          display: flex;
          width: 100%;
          overflow: hidden;
        }

        .item {
          display: flex;

          &:nth-of-type(4) {
            > p {
              font-weight: 500;
              color: ${Color.navy};
            }
          }

          @media (min-width: ${breakpoint.minMobile}) {
            &:nth-of-type(1),
            &:nth-of-type(2) {
              max-width: calc(10% + 23px);
            }

            &:nth-of-type(3) {
              max-width: calc(15% + 23px);
            }

            &:nth-of-type(4) {
              max-width: calc(65% - 69px);
            }
          }

          @media (max-width: ${breakpoint.mobile}) {
            &:nth-of-type(1) {
              max-width: calc(20% + 23px);
            }

            &:nth-of-type(2),
            &:nth-of-type(3) {
              max-width: calc(10% + 23px);
            }

            &:nth-of-type(4) {
              max-width: calc(60% - 69px);
            }
          }

          > p {
            font-size: 14px;
            font-weight: 400;
            line-height: 20px;
            text-overflow: ellipsis;
            white-space: nowrap;
            overflow: hidden;
            
            b {
              font-weight: 400;
              color: #1ccdcc;
            }
          }

          &:not(:last-of-type) {
            &::after {
              content: "";
              flex-shrink: 0;
              width: 11px;
              height: 11px;
              background: url('/images/search/ico_arrow_left_ccc_11x7.svg') no-repeat center/contain;
              margin: 5px 6px 0;
            }
          }
          
          &.cate0,
          &.cate0 ~ .item,
          &.cate1,
          &.cate1 ~ .item,
          &.cate2,
          &.cate2 ~ .item {
            &::after {
              display: none;
            }
          }
        }
      }
    }

    &.right {
      display: flex;
      justify-content: center;
      align-items: center;
      flex-shrink: 0;
      width: 30.48%;
      max-width: 256px;
      padding: 0 30px;

      @media (max-width: ${breakpoint.mobile}) {
        align-items: flex-start;
        width: 100%;
        max-width: 100%;
        margin-top: 16px;
        padding: 0;
      }

      > p {
        display: -webkit-box;
        width: 100%;
        max-height: 56px;
        font-size: 16px;
        font-weight: 500;
        line-height: 28px;
        text-align: center;
        overflow: hidden;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;

        @media (max-width: ${breakpoint.mobile}) {
          text-align: left;
        }
      }
    }
  }
`