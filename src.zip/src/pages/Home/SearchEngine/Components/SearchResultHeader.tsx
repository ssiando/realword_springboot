/* eslint-disable jsx-a11y/alt-text */
import * as React from 'react';
import clsx from 'clsx';
import {useEffect, useState, useRef} from 'react';
import {NavLink} from 'react-router-dom';

import {Box} from '@mui/material';
import styled from '@emotion/styled';
import {css} from '@emotion/react';
import {Color} from '~/components/StyleUtils';
import {breakpoint} from '../../styles/styleCommon';
import {CommonInner, screenOut} from '../styles';

import {searchKeywordsRelation, searchResultInfo} from '../Data/dataSearch';
import {useScrollStore, useWindowDimensions} from "shared/store/ScrollStore";
import SearchBar from '../Components/SearchBar';
import SearchKeywordRelation from './SearchKeywordRelation';
import SearchResultMsg from './SearchResultMsg';
import SearchResultNotMsg from './SearchResultNotMsg';
import SearchResultTab from './SearchResultTab';
import SearchResultCondition from './SearchResultCondition';
import {useScroll} from "shared/components/useScroll";

export default function SearchResultHeader(props: any) {
  const {scrollDirection, searchResultRef} = props;
  const searchHeaderRef = useRef<any>();
  const [isScrollActive, setIsScrollActive] = useState<boolean>(false);
  const [isScrollDirec, setIsScrollDirec] = useState<string>('');
  const {isContraction, scrollY} = useScroll()

  const headerCss = css`
    position: sticky;
    top: 0;
    background: ${Color.darkbg};
    z-index: 100;

    /* &.is-not-scroll {
      position: static;
    } */
  `;

  const handleScrollDirec = () => {
    if (isContraction) {
      // 스크롤 위치값 0이 아닐 때
      if (isScrollActive) {
        if (scrollDirection === 'up') {
          isScrollActive
           ? setIsScrollDirec('is-scroll-up')
           : setIsScrollDirec('is-not-scroll')

        } else if (scrollDirection === 'down') {
          isScrollActive
           ? setIsScrollDirec('is-scroll-dw')
           : setIsScrollDirec('is-not-scroll')
        }
      }
        
    } else {
      // 스크롤 위치값 0일 때
      isScrollActive ? setIsScrollDirec('') : setIsScrollDirec('is-not-scroll');
    }
    
    // if (!isContraction) {
    //   if (scrollY === 0) {
    //     setIsScrollDirec('');
    //   } else {
    //     scrollDirection === 'up'
    //       ? setIsScrollDirec('is-scroll-up')
    //       : setIsScrollDirec('is-scroll-dw');
    //   }
    // } else {
    //   setIsScrollDirec('is-not-scroll');
    // }
  };

  useEffect(() => {
    let containerH = 0;

    const containerW = window.innerWidth;
    const contensH = searchHeaderRef.current.clientHeight;

    containerW > 1200
      ? (containerH = searchResultRef.current.clientHeight * 0.3)
      : (containerH = searchResultRef.current.clientHeight * 0.2);

    containerH > contensH ? setIsScrollActive(true) : setIsScrollActive(false);

    window.addEventListener('resize', handleScrollDirec);
    return window.removeEventListener('resize', handleScrollDirec);
  });

  useEffect(() => {
    handleScrollDirec();
  }, [scrollY, scrollDirection]);

  return (
    <Box ref={searchHeaderRef} css={headerCss} className={isScrollDirec}>
      <HeaderLogo>
        <NavLink to={''} onClick={() => {
          window.location.href = `${process.env.REACT_APP_DOMAIN}`
        }}>
          <span css={screenOut}>AICA 인공지능산업융합사업단 검색페이지</span>
        </NavLink>
      </HeaderLogo>
      <CommonInner>
        <SearchResultForm className="search-result --keyword-absolute">
          <SearchBar
            iptFocus={props.iptFocus}
            setIptFocus={props.setIptFocus}
            searchValue={props.searchValue}
            setSearchValue={props.setSearchValue}
            iptDisabled={props.iptDisabled}
            searchHandler={props.searchHandler}
            isKeywordOnAddClass={props.isKeywordOnAddClass}
            setIsKeywordOnAddClass={props.setIsKeywordOnAddClass}
            setIsIptValue={props.setIsIptValue}
          />
        </SearchResultForm>

        {
          props.hashValue.length > 0 && (
            <SearchResultKeywordRelation className="--keyword-flex">
            {
              props.hashValue && props.hashValue != '' &&
              <SearchKeywordRelation
                searchValue={props.hashValue}
                evtHashClick={props.evtHashClick}/>
            }
            </SearchResultKeywordRelation>
          )
        }

        {/* 검색결과 메세지 */}
        {/*{props.searchResultInfo && props.searchResultInfo.total !== 0 ? <SearchResultMsg /> : <SearchResultNotMsg />}*/}
        {
          props.searchResultInfo.keyword != '' && props.searchResultInfo.total != 0 ?
            <SearchResultMsg searchResultInfo={props.searchResultInfo}/> :
            <SearchResultNotMsg searchResultInfo={props.searchResultInfo}/>
        }

        {/* 검색결과 관련 탭메뉴 */}
        {props.searchResultInfo.total !== 0 && (
          <SearchResultTab
            data={props.searchResult}
            tabsIdx={props.tabsIdx}
            evtTabsChange={props.evtTabsChange}
          />
        )}
      </CommonInner>

      {/* 검색조건 */}
      {/*{props.searchResultInfo.total !== 0 && <SearchResultCondition/>}*/}
    </Box>
  );
}

const HeaderLogo = styled('div')`
  position: relative;
  display: flex;
  align-items: center;
  height: 80px;
  padding-left: 40px;
  box-shadow: inset 0 -1px 0 0 rgba(204, 204, 204, 0.2);
  transition: height 0.3s;

  a {
    width: 240px;
    height: 23px;
    background: url('/images/logo01.png') no-repeat center / contain;
    transition: height 0.3s, opacity 0.3s;
  }

  .is-not-scroll & {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    background: ${Color.darkbg};
    z-index: 300;
  }

  @media (min-width: 320px) and (max-width: 1200px) {
    justify-content: center;
    height: 60px;
    padding-left: 0;
    a {
      width: 90px;
      height: 34px;
      background-image: url('/images/logo-wathermark-white.svg');
      background-size: 90px 34px;
    }

    .is-scroll-dw & {
      height: 0;

      a {
        height: 0;
        opacity: 0;
      }
    }

    .is-scroll-up & {
      height: 60px;
    }
  }
`;

const SearchResultForm = styled('div')`
  position: relative;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  flex-direction: column;
  width: 100%;
  height: 120px;
  transition: height 0.3s;

  @media (min-width: 1201px) {
    .is-scroll-dw &,
    .is-scroll-up & {
      height: 90px;
    }

    .is-not-scroll & {
      margin-top: 80px;
    }
  }
  @media (max-width: 1200px) {
    height: 82px;

    .is-scroll-dw & {
      height: 0;
    }

    .is-not-scroll & {
      margin-top: 60px;
    }
  }
  @media (min-width: 768px) and (max-width: 820px) {
    width: 100%;
    padding: 0 20px;
  }
  @media (max-width: ${breakpoint.mobile}) {
    padding: 0 15px;
  }
`;
const SearchResultKeywordRelation = styled('div')`
  /* padding-top: 30px;
  transition: padding 0.3s;

  @media (max-width: ${breakpoint.mobile}) {
    padding-top: 16px;
  }

  @media (min-width: 1201px) {
    .is-scroll-dw &,
    .is-scroll-up & {
      padding-top: 0;
    }
  }
  @media (max-width: 1200px) {
    .is-scroll-dw &,
    .is-scroll-up & {
      padding-top: 0;
    }
  } */
`;
