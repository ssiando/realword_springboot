/* eslint-disable jsx-a11y/alt-text */
import * as React from 'react';

import SearchSwiperEvent from './SearchSwiperEvent';

import {Box, Typography} from '@mui/material';

import {
  TabPanelGroup,
  CommonInner,
  SearchResultEventSection,
  TabPanelConts,
  TabPanelTitle,
} from '../styles';
import {CountResult, DxpCntsTmng, DxpDtstry} from "~/pages/Home/SearchEngine/Data/dataSearch";
import {Fragment} from "react";
import {SearchPortalType} from "~/pages/Home/SearchEngine/Components/SearchResultTabPanel";


export default function SearchResultAward(props: {
  type: SearchPortalType
  result?: CountResult<DxpCntsTmng>
}) {
  const {result} = props;

  return <Fragment>
    {
      result && result.cnt > 0 && <TabPanelGroup key={'event'}>
        <CommonInner>
          <TabPanelTitle>
            <Box component={'a'} onClick={() => {
              window.open(`${process.env.REACT_APP_DOMAIN}/dxp/datause/contestResult`, "_blank")
            }}>
              {'공모전 결과'}
            </Box>
            {
              result?.cnt && <Typography component={'p'}>
                <span className="point">{result?.cnt}</span>
                <span>건</span>
              </Typography>
            }
          </TabPanelTitle>
        </CommonInner>

        <TabPanelConts>
          <CommonInner>
            <SearchResultEventSection>
              <SearchSwiperEvent data={result?.collResult || []} type="award"/>
            </SearchResultEventSection>
          </CommonInner>
        </TabPanelConts>
      </TabPanelGroup>
    }
  </Fragment>
}