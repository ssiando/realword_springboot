/* eslint-disable jsx-a11y/alt-text */
import * as React from 'react';
import { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';

import {CardMedia, Typography} from '@mui/material';

import { Swiper, SwiperSlide } from 'swiper/react';
import SwiperCore, { Pagination, Autoplay } from "swiper";

import 'swiper/swiper.scss';

import styled from '@emotion/styled';
import { Color } from '~/components/StyleUtils';
import { breakpoint } from '../../styles/styleCommon';
import {
  searchThumbIcon,
  SearchIconRecruit01,
  SearchIconRecruit02,
} from '../styles';

import { CardMediaThumb, eventTitle } from '../styleCssCommon';

import {UspPblanc} from "~/pages/Home/SearchEngine/Data/dataSearch";
import * as common from "~/CommonFunction";

SwiperCore.use([Pagination, Autoplay])

export default function SearchSwiper(props: any) {
  const { data } = props;
  const [swiper, setSwiper] = useState<any | null>(null);
  const [slidesOffset, setSlidesOffset] = useState<number>(0);

  const handleSlidesOffset = () => {
    const offset = (window.innerWidth - 1260) / 2;
    window.innerWidth < 1260 ? setSlidesOffset(0) : setSlidesOffset(offset);

    if (swiper) swiper.updateSlides();
  };

  useEffect(() => {
    handleSlidesOffset();
  }, []);

  useEffect(() => {
    window.addEventListener('resize', handleSlidesOffset);
    return () => {
      window.removeEventListener('resize', handleSlidesOffset);
    };
  });

  return (
    <SwiperSection
      slidesPerView={'auto'}
      slidesPerGroup={1}
      spaceBetween={0}
      breakpoints={{
        1281: {
          slidesPerGroup: 4,
          spaceBetween: 20,
        },
      }}
      watchOverflow ={true}
      observer={true}
      observeParents={true}
      pagination={{
        el: '.swiper-pagination',
        clickable: true,
        type: 'bullets',
      }}
      // slidesOffsetBefore={slidesOffset}
      // slidesOffsetAfter={slidesOffset}
      onSwiper={(swiper) => setSwiper(swiper)}
    >
      {data.map((item: UspPblanc, i: number) => (
        <SwiperSlide key={i}>
          <NavLink to={''} onClick={() => {
            window.open(`${process.env.REACT_APP_DOMAIN}/Notice/Notice/${item.DOCID}`, "_blank")
          }}>
            <SwiperThumb>
              <CardMedia
                component="img"
                height="200"
                image={`${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/bsns-pblanc/${item.DOCID}/thumbnail`}
                onError={(e: any) => common.handleImgError(e)}
                alt={item.PBLANC_NM?.replace("<!HS>", "").replace("<!HE>", "")}
                css={CardMediaThumb}
              />
              {/*<figure*/}
              {/*  style={{*/}
              {/*    backgroundImage: `url(${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/bsns-pblanc/${item.DOCID}/thumbnail)`,*/}
              {/*  }}*/}
              {/*></figure>*/}
              <SearchIconRecruit01 css={searchThumbIcon}>
                {/* RECOMEND_CL => 다수 불러올 경우, "," 이후 삭제 */}
                {item.RECOMEND_CL?.substring(0, item.RECOMEND_CL?.indexOf(','))}
              </SearchIconRecruit01>
              <SearchIconRecruit02 css={searchThumbIcon}>
                마감 D-{item.RMNDR_DAY}
              </SearchIconRecruit02>
            </SwiperThumb>
            
            {/* 관련 검색어 있을 경우, 포인트 컬러 적용 */}
            <h3 css={eventTitle} dangerouslySetInnerHTML={{
              __html: item.PBLANC_NM?.replaceAll('<!HS>','<b>').replaceAll('<!HE>','</b>')
            }}/>
            {/* <SlideContsTitle>{item.PBLANC_NM}</SlideContsTitle> */}

            <SlideContsDate>
              <Typography component={'p'}>접수기간</Typography>
              <Typography component={'p'}>
                {item.RCEPT_PD} ({item.PBLANC_STTUS})
              </Typography>
            </SlideContsDate>
          </NavLink>
        </SwiperSlide>
      ))}
      <SwiperControllerGroup>
        <div className="swiper-pagination"></div>
      </SwiperControllerGroup>
    </SwiperSection>
  );
}
const SwiperSection = styled(Swiper)`
  .swiper {
    @media (max-width: ${breakpoint.desk1280}) {
      &-wrapper {
        /* padding: 0 15px; */
      }
    }
    &-slide {
      width: 300px;

      @media (max-width: ${breakpoint.desk1280}) {
        width: 285px;
        margin-left: 15px;

        &:last-of-type {
          margin-right: 15px;
        }
      }

      a {
        display: block;
        width: 100%;
      }

      /* @media (min-width: 1281px) {
        opacity: 0.4;

        &-active,
        &-next {
          opacity: 1;
        }
        &-next {
          & + .swiper-slide {
            opacity: 1;
            & + .swiper-slide {
              opacity: 1;
            }
          }
        }
      } */
    }
  }
`;

const SwiperThumb = styled('div')`
  figure {
    width: 100%;
    height: 200px;
    margin: 0;
    padding: 0;
    background: no-repeat center / cover;
    border-radius: 15px 15px 10px 10px;
  }
`;
const SlideContsTitle = styled('h3')`
  height: 60px;
  margin: 20px 0 16px;
  font-size: 20px;
  font-weight: 700;
  color: ${Color.black};
  line-height: 30px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;

  @media (max-width: ${breakpoint.desk1280}) {
    margin: 12px 0 6px;
    font-size: 18px;
  }
`;
const SlideContsDate = styled('div')`
  p {
    font-size: 14px;
    font-weight: 400;
    color: ${Color.warm_gray};
    line-height: 20px;
    letter-spacing: -0.06em;

    & + p {
      margin-top: 5px;
    }
  }
`;
const SwiperControllerGroup = styled('div')`
  position: relative;
  display: flex;
  justify-content: center;
  /* padding: 44px 0 61px; */
  padding-bottom: 61px;

  .swiper-pagination {
    position: static;
    display: flex;

    &-bullet {
      display: block;
      width: 60px;
      height: 2px;
      margin: 44px 5px 0;
      background: ${Color.gray};
      border-radius: 0;
      opacity: 1;

      &-active {
        background: ${Color.topaz};
      }
    }

    @media (max-width: ${breakpoint.desk1280}) {
      display: none;
    }
  }

  &::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    width: 1260px;
    height: 1px;
    background: ${Color.line};
    transform: translateX(-50%);
  }

  @media (max-width: ${breakpoint.desk1280}) {
    /* padding: 0 0 41px; */
    padding-bottom: 41px;

    &::after {
      left: 15px;
      width: calc(100vw - 30px);
      transform: translateX(0);
    }
  }
`;