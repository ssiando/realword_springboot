/* eslint-disable jsx-a11y/alt-text */
import * as React from 'react';
import { NavLink } from 'react-router-dom';

import { Box, Typography } from '@mui/material';
import styled from '@emotion/styled';
import { css } from '@emotion/react';
import { Color } from '~/components/StyleUtils';
import { breakpoint } from '../../styles/styleCommon';
import { CommonInner } from '../styles';

import SearchKeywordItemBtn from './SearchKeywordItemBtn';

import { searchKeywordsPopular } from '../Data/dataSearch';
import {SearchService} from "~/pages/Home/SearchEngine/SearchService";
import {useEffect, useState} from "react";

export default function SearchResultNotConts(props: any) {
  const [popWord, setPopWord] = useState<string[]>([])

  const query = SearchService.GetSearchPopWord({
    target: 'popword',
    collection: '_ALL_',
    range: 'day',
    datatype: 'json'
  })

  useEffect(() => {
    if (!query.isLoading && !query.isFetching) {
      if (!!query.data) {
        const popword = query.data.result?.flatMap(m => m.content) || []
        setPopWord(popword.slice(0, 10))
      }
    }
  }, [query.data, query.isLoading, query.isFetching])

  return <CommonInner css={containerCss}>
        <Typography component={'h2'} css={notContsTit}>
          인기검색어로 더 찾아보시겠어요?
        </Typography>
        <NotContsTagGroup>
          <ul>
            {popWord.map((item, i) => (
              <NotContsTagItem key={i}>
                <SearchKeywordItemBtn
                  type={'main'}
                  itemTxt={item}
                  evtClick={props.evtHashClick}
                />
              </NotContsTagItem>
            ))}
          </ul>
        </NotContsTagGroup>
      </CommonInner>
}

const containerCss = css`
    padding: 60px 0 120px;
    text-align: center;
  `;
const notContsTit = css`
    font-size: 18px;
    font-weight: 500;
    color: ${Color.black};
    line-height: 27px;
    letter-spacing: -0.06em;
  `;

const NotContsTagGroup = styled('div')`
  display: flex;
  justify-content: center;
  margin-top: 16px;

  ul {
    display: flex;
    margin: -6px -3px;
    overflow-x: auto;
    -ms-overflow-style: none;
    scrollbar-width: none;

    &::-webkit-scrollbar {
      display: none;
    }

    @media (max-width: ${breakpoint.mobile}) {
      padding-left: 15px;
      padding-right: 15px;
    }
  }
`;
const NotContsTagItem = styled('li')`
  flex-shrink: 0;
  margin: 6px 3px;

  button {
    height: 36px;

    &::before {
      margin-right: 4px;
    }
  }
`;
