/* eslint-disable @typescript-eslint/no-use-before-define */
import * as React from 'react';
import { useEffect } from 'react';
import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';
import {fetchSignInSnsSelf, fetchSignInSnsSelfDelete} from "~/fetches/fetchSignIn";
import {useNavigate} from "react-router-dom";

// 네이버 설정  콜백페이지
const SnsNaverConfigCallback = () => {
  const navigate = useNavigate();

  // useEffect(() => {
  //   const tokenData: any = window.location.href.split('=')[1].split('&')[0] || 'none'
  //
  //   let naverKey = sessionStorage.getItem('__SNS_KEY__');
  //   if(!!tokenData){
  //     if(naverKey=='true'){ // 설정
  //        fetchSignInSnsSelf({accessToken: tokenData,uri:"sns/naver",}).then((ress)=>{
  //         // setChangeSns((pre:any)=>({...pre,isNaver:true}));
  //
  //          window.close();
  //       }).catch((err)=>{
  //         // addModal({
  //         //   type:'normal',
  //         //   open: true,
  //         //   content: err.response.data.message
  //         // })
  //
  //          window.close();
  //       });
  //
  //     } else {
  //       fetchSignInSnsSelfDelete({accessToken: tokenData,uri:"sns/naver",}).then((ress)=>{
  //         // setChangeSns((pre:any)=>({...pre,isNaver:false}));
  //         window.close();
  //       }).catch((err)=>{
  //         //   type:'normal',
  //         //   open: true,
  //         //   content: err.response.data.message
  //         // })
  //         // addModal({
  //
  //         window.close();
  //       });
  //
  //     }
  //   }
  // }, [])
  useEffect(() => {
    if (typeof window !== "undefined") {
      // let naver_id_login:any = new window.naver_id_login(`${process.env.REACT_APP_CLIENT_ID_NAVER_AICA}`, `${process.env.REACT_APP_NAVER_CONF_CALLBACK}`);
      // let naver_id_login:any = new window.naver_id_login(`${process.env.REACT_APP_CLIENT_ID_NAVER_AICA}`, 'http://pc.atops.or.kr:5500/signin/snsNaverConfigCallback');
      // window.opener.setEncodeData(naver_id_login.oauthParams.access_token);
      const tokenData: any = window.location.href.split('=')[1].split('&')[0] || 'none'
      window.opener.setEncodeData(tokenData);
      window.close();
    }
  }, []);
  return (
    <section>
      <Box sx={{ display: 'flex',mt:25,ml:18 }} component='span'>
        <CircularProgress />
      </Box>
    </section>
  );
}

export default SnsNaverConfigCallback;
