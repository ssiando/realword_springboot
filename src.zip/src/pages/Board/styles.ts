import { css } from '@emotion/react';
export const container = css`
  position: relative;
  background-color: white;
  margin-top: 80;
  height: 400px;
  width: '100%';
`;