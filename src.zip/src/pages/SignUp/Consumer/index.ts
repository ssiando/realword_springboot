export { default } from './Consumer';
