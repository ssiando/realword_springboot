import React, {useState, useRef, useEffect} from 'react';
import {useMutation, useQueries} from "react-query";
import * as styles from '../styles';
import Box from '@mui/material/Box';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import {NavLink, useLocation, useNavigate} from 'react-router-dom';
import {steps, stepsbiz} from '~/models/Model';
import {CustomRadioButtons} from '~/components/ButtonComponents';
import {inithonBiz, joinBizErrorType, inithonBizErrors, emailReg, joinMemberType} from '~/models/ModelSignin';
import {
  fetchCheckUserId,
  fetchSignUp,
  fetchSignUpEmailRes,
  fetchSignUpPhoneRes,
  fetchSignUpPhoneCk,
  fetchSignUpEmailCk, fetchGetCommCode
} from '~/fetches';
import {InputAdornment} from '@mui/material';
import {CustomButton} from '~/components/ButtonComponents';
import {useNiceStore} from '~/pages/store/GlobalModalStore';
import {useGlobalModalStore} from '~/pages/store/GlobalModalStore';
import dayjs from "shared/libs/dayjs";
import {
  fetchEmailCertReq, fetchEmailCertReqCheck,
  FetchPhoneCertReq,
  fetchPhoneCertReqCheck, fetchSelfBzmnPhoneChange,
} from "~/fetches/fetchTerms";

/* 
  작성일    :   2022/05/30
  화면명    :   회원가입_정보입력 (사업자)
  회면ID    :   UI-USP-FRN-0010601
  화면/개발 :   Seongeonjoo / navycui
*/
function ProducerForm() {
  const navigate = useNavigate();
  const {addModal} = useGlobalModalStore();
  const [ssid, setSsid] = useState(sessionStorage.getItem("__BIZ_JOIN_KEY__"))

  const [bizForm, setBizForm] = useState<joinMemberType>(inithonBiz);
  const [bizNmValidation, setBizNmValidation] = useState<joinBizErrorType>(inithonBizErrors);

  const intervalMailRef = useRef<any>(null);
  const [count, setCount] = useState(false);
  const [emailExpiresAt, setEmailExpiresAt] = useState<null | number>(null)
  const [emailCountdown, setEmailCountdown] = useState(0);

  const intervalPhoneRefEl = useRef<any>(null);
  const [count1, setCount1] = useState(false);
  const [phoneExpiresAt, setPhoneExpiresAt] = useState<null | number>(null)
  const [phoneCountdown, setPhoneCountdown] = useState(0);

  const [isPerson, setIsPerson] = useState<boolean>(false);
  const [phoneCertKey, setPhoneCertKey] = useState("")
  const [emailCertKey, setEmailCertKey] = useState<string>("");
  const receive: any = useLocation();

// 공통코드 조회
  const userQueries: any = useQueries(
    [
      'MEMBER_TYPE'
    ].map(TermsType => {
      return {
        queryKey: [TermsType],
        queryFn: () => fetchGetCommCode(TermsType),
      }
    })
  )

  useEffect(() => {
    if (!!receive && receive.state?.type == 'SOLE') {
      setBizForm({...bizForm, memberType: 'CORPORATION'})
      setBizNmValidation(inithonBizErrors)
      setIsPerson(true)
    }

    const exprirse = new Date()
    exprirse.setMinutes(exprirse.getMinutes() + 10)
    setPhoneExpiresAt(exprirse.getTime())
    setCount1(true)
    setBizForm({...bizForm, ertNoDisabled: true, CertNoTel: false})
  },[])

  const format = (seconds: number) => {
    if (seconds < 0) {
      return '00:00'
    }
    const minute = Math.floor(seconds / 60)
    const second = seconds - minute * 60
    return `${minute}:${second}`
  };

  useEffect(() => {
    clearInterval(intervalMailRef.current);
    if (emailExpiresAt) {
      intervalMailRef.current = setInterval(() => {
        const diff = dayjs(emailExpiresAt).diff(+new Date(), 's')
        setEmailCountdown(diff)
      }, 1000)
      const diff = dayjs(emailExpiresAt).diff(+new Date(), 's')
      setEmailCountdown(diff)
    }
    return () => {
      clearInterval(intervalMailRef.current);
    }
  }, [count])


  useEffect(() => {
    clearInterval(intervalPhoneRefEl.current);
    if (phoneExpiresAt) {
      intervalPhoneRefEl.current = setInterval(() => {
        const diff = dayjs(phoneExpiresAt).diff(+new Date(), 's')
        setPhoneCountdown(diff)
      }, 1000)
      const diff = dayjs(phoneExpiresAt).diff(+new Date(), 's')
      setPhoneCountdown(diff)
    }
    return () => {
      clearInterval(intervalPhoneRefEl.current);
    }
  }, [count1])

  // 중복 확인
  const handelCheckId = (event: React.MouseEvent<HTMLElement>) => {
    event.preventDefault();
    if (!bizForm.loginId) {
      setBizNmValidation({...bizNmValidation, loginId: true, idlabel: "아이디는 필수입니다",});
      // setLabels({...labels,labelsTextemail:"이메일 인증 진행하세요."});
      return false;
    }
    const form = new FormData();
    // 아이디 중복 확인 호출
    form.append('loginId', bizForm.loginId)
    fetchCheckUserId(form).then((res: any) => {
      console.log('res - ' + JSON.stringify(res))
      if (res.data.duplicateYn) {
        setBizNmValidation({...bizNmValidation, idlabel: "중복된 아이디입니다.."});
        addModal({
          type: 'normal',
          open: true,
          content: "중복된 아이디입니다.",
        })

      } else { //helperTexts.helperTextloginId
        setBizForm({...bizForm, loginDisabled: true})
        setBizNmValidation({...bizNmValidation, idlabel: "사용가능한 아이디입니다."});
        addModal({
          type: 'normal',
          open: true,
          content: '사용가능한 아이디입니다.',
        })
      }
    }).catch((e) => {
      console.log('test')
      let {data: {message, status}} = e.response;
      addModal({
        type: 'normal',
        open: true,
        content: message,
      })
    });
  }

  // 메일 인증 요청
  const handelOnCallMail = async (event: React.MouseEvent<HTMLElement>) => {
    event.preventDefault();
    if (!bizForm.email) {
      setBizNmValidation({...bizNmValidation, email: true, mgrEmaillabel: "이메일 필수입니다..",});
      return false;
    }
    if (!emailReg.test(bizForm.email)) {
      setBizNmValidation({...bizNmValidation, email: true, mgrEmaillabel: "이메일 형식이 맞지않습니다.",});
      // setLabels({...labels,labelsTextemail:"이메일 형식이 맞지 않습니다."});
      return false;
    }

    const formData = new FormData();
    let result: any = null
    formData.append('email', bizForm.email)

    try {
      if (!!receive.state && receive.state.type) {
        if (ssid) formData.append('sessionId', ssid)
        // 사업자 전환시
        result = await fetchEmailCertReq(formData)
        setSsid(result.key)
      } else {
        // 사업자 회원가입시
        result = await fetchSignUpEmailRes(formData)
      }
    } catch (e: any) {
      addModal({
        open: true,
        content: e.response.data.message
      })
    }

    if (result && result.key) {
      setEmailCertKey(result.key)
      const emailExprirse = new Date()
      emailExprirse.setMinutes(emailExprirse.getMinutes() + 10)
      console.log('emailExprirse - ' + emailExprirse.getTime())
      setEmailExpiresAt(emailExprirse.getTime())
      setCount(true)
      setBizForm({...bizForm, emailDisabled: true, CertNoMaill: false})

      addModal({
        open: true,
        content: '인증 번호 발송되었습니다'
      })
    }
  }

  // 메일 인증 확인
  const handelOnCallMailCk = async (event: React.MouseEvent<HTMLElement>) => {
    event.preventDefault();

    if (!bizForm.certNo) {
      setBizNmValidation({...bizNmValidation, certNo: true, certNolabel: "인증번호 입력하세요",});
      return false;
    }
    const formData = new FormData();
    let result: any = null
    //이메일 확인 실행

    try {
      if (!!receive.state && receive.state.type) {
        // 사업자 전환시
        if (ssid) formData.append('sessionId', ssid);
        formData.append('certNo', bizForm.certNo);
        result = await fetchEmailCertReqCheck(formData).then(res => {
          setEmailExpiresAt(null)
          setCount(false)
          setBizForm({...bizForm, emailDisabled: true, CertNoMaill: true})
          addModal({
            open: true,
            content: '인증 완료되었습니다.'
          })
        }).catch(e => {
          addModal({
            open: true,
            content: e.response.data.message
          })
        })
      } else {
        // 사업자 회원가입시
        formData.append('emailCertKey', emailCertKey);
        formData.append('certNo', bizForm.certNo);
        result = await fetchSignUpEmailCk(formData).then(res => {
          setEmailExpiresAt(null)
          setCount(false)
          setBizForm({...bizForm, emailDisabled: true, CertNoMaill: true})
          addModal({
            open: true,
            content: '인증 완료되었습니다.'
          })
        }).catch(e => {
          addModal({
            open: true,
            content: e.response.data.message
          })
        })
      }
    } catch (e: any) {

    }
  }

  // 핸드폰 인증 요청
  const handelOnCallTel = async (event: React.MouseEvent<HTMLElement>) => {
    event.preventDefault();
    if (!bizForm.mobileNo) {
      setBizNmValidation({...bizNmValidation, mobileNo: true, mgrTellabel: "담당자휴대폰번호를 입력해주세요.",});
      return false;
    }
    if (ssid) {
      const formData = new FormData();
      let result: any = null
      formData.append('sessionId', ssid)
      formData.append('mobileNo', bizForm.mobileNo)

      if (!!receive.state && receive.state.type) {
        // 사업자 전환시
        result = await FetchPhoneCertReq(formData)
        setSsid(result.key)
      } else {
        // 사업자 회원가입시
        result = await fetchSignUpPhoneRes(formData)
      }

      if (!!result) {
        console.log('result - ' + JSON.stringify(result))

        const exprirse = new Date()
        setPhoneCertKey(result.key)
        exprirse.setMinutes(exprirse.getMinutes() + 10)
        setPhoneExpiresAt(exprirse.getTime())
        setCount1(true)
        setBizForm({...bizForm, ertNoDisabled: true, CertNoTel: false})
      }
    }
  }

  // 핸드폰 인증 확인
  const fetchSignUpTelCk = async (event: React.MouseEvent<HTMLElement>) => {
    event.preventDefault();

    if (!bizForm.certNoTel) {
      setBizNmValidation({...bizNmValidation, idlabel: "인증번호 입력하세요."});
      return false;
    }
    if (ssid) {
      const fmData = new FormData();
      let result: any = null

      try {
        if (!!receive.state && receive.state.type) {
          // 사업자 전환시
          fmData.append('sessionId', ssid);
          fmData.append('certNo', bizForm.certNoTel);
          result = await fetchPhoneCertReqCheck(fmData).then(res => {
            setCount1(false)
            setPhoneExpiresAt(null)
            setBizForm({...bizForm, ertNoDisabled: true, CertNoTel: true})

            addModal({
              open: true,
              content: '인증 완료되었습니다.'
            })
          }).catch(e => {
            addModal({
              open: true,
              content: e.response.data.message
            })
          })
        } else {
          // 사업자 회원가입시
          fmData.append('sessionId', ssid);
          fmData.append('phoneCertKey', phoneCertKey);
          fmData.append('certNo', bizForm.certNoTel);
          result = await fetchSignUpPhoneCk(fmData).then(res => {
            setCount1(false)
            setPhoneExpiresAt(null)
            setBizForm({...bizForm, ertNoDisabled: true, CertNoTel: true})

            addModal({
              open: true,
              content: '인증 완료되었습니다.'
            })
          }).catch(e => {
            addModal({
              open: true,
              content: e.response.data.message
            })
          })
        }
      } catch (e: any) {
      }
    }
  }

  // 화원 가입 호출
  const handelOnSubmitJoin = async (event: React.MouseEvent<HTMLElement>) => {
    event.preventDefault();
    if (!ckForm()) return
    if (!ssid) {
      addModal({
        open: true,
        content: '인증번호를 확인해 주세요'
      })
      return;
    }

    if (phoneCertKey == '') {
      addModal({
        open: true,
        content: '휴대폰 인증을 완료해 주세요'
      })
      return;
    }

    if (emailCertKey == '') {
      addModal({
        open: true,
        content: '이메일 인증을 완료해 주세요'
      })
      return;
    }

    let result: any = null

    try {
      if (!!receive.state && receive.state.type) {
        console.log('req - ' + JSON.stringify({...bizForm, sessionId: ssid ? ssid : ''}))
        result = await fetchSelfBzmnPhoneChange({...bizForm, sessionId: ssid ? ssid : ''}).then(res =>{
          navigate('/signup/CompleteConsumer', {
            state: {
              change: true
            }
          })
          }
        ).catch((e: any) => {
          if (e.response.data.message === 'errors') {
            const keys = e.response.data.errors.reduce((ac: any, c: any) => {
              return {
                ...ac,
                [c.field]: true,
                [c.field + 'helpLabel']: c.message
              }
            }, bizNmValidation)
            console.log('keys - ' + JSON.stringify(keys))
            setBizNmValidation(keys)
          } else {
            addModal({
              open: true,
              content: e.response.data.message
            })
          }
        })

        if (result) {
          if (result.memberType == '개인회원' || result.memberType == '개인사업자') {
          } else {
            addModal({
              open: true,
              content: '개인사용자 또는 개인사업자만 사용할 수 있습니다.'
            })
          }
        }
      } else {
        result = await fetchSignUp({...bizForm, sessionId: ssid ? ssid : ''}).then(res => {
          navigate('/signup/CompleteConsumer')
        }).catch((e: any) => {
          if (e.response.data.message === 'errors') {
            const keys = e.response.data.errors.reduce((ac: any, c: any) => {
              return {
                ...ac,
                [c.field]: true,
                [c.field + 'helpLabel']: c.message
              }
            }, bizNmValidation)
            console.log('keys - ' + JSON.stringify(keys))
            setBizNmValidation(keys)
          } else {
            addModal({
              open: true,
              content: e.response.data.message
            })
          }
        })
      }
    } catch (e: any) {
    }

  }

  // form validation check
  const ckForm = (): boolean => {
    let result = true
    let addtionValidation: any = {}
    // if(ckForm)
    if (!bizForm.memberNm) {
      addtionValidation = {...addtionValidation, memberNm: true, bizNmlabel: "사업자명은 필수입니다"}
      // setBizNmValidation({...bizNmValidation, memberNm: true, bizNmlabel: "사업자명은 필수입니다",});
      result = false;
    }
    if (!bizForm.ceoNm) {
      addtionValidation = {...addtionValidation, ceoNm: true, ceoNamelabel: "대표자명은 필수입니다"}
      // setBizNmValidation({...bizNmValidation, ceoNm: true, ceoNamelabel: "대표자명은 필수입니다",});
      result = false;
    }

    if (isPerson) {
      if (!bizForm.jurirno) {
        addtionValidation = {...addtionValidation, jurirno: true, bizNolabel: "법인등록번호는 필수입니다"}
        // setBizNmValidation({...bizNmValidation, jurirno: true, bizNolabel: "법인등록번호는 필수입니다",});
        result = false;
      }
    }
    if (!bizForm.chargerNm) {
      addtionValidation = {...addtionValidation, chargerNm: true, mgrNmlabel: "담당자명은 필수입니다"}
      // setBizNmValidation({...bizNmValidation, chargerNm: true, mgrNmlabel: "담당자명은 필수입니다",});
      result = false;
    }
    if (!bizForm.mobileNo) {
      addtionValidation = {...addtionValidation, mobileNo: true, mgrTellabel: "담당자 휴대폰번호는 필수입니다"}
      // setBizNmValidation({...bizNmValidation, mobileNo: true, mgrTellabel: "담당자 휴대폰번호는 필수입니다",});
      result = false;
    }
    if (!emailReg.test(bizForm.email)) {
      addtionValidation = {...addtionValidation, email: true, mgrEmaillabel: "이메일 형식이 맞지않습니다."}
      // setBizNmValidation({...bizNmValidation, email: true, mgrEmaillabel: "이메일 형식이 맞지않습니다.",});
      result = false;
    }
    if (!bizForm.certNo) {
      addtionValidation = {...addtionValidation, certNo: true, certNolabel: "인증번호는 필수입니다"}
      // setBizNmValidation({...bizNmValidation, certNo: true, certNolabel: "인증번호는 필수입니다",});
      result = false;
    }

    if (!receive){
      if (!bizForm.loginId) {
        addtionValidation = {...addtionValidation, loginId: true, idlabel: "아이디는 필수입니다"}
        // setBizNmValidation({...bizNmValidation, loginId: true, idlabel: "아이디는 필수입니다",});
        result = false;
      }
      if (!bizForm.passwd1) {
        addtionValidation = {...addtionValidation, passwd1: true, passwordlabel: "비밀번호는 필수입니다"}
        // setBizNmValidation({...bizNmValidation, passwd1: true, passwordlabel: "비밀번호는 필수입니다",});
        result = false;
      }
      if (!bizForm.passwd2) {
        addtionValidation = {...addtionValidation, passwd2: true, password2label: "비밀번호 확인 필수입니다"}
        // setBizNmValidation({...bizNmValidation, passwd2: true, password2label: "비밀번호 확인 필수입니다",});
        result = false;
      }
    }

    if (!result) {
      setBizNmValidation(addtionValidation)
    }
    return result;
  };

  // 사업정보 입력
  const handelChangebizNm = (e: React.ChangeEvent<HTMLInputElement>) => {
    setBizForm({
      ...bizForm,
      [e.target.name]: e.target.value
    });
    setBizNmValidation({...bizNmValidation, [e.target.name]: false});
  }

  const memberTypeList = () => {
    if (userQueries[0].status == 'success') {
      if (receive && receive.state?.type == 'INDIVIDUAL') {
        return userQueries[0].data.list.filter((f: any) =>
          (f.code == 'SOLE' || f.code == 'CORPORATION'))
          .map((m: any) => {
            return {code: m.code, codeNm: m.codeNm}
          })
      } else if (receive && receive.state?.type == 'SOLE') {
        return [{code: 'CORPORATION', codeNm: '법인사업자'}]
      }

      return userQueries[0].data.list.filter((f: any) =>
        (f.code == 'SOLE' || f.code == 'CORPORATION' || f.code == 'UNIVERSITY'))
        .map((m: any) => {
          return {code: m.code, codeNm: m.codeNm}
        })
    }

    return []
  }

  return (
    <section css={styles.container}>
      <Box css={styles.backPass}>
        <NavLink to={''} onClick={() => navigate(-1)}>
          이전 화면으로 돌아가기
        </NavLink>
      </Box>
      <div css={styles.content} className="heightfull">
        <Stack className="join_head">
          <div className="tit mobilepd">
            <h1>{!!receive.state && receive.state?.conversion? '사업자 전환' : 'AICA 회원가입'}</h1>
          </div>
          <Box className="step_scroll">
            <Stepper activeStep={2} alternativeLabel css={styles.step}>
              {stepsbiz.map((label) => (
                <Step key={label}>
                  <StepLabel>{label}</StepLabel>
                </Step>
              ))}
            </Stepper>
          </Box>
        </Stack>
        <Box sx={{mb: 5}}>
          <div className="sub_tit">
            <h2>{!!receive.state && receive.state?.conversion? '사업자 전환' : '사업자 회원 가입'}</h2>
            <p>{!!receive.state && receive.state?.conversion? '사업자 전환에 필요한 정보를 입력해주세요.' : 'AICA 회원가입에 필요한 정보를 입력해주세요.'}</p>
          </div>
        </Box>
        <Box className="mobilepd">
          <dl css={styles.input_group}>
            <dt className='star'>
              사업자 유형
            </dt>
            <dd>
              <Box component="form" noValidate autoComplete="off" className="input_radio" name="CustomRadioButtons">
                <CustomRadioButtons
                  row
                  data={memberTypeList()}
                  defaultData={bizForm.memberType}
                  onClick={(selected) => {
                    if (selected == "SOLE") {
                      setBizForm({...inithonBiz, memberType: selected})
                      setBizNmValidation(inithonBizErrors)
                      setIsPerson(false)
                    } else {
                      setBizForm({...inithonBiz, memberType: selected})
                      setBizNmValidation(inithonBizErrors)
                      setIsPerson(true)
                    }
                  }}
                />
              </Box>
            </dd>
          </dl>
          <dl css={styles.input_group}>
            <dt>
              사업자 정보
              <span className="input_star">*필수</span>
            </dt>
            <dd>
              <Box component="form"
                  noValidate
                  autoComplete="off"
                  css={styles.singform}>
                <TextField
                  required
                  name="memberNm"
                  value={bizForm.memberNm}
                  label={bizNmValidation.memberNm ? bizNmValidation.bizNmlabel : "사업자명"}
                  helperText={bizNmValidation.memberNm ? bizNmValidation.memberNmhelpLabel : ""}
                  error={bizNmValidation.memberNm}
                  variant="filled"
                  fullWidth
                  onChange={handelChangebizNm}
                />
                <TextField
                  required
                  name="ceoNm"
                  value={bizForm.ceoNm}
                  label={bizNmValidation.ceoNm ? bizNmValidation.ceoNamelabel : "대표자명"}
                  helperText={bizNmValidation.ceoNm ? bizNmValidation.ceoNmhelpLabel : ""}
                  error={bizNmValidation.ceoNm}
                  variant="filled"
                  fullWidth
                  onChange={handelChangebizNm}
                />
                {isPerson ?
                  <TextField
                    required
                    name="jurirno"
                    value={bizForm.jurirno}
                    label={bizNmValidation.jurirno ? bizNmValidation.bizNolabel : "법인등록번호"}
                    helperText={bizNmValidation.jurirno ? bizNmValidation.jurirnohelpLabel : ""}
                    error={bizNmValidation.jurirno}
                    variant="filled"
                    fullWidth
                    onChange={handelChangebizNm}
                  /> : null}
              </Box>
            </dd>
          </dl>
          <dl css={styles.input_group}>
            <dt>
              담당자 정보
            </dt>
            <dd>
              <Box component="form"
                  noValidate
                  autoComplete="off"
                  css={styles.singform}>
                <TextField
                  required
                  name="chargerNm"
                  value={bizForm.chargerNm}
                  label={bizNmValidation.chargerNm ? bizNmValidation.mgrNmlabel : "담당자명"}
                  helperText={bizNmValidation.chargerNm ? bizNmValidation.chargerNmhelpLabel : ""}
                  error={bizNmValidation.chargerNm}
                  variant="filled"
                  fullWidth
                  onChange={handelChangebizNm}
                />
                <TextField
                  required
                  name="mobileNo"
                  value={bizForm.mobileNo}
                  label={bizNmValidation.mobileNo ? bizNmValidation.mgrTellabel : "담당자 휴대폰번호"}
                  helperText={bizNmValidation.mobileNo ? bizNmValidation.mobileNohelpLabel : ""}
                  error={bizNmValidation.mobileNo}
                  variant="filled"
                  fullWidth
                  onChange={handelChangebizNm}
                  placeholder="'-'을 제외한 숫자만 입력"
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <Button className={`${bizForm.ertNoDisabled ? 'rbt block' : 'rbt'}`}
                                disabled={bizForm.ertNoDisabled} onClick={handelOnCallTel}>휴대폰인증</Button>
                      </InputAdornment>
                    ),
                  }}
                />
                <TextField
                  required
                  name="certNoTel"
                  value={bizForm.certNoTel}
                  label={bizNmValidation.certNo ? bizNmValidation.certNolabel : "휴대폰 인증번호"}
                  helperText={bizNmValidation.certNo ? bizNmValidation.certNohelpLabel : ""}
                  error={bizNmValidation.certNo}
                  variant="filled"
                  fullWidth
                  onChange={handelChangebizNm}
                  placeholder="숫자만 입력"
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        {phoneExpiresAt == null ?
                          <span className='rbt'>10:00</span> : <span className='rbt'>{format(phoneCountdown)}</span>}
                        {/*<span className='rbt'>{minutesEl}:{secondsEl < 10 ? `0${secondsEl}` : secondsEl}</span>*/}
                        <Button className={`${bizForm.CertNoTel ? 'rbt block' : 'rbt'}`} disabled={bizForm.CertNoTel}
                                onClick={fetchSignUpTelCk}>확인</Button>
                        {/* block class 들어가면 비활성 */}
                      </InputAdornment>
                    ),
                  }}
                />
                <TextField
                  required
                  name="email"
                  value={bizForm.email}
                  label={bizNmValidation.email ? bizNmValidation.mgrEmaillabel : "담당자 이메일"}
                  helperText={bizNmValidation.email ? bizNmValidation.emailhelpLabel : ""}
                  error={bizNmValidation.email}
                  variant="filled"
                  fullWidth
                  onChange={handelChangebizNm}
                  placeholder="인증 가능한 이메일 주소 입력"
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <Button className={`${bizForm.emailDisabled ? 'rbt block' : 'rbt'}`}
                                disabled={bizForm.emailDisabled} onClick={handelOnCallMail}>메일인증</Button>
                      </InputAdornment>
                    ),
                  }}
                />
                <TextField
                  required
                  name="certNo"
                  value={bizForm.certNo}
                  label={bizNmValidation.certNo ? bizNmValidation.certNolabel : "이메일 인증번호"}
                  helperText={bizNmValidation.certNo ? bizNmValidation.certNohelpLabel : ""}
                  error={bizNmValidation.certNo}
                  variant="filled"
                  fullWidth
                  onChange={handelChangebizNm}
                  placeholder="숫자만 입력"
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        {emailExpiresAt == null ?
                          <span className='rbt'>10:00</span> : <span className='rbt'>{format(emailCountdown)}</span>
                        }
                        <Button className={`${bizForm.CertNoMaill ? 'rbt block' : 'rbt'}`}
                                disabled={bizForm.CertNoMaill}
                                onClick={handelOnCallMailCk}>확인</Button>
                        {/* block class 들어가면 비활성 */}
                      </InputAdornment>
                    ),
                  }}
                />
              </Box>
            </dd>
          </dl>
          {
            (!!receive.state && (receive.state.type == 'INDIVIDUAL' || receive.state.type == 'SOLE')) ||
            <dl css={styles.input_group}>
              <dt>
                아이디 정보
              </dt>
              <dd>
                <Box component="form"
                    noValidate
                    autoComplete="off"
                    css={styles.singform}>
                  <TextField
                    required
                    name="loginId"
                    value={bizForm.loginId}
                    label={bizNmValidation.loginId ? bizNmValidation.idlabel : "아이디"}
                    helperText={bizNmValidation.loginId ? bizNmValidation.loginIdhelpLabel : ""}
                    error={bizNmValidation.loginId}
                    variant="filled"
                    fullWidth
                    onChange={handelChangebizNm}
                    placeholder="4~12자 영문자 대소문자와 숫자"
                    InputProps={{
                      endAdornment: (
                        <InputAdornment position="end">
                          <Button className='rbt' onClick={handelCheckId}>중복확인</Button>
                        </InputAdornment>
                      ),
                    }}
                  />
                  <TextField
                    required
                    name="passwd1"
                    type="password"
                    value={bizForm.passwd1}
                    label={bizNmValidation.passwd1 ? bizNmValidation.passwdlabel : "비밀번호"}
                    helperText={bizNmValidation.passwd1 ? bizNmValidation.passwd1helpLabel : ""}
                    error={bizNmValidation.passwd1}
                    variant="filled"
                    fullWidth
                    onChange={handelChangebizNm}
                    placeholder="8~16자 영문 대·소문자,숫자,특수문자"
                  />
                  <TextField
                    required
                    name="passwd2"
                    type="password"
                    value={bizForm.passwd2}
                    label={bizNmValidation.passwd2 ? bizNmValidation.passwd2label : "비밀번호 확인"}
                    helperText={bizNmValidation.passwd2 ? bizNmValidation.passwd2helpLabel : ""}
                    error={bizNmValidation.passwd2}
                    variant="filled"
                    onChange={handelChangebizNm}
                    fullWidth
                  />
                </Box>
              </dd>
            </dl>
          }
          <Stack spacing={2} direction="row" justifyContent={'center'} css={styles.signbtn}>
            {
              receive.state?.type ?
                <CustomButton label={'전환하기'} type={'formbtn'} color={'primary'} onClick={handelOnSubmitJoin}/> :
                <CustomButton label={'가입하기'} type={'formbtn'} color={'primary'} onClick={handelOnSubmitJoin}/>
            }
          </Stack>
        </Box>
      </div>
    </section>
  );
}

export default ProducerForm;
