/* eslint-disable jsx-a11y/iframe-has-title */
import * as styles from '../styles';
import React, {useState, useEffect, useRef} from 'react';
import {NavLink, useNavigate} from 'react-router-dom';
import {initProducerType, ProducerType, steps, stepsbiz, TermsResponse} from '~/models/Model';
import {CustomCheckBoxs} from '../Consumer/CustomCheckBoxs';
import {fetchGetCommCode, fetchTermsGet, fetchTermsImsi} from '~/fetches';
import {CustomButton} from '~/components/ButtonComponents';
import styled from '@emotion/styled';
import {useMutation, useQueries, useQuery} from 'react-query';
import {
  FetchAccountCertBzmn, FetchBzmnNiceIdRes,
  FetchNiceIdRes,
  FetchreactAppPkiCertInitUrl,
  FetchreactAppPkiCertResultUrl
} from '~/fetches/fetchTerms';
import {useNiceStore} from '~/pages/store/GlobalModalStore';
import {useGlobalModalStore} from '~/pages/store/GlobalModalStore';
import {
  Stack,
  Button,
  Box,
  Stepper,
  Step,
  StepLabel,
  FormGroup,
  FormControlLabel,
  TextField,
  Input,
  Checkbox
} from '@mui/material';
import {ConsumerModal} from '../Consumer/ConsumerModal';
import $ from 'jquery';

/* 
작성일    :   2022/05/30
화면명    :   FRN-0010201_회원가입_약관동의/인증 (사업자)
회면ID    :   UI-USP-FRN-0010201
화면/개발 :   Seongeonjoo / navycui
*/

const _global = (window /* browser */ || global /* node */) as any
const Producer = () => {
  // const status1 = useScript("../../shared/src/libs/MagicLine4Web/ML4Web/js/ext/jquery-1.10.2.js");
  // const status2 = useScript("../../shared/src/libs/MagicLine4Web/ML4Web/js/ext/jquery-ui.min.js");
  // const status3 = useScript("../../shared/src/libs/MagicLine4Web/ML4Web/js/ext/jquery.blockUI.js");
  // const status4 = useScript("../../shared/src/libs/MagicLine4Web/ML4Web/js/ext/json2.js");
  //
  // const status5 = useScript("../../shared/src/libs/MagicLine4Web/ML4Web/js/ext/ML_Config.js");
  // const status6 = useScript("../../shared/src/libs/MagicLine4Web/ML4Web/js/crypto/magicjs_1.2.1.0.min.js");
  // const status7 = useScript("../../shared/src/libs/MagicLine4Web/ML4Web/js/magic_e2e.js");

  const navigate = useNavigate();
  const formValues: any = useRef(null);
  const {addModal} = useGlobalModalStore();
  const {setSesionId, sesionId, setJoinKey} = useNiceStore()
  const [allCheck, setAllCheck] = useState(false);
  const [isValid, setIsValid] = useState(false);

  const [authBizBox, setAuthBizBox] = useState<authBizType>();
  const [encodeDataCallback, setEncodeDataCallback] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [termsBox, setTermsBox] = useState<TermsResponse[]>([]);
  const [validationBox, setValidationBox] = useState<string[]>([]);
  const [ctx, setCtx] = useState<string>("");
  const [titx, setTitx] = useState<string>("");
  const [openSeven, setOpenSeven] = useState(false);
  const [bizNm, setBizNm] = useState<ProducerType>(initProducerType);
  const [termsConsentSesionId, setTermsConsentSesionId] = useState('')
  const returnedTarget: TermsResponse[] = [];

  // 약관 조회
  const getSearchCategory = async () => {
    const box = await Promise.all([fetchTermsGet('TERMS_OF_USE'), fetchTermsGet('PRVC_CLCT_AGRE_BIZ'), fetchTermsGet('PRVC_THRD_AGRE_BIZ')])
    box.map((item, key) => {
      if (!!item) {
        item.list.map((mbox: any) => {
          returnedTarget.push(mbox)
        })
      }
    })
    setTermsBox(returnedTarget)
  };

  useEffect(() => {
    getSearchCategory();
    $("#pkiContainer").hide();
    window.addEventListener("message", receiveMessage, false);
  }, []);

  let objCert: any = {};

  // MagicLine JS 모듈 호출
  const doSignData = async () => {
    if (!!window) {
      let $form = $("form[name='reqForm']");
      $form.find("input[type='hidden'][name='bizrno']").val(bizNm.bizNum.toString());  // 사업자등록번호
      $form.find("input[type='hidden'][name='callback']").val('pkiCert');   // 콜백으로 받을 함수명

      $form.prop("method", "POST");
      $form.prop("target", "pki-frame");
      $form.prop("action", process.env.REACT_APP_PKI_CERT_URL);         // PKI Monolithic was 서버 공동인증서 페이지 URL

      $form.submit();
      $("#pkiContainer").show();
    }
    // await FetchreactAppPkiCertInitUrl().then((res) => {
    //   let uuid = res.uuid;
    //   let cert = res.cert;
    //
    //   setAuthBizBox((pre: any) => ({...pre, uuid: uuid}))
    //
    //   // 버튼 활성화
    //   if (cert != undefined && cert != "") {
    //     objCert = JSON.parse(cert);
    //     setAuthBizBox((pre: any) => ({...pre, idn: bizNm.bizNum, signOrigin: uuid}))
    //
    //   } else {
    //     alert("공동인증서 모듈 초기화에 실패하였습니다.");
    //   }
    // }).catch((err) => {
    //   if (err.code != "ERR_NETWORK") {
    //     alert("공동인증서 초기화 호출에 오류가 발생되었습니다.");
    //   }
    // })
  }

  // 사업자회원 계정 인증(PRG-COM-AST-02)
  _global.pkiCert = (pkiCertSessionId: string) => {
    let jsonData = {
      termsConsentSessionId: termsConsentSesionId,
      pkiCertSessionId: pkiCertSessionId
    };
    FetchAccountCertBzmn(jsonData).then(data => {
        if (!!data) {
          sessionStorage.setItem("__BIZ_JOIN_KEY__", data.key);
          // 가입여부
          if (data.duplicateYn) {
            if (data.secessionYn) { // 탈퇴계정 전환안내(개인) UI-USP-FRN-0011602 호출
              navigate('/signup/WithdrawPro', {
                state: {
                  key: data.key,
                  loginId: data.loginId,
                  chargerNm: data.chargerNm
                }
              })
            } else {
              navigate('/signup/exist', {
                state: {
                  loginId: data.loginId,
                  chargerNm: data.chargerNm
                }
              })
            }
          } else {
            navigate('/signup/producerform')
          }
          // niceResSave.mutate(data.key)
        }
      }
    );
  }

  // iframe 으로부터 메시지 수신 이벤트 함수
  function receiveMessage(e: any) {
    if (!!e && e.data && typeof e.data == 'string') {
      let data = JSON.parse(e.data);
      //console.log(data);

      // iframe 숨김 처리
      $("#pkiContainer").hide();
      $("#pki-frame").prop("src", "about:blank");

      if (data.code == "0") {
        // 콜백 함수 실행
        new Function(`${data.funcNm}("${data.sessionKey}");`)();
      }
    }
  }

  // 사업자 공동 인증 호출
  const handelProducerForm = () => {
    const boxvalue3: any = [];
    setIsValid(false)
    let boxvalue = termsBox.filter((m) => {
      return m.required == true
    })
    let boxvalue2 = validationBox.filter((m) => {
      return m.includes("false")
    })
    if (((validationBox.length) - (boxvalue2.length)) < boxvalue.length) {
      setIsValid(true)
      return;
    }
    termsBox.map((item, key) => {
      // let isItem = validationBox.filter((m) => {
      //   return m.includes(key + "")
      // });
      // if (isItem.length > 0) {
      //   boxvalue3.push({beginDay: item.beginDay, required: item.required, termsType: item.termsType, consentYn: true})
      //   // setTermsImsiBox(boxvalue3);
      // }
      const validate = validationBox.find(f => f.includes(key.toString()))

      boxvalue3.push({beginDay:item.beginDay,required:item.required,termsType:item.termsType,consentYn: !!validate})
    })
    // 사업자등록번호 확인
    if (!bizNm.bizNum) {
      setBizNm({...bizNm, error: true, label: "사업자등록번호 필수입니다."})
      return;
    }
    if (isNaN(Number(bizNm.bizNum))) {
      setBizNm({...bizNm, error: true, label: "숫자만 입력하세요."})
      return;
    }
    //약관 동의 후 임시 저장
    // 본인인증 서비스 결과 저장  임시... 지우지 마세요

    fetchTermsImsi(boxvalue3).then((res) => {

      if (!!res && res.key) {
        setTermsConsentSesionId(res.key)
        doSignData()
      }
      // setOpen(true)
      /*
        -> 프로세스 정의
          1. 휴대폰 인증 결과에 따라 분기 처리 ( 기가입여부 확인 / 탈퇴여부 확인 / 14미만 확인 이동)
      */
      // 1. 휴대폰 인증 결과에 따라 분기 처리 회원가입-휴대폰 본인인증 PRG-COM-MBR-06 솔루션

      // -> 2. 기가입여부 확인
      if ('isOk') {
        // -> 2.1.탈퇴여부 확인
        if ('isSeven') { // 탈퇴계정 전환안내(개인) UI-USP-FRN-0011602 호출
          setOpenSeven(true)
          // navigate('signup/confirm',{ // TODO ......
          //   state:{
          //     // loginId:loginId,
          //     chargerNm:'UI-USP-FRN-0011602'
          //   }
          // })
        } else { // out 7 day // 기가입 안내 (개인) UI-USP-FRN-0011601 -> 로그인
          // return (
          //   <Fragment>
          //     <ModalComponents open={open} type={'normal'} title={"존재한정보"} content={"기가입 안내 (개인) UI-USP-FRN-001160"}
          //       onConfirm={() => { setOpen(false) }}
          //       onClose={() => { setOpen(false)}}>
          //     </ModalComponents>
          //   </Fragment>
          // )
          // navigate('signup/confirm',{
          //   state:{
          //     // loginId:loginId,
          //     chargerNm:'UI-USP-FRN-0011601'
          //   }
          // })
        }

      } else {
        // -> 3. 14미만 확인 이동
        navigate('signup/confirm', {
          state: {
            // loginId:loginId,
            chargerNm: '14 미만이다'
          }
        })
      }

    }).catch((e) => {
      console.log('catchcatchcatchcatchcatchcatch')
    });
  }

  // 회원가입-탈퇴회원 정상전환
  const callFetchTermsJoin = () => {
    navigate('/signin')
    // todo ......
    // fetchTermsJoin("box").then((res)=>{

    // }).catch((e)=>{ console.log(e); })
    setOpenSeven(false);
  }

  // 사업 번호 입력
  const handelChangebizNm = (e: React.ChangeEvent<HTMLInputElement>) => {
    setBizNm({
      ...bizNm,
      [e.target.name]: e.target.value, error: false, label: "사업자등록번호"
    });
  }

  return (
    <section css={styles.container}>
      <Box css={styles.backPass}>
        <NavLink to={'/signup'}>
          이전 화면으로 돌아가기
        </NavLink>
      </Box>
      <Box css={styles.content}>
        <Stack className="join_head">
          <Box className="tit mobilepd">
            <h1>AICA 회원가입</h1>
          </Box>
          <Box className="step_scroll">
            <Stepper activeStep={0} alternativeLabel css={styles.step} className="steprt">
              {stepsbiz.map((label) => (
                <Step key={label}>
                  <StepLabel>{label}</StepLabel>
                </Step>
              ))}
            </Stepper>
          </Box>
        </Stack>
        <Box sx={{mb: 6}}>
          <Box className="sub_tit">
            <h2>사업자 회원가입</h2>
            <p>AICA 회원가입을 위해 약관에 동의해주세요.</p>
          </Box>
          <Box className="mobilepd">
            <FormGroup css={styles.listboxsup}>
              <FormControlLabel
                className="checklable" sx={{marginLeft: 0}}
                control={
                  <CheckboxStyle
                    checked={allCheck}
                    onClick={(e: React.MouseEvent<HTMLButtonElement>) => {
                      setAllCheck(!allCheck)
                    }}/>}
                label="모든 약관에 동의합니다."
              />
            </FormGroup>
            <FormGroup css={styles.listbox}>
              <CustomCheckBoxs
                checkbox={termsBox}
                isAll={allCheck}
                isValid={isValid}
                onClick={(s: string[]) => {
                  setValidationBox(s)
                  if (termsBox.length !== 0) {
                    setAllCheck((s.length) === (termsBox.length))
                  }
                }}
                modalOpen={(contents: string, titleText: string) => {
                  setCtx(contents)
                  setTitx(titleText)
                  setModalOpen(true);
                }}
              />
            </FormGroup>
            <Box component="div"
             css={styles.singTextbox}>
              <Box className='inputtxt'>
                사업자 확인
              </Box>
              <Box component="div" css={styles.singform} className="mgno lable_center">
                <TextField
                  required
                  id="bizNum"
                  name="bizNum"
                  value={bizNm.bizNum}
                  error={bizNm.error}
                  label={bizNm.label} // "사업자등록번호"
                  variant="filled"
                  fullWidth
                  onChange={handelChangebizNm}
                />
              </Box>
            </Box>
          </Box>
        </Box>
        <Stack spacing={2} direction="row" justifyContent={'center'} css={styles.signbtn} className="btncont2">
          <CustomButton label={'이전'} type={'formbtn'} color={'outlinedgwhite'} onClick={() => navigate(-1)}/>
          {/* onClick={handelProducerForm} */}
          <CustomButton label={'사업자 공동 인증'} type={'formbtn'} color={'primary'} onClick={handelProducerForm}/>
        </Stack>
        {/* <Stack spacing={2} direction="row" justifyContent={'center'} css={styles.signbtn}>
          <Button variant="contained" type="button" className="linebtn" onClick={goInfo}>이전</Button>
          <Button variant="contained" type="button" onClick={handelProducerForm}>휴대폰 본인인증</Button>
        </Stack> */}
        {/* 모달 팝업부분 */}
        <ConsumerModal isOpen={modalOpen} modalClose={() => {
          setModalOpen(false)
        }} ctx={ctx} titx={titx}/>
      </Box>


      <form name="reqForm">
        <input type="hidden" id='bizrno' name='bizrno'/>
        <input type="hidden" id="callback" name="callback"/>
      </form>
      <div id="pkiContainer">
        <iframe
          id="pki-frame" name="pki-frame" src="" scrolling="no" width="100%" height="100%" frameBorder="0"
          style={{
            position: 'fixed',
            zIndex: 100010,
            top: 0, left: 0,
            width: '100%', height: '100%'
          }}>
        </iframe>
      </div>
      {/* <!-- e : 공동인증서 연동 구현 필수 선언 태그 s --> */}
    </section>
  );
}

export default Producer;

function LargeTree(): any {
  return Array.from(new Array(5000)).map((_, index) => <span key={index}>.</span>);
}

type authBizType = {
  sign: string
  signOrigin: string
  vidRandom: string
  vidType: string
  encData: string
  signData: string
  idn: string
}

const CheckboxStyle = styled(Checkbox)`
  &.MuiCheckbox-root {
    padding: 0;
    margin-right: 10px;
  }

  .MuiSvgIcon-root {
    width: 20px;
    height: 20px;
    background-color: #fff;
    border-radius: 4px;

    path {
      display: none;
    }
  }

  &:before {
    content: '';
    position: absolute;
    left: 50%;
    top: 50%;
    width: 20px;
    height: 20px;
    margin: -10px 0 0 -10px;
    border-radius: 3px;
  }

  &.Mui-checked {
    &:before {
      border: none;
      background-color: #4063ec;
      background: url('/images/common/checkbox_active.png');
    }

    .MuiSvgIcon-root {
      background: none;
    }
  }
`;

