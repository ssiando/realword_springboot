// 공고알림/ -> 공지사항 상세페이지
// import React from "react"
import * as styles from '~/styles/styles';
import React, {useState, useEffect, useRef} from 'react';
import dayjs from 'shared/libs/dayjs';
import {useNavigate, useLocation, NavLink, useParams} from 'react-router-dom';
import fetchDownload from '~/fetches/fetchDownload';
import {fetchAnnouncementDetail} from '~/fetches';
import {CustomButton} from '~/components/ButtonComponents';
import {fetchBoardPreNext, fetchImageListGet} from "./../../../fetches/fetchBoard";
import {Banner} from '~/components/Banner';
import {Box, Button, Stack, Typography} from '@mui/material';
import fetchOpenPdf from "~/fetches/fetchOpenPdf";
import {useGlobalModalStore} from "~/pages/store/GlobalModalStore";

function AnnouncementDetail() {
  // const [open, setOpen] = useState(false);
  // const [error, setError] = useState("");
  const navigate = useNavigate();
  const {id} = useParams()
  const receive: any = useLocation();
  const {addModal} = useGlobalModalStore()
  // 목록에서 받아온 값 저장
  const [articleId, setArticleId] = useState(id!);
  const [data, setData]: any = useState([]);
  const [data1, setData1]: any = useState([]);
  const [boardId] = useState('usp-notice');
  const [title] = useState(receive?.state?.articleSrchWord)
  const [urlList, setUrl] = useState([]);
  const [attachmentList, setAttachmentList] = useState([]);
  const [articleCnList, setArticleCnList] = useState([]);
  const [imageList, setImageList] = useState([]);
  const [loading, setLoading] = useState(true)

  const getData = () => {
    setLoading(true)
    fetchAnnouncementDetail({boardId: 'usp-notice', articleId: id!}).then((res: any) => {
      setData(res);
      setUrl(res.articleUrlList);
      setAttachmentList(res.attachmentList);
      setArticleCnList(res.articleCnList);
      setImageList(res.imageList);
      setLoading(false)
    }).catch((e) => {
      addModal({
        open: true,
        content: e.response.data.message,
        onClose: () => {navigate('/Notice/Announcement')},
        onConfirm: () => {navigate('/Notice/Announcement')}
      })
      setLoading(false)
    });
  }
  const getPreNext = () => {
    fetchBoardPreNext({
      boardId: 'usp-notice',
      articleId: id!,
      posting: true,
      title: receive?.state?.articleSrchWord
    }).then((res: any) => {
      setData1(res);
    })
  }
  const getImageList = () => {
    fetchImageListGet('usp-notice', id!).then((res: any) => {
      console.log(res.list)
    })
  }
  useEffect(() => {
    getPreNext();
    getData();
    getImageList();
    if (id) {
      setArticleId(id)
    }
  }, [id])

  const download = async (attachmentId: any) => {
    fetchDownload(`${process.env.REACT_APP_DOMAIN_COMMON_BNET}/common/api/boards/${process.env.REACT_APP_USP_NOTICE}/articles/${articleId}/attachments/${attachmentId}`)
      .then()
      .catch((e) => {
        let status = e.response.status;
        console.log(status);

        if (status === 400) {
          addModal({
            open: true,
            content: "파일이 없습니다."
          })
        }
      });
  }

  return (
    <Banner title={'공지사항'} summary={'AICA에서 진행하는 채용공고, 운영과 관련한 안내사항 등을 확인하실 수 있습니다.'}
            loading={loading}
    >
      <Box css={styles.container}>
        <Box css={styles.sub_cont02}>
          {/* 상세 list 리스트 */}
          <div css={styles.detal_list}>
            <div className="content">
              {/* 텍스트 상단 */}
              <Box css={styles.detal_txtBox}>
                <Typography variant="h5" component="div">
                  {data.title}
                </Typography>
                <div className="date">
                  <span>조회 <em>{data.readCnt}</em></span>
                  <span><em className="ml0">{dayjs(data.updatedDt).format('YYYY-MM-DD')}</em></span>
                </div>
              </Box>
              <Box css={styles.detal_img}>
                {imageList?.map((item: any, i: number) => (
                  <div className="img_box" key={i}>
                    <img
                      src={`${process.env.REACT_APP_DOMAIN_COMMON_BNET}/common/api/boards/${boardId}/articles/${articleId}/images/${item.attachmentId}`}></img>
                  </div>
                ))}
                {!!articleCnList ? articleCnList.map((item: any, i: number) => (
                  <Typography className="txt_box" key={i}>
                    {item.header}
                    <br/>
                    {item.articleCn.replace(/(?:\r\n|\r|\n)/g, '\r\n')
                      .split('\r\n')
                      .map((item: any) => (
                        <p key={item}>
                          {item}
                        </p>
                      ))}
                  </Typography>
                )) : null}
              </Box>
            </div>
            <div className="content">
              <Box css={styles.box_type}>
                <Stack direction="row" alignItems="center" flexWrap="wrap" className="stbottom">
                  <strong className="noline">관련 사이트 주소</strong>
                  {!!urlList
                    ? urlList.map((item: any, i: number) => (
                      <Stack className="flexmo">
                        <div className="link_type" key={i}>
                          <a href={item.url}>{item.url}</a>
                        </div>
                      </Stack>
                    ))
                    : null}
                </Stack>
                <Stack direction="row" alignItems="center" flexWrap="wrap">
                  <strong>첨부파일</strong>
                  {!!attachmentList
                    ? attachmentList.map((item: any, i: number) => (
                      <Stack className="flexmo" css={styles.btnDown} key={i}>
                        <div>
                          <Button onClick={async () => {
                            if (item.fileNm.includes('.pdf')) {
                              await fetchOpenPdf('/pms/api/common/pdf/view', item.attachmentId)
                            } else {
                              download(item.attachmentId)
                            }
                          }}>
                            <span>{item.fileNm}</span>
                          </Button>
                        </div>
                      </Stack>
                    ))
                    : (
                      <div className="filenone">첨부파일 없습니다.</div>
                    )}
                </Stack>
              </Box>
              <div css={styles.bottom_list}>
                {data1.prevArticleId ?
                  <NavLink to={`/Notice/Announcement/${data1.prevArticleId}`}
                           state={{articleSrchWord: receive?.state?.articleSrchWord}}
                    // onClick={()=>setArticleId(data1.prevArticleId)}
                  >
                    <div className="txt01">
                      <div className="prev">
                        이전글
                      </div>
                    </div>
                    <div className="txt02">
                      {data1.prevTitle}
                    </div>
                  </NavLink>
                  : null}
                {data1.nextArticleId ?
                  <NavLink to={`/Notice/Announcement/${data1.nextArticleId}`}
                           state={{articleSrchWord: receive?.state?.articleSrchWord}}
                    // onClick={()=>setArticleId(data1.prevArticleId)}
                  >
                    <div className="txt01">
                      <div className="next">
                        다음글
                      </div>
                    </div>
                    <div className="txt02">
                      {data1.nextTitle}
                    </div>
                  </NavLink>
                  : null}
              </div>
              <Stack direction="row" justifyContent="center" css={styles.btnGroup}>
                <CustomButton label={'목록'} type={'listBack'} color={'outlined'} onClick={() => {
                  navigate('/Notice/Announcement')
                }}/>
              </Stack>
            </div>
          </div>
        </Box>
      </Box>
    </Banner>
  );
}

export default AnnouncementDetail;
