export { default } from './NoticeDetall';
export { default as selectionResDetail } from './SelectionResDetail';
//
