import {Box, Card, CardActionArea, CardContent, CardMedia, Chip, Stack, Typography} from "@mui/material";
import {useEffect, useState} from "react";
import {fetchBusinessInfoNotiGet, fetchEduInfoNotiGet} from "~/fetches";
import {CustomTabsBlacks} from "../../../components/LayoutComponents";
import {Modalfront} from "../../../components/SharedModalComponents";
import * as styles from '~/styles/styles';
import {TabPanel} from "@mui/lab";
import {NavLink} from "react-router-dom";
import authentication from "shared/authentication";

function BusiEduModal() {
  type modalType = 'normal' | 'confirm' | 'none';
  const [type, setType] = useState<modalType>('none');
  const [data, setData] = useState(false);
  const [open, setOpen] = useState(false);
  const [tabValue, setTabValue] = useState('사업정보')
  const [busiList, setBusi]: any = useState([]);
  const [eduList, setEdu]: any = useState([]);

  const getList = () => {
    let a = 1;
    let b = 1;
    if (!!authentication.getToken())
    {
      fetchBusinessInfoNotiGet().then((res: any) => {
        setBusi(res.list);
        if (Array.isArray(res) && res.length === 0) {
          a = 0;
        }
      })
      fetchEduInfoNotiGet().then((res: any) => {
        setEdu(res.list);
        if (Array.isArray(res) && res.length === 0) {
          b = 0;
        }
      })
      if (a === 1 || b === 1) {
        setOpen(true)
      }
    }
  }
  useEffect(() => {
    getList();
  }, []);
  const [busiTotal, setBusiTotal] = useState(busiList.length);
  const [eduTotal, setEduTotal] = useState(eduList.length);

  useEffect(() => {
    if (busiList.length > 5) {
      setBusiTotal(5)
    } else {
      setBusiTotal(busiList.length)
    }

    if (eduList.length > 5) {
      setEduTotal(5)
    } else {
      setEduTotal(eduList.length)
    }
  }, [eduList, busiList])

  const pre = () => {
    if (tabValue == '사업정보' && i > 0) {
      setI(i - 1)
    }else if (tabValue == '교육정보' && eduIndex > 0){
      setEduIndex(eduIndex - 1)
    }
  }
  const next = () => {
    if (tabValue == '사업정보' && i < busiTotal - 1) {
      setI(i + 1)
    }else if (tabValue == '교육정보' && eduIndex < eduTotal - 1){
      setEduIndex(eduIndex +1)
    }
  }
  const preArrowBlind = () => {
    if (tabValue == '사업정보' && i == 0){
      return 'blind'
    }else if (tabValue == '교육정보' && eduIndex == 0){
      return 'blind'
    }

    return ''
  }
  const nextArrowBlind = () => {
    if (tabValue == '사업정보' && i == busiTotal - 1){
      return 'blind'
    }else if (tabValue == '교육정보' && eduIndex== eduTotal - 1){
      return 'blind'
    }

    return ''
  }

  const [i, setI] = useState(0)
  const [eduIndex, setEduIndex] = useState(0)

  return (
    <div>
      {busiTotal > 0 || eduTotal > 0 ?
        <Modalfront
          open={open}
          type={'normal'}
          title={'사업정보알림'}
          content={type.toString() + ' 모달'}
          onConfirm={() => {
            setOpen(false);
          }}
          onClose={() => {
            setOpen(false);
            if (data) setData(false);
          }}
        >
          <Box css={styles.modalCustom} className="home_tabpop" minWidth={'500px'} minHeight={'300px'}>
            <CustomTabsBlacks tabs={[{name: '사업정보', count: busiTotal}, {name: '교육정보', count: eduTotal}]}
            onClick={(newValue) => {setTabValue(newValue)}}>
              {busiTotal > 0 ?
                // `사업정보(${busiTotal})`
                <TabPanel value={`사업정보`}>
                  <NavLink to={`/Notice/Notice/${busiList[i].pblancId}`}>
                    <Stack direction="row" spacing={1} css={styles.tagstyle}>
                      <div>
                        <Chip className="blue" label={busiList[i].recomendCl}/>
                        <Chip className="wh" variant="outlined" label={busiList[i].pblancSttus}/>
                      </div>
                      <Chip
                        label={'마감 D-' + busiList[i].rmndrDay}
                        className="green"
                      />
                    </Stack>
                    <Typography variant="h6" component="div">
                      {busiList[i].pblancNm}
                    </Typography>
                    <hr className="m20"/>
                    <div className="modal_text">
                      {busiList[i].pblancSumry}
                    </div>
                  </NavLink>
                </TabPanel>
                : null}
              {eduTotal > 0 ?
                <TabPanel value={`교육정보`}>
                  <Card css={styles.modalCard}>
                    <CardActionArea>
                      {/*<Stack direction="row" className="tag" spacing={1}>*/}
                      {/*  <div>*/}
                      {/*    <Chip className="blue" label={'기업가정신'}/>*/}
                      {/*    <Chip className="wh" variant="outlined" label={'마감 D' + 1}/>*/}
                      {/*  </div>*/}
                      {/*  <Chip*/}
                      {/*    label={'오늘마감'}*/}
                      {/*    className="green"*/}
                      {/*  />*/}
                      {/*</Stack>*/}
                      <CardMedia
                        component="img" height="267"
                        image={`${process.env.REACT_APP_DOMAIN_COMMON_BNET}${eduList[eduIndex]?.imgFile}`}
                        onError={(e: any) => {
                          e.target.src = '/images/subpage/temp_facility_01.png';
                        }}
                        alt="green iguana"
                      />
                      <CardContent>
                        <Typography gutterBottom variant="h6" component="div">
                          {eduList[eduIndex]?.lecNm}
                        </Typography>
                        <p className="sub_txt icon01">{`총 ${eduList[eduIndex]?.chpCnt} 챕터`}</p>
                        <p className="sub_txt icon02">{`교육인정 ${eduList[eduIndex]?.lecTime}시간`}</p>
                        <p className="sub_txt icon03">
                          {`수강기간 ${eduList[eduIndex]?.apyFrom.replace(/^(\d{4})(\d{2})(\d{2})$/, `$1-$2-$3`)} ~ ${eduList[eduIndex]?.apyTo.replace(/^(\d{4})(\d{2})(\d{2})$/, `$1-$2-$3`)}`}
                        </p>
                      </CardContent>
                    </CardActionArea>
                  </Card>
                </TabPanel>
                : null}
            </CustomTabsBlacks>
            <Box className="popup_listbtn">
              <Box
                className={`prev ${preArrowBlind()}`}
                onClick={pre}/>
              <Box
                className={`next ${nextArrowBlind()}`}
                onClick={next}/>
            </Box>
          </Box>
        </Modalfront>
        : null}
    </div>
  );
};

export default BusiEduModal;