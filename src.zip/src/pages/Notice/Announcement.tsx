// 공고알림/ -> 공지사항 페이지
// import React from "react"
import * as styles from '~/styles/styles';
import React, {useEffect, useState, useRef, useCallback} from 'react';
import dayjs from 'shared/libs/dayjs';
import {NavLink} from 'react-router-dom';
import {fetchAnnouncement} from '~/fetches';
import {CustomButton} from '~/components/ButtonComponents';
import {useGlobalModalStore} from '../store/GlobalModalStore';
import {SearchBar} from '~/components/BizCommon/SearchBar';
import {
  Box,
  Stack,
  Typography,
  List,
  ListItem,
  ListItemText,
  Chip,
  useMediaQuery,
  useTheme,
  Collapse
} from '@mui/material';
import NoData from '~/components/Loading/NoData';
import {Banner} from '~/components/Banner';

function Announcement() {
  const theme = useTheme();
  const {addModal} = useGlobalModalStore();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const today = new Date();
  today.setHours(today.getHours() - 24);
  const [list, setList] = useState([]);
  const [total, setTotal] = useState(0);
  const [srchCd, setSrchCd] = useState("");
  const [srchWord, setSrchWord] = useState("");
  const [loading, setLoading] = useState(true)

  const [params, setParams] = useState({
    boardId: process.env.REACT_APP_USP_NOTICE ? process.env.REACT_APP_USP_NOTICE : '',
    posting: true,
    articleSrchCd: "",
    articleSrchWord: "",
    page: 1,
    itemsPerPage: 5,
  })

  useEffect(() => {
    setSrchCd(params.articleSrchCd)
    setSrchWord(params.articleSrchWord)
  }, [params.articleSrchCd, params.articleSrchWord])

  //처음 세팅
  const getList = () => {
    setLoading(true)
    fetchAnnouncement(params).then((res: any) => {
      setList(res.list);
      setTotal(res.totalItems);
      setLoading(false)
    }).catch((e) => {
      let message = e.response.data.message;
      addModal({
        open: true,
        content: message
      })
      setLoading(false)
    })
  }

  useEffect(() => {
    getList();
  }, [params])

  const moreInfo = () => {
    const itemsPerPage: any = params.itemsPerPage + 10;
    setParams((state) => ({...state, itemsPerPage}));
  }

  return (
    <Banner title={'공지사항'} summary={'AICA에서 진행하는 채용공고, 운영과 관련한 안내사항 등을 확인하실 수 있습니다.'}
            loading={loading}
            searchContent={<SearchBar
              val={srchWord}
              placehold='어떤 공지사항을 찾고 계신가요?'
              onChange={(keyword) => setSrchWord(keyword)}
              handleSearch={(val: any) => {
                setParams((state) => ({...state, articleSrchWord: srchWord}))
              }}/>
            }>
      <Box css={styles.container}>
        <Box css={styles.sub_cont02}>
          <Box className="content list">
            {/* 상세 list 리스트 */}
            <div css={styles.detal_list}>
              <Stack
                spacing={6}
                direction="row"
                className="sub_tit"
                justifyContent="space-between"
              >
                <Typography variant="h4" component="div">
                  공지사항
                  <span className='data'><em>{total}</em> 건</span>
                </Typography>
              </Stack>
              <List>
                {list.length > 0 ? list.map((item: any, i: number) => (
                    <>
                      <NavLink to={`/Notice/Announcement/${item.articleId}`}
                               key={i}
                               state={{
                                 // item: item,
                                 // articleSrchCd: srchCd,
                                 articleSrchWord: srchWord
                               }}>
                        {/* 공지글 일반글 나누는 코드 */}
                        <ListItem style={item.notice ? {backgroundColor: '#f5f5f5'} : {}}>
                          <ListItemText
                            secondary={
                              <React.Fragment>
                      <span className="tit_body">
                        <Typography variant="body1" component="span">
                          {item.title}
                        </Typography>
                        <Stack direction="row" className='tag' spacing={1} component="span">
                          {/* new아이콘 24시간 이내인 경우만 */}
                          {today < item.createdDt ?
                            <Chip label="NEW" className='new' sx={{ml: 1}} component="span"/> : null}
                        </Stack>
                      </span>
                                <Typography
                                  component="span"
                                  variant="body2"
                                  className="body2 ellipsis"
                                  color="text.primary"
                                >
                                  {item.article}<br/>
                                </Typography>
                                <span className="date">
                          <span>조회 <em>{item.readCnt}</em></span>
                          <span><em className="ml0">{dayjs(item.createdDt).format('YYYY-MM-DD')}</em></span>
                        </span>
                              </React.Fragment>
                            }
                          />
                        </ListItem>
                      </NavLink>
                    </>
                  )) :
                  <NoData/>
                }
              </List>
              {(params.itemsPerPage) < total ?
                // 더보기
                <Stack css={styles.bottom_btn}>
                  <CustomButton label={'더보기'} type={'full'} color={'item'} onClick={() => moreInfo()}/>
                </Stack>
                : <Box sx={{borderBottom: "1px solid #e0e0e0"}}/>}
            </div>
          </Box>
        </Box>
      </Box>
    </Banner>
  );
}

export default Announcement;
