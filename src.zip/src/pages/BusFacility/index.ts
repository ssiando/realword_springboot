export { default } from './AboutTheBusinessGroup';
