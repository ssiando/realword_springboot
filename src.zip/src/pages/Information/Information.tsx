import { Avatar, Box, Grid, List, ListItem, ListItemIcon, ListItemText, Stack, styled } from '@mui/material';
import * as styles from '~/styles/styles';
import { BackPass } from '~/components/BackPass';
import { H1, H2, Body3, Body1, Body2, H3 } from '~/../../shared/src/components/TextComponents';
import {CustomSelect} from "~/components/SelectBoxComponents";
import { useState } from 'react';
import {CustomButton} from '~/components/ButtonComponents';
import {Link} from 'react-scroll'
import { NavLink } from 'react-router-dom';

/*
  화면: 개인정보처리방침
  작성자: Seongeonjoo / navycui
  작성일: 20220907
*/
function Information() {
  const [data, setData]: any = useState();
  const [categoryCd, setCategoryCd] = useState("CATE-STEP-01");
  const handleClick = () => {
    
  };
  return (
    <InforContainer css={styles.container}>
      <Box className="content pt40">
        <BackPass />
        <Stack className="title_flex">
          <H1 center preLine bold>
            개인정보 처리방침
          </H1>
          <Stack direction={'row'} spacing={2}>
            <Box sx={{width: '180px'}}>
              <CustomSelect
                value={categoryCd}
                onClick={(selected) => {
                  setCategoryCd(selected)
                }}
                data={[{code:"CATE-STEP-01", codeNm:"2022-01-01 시행"},{code:"CATE-STEP-02", codeNm:"2021-01-01 시행"}]}/>
            </Box>
            <CustomButton label={'확인'} type={'modify'} color={'outlined'} onClick={handleClick}/>
          </Stack>
        </Stack>
          <Box css={styles.box_gray} sx={{lineHeight:'28px', letterSpacing:'-0.64px', color: '#222', mb:'60px'}}>
            인공지능산업융합사업단 이하 ( ‘사업단’)에서 취급하는 모든 개인정보는 관련 법령에 근거하여 수집 · 보유 및 처리되고 있습니다. 사업단은 개인정보 보호법 제 30조에  따라 정보주체의
            개인정보 및 권익을 보호하고 개인정보와 관련한 고충을 신속하고 원활하게 처리할 수 있도록 다음과 같은 개인정보 처리방침을 정하여 운영하고 있습니다.
          </Box>
          <H2 center preLine bold>
            주요 개인정보 처리 표시 (라벨링)
          </H2>
          <Box sx={{ width: '100%', marginTop: '20px'}}>
            <Grid container rowSpacing={4} columnSpacing={{ xs: 1, sm: 2, md: 5 }}>
              <Grid item xs={6}>
                <Stack direction="row" spacing={2.5} alignItems="flex-start">
                  <Box className="infoIcon"><img src="/images/subpage/inforIcon_01.png" alt='개인정보 처리목적'/></Box>
                  <Stack direction="column" className="infor_card">
                    <Body2>개인정보의 처리 목적</Body2>
                    <Body3>회원관리, 포털 서비스 제공</Body3>
                  </Stack>
                </Stack>
              </Grid>
              <Grid item xs={6}>
                <Stack direction="row" spacing={2.5}>
                  <Box className="infoIcon"><img src="/images/subpage/inforIcon_02.png" alt='개인정보의 보유기간'/></Box>
                  <Stack direction="column" className="infor_card">
                    <Body2>개인정보의 보유기간</Body2>
                    <Body3>2년</Body3>
                  </Stack>
                </Stack>
              </Grid>
              <Grid item xs={6}>
                <Stack direction="row" spacing={2.5}>
                  <Box className="infoIcon"><img src="/images/subpage/inforIcon_03.png" alt='일반 개인정보 수집'/></Box>
                  <Stack direction="column" className="infor_card">
                    <Body2>일반 개인정보 수집</Body2>
                    <Body3>필수항목 : 성명, 생년월일 , 성별, 휴대폰번호, 이메일 , ID, 비밀번호<br/>선택항목 : 소속부서, 직위 , 전화번호, 팩스 ,번호, 마케팅정보,수신여부</Body3>
                  </Stack>
                </Stack>
              </Grid>
              <Grid item xs={6}>
                <Stack direction="row" spacing={2.5}>
                  <Box className="infoIcon"><img src="/images/subpage/inforIcon_04.png" alt='개인정보 처리 위탁'/></Box>
                  <Stack direction="column" className="infor_card">
                    <Body2>개인정보 처리 위탁</Body2>
                    <Body3>제 6조 제 1항 ‘개인정보 위탁현황’ 참조</Body3>
                  </Stack>
                </Stack>
              </Grid>
              <Grid item xs={6}>
                <Stack direction="row" spacing={2.5}>
                  <Box className="infoIcon"><img src="/images/subpage/inforIcon_05.png" alt='개인정보 열람 청구'/></Box>
                  <Stack direction="column" className="infor_card">
                    <Body2>개인정보 열람 청구</Body2>
                    <Body3>제 13조 제 1항 개인정보 열람청구 ‘접수·처리 및 개인정보 보호 관련 문의’ 참조</Body3>
                  </Stack>
                </Stack>
              </Grid>
            </Grid>
          </Box>
          <Stack flexDirection={'row'} className="link_ref" sx={{mt: '60px', mb: '60px'}}>
            <Stack flexDirection={'column'} flex={'0 0 50%'}>
              <Link to="cont01" offset={-30} spy={true} smooth={true}>제 1조 (개인정보의 처리목적)</Link>
              <Link to="cont02" offset={-30} spy={true} smooth={true}>제 2조 (개인정보의 처리 항목 및 보유기간)</Link>
              <Link to="cont03" offset={-30} spy={true} smooth={true}>제 3조 (개인정보파일 등록 현황)</Link>
              <Link to="cont04" offset={-30} spy={true} smooth={true}>제 4조 (개인정보영향평가 수행결과)</Link>
              <Link to="cont05" offset={-30} spy={true} smooth={true}>제 5조 (개인정보의 제 3자 제공)</Link>
              <Link to="cont06" offset={-30} spy={true} smooth={true}>제 6조 (개인정보처리의 위탁)</Link>
              <Link to="cont07" offset={-30} spy={true} smooth={true}>제 7조 (정보주체와 법정대리인의 권리 · 의무) 및 행사방법</Link>
              <Link to="cont08" offset={-30} spy={true} smooth={true}>제 8조 (개인정보의 파기절차 및 파기방법)</Link>
              <Link to="cont09" offset={-30} spy={true} smooth={true}>제 9조 (개인정보의 안전성 확보조치)</Link>
            </Stack>
            <Stack flexDirection={'column'} flex={'0 0 50%'}>
              <Link to="cont10" offset={-30} spy={true} smooth={true}>제 10조 (개인정보 자동수집 장치의 설치운영· 및 거부에 관한 사항)</Link>
              <Link to="cont11" offset={-30} spy={true} smooth={true}>제 11조 (가명처리 시 가명처리에 관한 사항)</Link>
              <Link to="cont12" offset={-30} spy={true} smooth={true}>제 12조 (개인정보 보호책임자 및 보호담당자)</Link>
              <Link to="cont13" offset={-30} spy={true} smooth={true}>제 13조 (개인정보 열람청구)</Link>
              <Link to="cont14" offset={-30} spy={true} smooth={true}>제 14조 (권익침해 구제방법)</Link>
              <Link to="cont15" offset={-30} spy={true} smooth={true}>제 15조 (정보주체의 동의없이 추가적인 이용 또는 제공할 때 판단기준)</Link>
              <Link to="cont16" offset={-30} spy={true} smooth={true}>제 16조 (개인정보 처리방침의 변경에 관한 사항)</Link>
            </Stack>
          </Stack>
          <Box className="columnBox" id="cont01">
            <Body1 bold>제 1조 (개인정보의 처리목적)<span className="icons ico01"></span></Body1>
            <Box className="lnnertxt">
              <Box>
                <Box className="subtit">제1항</Box>
                <Body3 color={'#707070'}>사업단은 대국민 서비스 제공 및 민원처리 소관업무 , 수행 등의 목적으로 필요 최소한의 개인정보를 수집하고 있습니다 처리한 . 개인정보는 목적이외의 용도로는 이용되지 않으며 이용 , 목적이 변경되는 경우에는 개인정보 보호법 제 18조에 따라 별도의 동의를 받는 등 필요한 조치를 이행할 예정입니다.</Body3>
              </Box>
              <Box className="mt16">
                <Box className="subtit">제2항</Box>
                <Body3 color={'#707070'}>사업단이 개인정보 보호법 제 32조에 따라 등록 · 공개하는 개인정보파일의처리목적은 다음과 같습니다.</Body3>
                <Box className="dot mt8">사업단 개인정보파일 현황</Box>
                <Box className='tableDefault_scroll'>
                  <table className="tableDefault">
                    <colgroup>
                      <col style={{width: '19%'}}/>
                      <col style={{width: '10%'}}/>
                      <col style={{width: '14%'}}/>
                      <col style={{width: '23%'}}/>
                      <col style={{width: '23%'}}/>
                      <col/>
                    </colgroup>
                    <thead>
                      <tr>
                        <th rowSpan={2}>개인정보파일의 명칭</th>
                        <th rowSpan={2}>운영근거</th>
                        <th rowSpan={2}>처리목적</th>
                        <th colSpan={2}>처리항목</th>
                        <th rowSpan={2}>보유기간</th>
                      </tr>
                      <tr>
                        <th>필수항목</th>
                        <th>선택항목</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>AI 통합지원 서비스 플랫폼 <br/>회원정보</td>
                        <td>정보주체<br/>동의</td>
                        <td>회원관리, <br/>포털 서비스 제공</td>
                        <td>성명, 생년월일, 성별, <br/>휴대폰번호, 이메일, ID, 비밀번호</td>
                        <td>소속부서, 직위, 전화번호, <br/>팩스 번호, 마케팅정보,수신여부</td>
                        <td>2년</td>
                      </tr>
                    </tbody>
                  </table>
                </Box>
              </Box>
            </Box>
          </Box>
          <Box className="columnBox" id="cont02">
            <Body1 bold>제 2조 (개인정보의 처리 항목 및 보유기간)<span className="icons ico03"></span><span className="icons ico02"></span></Body1>
            <Box className="lnnertxt">
              <Box>
                <Box className="subtit">제1항</Box>
                <Body3 color={'#707070'}>사업단에서 처리하는 개인정보는 수집 · 이용 목적으로 명시한 범위 내에서 처리하며, 개인정보보호법 및 관련법령 등에서 정하는 보유기간을 준용하며, 개인정보 수집 시에 정보주체의 동의를 받은 개인정보 보유기간 내에서 개인정보를 처리 · 보유합니다.</Body3>
              </Box>
              <Box className="mt16">
                <Box className="subtit">제2항</Box>
                <Body3 color={'#707070'}>사업단에서 처리하는 개인정보항목, 보유 기간은 본 방침 제 1조 2항의 ‘개인정보파일 현황’과 같습니다.</Body3>
              </Box>
            </Box>
          </Box>
          <Box className="columnBox" id="cont03">
            <Body1 bold>제 3조 (개인정보파일 등록 현황)</Body1>
            <Box className="lnnertxt">
              <Box>
                <Body3 color={'#707070'}>사업단이「 개인정보 보호법」제 32조에 따라 등록 · 공개하는 개인정보파일의 처리목적 · 보유기간 및 항목은 본 방침 제 1조 2항의 ‘개인정보파일 현황’과 같습니다.</Body3>
              </Box>
            </Box>
          </Box>
          <Box className="columnBox" id="cont04">
            <Body1 bold>제 4조 (개인정보영향평가 수행결과)</Body1>
            <Box className="lnnertxt">
              <Box>
                <Box className="subtit">제1항</Box>
                <Body3 color={'#707070'}>사업단에서 운영하고 있는 개인정보 처리시스템이 개인정보파일에 미칠 영향에 대해 조사, 분석, 평가하기 위해「 개인정보 보호법」 제 33조에  따라 “개인정보 영향평가”를 받고 있습니다.</Body3>
              </Box>
              <Box className="mt16">
                <Box className="subtit">제2항</Box>
                <Body3 color={'#707070'}> 사업단은 다음 개인정보파일에 대해 영향평가를 수행하였습니다.</Body3>
                <Box className='tableDefault_scroll'>
                  <table className="tableDefault">
                    <colgroup>
                      <col style={{width: '30%'}}/>
                      <col style={{width: '50%'}}/>
                      <col />
                    </colgroup>
                    <thead>
                      <tr>
                        <th>개인정보파일</th>
                        <th>개인정보파일에 기록되는 개인정보 항목</th>
                        <th>영향평가 수행연도</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>AI 통합지원 서비스 플랫폼 회원정보</td>
                        <td>(필수) 성명, 생년월일, 성별, 휴대폰번호, 이메일, 비밀번호, ID<br/>(선택) 소속부서, 직위, 전화번호, 팩스번호</td>
                        <td>2년</td>
                      </tr>
                    </tbody>
                  </table>
                </Box>
              </Box>
            </Box>
          </Box>
          <Box className="columnBox" id="cont05">
            <Body1 bold>제 5조 (개인정보의 제 3자 제공)</Body1>
            <Box className="lnnertxt">
              <Box>
                <Box className="subtit">제1항</Box>
                <Body3 color={'#707070'}>사업단은 원칙적으로 정보주체의 개인정보를 처리 목적 범위 내에서 처리하며, 정보주체의 사전 동의 없이는 본래의 범위를 초과하여 처리하거나 제3자에게 제공하지 않습니다. 단, 다음의 각 호의 경우에는 개인정보 보호법 제 18조  제 2항에 따라 예외적으로 개인정보를 제 3자에게  제공할 수 있습니다.</Body3>
                <List className='inforlist'>
                  <ListItem>
                    <ListItemText
                      primary="1. 정보주체에게 동의를 얻은 경우"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="2. 다른 법률에 특별한 규정이 있는 경우"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="3. 정보주체 또는 그 법정대리인이 의사표시를 할 수 없는 상태에 있거나 주소불명 등으로 사전 동의를 받을 수 없는 경우로서 명백히 정보주체 또는 제 3자의 급박한 생명, 신체, 재산의 이익을 위하여 필요하다고 인정되는 경우"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="4. 개인정보를 목적 외의 용도로 이용하거나 이를 제 3자에게  제공하지 아니하면 다른 법률 에서 정하는 소관 업무를 수행할 수 없는 경우로서 보호위원회의 심의·의결을 거친 경우"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="5. 조약 그 밖의 국제협정의 이행을 위하여 외국정부 또는 국제기구에 제공하기 위하여 필요한 경우"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="6. 범죄의 수사와 공소의 제기 및 유지를 위하여 필요한 경우"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="7. 법원의 재판업무 수행을 위하여 필요한 경우"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="8. 법원의 재판업무 수행을 위하여 필요한 경우"
                    />
                  </ListItem>
                </List>
              </Box>
              <Box className="mt16">
                <Box className="subtit">제2항</Box>
                <Body3 color={'#707070'}>사업단에서 개인정보를 제 3자에게  제공하는 경우 본 개인정보 처리방침을 통하여 공개할 예정입니다.</Body3>
              </Box>
            </Box>
          </Box>
          <Box className="columnBox" id="cont06">
            <Body1 bold>제 6조 (개인정보처리의 위탁)<span className="icons ico04"></span></Body1>
            <Box className="lnnertxt">
              <Box>
                <Box className="subtit">제1항</Box>
                <Body3 color={'#707070'}>사업단은 원활한 개인정보 업무처리를 위하여 다음과 같이 개인정보 처리업무를 위탁하고 있습니다.</Body3>
                <Box className="dot mt8">사업단 개인정보파일 현황</Box>
                <Box className='tableDefault_scroll'>
                  <table className="tableDefault">
                    <colgroup>
                      <col style={{width: '15%'}}/>
                      <col style={{width: '25%'}}/>
                      <col style={{width: '15%'}}/>
                      <col style={{width: '15%'}}/>
                      <col />
                    </colgroup>
                    <thead>
                      <tr>
                        <th>위탁부서</th>
                        <th>수탁자명</th>
                        <th>담당자 연락처</th>
                        <th>근무시간</th>
                        <th>위탁업무</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>데이터 융합팀</td>
                        <td>쌍용정보통신 컨소시엄</td>
                        <td>062-974-2491</td>
                        <td>09:00~18:00</td>
                        <td>AI통합지원서비스플랫폼 구축 및 운영 고도화</td>
                      </tr>
                    </tbody>
                  </table>
                </Box>
              </Box>
              <Box className="mt16">
                <Box className="subtit">제2항</Box>
                <Body3 color={'#707070'}>사업단은 위탁계약 체결시 개인정보 보호법 제26조에 따라 위탁업무 수행목적 외 개인정보 처리금지, 기술적․관리적 보호조치, 재위탁 제한, 수탁자에 대한 관리․감독, 손해배상 등 책임에 관한 사항을 계약서 등 문서에 명시하고, 수탁자가 개인정보를 안전하게 처리하는지를 감독하고 있습니다.</Body3>
              </Box>
              <Box className="mt16">
                <Box className="subtit">제3항</Box>
                <Body3 color={'#707070'}>사업단은 위탁업무의 내용이나 수탁자가 변경될 경우에는 지체없이 본 개인정보 처리방침을 통하여 공개하도록 하겠습니다.</Body3>
              </Box>
            </Box>
          </Box>
          <Box className="columnBox" id="cont07">
            <Body1 bold>제 7조 (정보주체와 법정대리인의 권리·의무 및 행사방법)</Body1>
            <Box className="lnnertxt">
              <Box>
                <Box className="subtit">제1항</Box>
                <Body3 color={'#707070'}>정보주체는 사업단에 대해 언제든지 개인정보 열람·정정·삭제·처리정지 요구 등의 권리를 행사할 수 있습니다.</Body3>
              </Box>
              <Box className="mt16">
                <Box className="subtit">제2항</Box>
                <Body3 color={'#707070'}>제1항에 따른 권리 행사는 개인정보(열람, 정정·삭제, 처리정리) 요구서를 서면, 전자우편, 모사전송(FAX) 등을 통해 요구할 수 있으며, 회사는 이에 대해 지체없이 조치하겠습니다.</Body3>
                <Box className="dot"><NavLink to='/'>개인정보 열람, 정정·삭제, 처리정지 요구서 다운로드(개인정보 보호지침 별지 제5호 서식)</NavLink></Box>
              </Box>
              <Box className="mt16">
                <Box className="subtit">제3항</Box>
                <Body3 color={'#707070'}>정보주체가 개인정보의 오류 등에 대한 정정 또는 삭제를 요구한 경우에는 사업단은 정정 또는 삭제를 완료할 때까지 당해 개인정보를 이용하거나 제공하지 않습니다.</Body3>
                <Box className="dot"><NavLink to='/'>개인정보 열람, 정정·삭제, 처리정지 요구서 다운로드(개인정보 보호지침 별지 제5호 서식)</NavLink></Box>
              </Box>
              <Box className="mt16">
                <Box className="subtit">제4항</Box>
                <Body3 color={'#707070'}>제1항에 따른 권리 행사는 정보주체의 법정대리인이나 위임을 받은 자 등 대리인을 통하여 하실 수 있습니다. 이 경우 개인정보 처리 방법에 관한 고시 별지 제11호 서식에 따른 위임장을 제출하셔야 합니다.</Body3>
                <Box className="dot"><NavLink to='/'>위임장 다운로드(개인정보 보호지침 별지 제8호 서식)</NavLink></Box>
              </Box>
              <Box className="mt16">
                <Box className="subtit">제5항</Box>
                <Body3 color={'#707070'}>개인정보의 열람 및 정정·삭제, 처리정지 요구는 개인정보 보호법 제35조 제4항, 제37조 제2항에 의하여 정보주체의 권리가 제한될 수 있습니다.</Body3>
              </Box>
              <Box className="mt16">
                <Box className="subtit">제6항</Box>
                <Body3 color={'#707070'}>개인정보의 정정 및 삭제 요구는 개인정보 보호법 제36조 제1항에 따라 다른 법령에서 그 개인정보가 수집 대상으로 명시되어 있는 경우에는 그 삭제를 요구할 수 없습니다.</Body3>
              </Box>
              <Box className="mt16">
                <Box className="subtit">제7항</Box>
                <Body3 color={'#707070'}>사업단에 정보주체 권리에 따른 열람의 요구, 정정·삭제의 요구, 처리정지의 요구 시 열람 등 요구를 한 자가 본인이거나 정당한 대리인인지를 확인합니다.</Body3>
              </Box>
              <Box className="mt16">
                <Box className="subtit">제8항</Box>
                <Body3 color={'#707070'}>개인정보 열람·정정·삭제·처리정지는 개인정보보호 포털(www.privacy.go.kr)의 “민원마당 → 개인정보열람등 요구 (아이핀 또는 휴대폰을 통한 본인인증 필요)” 메뉴를 통하여서도 요구할 수 있습니다.</Body3>
              </Box>
              <Box className="mt16">
                <Box className="subtit">제9항</Box>
                <Body3 color={'#707070'}>사업단은 정보주체가 열람 등 요구에 대한 거절 등 조치에 대하여 불복이 있는 경우 이의를 제기할 수 있도록 필요한 절차를 다음과 같이 안내합니다.</Body3>
                <List className='inforlist'>
                  <ListItem>
                    <ListItemText
                      primary="1. 불복사유"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary={<ul><li>가. 정보공개 청구에 대한 회사의 열람거절</li><li>나. 정보공개 청구에 대한 회사의 일부열람</li><li>다. 정보공개 청구일로부터 20일 이내에 회사가 공개 여부를 통지하지 않은 경우</li></ul>}
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="2. 처리절차"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary={<ul><li>가. 이의신청 : 사업단으로부터 열람여부의 결정통지를 받은 날 또는 열람 거절의 결정이 있는 것으로 보는 날부터 “30일”이내 제기</li><li>나. 행정심판 : 처분이 있음을 안 날부터 “90일” 이내 제기(처분이 있은 날로부터 180일이 경과하면 제기 불가)</li><li>다. 행정소송 : 처분 등이 있음을 안 날부터 “90일” 이내(처분 등이 있는 날로부터 1년이 경과하면 제기 불가)</li></ul>}
                    />
                  </ListItem>
                </List>
              </Box>
            </Box>
          </Box>
          <Box className="columnBox" id="cont08">
            <Body1 bold>제 8조 (개인정보의 파기절차 및 파기방법)</Body1>
            <Box className="lnnertxt">
              <Box>
                <Box className="subtit">제1항</Box>
                <Body3 color={'#707070'}>사업단은 원칙적으로 개인정보 보유기간이 경과했거나 처리목적이 달성된 경우에는 지체없이 해당 개인정보를 파기합니다. 다만, 다른 법령에 따라 보존하여야 하는 경우에는 그러하지 아니하며 해당 개인정보를 다른 개인정보와 분리하여 저장·관리합니다.</Body3>
              </Box>
              <Box className="mt16">
                <Box className="subtit">제2항</Box>
                <Body3 color={'#707070'}>파기의 절차, 기한 및 방법은 다음과 같습니다.</Body3>
                <List className='inforlist'>
                  <ListItem>
                    <ListItemText
                      primary="1. 파기절차 및 기한"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary={<ul><li>개인정보의 처리목적이 달성된 경우 또는 보유기간이 경과한 개인정보와 개인정보파일은 내부관리계획·절차 및 관련 법령에 따라 파기합니다.</li><li>가. 개인정보의 파기 : 보유기간이 경과한 개인정보는 종료일로부터 지체없이 파기합니다.</li><li>나. 개인정보파일의 파기 : 개인정보파일의 처리 목적 달성, 해당 업무 또는 서비스 종료 등으로 인하여 그 개인정보파일이 불필요하게 되었을 때에는, 개인정보의 처리가 불필요한 것으로 인정되는 날로부터 지체 없이 그 개인정보파일을 파기합니다.</li></ul>}
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="2. 파기방법"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary={<ul><li>가. 전자적 파일 형태인 경우 : 복원이 불가능한 방법으로 영구 삭제</li><li>나. 전자적 파일 형태 외의 기록물, 인쇄물, 서면, 그 밖의 기록매체인 경우 : 파쇄 또는 소각</li></ul>}
                    />
                  </ListItem>
                </List>
              </Box>
            </Box>
          </Box>
          <Box className="columnBox" id="cont09">
            <Body1 bold>제 9조 (개인정보의 파기절차 및 파기방법)</Body1>
            <Box className="lnnertxt">
              <Box>
                <Box className="subtit">제1항</Box>
                <Body3 color={'#707070'}>사업단은 개인정보 보호법 제29조에 따라 다음과 같이 안전성 확보에 필요한 기술적, 관리적, 물리적 조치를 하고 있습니다.</Body3>
                <List className='inforlist'>
                  <ListItem>
                    <ListItemText
                      primary="1. 내부관리계획의 수립 및 시행"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary={<ul><li>사업단이 취급하는 개인정보가 분실, 도난, 누출, 변조, 훼손, 오·남용 되지 않도록 내부관리계획 수립 및 시행을 통해 체계적으로 관리하고 있습니다.</li></ul>}
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="2. 내부관리계획의 수립 및 시행"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary={<ul><li>개인정보 취급 담당자의 최소화 및 교육</li></ul>}
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="3. 개인정보에 대한 접근 제한"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary={<ul><li>개인정보를 처리하는 데이터베이스시스템에 대한 접근권한의 부여, 변경, 말소를 통하여 개인정보에 대한 접근통제를 위한 필요한 조치를 하고 있으며, 침입차단시스템을 이용하여 외부로부터의 무단 접근을 통제하고 있습니다.</li></ul>}
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="4. 개인정보의 암호화"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary={<ul><li>개인정보는 암호화 등을 통해 안전하게 저장·관리되고 있으며, 중요한 데이터는 저장 및 전송 시 암호화 하여 사용하는 등 별도의 보안기능을 사용하고 있습니다.</li></ul>}
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="5. 접속기록의 보관 및 위변조 방지"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary={<ul><li>개인정보처리시스템에 접속한 기록을 최소 1년 이상 보관, 관리하고 있으며, 접속기록이 위변조 및 도난, 분실되지 않도록 조치하고 있습니다.</li></ul>}
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="6. 보안프로그램 설치 및 주기적 점검·갱신"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary={<ul><li>해킹이나 컴퓨터 바이러스 등에 의한 개인정보 유출 및 훼손을 막기 위하여 백신소프트웨어 등 보안프로그램을 운영하고 있으며 일 1회 이상 업데이트를 하고 있습니다.</li></ul>}
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="7. 비인가자에 대한 출입 통제"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary={<ul><li>개인정보를 보관하고 있는 개인정보시스템의 물리적 보관 장소를 별도로 두고 이에 대해 출입통제 절차를 수립, 운영하고 있습니다.</li></ul>}
                    />
                  </ListItem>
                </List>
              </Box>
            </Box>
          </Box>
          <Box className="columnBox" id="cont10">
            <Body1 bold>제 10조 (개인정보 자동수집 장치의 설치·운영 및 거부에 관한 사항)</Body1>
            <Box className="lnnertxt">
              <Box>
                <Box className="subtit">제1항</Box>
                <Body3 color={'#707070'}>사업단은 이용자의 웹사이트 방문기록 파악을 위해 이용정보를 저장하고 불러오는 ‘쿠키(cookie)’를 사용하며, 해당 정보를 목적 외로 이용하거나 제3자에게 제공하지 않습니다.</Body3>
              </Box>
              <Box className="mt16">
                <Box className="subtit">제2항</Box>
                <Body3 color={'#707070'}>쿠키는 웹사이트를 운영하는데 이용되는 서버가 이용자의 컴퓨터 브라우저에게 보내는 소량의 정보(텍스트 파일)이며 이용자의 PC 내의 하드디스크에 저장되기도 합니다. 이용자는 웹브라우저의 보안설정을 통해 쿠키의 허용·거부 여부를 선택하실 수 있습니다.</Body3>
                <List className='inforlist'>
                  <ListItem>
                    <ListItemText
                      primary="1. 쿠키의 사용목적"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary={<ul><li>이용자의 접속빈도, 방문시간 등 웹사이트 방문 기록을 파악하여 이용자에게 최적화된 정보를 제공하는데 사용됩니다.</li></ul>}
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="2. 쿠키의 설치‧운영 및 거부"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary={<ul><li>웹브라우저 상단의 ‘도구 &gt; 인터넷옵션 &gt; 개인정보 &gt; 고급’ 메뉴의 옵션 설정을 통해 쿠키 저장을 거부할 수 있습니다. 쿠키 저장을 거부할 경우 맞춤형 서비스 이용에 어려움이 발생할 수 있습니다. 사업단은 홈페이지 운영에 있어 필요 시 정보주체의 정보를 찾아내고 저장하는 ‘자동수집장치(쿠키 등)를 운용합니다.</li></ul>}
                    />
                  </ListItem>
                </List>
              </Box>
            </Box>
          </Box>
          <Box className="columnBox" id="cont11">
            <Body1 bold>제 11조 (가명처리 시 가명처리에 관한 사항)</Body1>
            <Box className="lnnertxt">
              <Box>
                <Box className="subtit">제1항</Box>
                <Body3 color={'#707070'}>사업단은 통계작성, 과학적 연구, 공익적 기록보존 등을 위하여 수집한 개인정보를 특정 개인을 알아볼 수 없도록 개인정보를 가명처리 하여 사용하는 경우, 정보주체가 지체없이 확인할 수 있도록 다음의 사항을 포함하여 안내하겠습니다.</Body3>
                <List className='inforlist'>
                  <ListItem>
                    <ListItemText
                      primary="1. 가명정보 처리 목적"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="2. 가명정보 처리 및 보유 기간"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="3. 가명정보 제3자 제공에 관한 사항(해당되는 경우)"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="4. 가명정보 처리의 위탁에 관한 사항(해당되는 경우)"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="5. 처리하는 가명정보의 항목"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="6. 가명정보의 안전성 확보 조치에 관한 사항"
                    />
                  </ListItem>
                </List>
              </Box>
            </Box>
          </Box>
          <Box className="columnBox" id="cont12">
            <Body1 bold>제 12조 (개인정보 보호책임자 및 보호담당자)</Body1>
            <Box className="lnnertxt">
              <Box>
                <Box className="subtit">제1항</Box>
                <Body3 color={'#707070'}>사업단은 개인정보 처리에 관한 업무를 총괄해서 책임지고, 개인정보 처리와 관련한 정보주체의 불만처리 및 피해구제 등을 위하여 아래와 같이 개인정보 보호책임자 및 보호담당자를 지정하고 있습니다.</Body3>
                <Box className="dot mt8">개인정보 보호책임자 및 보호담당자 현황</Box>
                <Box className='tableDefault_scroll'>
                  <table className="tableDefault">
                    <colgroup>
                      <col style={{width: '20%'}}/>
                      <col style={{width: '25%'}}/>
                      <col style={{width: '15%'}}/>
                      <col style={{width: '15%'}}/>
                      <col />
                    </colgroup>
                    <thead>
                      <tr>
                        <th>구분</th>
                        <th>부서명/직책</th>
                        <th>성명</th>
                        <th>연락처</th>
                        <th>이메일</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>개인정보 보호책임자</td>
                        <td>사업본부/본부장</td>
                        <td>곽재도</td>
                        <td rowSpan={3}>062-610-3921</td>
                        <td rowSpan={3}>jhbyun@aicluster.or.kr</td>
                      </tr>
                      <tr>
                        <td>개인정보 보호책임자</td>
                        <td>사업본부/본부장</td>
                        <td className="borrt">곽재도</td>
                      </tr>
                      <tr>
                        <td>개인정보 보호책임자</td>
                        <td>사업본부/본부장</td>
                        <td className="borrt">곽재도</td>
                      </tr>
                    </tbody>
                  </table>
                </Box>
              </Box>
              <Box className="mt16">
                <Box className="subtit">제2항</Box>
                <Body3 color={'#707070'}>정보주체는 사업단의 서비스(또는 사업)를 이용하시면서 발생한 모든 개인정보 보호 관련 문의, 불만처리, 피해구제 등에 관한 사항을 개인정보 보호책임자 및 담당부서로 문의하실 수 있습니다. 사업단은 정보주체의 문의에 대해 지체없이 답변 및 처리해 드릴 것입니다.</Body3>
              </Box>
            </Box>
          </Box>
          <Box className="columnBox" id="cont13">
            <Body1 bold>제 13조 (개인정보 열람청구)<span className="icons ico05"></span></Body1>
            <Box className="lnnertxt">
              <Box>
                <Box className="subtit">제1항</Box>
                <Body3 color={'#707070'}>정보주체는 개인정보 보호법 제35조에 따른 개인정보의 열람 청구 및 개인정보 보호 관련 문의를 아래의 부서에 할 수 있습니다. 사업단은 정보주체의 개인정보 열람청구가 신속하게 처리되도록 노력하겠습니다.</Body3>
                <Box className="dot mt8">개인정보 열람청구 접수·처리 및 개인정보 보호 관련 문의</Box>
                <Box className='tableDefault_scroll'>
                  <table className="tableDefault">
                    <colgroup>
                      <col style={{width: '30%'}}/>
                      <col style={{width: '15%'}}/>
                      <col style={{width: '15%'}}/>
                      <col style={{width: '15%'}}/>
                      <col />
                    </colgroup>
                    <thead>
                      <tr>
                        <th>부서명 </th>
                        <th>성명</th>
                        <th>연락처</th>
                        <th>연락처</th>
                        <th>이메일</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>인공지능데이터센터 데이터융합팀</td>
                        <td>변정환</td>
                        <td>062-610-3921</td>
                        <td>062-974-1943</td>
                        <td>jhbyun@aicluster.or.kr</td>
                      </tr>
                    </tbody>
                  </table>
                </Box>
              </Box>
              <Box className="mt16">
                <Box className="subtit">제2항</Box>
                <Body3 color={'#707070'}>정보주체는 개인정보보호법 제35조에 따른 개인정보의 열람청구를 개인정보보호위원회의 개인정보보호 포털 웹사이트(www.privacy.go.kr)’를 통하여 개인정보 열람청구를 하실 수도 있습니다.</Body3>
                <List className='inforlist'>
                  <ListItem>
                    <ListItemText
                      primary="- 개인정보보호 포털(www.privacy.go.kr)의 “민원마당 → 개인정보열람등 요구(아이핀 또는 휴대폰을 통한 본인인증 필요)”"
                    />
                  </ListItem>
                </List>
              </Box>
            </Box>
          </Box>
          <Box className="columnBox" id="cont14">
            <Body1 bold>제 14조 (권익침해 구제방법)</Body1>
            <Box className="lnnertxt">
              <Box>
                <Box className="subtit">제1항</Box>
                <Body3 color={'#707070'}>정보주체는 아래의 기관에 대해 개인정보 침해에 대한 피해구제, 상담 등을 문의하실 수 있습니다.</Body3>
                <List className='inforlist'>
                  <ListItem>
                    <ListItemText
                      primary="- 아래의 기관은 사업단과는 별개의 기관으로서, 사업단의 자체적인 개인정보 불만처리, 피해구제 결과에 만족하지 못하시거나 보다 자세한 도움이 필요하시면 문의하여 주시기 바랍니다."
                    />
                  </ListItem>
                </List>
                <Box sx={{marginLeft:'30px'}}>
                  <Box className="dot">개인정보 침해신고센터 (한국인터넷진흥원 운영)</Box>
                  <Box className='tableDefault_scroll'>
                    <table className="tableDefault">
                      <colgroup>
                        <col style={{width: '24%'}}/>
                        <col style={{width: '15%'}}/>
                        <col style={{width: '12%'}}/>
                        <col />
                      </colgroup>
                      <thead>
                        <tr>
                          <th>소관업무</th>
                          <th>홈페이지</th>
                          <th>전화</th>
                          <th>주소</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>개인정보 침해사실 신고, 상담 신청</td>
                          <td>privacy.kisa.or.kr</td>
                          <td>(국번없이) 118</td>
                          <td>(58324) 전남 나주시 진흥길 9(빛가람동 301-2) 3층 개인정보 침해신고센터</td>
                        </tr>
                      </tbody>
                    </table>
                  </Box>
                  <Box className="dot mt8">개인정보 분쟁조정위원회</Box>
                  <Box className='tableDefault_scroll'>
                    <table className="tableDefault">
                      <colgroup>
                        <col style={{width: '24%'}}/>
                        <col style={{width: '15%'}}/>
                        <col style={{width: '12%'}}/>
                        <col />
                      </colgroup>
                      <thead>
                        <tr>
                          <th>소관업무</th>
                          <th>홈페이지</th>
                          <th>전화</th>
                          <th>주소</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>개인정보 분쟁조정신청, 집단분쟁조정 (민사적 해결)</td>
                          <td>www.kopico.go.kr</td>
                          <td>1833-6972</td>
                          <td>(03171) 서울시 종로구 세종대로 209 정부서울청사 12층</td>
                        </tr>
                      </tbody>
                    </table>
                  </Box>
                  <Box className="dot mt8">대검찰청 사이버범죄수사단</Box>
                  <Box sx={{color: '#707070', ml: '10px', mt:'8px'}}>(국번없이) 1031 (www.spo.go.kr, cid@spo.go.kr)</Box>
                  <Box className="dot mt8">경찰청 사이버안전국</Box>
                  <Box sx={{color: '#707070', ml: '10px', mt:'8px'}}>(국번없이) 182 (cyberbureau.police.go.kr)</Box>
                </Box>
              </Box>
              <Box className="mt16">
                <Box className="subtit">제2항</Box>
                <Body3 color={'#707070'}>또한, 개인정보의 열람, 정정·삭제, 처리정지 등에 대한 정보주체의 요구에 대하여 사업단이 행한 처분 또는 부작위로 인하여 권리 또는 이익을 침해 받은 자는 행정심판법이 정하는 바에 따라 행정심판을 청구할 수 있습니다. 행정심판에 대한 자세한 사항은 중앙행정심판위원회(www.simpan.go.kr)의 홈페이지를 참고하시기 바랍니다.</Body3>
              </Box>
            </Box>
          </Box>
          <Box className="columnBox" id="cont15">
            <Body1 bold>제 15조 (정보주체의 동의없이 추가적인 이용 또는 제공할 때 판단기준)</Body1>
            <Box className="lnnertxt">
              <Box>
                <Body3 color={'#707070'}>정보주체의 동의없이 개인정보의 추가적인 이용 또는 제공할 때의 판단기준은 다음과 같습니다.</Body3>
                <List className='inforlist'>
                  <ListItem>
                    <ListItemText
                      primary="1. 당초 수집 목적과 관련성이 있는지 여부"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="2. 개인정보를 수집한 정황 또는 처리 관행에 비추어 볼 때 개인정보의 추가적인 이용 또는 제공에 대한 예측 가능성이 있는지 여부"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="3. 정보주체의 이익을 부당하게 침해하는지 여부"
                    />
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="4. 가명처리 또는 암호화 등 안전성 확보에 필요한 조치를 하였는지 여부"
                    />
                  </ListItem>
                </List>
              </Box>
            </Box>
          </Box>
          <Box className="columnBox" id="cont16">
            <Body1 bold>제 16조 (개인정보 처리방침의 변경에 관한 사항)</Body1>
            <Box className="lnnertxt">
              <Box>
                <Body3 color={'#707070'}>본 개인정보 처리방침은 2022년 1월 1일부터 시행됩니다.</Body3>
              </Box>
            </Box>
          </Box>
      </Box>
    </InforContainer>
  )
}

const InforContainer = styled(Box)`
  background-color:#fff;
  letter-spacing: -0.64px;
  .title_flex{
    flex-direction: row;
    justify-content: space-between; 
    align-items: center;
    margin-bottom: 48px; 
    margin-top: 40px;
  }
  .columnBox{
    margin-top: 30px;
    .lnnertxt{
      padding: 30px; 
      border-top: 1px solid #1f2437; 
      margin-top: 20px; 
    }
    .icons{
      width: 40px; height: 40px; display: inline-block; margin-bottom: -5px;
      margin-left: 8px;
      &.ico01{
        background: url('/images/subpage/inforIcon_01.png') no-repeat; 
        background-size: cover;
      }
      &.ico02{
        background: url('/images/subpage/inforIcon_02.png') no-repeat;
        background-size: cover;
      }
      &.ico03{
        background: url('/images/subpage/inforIcon_03.png') no-repeat; 
        background-size: cover;
      }
      &.ico04{
        background: url('/images/subpage/inforIcon_04.png') no-repeat; 
        background-size: cover;
      }
      &.ico05{
        background: url('/images/subpage/inforIcon_05.png') no-repeat; 
        background-size: cover;
      }
    }
  }
  .infor_card{
    > span{
      &:first-child{
        margin-bottom: 4px;
        font-weight: 500;
      }
    } 
  }
  .link_ref{
    a{
      color: #222;
      font-size: 16px;
      line-height: 1.88;
      letter-spacing: -0.64px;
      text-decoration: underline;
      &:hover{
        color: #4063ec;
      }
    }
  }
  .infoIcon{
    width: 64px;
    min-width: 64px;
    height: 64px;
    display: inline-block;
    img{
      width: 100%;
      height: 100%;
    }
  } 
  .subtit{
    font-size: 16px;
    font-weight: 500;
    line-height: 1;
    margin-bottom: 9px;
  }
  .mt16{margin-top: 16px;}
  .mt8{margin-top: 8px;}
  .dot{
    align-items: flex-start;
    display: flex;
    line-height: 1.75;
    &::before{
      content: '';
      width: 4px;
      height: 4px;
      border-radius: 5px;
      display: inline-block;
      background-color: #707070;
      margin-right: 8px;
      margin-top:10px;
    }
    a{
      color: #222;
      font-weight: 400;
      text-decoration-color: #222;
    }
  }
  
  .inforlist{
    .MuiListItemText-root{
      margin: 0;
    }
    .MuiListItem-root{
      padding-top: 0;
      padding-bottom: 0;
      color: #707070;
      font-size: 16px;
      font-weight: normal;
      line-height: 1.5;
      letter-spacing: -0.64px;
      .MuiTypography-root{
        line-height: 2;
        letter-spacing: -0.64px;
      }
      ul {
        margin-left: 20px;
        li{
          margin-bottom: 8px;
          &:last-child{
            margin-bottom: 0;
          }
        }
      }
    }
  }
  .tableDefault{
    margin-top: 8px;
    margin-left: 12px;
    tr{
      text-align: center;
    }
    th{
      font-weight: 400;
      height: 48px;
    }
    td{
      padding: 18px 20px;
      &.borrt{
        border-right: 1px solid #e0e0e0;
      }
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .title_flex{
      flex-direction: column;
      justify-content: flex-start; 
      align-items: baseline;
      margin-bottom: 30px; 
      margin-top: 20px;
      > span{
        margin-bottom: 10px;
      }
    }
  }
`;

export default Information;