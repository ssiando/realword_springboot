export { default } from './Information';
