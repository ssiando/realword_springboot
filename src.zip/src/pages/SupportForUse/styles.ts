import { css } from '@emotion/react';
export const container = css`
  position: relative;
  margin-top: 300px;
`;
