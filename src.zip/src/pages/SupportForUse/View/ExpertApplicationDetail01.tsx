// 이용지원/ ->  전문가신청 페이지
// import React from "react"
import {
  Box,
  IconButton,
  MenuItem,
  Select,
  SelectChangeEvent,
  Stack,
  Step,
  StepLabel,
  Stepper,
  TableCell,
  TextField,
  Typography
} from '@mui/material';
import * as styles from '~/styles/styles';
import {
  applyExpert,
  applyExpertAcdmcr,
  applyExpertCareer, applyExpertCrqfc, initExpertAcdmcr,
  initExpertCarrer, initExpertCrqfc,
  steps03,
  usptExpertClMapng
} from '~/models/Model';
import {CustomButton} from '~/components/ButtonComponents';
import {NavLink, useLocation, useNavigate} from 'react-router-dom';
import {TrashIcon, PlusIcon, SelectIcon} from '~/components/IconComponents';
import {useEffect, useState, useRef, Fragment} from 'react';
import {initApplyExpert} from "./../../../models/Model";
import {useDaumPostcodePopup} from 'react-daum-postcode';
import {intialErrorExpert} from '~/models/ModelExpert';
import {fetchExpertClid, fetchExpertGet, fetchExpertParnts} from '~/fetches/fetchExpert';
import {useGlobalModalStore, useScroll} from '~/pages/store/GlobalModalStore';
import {useQueries, useQuery} from 'react-query';
import {Banner} from '~/components/Banner';
import {CustomHeadCell, TableComponents, WithCustomRowData} from "shared/components/TableComponents";
import { MenuProps, SelectItemStyle } from '~/styles/styledConst';

function ExpertApplicationDetail01() {
  const receive: any = useLocation();
  const {addModal} = useGlobalModalStore();
  const open = useDaumPostcodePopup("//t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js");
  //신청자정보
  // const [memberData, setMemberData]: any = useState();
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate();
  // 신청자 전문가정보
  const [usptExpert, setExpert] = useState<applyExpert>(initApplyExpert)
  const [usptExpertCareer, setExpertCarrer] = useState<applyExpertCareer[]>([initExpertCarrer])
  const [usptExpertAcdmcr, setExpertAcdmcr] = useState<applyExpertAcdmcr[]>([initExpertAcdmcr])
  const [usptExpertCrqfc, setExpertCrqfc] = useState<applyExpertCrqfc[]>([initExpertCrqfc])
  const [usptExpertClMapng, setUsptExpertClMapng] = useState<usptExpertClMapng[]>([{
    expertClId: '',
    expertClNm: '',
    parntsExpertClId: ''
  }])
  const [attachmentFileList, setAttachmentFileList]: any = useState([]);
  const [deleteAttach, setDeleteAttach] = useState<any[]>([]);
  // 입력값오류
  const [errorValues, setErrorValues] = useState(intialErrorExpert);
  console.log('usptExpertClMapng - ' + JSON.stringify(usptExpertClMapng))
  // 전문가 분야정보
  const [expertParnts, setExpertParnts] = useState<usptExpertClMapng[]>([])
  const [expertChild, setExpertChild] = useState<usptExpertClMapng[]>([])
  const [expertRowList, setExpertRowList] = useState<WithCustomRowData<{ parents?: usptExpertClMapng, chiled?: usptExpertClMapng }>[]>([])
  const [expertSelected, setExpertSelected] = useState<string[]>([])
  const {data: parents_box} = useQuery("getExpertParants", async () => await fetchExpertParnts(), {
    onSuccess: async (res: any) => {
      setExpertRowList([{key: Math.random().toString()}])
      setExpertParnts(res.list)
      let box: usptExpertClMapng[] = [];
      let index = res.list.length
      while (index > 0) {
        await fetchExpertClid(res.list[index - 1].expertClId).then((res) => {
          box = box.concat(res.list.map((m: any) => {
            return {...m}
          }))
        })
        index--;
      }

      setExpertChild(box)

    }
  });

  useEffect(() => {
    if (usptExpertClMapng && usptExpertClMapng.length > 0 && expertChild && expertChild.length > 0) {
      console.log('update - ' + JSON.stringify(
        usptExpertClMapng.map((m: usptExpertClMapng) => {
          return {
            key: Math.random().toString(),
            parents: expertParnts.find((f: any) => f.expertClId == m.parntsExpertClId),
            chiled: m
          }
        })
      ))
      setExpertRowList(usptExpertClMapng.map((m: usptExpertClMapng) => {
        return {
          key: Math.random().toString(),
          parents: expertParnts.find((f: any) => f.expertClId == m.parntsExpertClId),
          chiled: m
        }
      }))
    }
  }, [usptExpertClMapng, expertChild])

  const getList = () => {
    setLoading(true)
    fetchExpertGet().then((res: any) => {
      // setMemberData(res.usptExpert);
      console.log('init')
      setLoading(false)
      setExpert(res.usptExpert)
      if (res.usptExpertCareer) setExpertCarrer(res.usptExpertCareer)
      if (res.usptExpertAcdmcr) setExpertAcdmcr(res.usptExpertAcdmcr)
      if (res.usptExpertCrqfc) setExpertCrqfc(res.usptExpertCrqfc)
      if (res.usptExpertClMapng) {
        const update = res.usptExpertClMapng.map((m: any) => {
          return {
            parntsExpertClId: m.parntsExpertClId,
            expertClId: m.expertClId,
            expertClNm: m.expertClNm
          }
        })
        console.log('update - ' + JSON.stringify(update))
        setUsptExpertClMapng(update)
      }
      if (res.attachFileList) setAttachmentFileList(res.attachFileList)
    }).catch((e) => {
      setLoading(false)
      let message = e.response.data.message;
      addModal({
        open: true,
        content: message
      })
    })
  }
  useEffect(() => {
    if (receive.state) {
      if (receive.state.step == 'step3') {
        setExpert(receive.state.usptExpert)
        setExpertCarrer(receive.state.usptExpertCareer)
        setExpertAcdmcr(receive.state.usptExpertAcdmcr)
        setExpertCrqfc(receive.state.usptExpertCrqfc)
        setUsptExpertClMapng(receive.state.usptExpertClMapng)
        setAttachmentFileList(receive.state.attachmentFileList)
        setDeleteAttach(receive.state.deleteAttach)
        setLoading(false)
      } else if (receive.state.step == 'step1') {
        getList()
      } else {
        setLoading(false)
      }
    } else {
      navigate('/SupportForUse/ExpertApplication')
    }
  }, [])

  //소속 및 대학정보 입력부분
  const handelChangeInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const {name, value} = e.currentTarget;
    setExpert((state: any) => ({...state, [name]: value}));
  }

  // Daum 우편번호 서비스
  const DaumPost = (data: any) => {
    setExpert((pre: any) => ({...pre, wrcAdresZip: data.zonecode, wrcAdres: data.address}))
  };

  // 주소 찾기 호출
  const handleClick = () => {
    open({onComplete: DaumPost});
  };

  const validate = () => {
    let check = true;
    let update = {...errorValues};
    if (usptExpert.lastUnivNm === "") {
      update = {...update, errorLastUnivNm: true, helperLastUnivNm: "최종 대학명을 입력하세요."}
      check = false;
    } else {
      update = {...update, errorLastUnivNm: false, helperLastUnivNm: ""}
    }
    //학부 확인
    if (usptExpert.univDeptNm === "") {
      check = false;
      update = {...update, errorUnivDeptNm: true, helperUnivDeptNm: "학부를 입력하세요."}
    } else {
      update = {...update, errorUnivDeptNm: false, helperUnivDeptNm: ""}
    }
    setErrorValues(update);

    if (check === true) {
      navigate('/SupportForUse/ExpertApplicationDetail02', {
        state: {
          usptExpert: usptExpert,
          usptExpertClMapng: expertRowList.flatMap(m => m.chiled),
          validationBox: receive.state.validationBox,
          expertReqstProcessSttusCd: receive.state.expertReqstProcessSttusCd,
          usptExpertCareer: usptExpertCareer,
          usptExpertAcdmcr: usptExpertAcdmcr,
          usptExpertCrqfc: usptExpertCrqfc,
          attachmentFileList: attachmentFileList,
          step: "step3"
        }
      });
    }

  }

  const addItem = () => {
    setExpertRowList(expertRowList.concat({key: Math.random().toString()}))
  }

  const deleteItem = () => {
    let filter = expertRowList.filter(f => !expertSelected.includes(f.key))
    if (filter.length == 0) {
      filter = [{key: Math.random().toString()}]
    }
    setExpertRowList(filter)
  }

  const updateItem = (i: number, type: 'p' | 'c', item?: usptExpertClMapng) => {
    if (item) {
      const updated = [...expertRowList];
      if (type == "p") {
        updated[i].parents = item;
      } else {
        updated[i].chiled = item;
      }
      setExpertRowList(updated);
    }
  }

  return (
    <Banner
      title={'전문가 신청'}
      loading={loading}
      summaryStep={
        <Stepper activeStep={1} alternativeLabel css={styles.step03} className="step03">
          {
            steps03.map((label: string) => {
              return <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            })
          }
        </Stepper>
      }
    >
      <div css={styles.container}>
        <Box css={styles.sub_cont02}>
          <div className="content">
            <Box css={styles.box_graylist}>
              <ul>
                <li>신청자정보를 확인해 주세요. 변경이 필요하시면 마이페이지에서 수정할 수 있습니다.</li>
                <li>소속 및 대학정보를 입력해 주세요. 상세하게 입력해 주실수록 접수 시 도움이 됩니다.</li>
                <li><em>*</em> 표시는 필수입력 항목입니다.</li>
              </ul>
            </Box>
            <Box>
              <Box css={styles.table05}>
                {/* 신청자 정보 */}
                <Stack direction="row" justifyContent="space-between" className="table_tit">
                  <Typography
                    gutterBottom
                    variant="h6"
                    component="div"
                  >
                    {'신청자 정보'}
                  </Typography>
                  <NavLink to="/MyPage/MemberInfoMmt/MemberInfoMdf">
                    <CustomButton label={'회원정보 변경'} type={'modify'} color={'outlinedblack'}
                                  style={{marginBottom: '10px'}}/>
                  </NavLink>
                </Stack>
                {usptExpert ?
                  <div className="detail_table">
                    <dl>
                      <dt>이름</dt>
                      <dd>{usptExpert.expertNm}</dd>
                      <dt>생년월일</dt>
                      <dd>{usptExpert.encBrthdy}</dd>
                    </dl>
                    <dl>
                      <dt>성별</dt>
                      <dd>{usptExpert.genderNm}</dd>
                      {/* <dt>내외국인</dt>
                    <dd>내국인</dd> */}
                    </dl>
                    <dl>
                      <dt>휴대폰번호</dt>
                      <dd>{usptExpert.encMbtlnum}</dd>
                      <dt>이메일</dt>
                      <dd>{usptExpert.encEmail}</dd>
                    </dl>
                  </div>
                  : null}
              </Box>
              <Box css={styles.table04}>
                {/* 소속 및 대학정보 */}
                <Typography
                  gutterBottom
                  variant="h6"
                  component="div"
                >
                  {'소속 및 대학정보'}
                </Typography>
                {/* 테이블 pc */}
                <Box className="pc">
                  <table>
                    <colgroup>
                      <col width='15%'></col>
                      <col width='35%'></col>
                      <col width='15%'></col>
                      <col width='35%'></col>
                    </colgroup>
                    <tbody>
                    <tr>
                      <th>최종 대학명<em>*</em></th>
                      <td className='table_input'>
                        <TextField
                          id='lastUnivNm'
                          name='lastUnivNm'
                          value={usptExpert.lastUnivNm}
                          onChange={handelChangeInput}
                          variant='outlined'
                          fullWidth
                          error={errorValues.errorLastUnivNm}
                          helperText={errorValues.helperLastUnivNm}
                        />
                      </td>
                      <th>학부<em className="star">*</em></th>
                      <td className='table_input'>
                        <TextField
                          id='univDeptNm'
                          name='univDeptNm'
                          value={usptExpert.univDeptNm}
                          onChange={handelChangeInput}
                          variant='outlined'
                          fullWidth
                          error={errorValues.errorUnivDeptNm}
                          helperText={errorValues.helperUnivDeptNm}
                        />
                      </td>
                    </tr>
                    <tr>
                      <th>직장명</th>
                      <td className='table_input'>
                        <TextField
                          id='wrcNm'
                          name='wrcNm'
                          value={usptExpert.wrcNm}
                          onChange={handelChangeInput}
                          variant='outlined'
                          fullWidth
                        />
                      </td>
                      <th>부서명</th>
                      <td className='table_input'>
                        <TextField
                          id='deptNm'
                          name='deptNm'
                          value={usptExpert.deptNm}
                          onChange={handelChangeInput}
                          variant='outlined'
                          fullWidth
                        />
                      </td>
                    </tr>
                    <tr>
                      <th>직위</th>
                      <td className='table_input'>
                        <TextField
                          id='ofcpsNm'
                          name='ofcpsNm'
                          value={usptExpert.ofcpsNm}
                          onChange={handelChangeInput}
                          variant='outlined'
                          fullWidth
                        />
                      </td>
                      <th>직무</th>
                      <td className='table_input'>
                        <TextField
                          id='dtyNm'
                          name='dtyNm'
                          value={usptExpert.dtyNm}
                          onChange={handelChangeInput}
                          variant='outlined'
                          fullWidth
                        />
                      </td>
                    </tr>
                    <tr>
                      <th rowSpan={2}>직장주소</th>
                      <td className='table_input noline'>
                        <Stack direction='row' justifyContent='center' spacing={2} sx={{width: '100%'}}>
                          <TextField
                            id='wrcAdresZip'
                            name='wrcAdresZip'
                            value={usptExpert.wrcAdresZip}
                            onChange={handelChangeInput}
                            variant='outlined'
                            fullWidth
                          />
                          <CustomButton label={'주소찾기'} type={'modalBtn'} color={'outlined'} onClick={handleClick}/>
                        </Stack>
                      </td>
                    </tr>
                    <tr>
                      <td className='table_input pt0'>
                        <TextField
                          id='wrcAdres'
                          name='wrcAdres'
                          value={usptExpert.wrcAdres}
                          onChange={handelChangeInput}
                          variant='outlined'
                          fullWidth
                        />
                      </td>
                      <th className='table_input wh pt0' colSpan={2}>
                        <TextField
                          id='wrcAdresDetail'
                          name='wrcAdresDetail'
                          value={usptExpert.wrcAdresDetail}
                          onChange={handelChangeInput}
                          variant='outlined'
                          fullWidth
                        />
                      </th>
                    </tr>
                    <tr>
                      <th>직장 전화번호</th>
                      <td className='table_input'>
                        <TextField
                          id='wrcTelno'
                          name='wrcTelno'
                          value={usptExpert.wrcTelno}
                          onChange={handelChangeInput}
                          variant='outlined'
                          sx={{maxWidth: '480px', width: '100%'}}
                        />
                      </td>
                      <th className='table_input wh' colSpan={2}>
                      </th>
                    </tr>
                    </tbody>
                  </table>
                </Box>
                {/* 테이블 mo */}
                <Box className="mo">
                  <table>
                    <colgroup>
                      <col width='30%'></col>
                      <col/>
                    </colgroup>
                    <tbody>
                    <tr>
                      <th>최종 대학명<em>*</em></th>
                      <td className='table_input'>
                        <TextField
                          id='lastUnivNm'
                          name='lastUnivNm'
                          value={usptExpert.lastUnivNm}
                          onChange={handelChangeInput}
                          variant='outlined'
                          fullWidth
                        />
                      </td>
                    </tr>
                    <tr>
                      <th>학부<em className="star">*</em></th>
                      <td className='table_input'>
                        <TextField
                          id='univDeptNm'
                          name='univDeptNm'
                          value={usptExpert.univDeptNm}
                          onChange={handelChangeInput}
                          variant='outlined'
                          fullWidth
                        />
                      </td>
                    </tr>
                    <tr>
                      <th>직장명</th>
                      <td className='table_input'>
                        <TextField
                          id='wrcNm'
                          name='wrcNm'
                          value={usptExpert.wrcNm}
                          onChange={handelChangeInput}
                          variant='outlined'
                          fullWidth
                        />
                      </td>
                    </tr>
                    <tr>
                      <th>부서명</th>
                      <td className='table_input'>
                        <TextField
                          id='deptNm'
                          name='deptNm'
                          value={usptExpert.deptNm}
                          onChange={handelChangeInput}
                          variant='outlined'
                          fullWidth
                        />
                      </td>
                    </tr>
                    <tr>
                      <th>직위</th>
                      <td className='table_input'>
                        <TextField
                          id='ofcpsNm'
                          name='ofcpsNm'
                          value={usptExpert.ofcpsNm}
                          onChange={handelChangeInput}
                          variant='outlined'
                          fullWidth
                        />
                      </td>
                    </tr>
                    <tr>
                      <th>직무</th>
                      <td className='table_input'>
                        <TextField
                          id='dtyNm'
                          name='dtyNm'
                          value={usptExpert.dtyNm}
                          onChange={handelChangeInput}
                          variant='outlined'
                          fullWidth
                        />
                      </td>
                    </tr>
                    <tr>
                      <th rowSpan={3}>직장주소</th>
                      <td className='table_input noline'>
                        <Stack direction='row' justifyContent='center' spacing={2} sx={{width: '100%'}}>
                          <TextField
                            id='wrcAdresZip'
                            name='wrcAdresZip'
                            value={usptExpert.wrcAdresZip}
                            onChange={handelChangeInput}
                            variant='outlined'
                            fullWidth
                          />
                          <CustomButton label={'주소찾기'} type={'modalBtn'} color={'outlined'} onClick={handleClick}/>
                        </Stack>
                      </td>
                    </tr>
                    <tr>
                      <td className='table_input' colSpan={2}>
                        <TextField
                          id='wrcAdres'
                          name='wrcAdres'
                          value={usptExpert.wrcAdres}
                          onChange={handelChangeInput}
                          variant='outlined'
                          fullWidth
                        />
                      </td>
                    </tr>
                    <tr>
                      <td className='table_input wh'>
                        <TextField
                          id='wrcAdresDetail'
                          name='wrcAdresDetail'
                          value={usptExpert.wrcAdresDetail}
                          onChange={handelChangeInput}
                          variant='outlined'
                          fullWidth
                        />
                      </td>
                    </tr>
                    <tr>
                      <th>직장 전화번호</th>
                      <td className='table_input'>
                        <TextField
                          id='wrcTelno'
                          name='wrcTelno'
                          value={usptExpert.wrcTelno}
                          onChange={handelChangeInput}
                          variant='outlined'
                          sx={{maxWidth: '480px', width: '100%'}}
                        />
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </Box>
              </Box>
              <Box css={styles.table05}>
                {/* 전문분야 */}
                <Stack direction="row" justifyContent="space-between" className="table_tit">
                  <Typography
                    gutterBottom
                    variant="h6"
                    component="div"
                  >
                    {'전문분야'} <em>*</em> <span>(복수선택 가능)</span>
                  </Typography>
                  <Stack direction="row">
                    <IconButton size="large" edge="start" color="inherit" aria-label="delete" sx={{mr: 1.5}}
                                onClick={deleteItem}>
                      <TrashIcon/>
                    </IconButton>
                    <IconButton size="large" edge="start" color="inherit" aria-label="delete" onClick={addItem}>
                      <PlusIcon/>
                    </IconButton>
                  </Stack>
                </Stack>
                <TableComponents<{ parents?: usptExpertClMapng, chiled?: usptExpertClMapng }>
                  isCheckBox hidePagination hideRowPerPage
                  hideBoarderTopColor page={0} rowCount={expertRowList.length} rowsPerPage={0}
                  headCells={headCells}
                  bodyRows={expertRowList}
                  onSelectedKey={(keys: string[]) => {
                    setExpertSelected(keys)
                  }}
                  tableCell={(data, i) => {

                    return <Fragment>
                      <TableCell key={"count-" + data.key} width={'60px'} align={'center'}>{i + 1}</TableCell>
                      <TableCell key={"dscntRate-" + data.key} width={'90%'} sx={{padding: '8px'}}>
                        <Stack direction={'row'} spacing={'8px'}>
                          <Select
                            size={'small'} value={data.parents ? data.parents.expertClNm : ''}
                            sx={{width: '150px'}}
                            MenuProps={MenuProps}
                            IconComponent={SelectIcon}
                            onClick={(e) => {
                              e.stopPropagation()
                            }}
                            onChange={(event: SelectChangeEvent) => {
                              const item = expertParnts.find(f => f.expertClNm == event.target.value)
                              updateItem(i, 'p', item)
                            }}>
                            {
                              expertParnts.flatMap(f => f.expertClNm).map((m, i) => {
                                return <SelectItemStyle key={i} value={m}>{m}</SelectItemStyle>
                              })
                            }
                          </Select>
                          <Select
                            size={'small'} value={data.chiled ? data.chiled.expertClNm : ''}
                            MenuProps={MenuProps}
                            IconComponent={SelectIcon}
                            sx={{width: '150px'}}
                            onClick={(e) => {
                              e.stopPropagation()
                            }}
                            onChange={(event: SelectChangeEvent) => {
                              const item = expertChild.filter(f => f.parntsExpertClId == data.parents?.expertClId).find(f => f.expertClNm == event.target.value)
                              updateItem(i, 'c', item)
                            }}>
                            {
                              expertChild.filter(f => f.parntsExpertClId == data.parents?.expertClId)
                                .flatMap(f => f.expertClNm).map((m, i) => {
                                return <SelectItemStyle key={i} value={m}>{m}</SelectItemStyle>
                              })
                            }
                          </Select>
                        </Stack>
                      </TableCell>
                    </Fragment>
                  }}
                />

                {/*<table className="tableDefault type5 pc">*/}
                {/*  <colgroup>*/}
                {/*    <col style={{width:'5%'}}/>*/}
                {/*    <col style={{width:'7%'}}/>*/}
                {/*    <col />*/}
                {/*  </colgroup>*/}
                {/*  <thead>*/}
                {/*    <tr>*/}
                {/*      <th>                      */}
                {/*          <Box className="checkbox"><Checkbox checked={allCheck} onClick={(e:React.MouseEvent<HTMLButtonElement>)=>{*/}
                {/*        changeAllCheck()*/}
                {/*      }}/></Box></th>*/}
                {/*      <th>번호</th>*/}
                {/*      <th>전문가분야</th>*/}
                {/*    </tr>*/}
                {/*  </thead>*/}
                {/*  <tbody>*/}
                {/*  <ExpertTable */}
                {/*  checkList={select} */}
                {/*  change={changeCheck} */}
                {/*  data={usptExpertClMapng} */}
                {/*  updateItem={updateItem} */}
                {/*  parents_box={parents_box?parents_box.list:[]}*/}
                {/*  childs_box={childs_box}*/}
                {/*  parents={parents}*/}
                {/*  childs={usptExpertClMapng}*/}
                {/*  updateItem2={updateItem2}*/}
                {/*  />*/}
                {/*  </tbody>*/}
                {/*</table>*/}
              </Box>
            </Box>
            <Stack direction="row" justifyContent="center" spacing={2} css={styles.btnGroup}>
              <CustomButton label={'다음'} type={'listBack'} color={'primary'} onClick={validate}/>
            </Stack>
          </div>
        </Box>
      </div>
    </Banner>
  );
}

const headCells: CustomHeadCell<{ count: number, experApp: string }>[] = [
  {
    id: 'count',
    align: 'center',
    label: '번호',
    width: '60px'
  },
  {
    id: 'experApp',
    align: "center",
    label: '전문분야',
  },
];
export default ExpertApplicationDetail01;

