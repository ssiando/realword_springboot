export { default } from './FactorFind';
