export { default } from './IdTrouver';
