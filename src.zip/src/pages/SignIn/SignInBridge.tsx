import {useLocation, useNavigate} from "react-router-dom";
import {useEffect} from "react";


const SignInBridge = () => {
  const navigate = useNavigate()
  const location = useLocation()
  const originpath = window.location.origin;

  const init = () => {
    const changePasswd = sessionStorage.getItem('changePasswd')
    const params = new URLSearchParams(location.search);
    const nextUrl = params.get('nextUrl');

    if (changePasswd == "true"){
      sessionStorage.setItem("changePasswd", 'false');
      navigate("/signin/dormancyPass",{
        state: {
          nextUrl: !!nextUrl ? window.atob(nextUrl).replace(originpath, '') : ''
        }
      })
      return
    }

    if (nextUrl && nextUrl.length > 0) {
      window.location.href = window.atob(nextUrl).replace(originpath, '')
      return
    }

    navigate('/')
  }

  useEffect(() => {
    init()
  }, [])

  return <div/>
}

export default SignInBridge