import {useEffect, useRef, useState} from 'react';
import * as styles from './styles';
import styled from '@emotion/styled';
import NaverLogin from 'react-naver-login';
import KakaoLogin from 'react-kakao-login';
import GoogleLogin from 'react-google-login';
import {gapi} from 'gapi-script';
import {useNavigate, useLocation, NavLink, useParams} from 'react-router-dom';
import authentication from 'shared/authentication';
import {fetchSignIn, fetchSignInSns} from '~/fetches';
import {Button, Stack, Box, TextField} from '@mui/material';
import {intialLoginValues, UserType} from '~/models/ModelSignin';
import {useGlobalModalStore} from '../store/GlobalModalStore';
import {ModalComponents} from '~/components/ModalComponents';
import $ from 'jquery';
import {VerticalInterval} from "shared/components/LayoutComponents";
import {keySecureDec} from "shared/utils/NxKeyUtile";
import { values } from 'ramda';

/* 
  작성일    :   2022/04/10
  화면명    :   공통 -> 로그인
  회면ID    :   UI-USP-FRN-0020101
  화면/개발 :   Seongeonjoo / navycui
*/
export type memType = {
  loginId: string;
}
const _global = (window /* browser */ || global /* node */) as any
const SignIn = () => {
  const navigate = useNavigate();
  const location: any = useLocation();
  const [open, setOpen] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true)
  const [sts, setSts] = useState(0);
  const originpath = window.location.origin;
  const {addModal} = useGlobalModalStore();
  const [formValues, setFormValues] = useState(intialLoginValues);
  const [backspacePath, setBackSpacePath] = useState('/')
  // const test = useScript("../../../public/raonnx/nxKey/js/TouchEnNxKey");
  // const sampleModule = require('../../../public/raonnx/nxKey/js/TouchEnNxKey');

  const keyboardId = useRef<any>(null)
  const testId = useRef<any>(null)
  const testPw = useRef<any>(null)
  const [labelAction, setLabelAction] = useState<{id: boolean, pwd: boolean}>({id: false, pwd: false})

  const isMobileCheck = /iPhone|iPad|iPod|Android/i.test(
    window.navigator.userAgent
  );

  // 로그인 입력 폼
  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>) => {
    const {value, name} = e.target;
    setFormValues({
      ...formValues,
      [name]: value, errorId: false, errorPw: false
    });
  }

  useEffect(() => {
    //@ts-ignore
    if (loadflag && keyboardId) {
      setTimeout(() => {
        keyboardId.current.focus()
      }, 300)

    }
    //@ts-ignore
  }, [loadflag])


  // 화면 초기 호출
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const agentId = params.get('agentId');

    if (isMobileCheck) {
      setTimeout(() => {
        const tmTranskey = document.getElementById('tmTranskey')
        if (tmTranskey) tmTranskey.click()
      }, 300)
    } else {
      const nxLoading = document.getElementById('nxLoading')
      if (nxLoading) nxLoading.click()
      setTimeout(() => {
        const nxRescan = document.getElementById('nxRescan')
        if (nxRescan) nxRescan.click()
      }, 300)
    }

    if (!agentId) {
      const url = process.env.REACT_APP_SSO_CHECK_PATH
      if (url && location.state && location.state.nextUrl) {
        post(`${url}?nextUrl=${window.btoa(location.state.nextUrl)}`, null)
        // window.location.replace(`${url}?nextUrl=${window.btoa(location.state.nextUrl)}`)
        return
      }
    }

    const initClient = () => {
      gapi.client.init({
        clientId: `${process.env.REACT_APP_CLIENT_ID_GOOGLE_AICA}`,
        scope: 'email profile openid'
      });
    };
    gapi.load('client:auth2', initClient);
    const domainPath = process.env.REACT_APP_DOMAIN
    if (domainPath){
      switch (agentId){
        case '2':
        case '7':
          setBackSpacePath(domainPath.concat('/dxp'))
          break
        case '3':
        case '8':
          setBackSpacePath(domainPath.concat('/saz'))
          break
        case '4':
        case '9':
          setBackSpacePath(domainPath.concat('/lms'))
          break
      }
    }
    setLoading(false)
  }, []);

  function post(path: string, params: any, method = 'post') {

    // The rest of this code assumes you are not using a library.
    // It can be made less verbose if you use one.
    const form = document.createElement('form');
    form.method = method;
    form.action = path;

    for (const key in params) {
      if (params.hasOwnProperty(key)) {
        const hiddenField = document.createElement('input');
        hiddenField.type = 'hidden';
        hiddenField.name = key;
        hiddenField.value = params[key];

        form.appendChild(hiddenField);
      }
    }

    document.body.appendChild(form);
    form.submit();
  }

  // 로그인
  const handleClickLogin = async () => {
    // $("#loginId").val()
    // const loginId = document.getElementById('loginId')
    // const passwd = document.getElementById('passwd')

    const data = {
      ...formValues,
      loginId: $("#loginId").val()?.toString() || '',
      passwd: $("#passwd").val()?.toString() || ''
    }
    if (!validate(data)) {
      return;
    }

    await fetchSignIn(data).then((res) => {
      let {data} = res;

      //* Ref 페이지가 있는 경우.
      let qs = new URLSearchParams(location.search);
      let next = qs.get('nextUrl');
      sessionStorage.setItem('__LOG_KEY__', formValues.loginId);
      authentication.set(data);
      let boxuser = authentication.getMemberData();

      if (boxuser.memberSt.includes('DORMANT')) { // 휴면회원여부 체크
        if (boxuser.memberType.includes('INDIVIDUAL')) { // 개인
          navigate("/signup/dormancyCon")
        } else {  // 기업
          //..TODO.... 공인인증 솔루션 적용중...
          navigate("/signup/dormancyPro")
        }
      } else if (boxuser.memberSt.includes('LOCK')) { // 계정잠김여부 체크
        console.log('boxuser.memberSt', boxuser.memberSt);
        if (boxuser.memberType.includes('INDIVIDUAL')) {  // 개인
          navigate("/signup/dormancyLock")
        } else { // 기업
          //..TODO.... 공인인증 솔루션 적용중...
          navigate("/signup/dormancyLockPro")
        }
      } else {
        const params = new URLSearchParams(location.search);
        const agentId = params.get('agentId');

        // sso처리
        if (agentId) {
          sessionStorage.setItem("changePasswd", data.changePasswd)
          const params = {
            agentId: agentId,
            id: data.dbid,
            pw: data.dbpw
          };

          const url = process.env.REACT_APP_SSO_PATH
          if (url) post(url, params);
        } else {
          if (data.changePasswd) { // 비밀번호 60일 변경 체크
            navigate("/signin/dormancyPass", {
              state: {
                nextUrl: !!next ? window.atob(next).replace(originpath, '') : ''
              }
            })
            return
          }

          if (next) {
            window.location.href = window.atob(next).replace(originpath, '')
            // navigate(`${window.atob(next).replace(originpath,'')}`)
          } else {
            navigate('/');
          }
        }
      }
    }).catch((e) => {
      let {data: {message, status}} = e.response;
      setFormValues({
        ...formValues,
        isLock: true
      });
      setFormValues({
        ...formValues,
        loginId: "", passwd: "", errorId: false, errorPw: false, labelPw: "", isLock: false
      });
      // setOpen(true)
      setError(message)
      setSts(status)
      if (status == 400) {
        addModal({
          type: 'normal',
          open: true,
          content: message,
        })
      }
      if (status == 602) {
        navigate("/signup/dormancyLock", {
          state: {
            isBzmn: false
          }
        })
      } else if (status == 604) {
        navigate("/signup/dormancyLockPro", {
          state: {
            isBzmn: true
          }
        })
      } else if (status == 603) {
        navigate("/signup/dormancyCon", {
          state: {
            isBzmn: false
          }
        })
      } else if (status == 605) {
        navigate("/signup/dormancyPro", {
          state: {
            isBzmn: true
          }
        })
      }
      // addModal({
      //   type:'normal',
      //   open: true,
      //   title:status,
      //   content: message,
      //   onConfirm:()=> {
      //     if(status == 602 || status == 604 ){
      //       // window.location.href = '/signup/dormancyLock';
      //       navigate("/signup/dormancyLock")
      //     } else if(status == 603 || status == 605) {
      //       // window.location.href = '/signup/dormancyCon';
      //       navigate("/signup/dormancyCon")
      //     }
      //   },
      // })
    });
  };

  // login form validation check
  const validate = (values: UserType) => {
    // id 확인
    if (!values.loginId) {
      setFormValues({...formValues, errorId: true, labelId: "아이디 입력하세요"});
      return false;
    }
    //비밀번호  확인
    if (!values.passwd) {
      setFormValues({...formValues, errorPw: true, labelPw: "비밀번호 입력하세요"});
      return false;
      //비밀번호 길이 체크
    } else if (values.passwd.length < 4) {
      setFormValues({...formValues, errorPw: true, labelPw: "비밀번호는 4자리이상으로 입력하세요"});
      return false;
    }
    return true;
  };

  // 카카오 로그인
  const handleClickKakao = async (res: any) => {
    await fetchSignInSns({accessToken: res.response.access_token, uri: "sns/kakao",}).then((ress) => {
      authentication.set(ress.data);
      //* Ref 페이지가 있는 경우.
      const qs = new URLSearchParams(location.search);
      const next = qs.get('nextUrl');

      if (next) {
        navigate(`${window.atob(next).replace(originpath, '')}`)
      } else {
        navigate('/');
      }
    }).catch((err) => {
      addModal({
        open: true,
        content: err.response.data.message
      })
    });

  };
  //  구글 로그인
  const handleClickGoogle = async (res: any) => {
    await fetchSignInSns({accessToken: res.accessToken, uri: "sns/google",}).then((ress) => {

      authentication.set(ress.data);
      //* Ref 페이지가 있는 경우.
      const qs = new URLSearchParams(location.search);
      const next = qs.get('nextUrl');
      if (next) {
        navigate(`${window.atob(next).replace(originpath, '')}`)
      } else {
        navigate('/');
      }
    }).catch((err) => {
      addModal({
        type: 'normal',
        open: true,
        content: err.response.data.message
      })
    });
  };

  // 팝업창 콜백
  if (typeof window !== "undefined") {
    _global.setEncodeData = (encodeData: string) => {
      debugger
      if (!!encodeData) {
        handleLoginNaver(encodeData)
      }
    }
  }

  //  네이버 로그인
  const handleLoginNaver = async (res: any) => {
    await fetchSignInSns({accessToken: res, uri: "sns/naver",}).then((ress) => {
      authentication.set(ress.data);
      //* Ref 페이지가 있는 경우.
      const qs = new URLSearchParams(location.search);
      const next = qs.get('nextUrl');
      if (next) {
        navigate(`${window.atob(next).replace(originpath, '')}`)
      } else {
        navigate('/');
      }
      // window.close();
    }).catch((err) => {
      addModal({
        type: 'normal',
        open: true,
        content: err.response.data.message
      })
      _global.close();
    });
  };


  return <section css={styles.container}>
    <Box css={styles.backPass}>
      <a href={backspacePath}>
        메인 화면으로 돌아가기
      </a>
      {/*<NavLink to={'/'}>*/}
      {/*  메인 화면으로 돌아가기*/}
      {/*</NavLink>*/}
    </Box>
    {
      loading || <div css={styles.content} className="contcenter">
        <Box className="centerBox">
          <div className="tit">
            <h1>AICA 로그인</h1>
            <p>로그인하고, 다양한 서비스를 이용하세요.</p>
          </div>
          {/* mo */}
          {
            isMobileCheck && <Box
              component={'form'}
              css={styles.signinput_mo} id={"loginForm"} name={"loginForm"}
            >
              <Box className="inputlabel">
                <label className='stars'>아이디</label>
                <input
                  ref={testId}
                  // inputRef={testId}
                  type="text"
                  name="loginId"
                  id="loginId"
                  autoComplete="new-id"
                  data-tk-kbdType="qwerty"
                  data-tk-bottom="true"
                  onFocus={() => {
                    //@ts-ignore
                    mtk.onKeyboard(testId.current);
                  }}
                  // label="아이디"
                  placeholder={'아이디'}
                  // fullWidth
                  // error={formValues.errorId}
                  onChange={handleChange}
                  // helperText={formValues.errorId ? formValues.labelId : ""}
                />
              </Box>
              <VerticalInterval size={'16px'}/>
              <Box className="inputlabel">
                <label className='stars'>비밀번호</label>
                <input
                  ref={testPw}
                  type="password"
                  name='passwd'
                  id="passwd"
                  data-tk-kbdType="qwerty"
                  data-tk-bottom="true"
                  onFocus={() => {
                    //@ts-ignore
                    mtk.onKeyboard(testPw.current);
                  }}
                  autoComplete="new-password"
                  placeholder="비밀번호"
                  // fullWidth
                  // error={formValues.errorPw}  
                  // value={!!formValues.passwd ? formValues.passwd : ''}
                  // helperText={formValues.errorPw ? formValues.labelPw : ""}
                  onChange={handleChange}
                />
              </Box>
              <Stack spacing={2} direction="row" css={styles.login_btn}>
                <Button fullWidth variant="contained" onClick={() => {
                  // _global.keySecureDec('passwd', 'login_member')
                  keySecureDec('passwd', (decode: string) => {
                    $("#passwd").val(decode)
                    handleClickLogin()
                  })
                  // keySecureDec('passwd', 'login_member')
                }}> 로그인 </Button>
              </Stack>
            </Box>
          }
          {/* pc */}
          {
            isMobileCheck || <Box
              component={'form'}
              css={styles.signinput} id={"loginForm"} name={"loginForm"}
            >
              <TextField
                inputRef={keyboardId}
                type="text"
                name="loginId"
                id="loginId"
                variant="filled"
                autoComplete="new-id"
                // autoFocus
                fullWidth
                error={formValues.errorId}
                onChange={handleChange}
                helperText={formValues.errorId ? formValues.labelId : ""}
                label="아이디"
                placeholder="아이디"
                required
                sx={{'.MuiFilledInput-root':{padding: '0'}, '.MuiFilledInput-input':{padding: '21px 15px 8px'}}}
                InputProps={{
                  startAdornment: labelAction.id? <i/> : undefined,
                }}
                onKeyDown={(e) => {
                  if ($("#loginId").val() && $("#loginId").val()?.toString() != ''){
                    setLabelAction({...labelAction, id: true})
                  }else {
                    setLabelAction({...labelAction, id: false})
                  }
                }}
              />
              <TextField
                type="password"
                variant="filled"
                name='passwd'
                id="passwd"
                autoComplete="new-password"
                label="비밀번호"
                placeholder="비밀번호"
                required
                fullWidth
                error={formValues.errorPw}
                // value={!!formValues.passwd ? formValues.passwd : ''}
                helperText={formValues.errorPw ? formValues.labelPw : ""}
                onChange={handleChange}
                sx={{'.MuiFilledInput-root':{padding: '0'}, '.MuiFilledInput-input':{padding: '21px 15px 8px'}}}
                InputProps={{
                  startAdornment: labelAction.pwd? <i/> : undefined,
                }}
                onKeyUp={(e) => {
                  if (e.key === 'Enter') {
                    handleClickLogin()
                  }
                  if ($("#passwd").val() && $("#passwd").val()?.toString() != ''){
                    setLabelAction({...labelAction, pwd: true})
                  }else {
                    setLabelAction({...labelAction, pwd: false})
                  }
                }}
              />
              <Stack spacing={2} direction="row" css={styles.login_btn}>
                <Button fullWidth variant="contained" type="button" onClick={handleClickLogin}> 로그인 </Button>
              </Stack>
            </Box>
          }


          <Box css={styles.linkbtn}>
            <NavLink to={'idtrouver'}>
              {'아이디 찾기'}
            </NavLink>
            <NavLink to={'/Signin/Factor'}>
              {'비밀번호 찾기'}
            </NavLink>
            <NavLink to={'/signup'}>
              {'회원가입'}
            </NavLink>
          </Box>
          <Stack spacing={5} direction="row" css={styles.snsicon}>
            {/* 카카오 로그인 */}
            <KakaoLogin
              token={`${process.env.REACT_APP_ACCESS_TOKEN_AICA}`}
              onSuccess={(res: any) => {
                handleClickKakao(res);
                console.log("KakaoLogin:=> onSuccess :: ", res)
              }}
              onFail={(err: any) => {
                console.log("KakaoLogin:=> onFail :: ", err)
              }}
              onLogout={() => {
                console.log("로그아웃")
              }}
              render={(renderProps: any) => (
                <Button className="kakao" variant="text" type="button" onClick={renderProps.onClick}></Button>
              )}
            />
            {/* 네이버 로그인 */}
            <NaverLogin
              clientId={`${process.env.REACT_APP_CLIENT_ID_NAVER_AICA}`}
              callbackUrl={`${process.env.REACT_APP_NAVER_CALLBACK}`}
              // callbackUrl={'http://pc.atops.or.kr:5500/signin/snsNaverCallback'}
              render={(renderProps: any) =>
                <div onClick={() => {
                  $("#naverIdLogin_loginButton").removeAttr("href")
                  renderProps.onClick()
                }}>
                  <Button className="naver" variant="text" type="button"></Button>
                </div>
              }
              onSuccess={(res: any) => {
                console.log("NaverLogin:NaverLogin=> onSuccess :: ", res);
              }}
              onFailure={() => console.error("NaverLogin:=> onFailure :: ")}
            />
            {/* 구글 로그인 */}
            <GoogleLogin
              responseType={"id_token"}
              clientId={`${process.env.REACT_APP_CLIENT_ID_GOOGLE_AICA}`}
              render={(renderProps: any) => (
                <div onClick={renderProps.onClick}>
                  <Button className="google" variant="text" type="button"></Button>
                </div>
              )}
              scope='email profile openid https://www.googleapis.com/auth/user.birthday.read'
              onSuccess={(res: any) => {
                console.log("GoogleLogin:=> onSuccess :: ", res);
                handleClickGoogle(res);
              }}
              onFailure={(err: any) => {
                console.error("GoogleLogin:=> onFailure111 :: ", err)
              }}
              cookiePolicy={'single_host_origin'}
            />
          </Stack>
          {formValues.isLock ?
            <div css={styles.error}>
              <p>아이디 혹은 비밀번호를 5회 잘못 입력하였습니다.</p>
              <p>비밀번호 재 설정을 통해 비밀번호를 변경하신 후 이용가능합니다.</p>
            </div> : null}
        </Box>
      </div>}
    <ModalComponents
      open={open}
      type={'confirm'}
      title={"" + ((sts == 400 && error.includes("7일")) ? '407' : sts)}
      content={error}
      onConfirm={(type: string) => {
        debugger;
        if (sts == 602 || sts == 604) {
          window.location.href = '/signup/dormancyLock';
          navigate("/signup/dormancyLock")
        } else if (sts == 603 || sts == 605) {
          window.location.href = '/signup/dormancyCon';
          navigate("/signup/dormancyCon")
        } else {
          navigate("/signup")
        }
      }}
      onClose={(type: string) => {
        setOpen(false)
      }}>
    </ModalComponents>
  </section>
}

const SignTextField = styled(TextField)({
  '& label.Mui-focused': {
    color: '#fff',
  },
  '& .MuiInput-underline:after': {
    borderBottomColor: '#fff',
  },
  '& .MuiOutlinedInput-root': {
    color: '#fff',
    padding: 0,
    '& fieldset': {
      borderColor: '#707070',
    },
    '&:hover fieldset': {
      borderColor: '#fff',
    },
    '&.Mui-focused fieldset': {
      borderColor: '#fff',
    },
  },
});

export default SignIn;