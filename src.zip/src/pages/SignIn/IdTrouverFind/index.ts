export { default } from './IdTrouverFind';
