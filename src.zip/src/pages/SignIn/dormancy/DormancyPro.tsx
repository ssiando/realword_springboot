import * as styles from '../styles';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { TextField } from '@mui/material';
import authentication from '~/../../shared/src/authentication';
import { NavLink, useNavigate } from 'react-router-dom';
import React, {useEffect, useState} from "react";
import {fetchTermsImsi} from "~/fetches";
import {FetchAccountCertBzmn, FetchBzmnNiceIdRes, FetchreactAppPkiCertInitUrl} from "~/fetches/fetchTerms";
import $ from "jquery";
import {useMutation} from "react-query";
import {fetchAccountUndomant} from "~/fetches/fetchSignIn";
import {useGlobalModalStore} from "~/pages/store/GlobalModalStore";

const _global = (window /* browser */ || global /* node */) as any

function DormancyPro() {
  const navigate = useNavigate();
  const [bizNum,setBizNum] = useState('')
  const {addModal} = useGlobalModalStore()

  // 로그인 계정 잠금 해제
  const {mutate:AccountUndomant} = useMutation(async (key: string) => await fetchAccountUndomant(key), {
    onError: (error:any) => {
      addModal({
        type:'normal',
        open: true,
        content: error.response.message
      })
    },
    onSuccess: (data) => {
      navigate('/signup/dormancyLift',{
        state:{
          type:'dormancyCon'
        }
      })
    }
  });

  // iframe 으로부터 메시지 수신 이벤트 함수
  function receiveMessage(e: any) {
    if (!!e && e.data && typeof e.data == 'string') {
      let data = JSON.parse(e.data);
      //console.log(data);

      // iframe 숨김 처리
      $("#pkiContainer").hide();
      $("#pki-frame").prop("src", "about:blank");

      if (data.code == "0") {
        // 콜백 함수 실행
        new Function(`${data.funcNm}("${data.sessionKey}");`)();
      }
    }
  }

  // 사업자회원 계정 인증(PRG-COM-AST-02)
  _global.pkiCert = (pkiCertSessionId: string) => {

    FetchBzmnNiceIdRes({pkiCertSessionId: pkiCertSessionId}).then(data => {
        if (!!data) {
          console.log('data - ' + JSON.stringify(data))
          AccountUndomant(data.key)
        }
      }
    );
  }

  const doSignData = async () => {
    if (bizNum == ''){
      addModal({
        open: true,
        content: '사업자 등록번호를 입력해주세요.'
      })
      return
    }

    await FetchreactAppPkiCertInitUrl().then((res) => {
      let cert = res.cert;

      // 버튼 활성화
      if (cert != undefined && cert != "") {
        if (!!window) {
          let $form = $("form[name='reqForm']");
          $form.find("input[type='hidden'][name='bizrno']").val(bizNum.toString());  // 사업자등록번호
          $form.find("input[type='hidden'][name='callback']").val('pkiCert');   // 콜백으로 받을 함수명

          $form.prop("method", "POST");
          $form.prop("target", "pki-frame");
          $form.prop("action", process.env.REACT_APP_PKI_CERT_URL);         // PKI Monolithic was 서버 공동인증서 페이지 URL

          $form.submit();
          $("#pkiContainer").show();
        }
      } else {
        alert("공동인증서 모듈 초기화에 실패하였습니다.");
      }
    }).catch((err) => {
      if (err.code != "ERR_NETWORK") {
        alert("공동인증서 초기화 호출에 오류가 발생되었습니다.");
      }
    })
  }

  useEffect(() => {
    $("#pkiContainer").hide();
    window.addEventListener("message", receiveMessage, false);
  }, []);

  return (
    <section css={styles.container}>
      <Box css={styles.backPass}>
        <NavLink to={''} onClick={() => navigate(-1)}>
          이전 화면으로 돌아가기
        </NavLink>
      </Box>
      <div css={styles.content}>
        <div className="tit">
          <h1>휴면회원 안내</h1>
        </div>
        <Box css={styles.card_Box}>
          <Box className="icon_errBox">
            <img src="/images/subpage/icon_sleep.png" />
          </Box>
          <Box className="confirm_tit mt20">
            {/*<div><strong>{!!nmval ? nmval : ''}</strong> 님</div>*/}
            <p>장기 미접속으로 인하여 <br className='mo'/>휴면계정으로 전환되었습니다.</p>
            <span className="mintit">공동인증서 인증을 수행하셔야 서비스를 이용할 수 있습니다.</span>
          </Box>
          <Box component="div" css={styles.singform} sx={{ mt:5 }}>
            <TextField
              required
              id="bizNum" 
              name="bizNum"
              variant="filled"
              placeholder="‘-’제외한 숫자만 입력"
              label="사업자등록번호" 
              fullWidth
              value={bizNum}
              onChange={(e) => {
                const num = e.target.value
                //match(/[0-9]/g)
                setBizNum(num)
              }}
            />
          </Box>
          <Stack spacing={2} direction="row" justifyContent={'center'} css={styles.signbtn}>
            <Button variant="contained" type="button" className="linebtn" onClick={()=>navigate('/')}>
              취소
            </Button>
            <Button variant="contained" type="button" className="primary" onClick={doSignData}>
              공동인증서 인증
            </Button>
          </Stack>
        </Box>
      </div>

      <form name="reqForm">
        <input type="hidden" id='bizrno' name='bizrno'/>
        <input type="hidden" id="callback" name="callback"/>
      </form>
      <div id="pkiContainer">
        <iframe
          id="pki-frame" name="pki-frame" src="" scrolling="no" width="100%" height="100%" frameBorder="0"
          style={{
            position: 'fixed',
            zIndex: 100010,
            top: 0, left: 0,
            width: '100%', height: '100%'
          }}>
        </iframe>
      </div>
    </section>
  )
}

export default DormancyPro;
