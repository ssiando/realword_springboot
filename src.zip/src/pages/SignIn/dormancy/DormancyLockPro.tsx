import * as styles from '../styles';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { TextField } from '@mui/material';
import { NavLink, useNavigate } from 'react-router-dom';
import React, {useEffect, useState} from "react";
import $ from "jquery";
import {FetchBzmnNiceIdRes, FetchreactAppPkiCertInitUrl} from "~/fetches/fetchTerms";
import {useGlobalModalStore} from "~/pages/store/GlobalModalStore";

const _global = (window /* browser */ || global /* node */) as any

function DormancyLockPro() {
  const navigate = useNavigate();
  const [bizNum,setBizNum] = useState('')
  const {addModal} = useGlobalModalStore()

  // iframe 으로부터 메시지 수신 이벤트 함수
  function receiveMessage(e: any) {
    if (!!e && e.data && typeof e.data == 'string') {
      let data = JSON.parse(e.data);
      //console.log(data);

      // iframe 숨김 처리
      $("#pkiContainer").hide();
      $("#pki-frame").prop("src", "about:blank");

      if (data.code == "0") {
        // 콜백 함수 실행
        new Function(`${data.funcNm}("${data.sessionKey}");`)();
      }
    }
  }

  // 사업자회원 계정 인증(PRG-COM-AST-02)
  _global.pkiCert = (pkiCertSessionId: string) => {

    FetchBzmnNiceIdRes({pkiCertSessionId: pkiCertSessionId}).then(data => {
        if (!!data) {
          navigate('/signin/factorreset', {
            state: {
              secessionKey: data.key
            }
          })
          // AccountUndomant(data.key)
        }
      }
    );
  }

  const doSignData = async () => {
    if (bizNum == ''){
      addModal({
        open: true,
        content: '사업자 등록번호를 입력해주세요.'
      })
      return
    }

    await FetchreactAppPkiCertInitUrl().then((res) => {
      let cert = res.cert;

      // 버튼 활성화
      if (cert != undefined && cert != "") {
        if (!!window) {
          let $form = $("form[name='reqForm']");
          $form.find("input[type='hidden'][name='bizrno']").val(bizNum.toString());  // 사업자등록번호
          $form.find("input[type='hidden'][name='callback']").val('pkiCert');   // 콜백으로 받을 함수명

          $form.prop("method", "POST");
          $form.prop("target", "pki-frame");
          $form.prop("action", process.env.REACT_APP_PKI_CERT_URL);         // PKI Monolithic was 서버 공동인증서 페이지 URL

          $form.submit();
          $("#pkiContainer").show();
        }
      } else {
        alert("공동인증서 모듈 초기화에 실패하였습니다.");
      }
    }).catch((err) => {
      if (err.code != "ERR_NETWORK") {
        alert("공동인증서 초기화 호출에 오류가 발생되었습니다.");
      }
    })
  }

  useEffect(() => {
    $("#pkiContainer").hide();
    window.addEventListener("message", receiveMessage, false);
  }, []);

  return (
    <section css={styles.container}>
      <Box css={styles.backPass}>
        <NavLink to={''} onClick={() => navigate(-1)}>
          이전 화면으로 돌아가기
        </NavLink>
      </Box>
      <div css={styles.content}>
        <div className="tit">
          <h1>계정잠김 안내</h1>
        </div>
        <Box css={styles.card_Box}>
          <Box className="icon_errBox">
            <img src="/images/subpage/icon_wake.png" />
          </Box>
          <Box className="confirm_tit mt20">
            {/*<div><strong>강환국</strong> 님</div>*/}
            <p>계정에서 의심스러운 활동을 감지했으며 보안을 위해 계정을 일시적으로 잠갔습니다.</p>
            <span className="mintit">공동 인증서 인증 후 비밀번호 재설정을 수행하셔야 서비스를 이용할 수 있습니다. </span>
          </Box>
          <Box component="div" css={styles.singform} sx={{ mt:5 }}>
            <TextField
              required
              id="bizNum" 
              name="bizNum"
              variant="filled"
              placeholder="‘-’제외한 숫자만 입력"
              label="사업자등록번호" 
              fullWidth
              value={bizNum}
              onChange={(e) => {
                const num = e.target.value
                //match(/[0-9]/g)
                setBizNum(num)
              }}
            />
          </Box>
          <Stack spacing={2} direction="row" justifyContent={'center'} css={styles.signbtn}>
            <Button variant="contained" type="button" className="linebtn" onClick={()=>navigate("/")}>
              취소
            </Button>
            <Button variant="contained" type="button" className="primary" onClick={doSignData}>
              공동인증서 인증
            </Button>
          </Stack>
        </Box>
      </div>


      <form name="reqForm">
        <input type="hidden" id='bizrno' name='bizrno'/>
        <input type="hidden" id="callback" name="callback"/>
      </form>
      <div id="pkiContainer">
        <iframe
          id="pki-frame" name="pki-frame" src="" scrolling="no" width="100%" height="100%" frameBorder="0"
          style={{
            position: 'fixed',
            zIndex: 100010,
            top: 0, left: 0,
            width: '100%', height: '100%'
          }}>
        </iframe>
      </div>
    </section>
  )
}

export default DormancyLockPro;
