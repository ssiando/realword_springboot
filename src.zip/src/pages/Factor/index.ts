export { default } from './Factor';
