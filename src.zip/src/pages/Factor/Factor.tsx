import React, {useEffect, useRef, useState} from "react";
import * as styles from '~/styles/styles';
import {Autocomplete, Box, Stack, TextField} from '@mui/material';
import {CustomButton} from '~/components/ButtonComponents';
import {useLocation, useNavigate} from "react-router-dom";
import {fetchCheckUserPw} from "~/fetches/fetchSignIn";
import {useGlobalModalStore} from "../store/GlobalModalStore";
import $ from "jquery";
import {keySecureDec} from "shared/utils/NxKeyUtile";
import {Banner} from "~/components/Banner";
import {VerticalInterval} from "shared/components/LayoutComponents";

type FormType = {
  passwd?: string;
};
/* 
  작성일    :   2022/06/05
  화면명    :   이페이지 -> 비밀번호 확인
  회면ID    :   UI-USP-FRN-0050101
  화면/개발 :   Seongeonjoo / navycui
*/

const _global = (window /* browser */ || global /* node */) as any
const Factor = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const formData = new FormData();
  const {addModal} = useGlobalModalStore();
  const [form, setForm] = useState<FormType>({passwd: ''});

  const keyboardId = useRef<any>(null)
  const testPw = useRef<any>(null)

  const isMobileCheck = /iPhone|iPad|iPod|Android/i.test(
    window.navigator.userAgent
  );

  useEffect(() => {
    if (isMobileCheck) {
      setTimeout(() => {
        const tmTranskey = document.getElementById('tmTranskey')
        if (tmTranskey) tmTranskey.click()
      }, 500)
    } else {
      const nxLoading = document.getElementById('nxLoading')
      if (nxLoading) nxLoading.click()
      setTimeout(() => {
        const nxRescan = document.getElementById('nxRescan')
        if (nxRescan) nxRescan.click()
      }, 300)
    }
  }, [])

  useEffect(() => {
    //@ts-ignore
    if (loadflag && keyboardId) {
      setTimeout(() => {
        keyboardId.current.focus()
      }, 500)
    }
    //@ts-ignore
  }, [loadflag])

  // 입력 제어
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const {name, value} = e.currentTarget;
    setForm({...form, [name]: value})
  };

  // 확인 이벤트
  const handleSubmit = async () => {
    // e.preventDefault();
    const pwd = $(`#${isMobileCheck ? 'passwd_mo' : 'passwd'}`).val()?.toString() || ''
    console.log('passwd - ' + pwd)
    // TODO: 비밀번호 확인
    if (pwd != '') {
      formData.append('passwd', pwd)
      await fetchCheckUserPw(formData)
        .then((res) => {
          const {passwdCheckKey: key} = res.data;
          sessionStorage.setItem('__FACTOR_KEY__', key);
          navigate({
            pathname: '/Mypage/MemberInfoMmt/MemberInfoMdf',
            search: '?check=factor',
          });
        })
        .catch((e) => {
          addModal({
            type: 'normal',
            open: true,
            content: e.response.data.message
          })
        });
    } else {
      addModal({
        type: 'normal',
        open: true,
        content: "비밀번호 입력하세요."
      })
    }
  }

  return <Banner
    title={'비밀번호 확인'}
    summary={<p>
      AICA에서 진행하는 채용공고, 운영과 관련한 안내사항 등을 확인하실
      수 있습니다.
    </p>}>
    <section>
    <Box css={styles.sub_cont02}>
      <div className="content">
        <Box css={styles.login_cont}>
          <Box className="input_form">
            <VerticalInterval size={'40px'}/>
            <dl>
              <dt>비밀번호입력</dt>
              <dd> {
                isMobileCheck ?
                  <Box component={'form'} css={styles.signinput} id={"pwdForm"} name={"pwdForm"}>
                    <input
                      ref={testPw}
                      type="password"
                      name='passwd_mo'
                      id="passwd_mo"
                      data-tk-kbdType="qwerty"
                      data-tk-bottom="true"
                      style={{width: '100%', padding: "15px"}}
                      onFocus={() => {
                        //@ts-ignore
                        mtk.onKeyboard(testPw.current);
                      }}
                      autoComplete="new-password"
                      placeholder="비밀번호"
                      onChange={handleChange}
                    />
                  </Box> : <Box component={'form'} id={"pwdForm"} name={"pwdForm"}>
                    <TextField
                      inputRef={keyboardId}
                      type="password"
                      name='passwd'
                      id="passwd"
                      placeholder="비밀번호"
                      fullWidth
                      onChange={handleChange}
                      onKeyUp={(e) => {
                        if (e.key === 'Enter') {
                          handleSubmit()
                        }
                      }}
                    />
                    <TextField
                      inputRef={keyboardId}
                      type="password"
                      name='passwd'
                      id="passwd"
                      placeholder="비밀번호"
                      fullWidth
                      style={{display: 'none'}}
                    />
                  </Box>
              }
              </dd>
            </dl>
          </Box>
          <Stack justifyContent={'center'} direction={'row'} css={styles.btnGroup}>
            <CustomButton label={'확인'} type={'listBack'} color={'primary'} onClick={() => {
              isMobileCheck ? keySecureDec('passwd_mo', (decode: string) => {
                $("#passwd_mo").val(decode)
                handleSubmit()
              }) : handleSubmit()
            }}/>
          </Stack>
          <VerticalInterval size={'40px'}/>
        </Box>
      </div>
    </Box>
    </section>
  </Banner>
};
export default Factor;