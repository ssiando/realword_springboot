import React, {Fragment, useEffect, useState} from 'react';
import dayjs from 'dayjs';
import * as styles from '~/styles/styles';
import Box from '@mui/material/Box';
import {Chip, Stack, useMediaQuery, List, ListItem, ListItemText} from '@mui/material';
import Typography from '@mui/material/Typography';
import {useTheme} from '@mui/material';
import {CustomButton} from '~/components/ButtonComponents';
import {CustomRadioButtons} from '~/components/NoticeCustomCheckBoxs';
import {NavLink} from 'react-router-dom';
import {fetchOneByOneMmt, fetchGetCommCode} from '~/fetches';
import {questsType} from '~/fetches/fetchQnaQuest';
import {useQuery} from "react-query";
import DatePicker from '~/components/DatePicker';
import {SearchBar} from '~/components/BizCommon/SearchBar';
import {SearchModal} from '~/components/BizCommon/SearchModal';
import NoData from '~/components/Loading/NoData';
import {ModalComponents} from '~/components/ModalComponents';
import {useNavigate} from 'react-router-dom';
import authentication from 'shared/authentication';
import {Banner} from '~/components/Banner';
/* 
  작성일    :   2022/06/01
  화면명    :   이페이지 -> 문의관리 -> 1:1문의 목록
  회면ID    :   UI-USP-FRN-0350101
  화면/개발 :   Seongeonjoo / navycui
*/
const OneByOneMmt = () => {
  const beginDay = new Date();
  const endDay = new Date();
  endDay.setDate(endDay.getDate() + 15);
  const theme = useTheme();
  beginDay.setDate(beginDay.getDate() - 30)
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [answer, setAnswer] = useState<any>(null)
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [loading, setLoading] = useState(true)
  const [quests, setQuests] = useState<questsType>({
    title: "",
    qnaId: process.env.REACT_APP_USP_PERSNAL,
    questId: "",
    questBeginDay: dayjs(beginDay).format('YYYYMMDD').toString(),
    questEndDay: dayjs(endDay).format('YYYYMMDD').toString(),
    questStatus: "",
    memberNm: "",
    page: 1,
    itemsPerPage: 5,
  })

  // 공통 코드 조회
  const {data: assign_box} = useQuery("QUEST_STATUS", async () => await fetchGetCommCode("QUEST_STATUS"));

  // 질의응답 목록 조회
  const {
    data: list,
    refetch, isLoading, isFetching,
    error
  } = useQuery(["fetchOneByOneMmt", quests], async () => await fetchOneByOneMmt(quests, `${process.env.REACT_APP_USP_PERSNAL}`), {
    onSuccess: (res: any) => {
      setLoading(false)
    },
    onError: (err: any) => {
      setOpen(true)
      setLoading(false)
    }
  });

  useEffect(() => {
    if (!!!authentication.getToken()) {
      navigate(`/signin?nextUrl=${window.btoa(window.location.href)}`)
      return
    }
  }, []);

  useEffect(() => {
    if (!isLoading && !isFetching){
      if (!!list){
        setAnswer(list)
      }
    }
  })

  const moreInfo = () => {
    const itemsPerPage: any = quests.itemsPerPage + 5;
    setQuests((state) => ({...state, itemsPerPage}));
  }

  const questSt = (item: string) => {
    if (item === "REQUEST") {
      return "요청"
    } else if (item === "RECEIPT") {
      return "접수"
    } else if (item === "ANSWER") {
      return "답변"
    } else if (item === "CONFIRM") {
      return "확인"
    }
  }

  const categoryCd = (item: string) => {
    if (item === "CATE-PERSNAL-01") {
      return "지원/신청"
    } else if (item === "CATE-PERSNAL-02") {
      return "데이터/시스템"
    }
  }
  console.log('answer - ' + JSON.stringify(answer))
  return (
    <Banner
      title={'1:1문의 관리'}
      summary={<p>AICA에서 운영 및 지원하는 사업과 시설 전반에 대해 문의하신 목록과 답변을 확인하실 수 있습니다.</p>}
      loading={loading}
      searchContent={<SearchBar
        placehold='1:1문의를 확인해보세요!'
        handleSearch={(val: any) => {
          setQuests((state) => ({...state, title: val}))
        }}
      />}
      detailContent={<>
        {isMobile ? (
          <SearchModal
            placehold='1:1문의를 확인해보세요!'
            handleSearch={(searchInput: string | undefined, sdt: string, edt: string) => {
              setQuests((state) => ({
                ...state,
                questStatus: searchInput ? searchInput : '',
                questBeginDay: dayjs(sdt).format('YYYYMMDD').toString(),
                questEndDay: dayjs(edt).format('YYYYMMDD').toString()
              }))
            }}
            assign_box={!!assign_box ? assign_box.list : []}
          />
        ) : (
          <Box css={styles.picker_card}>
            <dl>
              <dt>접수일</dt>
              <dd>
                <Box className="box_scroll">
                  <DatePicker
                    pickerType='two'
                    questBeginDay={dayjs(quests.questBeginDay, 'YYYYMMDD').toString()}
                    questEndDay={dayjs(quests.questEndDay, 'YYYYMMDD').toString()}
                    changeStart={(startNewTime: Date | null) => {
                      setQuests((prevState) => ({
                        ...prevState,
                        questBeginDay: dayjs(startNewTime).format('YYYYMMDD').toString()
                      }))
                    }}
                    changeEnd={(endNewTime: Date | null) => {
                      setQuests((prevState) => ({
                        ...prevState,
                        questEndDay: dayjs(endNewTime).format('YYYYMMDD').toString()
                      }))
                    }}
                  />
                </Box>
              </dd>
            </dl>
            <dl>
              <dt>상태</dt>
              <dd>
                <Box className="box_scroll">
                  <CustomRadioButtons
                    row data={!!assign_box ? assign_box.list : []}
                    onClick={(s) => {
                      if (s == 'all') {
                        setQuests({...quests, questStatus: ''})
                      } else {
                        setQuests({...quests, questStatus: s})
                      }
                    }}/>
                </Box>
              </dd>
            </dl>
          </Box>
        )}
      </>}>
      <div css={styles.container}>
        <Box css={styles.sub_cont02}>
          <div className="content list">
            <div css={styles.detal_list}>
              <Stack
                spacing={6}
                direction="row"
                className="sub_tit"
                justifyContent="space-between"
              >
                <Typography variant="h4" component="div">
                  1:1문의
                  {answer && <span className='data'><em>{answer.totalItems}</em> 건</span>}
                </Typography>
              </Stack>
              {
                answer && answer.list.length > 0 ? <Fragment>
                  <List>
                    {
                      answer.list.map((item: any, i: number) => (
                        <NavLink to={`/MyPage/InquiryMmt/OneByOneMmt/${item.questId}`}
                                 key={i}
                                 state={{item: item, lists: answer.list}}>
                          <ListItem>
                            <ListItemText
                              secondary={
                                <React.Fragment>
                        <span className="tit_body">
                          <Stack direction="row" className='tag' spacing={1} component="span">
                            <Chip label={categoryCd(item.categoryCd)} className='item' sx={{mr: 1}}/>
                          </Stack>
                          <Typography variant="body1" component="span" className="mb0">
                            {item.title}
                          </Typography>
                        </span>
                                  <span className="date">
                          <span>접수일 <em>{dayjs(item.questCreatedDt).format('YYYY-MM-DD')}</em></span>
                        </span>
                                  <span className="right_tag">
                          <em>{questSt(item.questSt)}</em>
                        </span>
                                </React.Fragment>
                              }
                            />
                          </ListItem>
                        </NavLink>
                      ))
                    }
                  </List>
                  {quests.itemsPerPage < answer.totalItems ? 
                    <Stack css={styles.bottom_btn}>
                      <CustomButton label={'더보기'} type={'full'} color={'item'} style={{margin: '10px 0'}} onClick={() => moreInfo()}/>
                    </Stack> : <Box sx={{borderBottom: "1px solid #e0e0e0"}}/>
                  }
                </Fragment> : <NoData/>
              }
            </div>
          </div>
        </Box>
        <ModalComponents
          open={open} type={'normal'}
          content={!!error ? error.response.data.message : ''}
          onConfirm={() => {
            setOpen(false)
          }}
          onClose={() => {
            setOpen(false)
          }}>
        </ModalComponents>
      </div>
    </Banner>
  );
}

export default OneByOneMmt;
