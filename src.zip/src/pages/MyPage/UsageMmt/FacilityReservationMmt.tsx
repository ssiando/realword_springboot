import React, {useEffect, useState} from 'react';
import dayjs from 'dayjs';
import * as styles from '~/styles/styles';
import Box from '@mui/material/Box';
import {Stack, useMediaQuery, List, ListItem, ListItemText, Collapse} from '@mui/material';
import Typography from '@mui/material/Typography';
import {useTheme} from '@mui/material';
import {CustomButton} from '~/components/ButtonComponents';
import {CustomRadioButtons} from '~/components/NoticeCustomCheckBoxs';
import {NavLink} from 'react-router-dom';
import {fetchGetCommCode} from '~/fetches';
import {SearchModal} from '~/components/BizCommon/SearchModal';
import DatePicker from '~/components/DatePicker';
import {ModalReasonConfirm} from '~/pages/biz/BusinessAppMgt/PopComp/ModalReasonConfirm';
import NoData from '~/components/Loading/NoData';
import RceptStus from '~/pages/biz/BusinessAppMgt/PopComp/RceptStus';
import {fetchReservationUser} from '~/fetches/fetchMoveIn';
import {useQuery} from 'react-query';
import {ModalComponents} from '~/components/ModalComponents';
import {SearchBar} from '~/components/BizCommon/SearchBar';
import {useNavigate} from 'react-router-dom';
import authentication from 'shared/authentication';
import {Banner} from '~/components/Banner';

/* 
  작성일    :   2022/06/09
  화면명    :   이페이지 -> 사용자지원 -> 시설예약관리 (사유 파업 UI-USP-FRN-0290102)
  회면ID    :   UI-USP-FRN-0290101
  화면/개발 :   Seongeonjoo / navycui
*/
const FacilityReservationMmt = () => {
  const today = new Date();
  const navigate = useNavigate();
  today.setHours(today.getHours() - 24);
  const theme = useTheme();
  const [open, setOpen] = useState(false);
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [loading, setLoading] = useState(true)
  const [quests, setQuests] = useState({
    mvnFcNm: "",
    srchBeginDay: dayjs(today).format('YYYYMMDD'),
    srchEndDay: dayjs(today).add(1, "M").format('YYYYMMDD'),
    reserveSt: "",
    page: 1,
    itemsPerPage: 5,
  })
  const [tempQuests, setTempQuests] = useState({
    mvnFcNm: "",
    srchBeginDay: dayjs(today).format('YYYYMMDD'),
    srchEndDay: dayjs(today).add(1, "M").format('YYYYMMDD'),
    reserveSt: "",
  })

  // 공통 코드 조회
  const {data: assign_box} = useQuery("RESERVE_ST", async () => await fetchGetCommCode("RESERVE_ST"));

  // 목록 조회
  const {
    data: list,
    refetch,
    error
  } = useQuery(["fetchOneByOneMmt", quests], async () => await fetchReservationUser(quests), {
    onSuccess: (res: any) => {
      setLoading(false)
    },
    onError: (err: any) => {
      //  setOpen(true)
      setLoading(false)
    }
  });

  useEffect(() => {
    if (!!!authentication.getToken()) {
      navigate(`/signin?nextUrl=${window.btoa(window.location.href)}`)
    }
    setLoading(true)
    // refetch();
  }, [])

  const moreInfo = () => {
    const itemsPerPage: any = quests.itemsPerPage + 5;
    setQuests((state) => ({...state, itemsPerPage}));
  }

  return (
    <Banner
      title={'시설예약 관리'}
      summary={<p>신청한 시설예약 목록을 조회하고, 현재 예약 상태를 확인할 수 있습니다.</p>}
      loading={loading}
      searchContent={<SearchBar
        placehold='예약한 시설을 확인해보세요!'
        handleSearch={(val: any) => {
          setQuests({...quests, ...tempQuests})
        }}
        onChange={(keyword) => {
          setTempQuests({...tempQuests, mvnFcNm: keyword})
        }}
      />}
      detailContent={<>
        {isMobile ? (
          <SearchModal
            placehold='예약한 시설을 확인해보세요!'
            handleSearch={(s: string | undefined) => {
              if (!!s) {
                setQuests((state) => ({...state, mvnFcNm: s}))
              }
            }}
            assign_box={!!assign_box ? assign_box.list : []}
          />
        ) : (
          <Box css={styles.picker_card}>
            <dl>
              <dt>예약일</dt>
              <dd>
                <Box className="box_scroll">
                  <DatePicker
                    pickerType='two'
                    questBeginDay={dayjs(tempQuests.srchBeginDay, 'YYYYMMDD').toString()}
                    questEndDay={dayjs(tempQuests.srchEndDay, 'YYYYMMDD').toString()}
                    changeStart={(startNewTime: Date | null) => {
                      if (startNewTime){
                        const end = new Date(Number(tempQuests.srchEndDay.slice(0,4)),
                          Number(tempQuests.srchEndDay.slice(4,6)) - 1, Number(tempQuests.srchEndDay.slice(6,8)))
                        if (startNewTime.getTime() > end.getTime()){
                          setTempQuests({...tempQuests, srchBeginDay: dayjs(end).format('YYYYMMDD')})
                        }else {
                          setTempQuests({...tempQuests, srchBeginDay: dayjs(startNewTime).format('YYYYMMDD')})
                        }
                      }
                    }}
                    changeEnd={(endNewTime: Date | null) => {
                      if (endNewTime){
                        const begin = new Date(Number(tempQuests.srchBeginDay.slice(0,4)),
                          Number(tempQuests.srchBeginDay.slice(4,6)) - 1, Number(tempQuests.srchBeginDay.slice(6,8)))
                        if (endNewTime.getTime() < begin.getTime()){
                          setTempQuests({...tempQuests, srchEndDay: dayjs(begin).format('YYYYMMDD')})
                        }else {
                          setTempQuests({...tempQuests, srchEndDay: dayjs(endNewTime).format('YYYYMMDD')})
                        }
                      }
                    }}
                  />
                </Box>
              </dd>
            </dl>
            <dl>
              <dt>예약상태</dt>
              <dd>
                <Box className="box_scroll">
                  <CustomRadioButtons
                    row
                    data={!!assign_box ? assign_box.list : []}
                    onClick={(s: string) => {
                      setTempQuests({
                        ...tempQuests,
                        reserveSt: s
                      })
                    }}
                  />
                </Box>
              </dd>
            </dl>
          </Box>
        )}
      </>}>
      <div css={styles.container}>
        <Box css={styles.sub_cont02}>
          <div className="content list">
            {/* className="list02" 클래스는 사유확인버튼이 있을시에만 추가 */}
            <div css={styles.detal_list} className="list02">
              <Stack
                spacing={6}
                direction="row"
                className="sub_tit"
                justifyContent="space-between"
              >
                <Typography variant="h4" component="div">
                  시설예약
                  <span className='data'><em>{list?.totalItems}</em> 건</span>
                </Typography>
              </Stack>
              <List>
                {!!list ? list.list.map((item: any, i: number) => (
                  <div className="btn_cont" key={i}>
                    <NavLink
                      key={i} to={`/MyPage/UsageMmt/FacilityReservationMmt/${item.reserveId}`}
                      state={{
                        item: item, lists: list.list,
                        total: list?.totalItems
                      }}>
                      <ListItem>
                        <ListItemText
                          secondary={
                            <React.Fragment>
                              <Stack className="listflex" direction={'row'} spacing={2} justifyContent={'space-between'}
                                     component="span">
                                <Box className="listflex01" component="span">
                                  <span className="tit_body">
                                    <Typography variant="body1" component="span">
                                      {item.mvnFcNm}
                                    </Typography>
                                  </span>
                                  <Box className="dateBoxto" component="span">
                                    <span className="date">
                                      <span>예약일시 <em>{dayjs(item.rsvtDay).format('YYYY-MM-DD')}</em></span>
                                    </span>
                                    <span className="date">
                                      <span>예약인원수 <em>{item.rsvtNope + '명'}</em></span>
                                      <span>신청일시 <em>{dayjs(item.rsvtReqDt).format('YYYY-MM-DD')}</em></span>
                                    </span>
                                  </Box>
                                </Box>
                              </Stack>
                            </React.Fragment>
                          }
                        />
                      </ListItem>
                    </NavLink>
                    <Stack className="listflex02" direction={'row'} component="span">
                      <RceptStus stus={!!item.reserveStNm ? item.reserveStNm : ''}/>
                      {
                        item.reserveSt == 'RJCT' &&
                        <div className="right_btn">
                          <ModalReasonConfirm title={''} applyId={item.reserveId}
                                              viewNm="FacilityReservationMmt"/>
                        </div>
                      }
                    </Stack>
                  </div>
                )) : <NoData/>}
              </List>
              {quests.itemsPerPage < list?.totalItems ?
                <Stack css={styles.bottom_btn}>
                  <CustomButton label={'더보기'} style={{margin: '10px 0'}} type={'full'} color={'item'}
                                onClick={() => moreInfo()}/>
                </Stack> : <Box sx={{borderBottom: "1px solid #e0e0e0"}}/>
              }
            </div>
          </div>
        </Box>
        <ModalComponents open={open} type={'normal'} content={!!error ? error.message : ''}
                         onConfirm={() => {
                           setOpen(false)
                         }}
                         onClose={() => {
                           setOpen(false)
                         }}>
        </ModalComponents>
      </div>
    </Banner>
  );
}

export default FacilityReservationMmt;

