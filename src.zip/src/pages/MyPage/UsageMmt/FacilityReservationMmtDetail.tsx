import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from "react-router-dom";
import * as styles from '~/styles/styles';
import Box from '@mui/material/Box';
import dayjs from 'dayjs';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import { CustomButton } from '~/components/ButtonComponents';
import { useMutation, useQuery } from 'react-query';
import { useGlobalModalStore } from '~/pages/store/GlobalModalStore';
import { fetchMvnFcSpacesPut, fetchReservationUserDetail } from '~/fetches/fetchMoveIn';
import { ModalComponents } from '~/components/ModalComponents';
import { Banner } from '~/components/Banner';

/* 
  작성일    :   2022/06/09
  화면명    :   마이페이지/ -> 시설예약관리 상세페이지
  회면ID    :   UI-USP-FRN-0290201
  화면/개발 :   Seongeonjoo / navycui
*/
const  FacilityReservationMmtDetail =  () => {
  const {addModal} = useGlobalModalStore();
  const navigate = useNavigate();
  const receive:any = useLocation();
  const [reserveId, setReserveId] = useState('');
  const [open, setOpen] = useState(false);
  const [errors, setErrors] = useState('');
  const [loading, setLoading] = useState(true)

  // 초기화
  useEffect(() => {
    if(!!receive.state){
      setReserveId(receive.state.item.reserveId)
    }
  }, []);

  // 상세 조회
  const { data } = useQuery(["getReservationDetail",reserveId], async () => await fetchReservationUserDetail(reserveId),{
    onSuccess:(data) => {
      setLoading(false)
    },
    enabled:!!reserveId,
    onError:(err:any)=> {
      setErrors(err.response.data.message)
      setOpen(true)
      setLoading(false)
    },
  });

  // 예약 취소 [시설예약 상태변경] (PRG-USP-R01-03)
  const {mutate} = useMutation(async () => await fetchMvnFcSpacesPut({reserveId: reserveId , reserveSt: 'RSVT_RTRCN', rejectReasonCn: data.mvnFcRsvt.rejectReasonCn}), { 
    onError: (error:any, variable, context) => {
      console.log("error", error);
      setErrors(error.response.data.message)
      setOpen(true)
    },
    onSuccess: (data) => {
      addModal({
        type:'normal',
        open: true,
        content: "예약이 취소되었습니다."
      })
      navigate('/MyPage/UsageMmt/FacilityReservationMmt')
    }
  });

  return (
    <Banner
      title={'시설예약 상세'}
      summary={<p>AICA에 전달하신 의견 및 제안 목록과 답변을 확인하실 수 있습니다.</p>}
      loading={loading}>
      <div css={styles.container}>
        <Box css={styles.sub_cont02}>
          <div className="content">
            <Box css={styles.table05}>
              <Typography
                gutterBottom
                variant="h6"
                component="div"
              >
                {'기본정보'}
              </Typography>
              <div className="detail_table"> 
                <dl>
                  <dt>신청일시</dt>
                  <dd>{!!data ? dayjs(data.mvnFcRsvt.fmtReserveStDt).format('YYYY-MM-DD hh:mm') : ''}</dd>
                  <dt>예약상태</dt>
                  <dd>{!!data ? data.mvnFcRsvt.reserveStNm : ''}</dd>
                </dl>
                {
                  data && data.mvnFcRsvt.reserveSt == 'RJCT' && <dl>
                    <dt>사유</dt>
                    <dd>{data.mvnFcRsvt.rejectReasonCn}</dd>
                  </dl>
                }
              </div>
              <Typography
                gutterBottom
                variant="h6"
                component="div"
              >
                {'시설정보'}
              </Typography>
              <div className="detail_table"> 
                <dl>
                  <dt>시설명</dt>
                  <dd>{!!data ? data.mvnFc.mvnFcNm : ''}</dd>
                  <dt>예약유형</dt>
                  <dd>{!!data ? data.mvnFc.reserveTypeNm : ''}</dd>
                </dl>
                <dl>
                  <dt>수용인원</dt>
                  <dd>{(data && data.mvnFc.mvnFcCapacity)? `최대 ${data.mvnFc.mvnFcCapacity}명` : ''}</dd>
                  <dt>이용가능시간</dt>
                  <dd>{!!data ? data.mvnFc.utztnBeginHh : ''} ~ {!!data ? data.mvnFc.utztnEndHh : ''}시</dd>
                </dl>
              </div>
              <Typography
                gutterBottom
                variant="h6"
                component="div"
              >
                {'신청정보'}
              </Typography>
              <div className="detail_table"> 
                <dl>
                  <dt>예약일</dt>
                  <dd>{!!data ? dayjs(data.mvnFcRsvt.rsvtDay).format('YYYY-MM-DD') : ''}</dd>
                  <dt>예약시간</dt>
                  <dd>{!!data ? data.mvnFcRsvt.fmtRsvtTm : ''}</dd>
                </dl>
                <dl>
                  <dt>이용인원수</dt>
                  <dd>{!!data ? data.mvnFcRsvt.rsvtNope : ''}명</dd>
                </dl>
                <dl>
                  <dt>이용목적</dt>
                  <dd>
                    <div>
                      {!!data ? data.mvnFcRsvt.utztnPurpose.replace(/(?:\r\n|\r|\n)/g, '\r\n').split('\r\n').map((item:any) => ( <p>{item} </p>))
                      : ''}
                    </div>
                  </dd>
                </dl>
              </div>
              {
                data && data.mvnFcRsvt.reserveSt != 'RJCT' && data.mvnFcRsvt.reserveSt != 'CLOSE' &&
                data.mvnFcRsvt.reserveSt != 'RSVT_RTRCN' && data.mvnFcRsvt.reserveSt != 'APRV_RTRCN' &&
                <Stack direction="row" justifyContent="center" spacing={2} css={styles.btnGroup}>
                  <CustomButton label={'예약취소'} type={'listBack'} color={'primary'} onClick={() => {
                    mutate()
                  }}/>
                </Stack>
              }
              </Box>
          </div>
        </Box>
        <ModalComponents open={open} type={'normal'} content={errors} 
          onConfirm={() => { setOpen(false) }} 
          onClose={() => { setOpen(false)}}>
        </ModalComponents>
      </div>
    </Banner>
  );
}

export default FacilityReservationMmtDetail;
