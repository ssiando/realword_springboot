import * as styles from '~/styles/styles';
import React, {Fragment, useState} from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import dayjs from 'shared/libs/dayjs';
import {useNavigate, useLocation, NavLink} from 'react-router-dom';
import fetchDownload from '~/fetches/fetchDownload';
import {fetchOneByOneMmt, fetchOneByOneMmtDetail} from '~/fetches';
import {useEffect} from "react";
import {CustomButton} from '~/components/ButtonComponents';
import {Button, Chip, TextField} from '@mui/material';
import {useQuery} from 'react-query';
import {useGlobalModalStore} from "./../../store/GlobalModalStore";
import {Banner} from '~/components/Banner';
import {dayFormat} from "shared/utils/stringUtils";
import {
  fetchOneByOneFiles,
  fetchOneByOneFilesDelete,
  fetchOneByOneMmtDelete,
  fetchOneByOneMmtModify
} from "~/fetches/fetchQnaQuest";
import {FileUpload1} from "~/pages/EventNews/FileUpload";

/* 
  작성일    :   2022/06/01
  화면명    :   마이페이지/ -> 디딤널관리 상세페이지
  회면ID    :   UI-USP-FRN-0360201
  화면/개발 :   Seongeonjoo / navycui
*/
export default function TreadmillMmtDetail() {
  const {addModal} = useGlobalModalStore();
  const navigate = useNavigate();
  const receive: any = useLocation();
  const [data, setData] = useState<any>()
  const [rowNum, setRowNum] = useState(0);
  const [questId, setQuestId] = useState('');
  const [lists, setLists] = useState([]);
  const [loading, setLoading] = useState(true)

  const [modify, setModify] = useState(false)
  const [modifyContent, setModifyContent] = useState('')

  const [files, setFiles]: any = useState([])
  const [deleteAttachFileList, setDeleteAttachFileList]: any = useState([])

  // 상세 조회
  const {data: noticeData, isLoading, isFetching, refetch} = useQuery(
    ["getDetail", questId], async () => await fetchOneByOneMmtDetail(questId, 'step-flat'));

  // 초기화
  useEffect(() => {
    if (!!receive.state) {
      setRowNum(receive.state.item.rn)
      setQuestId(receive.state.item.questId)
      setLists(receive.state.lists)
    }
    setLoading(false)
  }, []);

  useEffect(() => {
    if (!isLoading && !isFetching) {
      if (!!noticeData) {
        setData(noticeData)
      }
    }
  }, [noticeData, isLoading, isFetching])

  //이전글
  function isPre(element: any) {
    if (element.rn === rowNum - 1) {
      return true;
    }
  }

  const pre: any = lists ? lists.filter(isPre) : [];

  //다음글
  function isNext(element: any) {
    if (element.rn === rowNum + 1) {
      return true;
    }
  }

  const next: any = lists ? lists.filter(isNext) : [];

  const download = async (attachmentId: any) => {
    fetchDownload(`${process.env.REACT_APP_DOMAIN_COMMON_BNET}/common/api/qna/step-flat/quests/${questId}/attachments/${attachmentId}`)
      .then()
      .catch((e) => {
        let status = e.response.status;
        console.log(status);
        if (status === 400) {
          addModal({
            open: true,
            content: "파일이 없습니다."
          })
        }
      });
  }

  const deleteBoard = async () => {
    const res = await fetchOneByOneMmtDelete(questId, 'step-flat').then((e) => {
      addModal({
        open: true,
        content: '게시글이 삭제되었습니다.',
        onClose: () => {
          navigate('/MyPage/UsageMmt/TreadmillMmt')
        },
        onConfirm: () => {
          navigate('/MyPage/UsageMmt/TreadmillMmt')
        }
      })
    }).catch((e) => {
      addModal({
        open: true,
        content: e.response.data.message,
      })
    })
  }

  const deleteAttachment = async () => {
    let count = deleteAttachFileList.length
    try {
      while (count > 0) {
        const attachmentId = deleteAttachFileList[count - 1].attachmentId
        await fetchOneByOneFilesDelete(questId, `${process.env.REACT_APP_USP_PERSNAL}`, attachmentId)
        count -= 1
      }
      addModal({
        open: true,
        content: '게시글이 수정 되었습니다.',
        onClose: () => {
          refetch()
        },
        onConfirm: () => {
          refetch()
        }
      })
      setModify(false)
      setFiles([])
      setDeleteAttachFileList([])
    }catch(e: any) {
      addModal({
        open: true,
        content: e.response.data.message,
        onClose: () => {
          refetch()
        },
        onConfirm: () => {
          refetch()
        }
      })

      setModify(false)
      setFiles([])
      setDeleteAttachFileList([])
    }
  }

  const modifyBoard = async () => {
    if (modifyContent == data?.question && files.length == 0 && deleteAttachFileList.length == 0) {
      addModal({
        open: true,
        content: '변경 사항이 없습니다.',
      })
      setModify(false)
      // setFiles([])
      return;
    }

    if (modifyContent != data?.question || files.length != 0) {
      const form = new FormData();
      form.append("qnaQuest", new Blob([JSON.stringify({
        categoryCd: data.categoryCd,
        title: data.title,
        question: modifyContent,
      })], {type: "application/json"}));

      for (let i = 0; i < files.length; i++) {
        form.append("file", files[i])
      }

      const res = await fetchOneByOneMmtModify(questId, 'step-flat', form).then((e) => {
        addModal({
          open: true,
          content: '게시글이 수정 되었습니다.',
          onClose: () => {
            refetch()
          },
          onConfirm: () => {
            refetch()
          }
        })
        setModify(false)
        setFiles([])
      }).catch((e) => {
        addModal({
          open: true,
          content: e.response.data.message,
        })

        setModify(false)
        setFiles([])
      })
    }

    if (deleteAttachFileList.length > 0) {
      await deleteAttachment()
    }
  }

  return (
    <Banner
      title={'디딤널 상세'}
      summary={<p>AICA에 전달하신 의견 및 제안 목록과 답변을 확인하실 수 있습니다.</p>}
      loading={loading}>
      {
        data && <div css={styles.container}>
          <Box css={styles.sub_cont02}>
            <div className="content">
              {/* 상세 list 리스트 */}
              <div css={styles.detal_list}>
                {/* 텍스트 상단 */}
                <Box css={styles.detal_txtBox}>
                  <Stack direction="row" className='mb10' spacing={1} component="span">
                    {!!data ?
                      <Chip label={
                        data.questSt == 'REQUEST' ? "문의요청" :
                          data.questSt == 'RECEIPT' ? "문의접수" :
                            data.questSt == 'ANSWER' ? "답변완료" :
                              data.questSt == 'CONFIRM' ? "문의확인" : ""
                      } className='blue'/> : ''}
                    {
                      data?.categoryCd == 'CATE-STEP-01'
                        ? <Chip label="창업아이디어" className='wh'/>
                        : data?.categoryCd == 'CATE-STEP-02'
                          ? <Chip label="구인/구직" className='wh'/>
                          : <Chip label="제안/기타" className='wh'/>
                    }
                  </Stack>
                  <Typography variant="h5" component="div">
                    {data?.title}
                  </Typography>
                  <div className="date">
                    <span><em>{dayjs(!!data ? data.updatedDt : new Date()).format('YYYY-MM-DD')}</em></span>
                  </div>
                </Box>
                {
                  modify ? <Box css={styles.inputBox} sx={{paddingTop: '20px'}}>
                    <TextField
                      id="outlined-multiline-static"
                      className="scrollBox"
                      multiline
                      rows={6}
                      value={modifyContent}
                      onChange={(e) => {
                        setModifyContent(e.target.value)
                      }}
                      inputProps={{
                        maxLength: 1000,
                      }}
                    />
                    <span className="count"><em>{modifyContent.length}</em>/1000</span>
                  </Box> : <Box css={styles.detal_img}>
                    <p style={{whiteSpace: 'pre-line'}}>{data.question}</p>
                  </Box>
                }
                {
                  modify ? <Fragment>
                    <Box css={styles.fileupload}>
                      <FileUpload1
                        files={files}
                        handleDelete={(i: number) => {
                          {
                            const update = [...files]
                            update.splice(i, 1)
                            setFiles(update);
                          }
                        }}
                        handleUpload={(e: React.ChangeEvent<HTMLInputElement>) => {
                          let upfile: any = e.target.files;
                          const update = [...files]
                          for (var i = 0; i < upfile.length; i++) {
                            update.push(upfile[i]);
                          }
                          setFiles(update)
                        }}
                        files1={data?.questAttachmentList}
                        handleDelete2={(attachmentId: string, i: number) => {
                          const update = [...deleteAttachFileList]
                          update.push({
                            attachmentId: attachmentId
                          })
                          setDeleteAttachFileList(update)
                          const update1 = [...data?.questAttachmentList]
                          update1.splice(i, 1)
                          setData({...data, questAttachmentList: update1})
                        }}
                      />
                    </Box>
                    <Stack direction="row" justifyContent={"center"} sx={{mb: "40px"}}>
                      <CustomButton label={'저장'} type={'modalBtn'} color={'primary'} onClick={() => {
                        modifyBoard()
                      }}/>
                    </Stack>
                  </Fragment> : <Fragment>
                    <Box css={styles.box_type}>
                      <Stack direction="row" alignItems="center" flexWrap="wrap">
                        <strong>첨부파일</strong>
                        <Stack className="flexmo" css={styles.btnDown}>
                          {
                            data?.questAttachmentList?.map((item: any, i: number) => (
                              // eslint-disable-next-line jsx-a11y/anchor-is-valid
                              <div key={i}>
                                <Button onClick={() => download(item.attachmentId)}>
                                  <span>{item.fileNm}</span>
                                </Button>
                              </div>
                            ))
                          }
                        </Stack>
                      </Stack>
                    </Box>
                    {data?.questSt == 'ANSWER' ?
                      <Box css={styles.qna_box}>
                        <dl>
                          <dt>답변</dt>
                          <dd>
                            {data && <p style={{whiteSpace: 'pre-line'}}>{data.answer}</p>}
                            <span className="date">
                        <span>{!!data ? !!data.answererNm ? data.answererNm : '' : ''}</span>
                        <span><em>{!!data ? !!data.answerUpdatedDt ? dayFormat(data.answerUpdatedDt) : '' : ''}</em></span>
                      </span>
                          </dd>
                        </dl>
                      </Box>
                      : ''}

                    {/* 수정삭제버튼추가 */}
                    <Stack direction="row" justifyContent="end" spacing={1} css={styles.fileBtn}>
                      <CustomButton label={'삭제'} type={'modalBtn'} color={'outlinedblack'} onClick={deleteBoard}/>
                      <CustomButton label={'수정'} type={'modalBtn'} color={'outlined'} onClick={() => {
                        window.scrollTo(0, 5)
                        setModifyContent(data?.question || '')
                        setModify(true)
                      }}/>
                    </Stack>
                  </Fragment>
                }
                <div css={styles.bottom_list}>
                  {Object.keys(pre).length !== 0 ?
                    <NavLink to='' onClick={() => {
                      setModify(false)
                      setQuestId(pre[0].questId);
                      setRowNum(rowNum - 1);
                    }}>
                      <div className="txt01">
                        <div className="prev">
                          다음글
                        </div>
                      </div>
                      <div className="txt02">
                        {pre[0].title}
                      </div>
                    </NavLink>
                    : null}
                  {Object.keys(next).length !== 0 ?
                    <NavLink to='' onClick={() => {
                      setModify(false)
                      setQuestId(next[0].questId);
                      setRowNum(rowNum + 1);
                    }}>
                      <div className="txt01">
                        <div className="next">
                          이전글
                        </div>
                      </div>
                      <div className="txt02">
                        {next[0].title}
                      </div>
                    </NavLink>
                    : null}
                </div>
                <Stack direction="row" justifyContent="center" css={styles.btnGroup}>
                  <CustomButton label={'목록'} type={'listBack'} color={'outlined'} onClick={() => {
                    navigate('/MyPage/UsageMmt/TreadmillMmt')
                  }}/>
                </Stack>
              </div>
            </div>
          </Box>
        </div>}
    </Banner>
  );
}
