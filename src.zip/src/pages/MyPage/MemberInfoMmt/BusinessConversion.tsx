import React, {useState, useEffect, Fragment, useRef} from 'react';
import * as styles from '~/styles/styles';
import Box from '@mui/material/Box';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import FormGroup from '@mui/material/FormGroup';
import {CustomButton} from '~/components/ButtonComponents';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import {useNavigate} from 'react-router-dom';
import {initProducerType, ProducerType, steps02, TermsResponse} from '~/models/Model';
import {CustomCheckBoxs} from '../../SignUp/Consumer/CustomCheckBoxs';
import {ConsumerModal} from '../../SignUp/Consumer/ConsumerModal';
import {fetchTermsGet, fetchTermsImsi} from '~/fetches';
import {ModalComponents} from '~/components/ModalComponents';
import BreadCrumb from "~/components/BreadCrumb";
import {CommonService} from '~/service/CommonService';
import create from 'zustand';
import authentication, {getMemberType} from 'shared/authentication';
import {useGlobalModalStore, useGlobalScroll} from '~/pages/store/GlobalModalStore';
import styled from '@emotion/styled';
import {TermCdimsiType} from '~/models/ModelSignin';
import {
  FetchAccountCertBzmn,
  FetchConversionBzmn,
  FetchreactAppPkiCertInitUrl,
  fetchTermsImsiBizChange
} from '~/fetches/fetchTerms';
import $ from "jquery";

/* 
  작성일    :   2022/06/14
  화면명    :   이페이지 -> 사용자지원 -> 사업자전환
  회면ID    :   UI-USP-FRN-0070101
  화면/개발 :   Seongeonjoo / navycui
  // 모바일 작업안됨 추후수정예정
*/

const _global = (window /* browser */ || global /* node */) as any

const BusinessReservation = () => {
  const tokenBox = authentication.get('accessToken');
  const navigate = useNavigate();
  const formValues: any = useRef(null);
  const [open, setOpen] = useState(false);
  const [open1, setOpen1] = useState(false);
  const [allCheck, setAllCheck] = useState(false);
  const [isValid, setIsValid] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [termsBox, setTermsBox] = useState<TermsResponse[]>([]);
  const [validationBox, setValidationBox] = useState<string[]>([]);
  const [ctx, setCtx] = useState<string>("");
  const [titx, setTitx] = useState<string>("");
  const [bizNm, setBizNm] = useState<ProducerType>(initProducerType);
  const returnedTarget: TermsResponse[] = [];
  const [termsConsentSesionId, setTermsConsentSesionId] = useState('')
  const {addModal} = useGlobalModalStore()

  // 약관 조회
  const getSearchCategory = async () => {
    const box = await Promise.all([fetchTermsGet('PRVC_CLCT_AGRE_BIZ')])
    box.map((item, key) => {
      if (!!item) {
        item.list.map((mbox: any) => {
          returnedTarget.push(mbox)
        })
      }
    })
    setTermsBox(returnedTarget)
  }; // todo...

  useEffect(() => {
    if (!!!authentication.getToken()) {
      navigate(`/signin?nextUrl=${window.btoa(window.location.href)}`)
    }
    // 사업자 회원 체크
    if (!!tokenBox) {
      if (typeof window != undefined) {
        const res = tokenBox.split('.')[1];
        const resBox = JSON.parse(window.atob(res))
        if (resBox.principal.memberType != 'UNIVERSITY' && resBox.principal.memberType != 'INDIVIDUAL' && resBox.principal.memberType != 'SOLE') {
          navigate('/MyPage/MemberInfoMmt/BusinessConversionSpool')
        } else {
          if (getMemberType() != 'SOLE') {
            getSearchCategory();
          }
          $("#pkiContainer").hide();
          window.addEventListener("message", receiveMessage, false);
        }
      }
    }
  }, []);

  // 사업 번호 입력
  const handelChangebizNm = (e: React.ChangeEvent<HTMLInputElement>) => {
    setBizNm({
      ...bizNm,
      [e.target.name]: e.target.value, error: false, label: "사업자등록번호"
    });
  }

  let objCert: any = {};

  // MagicLine JS 모듈 호출
  const doSignData = async () => {
    if (!!window) {
      let $form = $("form[name='reqForm']");
      $form.find("input[type='hidden'][name='bizrno']").val(bizNm.bizNum.toString());  // 사업자등록번호
      $form.find("input[type='hidden'][name='callback']").val('pkiCert');   // 콜백으로 받을 함수명

      $form.prop("method", "POST");
      $form.prop("target", "pki-frame");
      $form.prop("action", process.env.REACT_APP_PKI_CERT_URL);         // PKI Monolithic was 서버 공동인증서 페이지 URL

      $form.submit();
      $("#pkiContainer").show();
    }
    // await FetchreactAppPkiCertInitUrl().then((res) => {
    //   let uuid = res.uuid;
    //   let cert = res.cert;
    //
    //   // 버튼 활성화
    //   if (cert != undefined && cert != "") {
    //     objCert = JSON.parse(cert);
    //   } else {
    //     alert("공동인증서 모듈 초기화에 실패하였습니다.");
    //   }
    // }).catch((err) => {
    //   if (err.code != "ERR_NETWORK") {
    //     alert("공동인증서 초기화 호출에 오류가 발생되었습니다.");
    //   }
    // })
  }

  // 사업자 공동 인증 호출
  const handelProducerForm = () => {
    if (getMemberType() == 'SOLE') {
      doSignData()
    } else {
      const boxvalue3: any = [];
      setIsValid(false)
      let boxvalue = termsBox.filter((m) => {
        return m.required == true
      })
      let boxvalue2 = validationBox.filter((m) => {
        return m.includes("false")
      })
      if (((validationBox.length) - (boxvalue2.length)) < boxvalue.length) {
        setIsValid(true)
        return;
      }
      termsBox.map((item, key) => {
        // let isItem = validationBox.filter((m) => {
        //   return m.includes(key + "")
        // });
        // if (isItem.length > 0) {
        //   boxvalue3.push({beginDay: item.beginDay, required: item.required, termsType: item.termsType, consentYn: true})
        //   // setTermsImsiBox(boxvalue3);
        // }
        const validate = validationBox.find(f => f.includes(key.toString()))

        boxvalue3.push({beginDay:item.beginDay,required:item.required,termsType:item.termsType,consentYn: !!validate})
      })
      // 사업자등록번호 확인
      if (!bizNm.bizNum) {
        setBizNm({...bizNm, error: true, label: "사업자등록번호 필수입니다."})
        return;
      }
      if (isNaN(Number(bizNm.bizNum))) {
        setBizNm({...bizNm, error: true, label: "숫자만 입력하세요."})
        return;
      }

      fetchTermsImsi(boxvalue3).then((res) => {
        console.log('res - ' + JSON.stringify(res))
        if (!!res && res.key) {
          setTermsConsentSesionId(res.key)
          doSignData()
        }
        if ('isOk') {
          if ('isSeven') { // 탈퇴계정 전환안내(개인) UI-USP-FRN-0011602 호출
          } else { // out 7 day // 기가입 안내 (개인) UI-USP-FRN-0011601 -> 로그인
          }

        } else {
          // -> 3. 14미만 확인 이동
          navigate('signup/confirm', {
            state: {
              // loginId:loginId,
              chargerNm: '14 미만이다'
            }
          })
        }

      }).catch((e) => {
        console.log(e)
      });
    }
  }

  // 사업자회원 계정 인증(PRG-COM-AST-02)
  _global.pkiCert = (pkiCertSessionId: string) => {
    let jsonData = {
      termsConsentSessionId: termsConsentSesionId,
      pkiCertSessionId: pkiCertSessionId
    };

    FetchConversionBzmn(jsonData).then(data => {
        if (!!data) {
          console.log('conversion - ' + JSON.stringify(data))
          sessionStorage.setItem("__BIZ_JOIN_KEY__", data.key);
          // 가입여부
          if (data.duplicateYn) {
            if (data.secessionYn) { // 탈퇴계정 전환안내(개인) UI-USP-FRN-0011602 호출
              navigate('/signup/WithdrawPro', {
                state: {
                  key: data.key,
                  loginId: data.loginId,
                  chargerNm: data.chargerNm
                }
              })
            } else {
              navigate('/signup/exist', {
                state: {
                  loginId: data.loginId,
                  chargerNm: data.chargerNm
                }
              })
            }
          } else {
            navigate('/signup/producerform', {
              state: {
                type: getMemberType(),
                conversion: true
              }
            })
          }
          // niceResSave.mutate(data.key)
        }
      }
    ).catch((e) => {
      console.log(' e - ', e)
      let {data: {message, status}} = e.response;
      addModal({
        type: 'normal',
        open: true,
        content: message,
      })
    })
  }

  // iframe 으로부터 메시지 수신 이벤트 함수
  function receiveMessage(e: any) {
    if (!!e && e.data && typeof e.data == 'string') {
      let data = JSON.parse(e.data);
      //console.log(data);

      // iframe 숨김 처리
      $("#pkiContainer").hide();
      $("#pki-frame").prop("src", "about:blank");

      if (data.code == "0") {
        // 콜백 함수 실행
        new Function(`${data.funcNm}("${data.sessionKey}");`)();
      }
    }
  }

  return (
    <div css={styles.container} className="darkbg">
      <Box css={styles.sub_cont01}>
        <div className='benner'>
          <BreadCrumb/>
          <div className='content'>
            <div className='txtbox'>
              <h2 className='tit'>사업자로 전환</h2>
              <p>사업자로 전환하기 위해 법인회원 약관 동의하고<br className="mo"/> 공동인증서로 인증 후<br className="pc"/> 사업자 회원가입 <br
                className="mo"/>정보를 입력해 주세요.</p>
              <Stepper activeStep={0} alternativeLabel css={styles.step}>
                {steps02.map((label) => (
                  <Step key={label}>
                    <StepLabel>{label}</StepLabel>
                  </Step>
                ))}
              </Stepper>
            </div>
          </div>
        </div>
      </Box>
      <Box css={styles.sub_cont03}>
        <Box css={styles.line_box} sx={{mb: 5}}>
          <span>사업자로 전환후에도 기존 정보는 모두 그대로 유지됩니다. </span>
        </Box>
        {
          getMemberType() != 'SOLE' &&
          <Box sx={{mb: 5}}>
            <FormGroup sx={{mb: 2}}>
              <FormControlLabel
                sx={{ml: 0}}
                control={<CheckboxStyle
                  checked={allCheck}
                  onClick={(e: React.MouseEvent<HTMLButtonElement>) => {
                    setAllCheck(!allCheck)
                  }}/>} label="모든 약관에 동의합니다."/>
            </FormGroup>
            <FormGroup css={styles.listbox}>
              <CustomCheckBoxs
                checkbox={termsBox}
                isAll={allCheck}
                isValid={isValid}
                onClick={(s: string[]) => {
                  setValidationBox(s)
                  if (termsBox.length !== 0) {
                    setAllCheck((s.length) === (termsBox.length))
                  }
                }}
                modalOpen={(contents: string, titleText: string) => {
                  setCtx(contents)
                  setTitx(titleText)
                  setModalOpen(true);
                }}
              />
            </FormGroup>
          </Box>
        }
        <Box component="div"
             css={styles.singTextbox}>
          <div className='inputtxt'>
            사업자 확인
          </div>
          <Box component="div" css={styles.singform} className="mgno lable_center">
            <TextField
              required
              id="bizNum"
              name="bizNum"
              value={bizNm.bizNum}
              error={bizNm.error}
              label={bizNm.label} // "사업자등록번호"
              variant="filled"
              fullWidth
              onChange={handelChangebizNm}
            />
          </Box>
        </Box>
        <Stack direction="row" justifyContent="center" spacing={2} css={styles.btnGroup}>
          <CustomButton label={'취소'} type={'formbtn'} color={'outlinedgdark'} onClick={() => navigate('/')}/>
          <CustomButton label={'사업자 공동 인증'} type={'formbtn'} color={'primary'} onClick={handelProducerForm}/>
        </Stack>
        {/* 모달 팝업부분 */}
        <ConsumerModal isOpen={modalOpen} modalClose={() => {
          setModalOpen(false)
        }} ctx={ctx} titx={titx}/>
        <ModalComponents open={open} type={'normal'} title={"존재한정보"} content={"기가입 안내 (개인) UI-USP-FRN-001160"}
                         onConfirm={() => {
                           setOpen(false)
                         }}
                         onClose={() => {
                           setOpen(false)
                         }}>
        </ModalComponents>


        <form name="reqForm">
          <input type="hidden" id='bizrno' name='bizrno'/>
          <input type="hidden" id="callback" name="callback"/>
        </form>
        <div id="pkiContainer">
          <iframe
            id="pki-frame" name="pki-frame" src="" scrolling="no" width="100%" height="100%" frameBorder="0"
            style={{
              position: 'fixed',
              zIndex: 100010,
              top: 0, left: 0,
              width: '100%', height: '100%'
            }}>
          </iframe>
        </div>
      </Box>
      <ModalComponents open={open1} type={'normal'} title={"사업자 전환"} content={"공동인증 진행중..."}
                       onConfirm={() => {
                         setOpen1(false)
                       }}
                       onClose={() => {
                         setOpen1(false)
                       }}>
      </ModalComponents>
    </div>
  );
}
// 본인인증 서비스 결과 저장
export const useNiceStore = create((set) => ({
  fishies: '',
  setEncodeData: async (encodeData: any) => {
    const response = await CommonService.FetchNiceIdRes({encodeData: ""})
    set({fishies: await response.json()})
  },
}));

export default BusinessReservation;

const CheckboxStyle = styled(Checkbox)`
  &.MuiCheckbox-root {
    padding: 0;
    margin-right: 10px;
  }

  .MuiSvgIcon-root {
    width: 20px;
    height: 20px;
    background-color: #fff;
    border-radius: 4px;

    path {
      display: none;
    }
  }

  &:before {
    content: '';
    position: absolute;
    left: 50%;
    top: 50%;
    width: 20px;
    height: 20px;
    margin: -10px 0 0 -10px;
    border-radius: 3px;
  }

  &.Mui-checked {
    &:before {
      border: none;
      background-color: #4063ec;
      background: url('/images/common/checkbox_active.png');
    }

    .MuiSvgIcon-root {
      background: none;
    }
  }
`;