export { default } from './MyPage';
