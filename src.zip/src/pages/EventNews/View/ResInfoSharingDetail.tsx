// 참여이벤트/ ->  자원정보공유상세 페이지
// import React from "react"
import * as styles from '~/styles/styles';
import React, {useState, useEffect, Fragment} from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import dayjs from 'shared/libs/dayjs';
import {useNavigate, useLocation, NavLink} from 'react-router-dom';
import fetchDownload from '~/fetches/fetchDownload';
import {fetchAnnouncementDetail} from '~/fetches';
import {CustomButton} from '~/components/ButtonComponents';
import {fetchBoardPreNext} from "./../../../fetches/fetchBoard";
import {useGlobalModalStore} from "./../../store/GlobalModalStore";
import {ModalComponents} from '~/components/ModalComponents';
import {Banner} from '~/components/Banner';
import {
  fetchAnnouncementDelete,
  fetchAnnouncementFiles,
  fetchAnnouncementFilesDelete,
  fetchAnnouncementModify
} from "~/fetches/fetchAnnouncement";
import {
  fetchOneByOneFiles,
  fetchOneByOneFilesDelete,
  fetchOneByOneMmtDelete,
  fetchOneByOneMmtModify
} from "~/fetches/fetchQnaQuest";
import {TextField} from "@mui/material";
import {FileUpload1} from "~/pages/EventNews/FileUpload";
import authentication, {getUserNm} from "shared/authentication";

function ResInfoSharingDetail() {
  const [open, setOpen] = useState(false);
  const [error, setError] = useState("");
  const {addModal} = useGlobalModalStore();
  const navigate = useNavigate();
  const receive: any = useLocation();
  const [articleId, setArticleId] = useState(receive?.state?.item?.articleId);
  const [data, setData]: any = useState([]);
  const [data1, setData1]: any = useState([]);
  const [boardId] = useState(receive?.state?.item?.boardId);
  const [title] = useState(receive?.state?.articleSrchWord)
  const [loading, setLoading] = useState(true)

  const [modify, setModify] = useState(false)
  const [modifyContent, setModifyContent] = useState('')

  const [files, setFiles]: any = useState([])
  const [deleteAttachFileList, setDeleteAttachFileList]: any = useState([])

  const params = {
    boardId: boardId,
    articleId: articleId,
    posting: true,
    title: title,
  }

  const detailParams = {
    boardId: boardId,
    articleId: articleId,
  }

  const getData = () => {
    setLoading(true)
    fetchAnnouncementDetail(detailParams).then((res: any) => {
      setData(res);
      // fetchAnnouncementFiles(detailParams).then((res) => {
      //   console.log('res - ' + JSON.stringify(res))
      // })
      setLoading(false)
    }).catch((e) => {
      setOpen(true);
      setError(e.response.data.message)
    });

  }
  const getPreNext = () => {
    fetchBoardPreNext(params).then((res: any) => {
      setData1(res);
    })
  }
  useEffect(() => {
    getPreNext();
    getData();
  }, [articleId])

  const attachmentList = data.attachmentList;

  const download = async (attachmentId: any) => {
    fetchDownload(`${process.env.REACT_APP_DOMAIN_COMMON_BNET}/common/api/boards/${process.env.REACT_APP_USP_NOTICE}/articles/${articleId}/attachments/${attachmentId}`)
      .then()
      .catch((e) => {
        let status = e.response.status;
        console.log(status);

        if (status === 400) {
          setOpen(true);
          setError("파일이 없습니다.")
        }
      });
  }

  const deleteBoard = async () => {
    const res = await fetchAnnouncementDelete(detailParams).then((e) => {
      addModal({
        open: true,
        content: '게시글이 삭제되었습니다.',
        onClose: () => {
          navigate('/EventNews/ResInfoSharing')
        },
        onConfirm: () => {
          navigate('/EventNews/ResInfoSharing')
        }
      })
    }).catch((e) => {
      addModal({
        open: true,
        content: e.response.data.message,
      })
    })
  }
  const deleteAttachment = async () => {
    let count = deleteAttachFileList.length
    try {
      while (count > 0) {
        const attachmentId = deleteAttachFileList[count - 1].attachmentId
        await fetchAnnouncementFilesDelete(detailParams, attachmentId)
        count -= 1
      }
      addModal({
        open: true,
        content: '게시글이 수정 되었습니다.',
        onClose: () => {
          getData()
        },
        onConfirm: () => {
          getData()
        }
      })
      setModify(false)
      setFiles([])
      setDeleteAttachFileList([])
    }catch(e: any) {
      addModal({
        open: true,
        content: e.response.data.message,
        onClose: () => {
          getData()
        },
        onConfirm: () => {
          getData()
        }
      })

      setModify(false)
      setFiles([])
      setDeleteAttachFileList([])
    }
  }

  const modifyBoard = async () => {
    if (modifyContent == data?.question && files.length == 0) {
      addModal({
        open: true,
        content: '변경 사항이 없습니다.',
      })
      setModify(false)
      // setFiles([])
      return;
    }

    if (modifyContent != data?.question || files.length != 0) {
      const form = new FormData();
      form.append("article", new Blob([JSON.stringify({
        ...data,
        article: modifyContent,
      })], {type: "application/json"}));

      for (let i = 0; i < files.length; i++) {
        form.append("attachment", files[i])
      }

      const res = await fetchAnnouncementModify(detailParams, form).then((e) => {
        addModal({
          open: true,
          content: '게시글이 수정 되었습니다.',
          onClose: () => {
            getData()
          },
          onConfirm: () => {
            getData()
          }
        })
        setModify(false)
        setFiles([])
      }).catch((e) => {
        addModal({
          open: true,
          content: e.response.data.message,
        })

        setModify(false)
        setFiles([])
      })
    }

    if (deleteAttachFileList.length > 0) {
      await deleteAttachment()
    }
  }

  console.log('authentication.getUser() - ' + authentication.getUserNm())

  return (
    <Banner
      title={'자원정보공유'}
      summary={<p>AI 관련 사업에 대한 업계 소식이나 개선 및 보완이 필요한 부분에 대한 의견을 남겨주세요<br className="pc"/> 사업이나 프로젝트를 진행하면서 필요한 도움이나 자원에
        대한 의견을 남겨 주시면 참고하여 더 나은 사업을 준비하겠습니다</p>}
      loading={loading}>
      <div css={styles.container}>
        <ModalComponents
          open={open} type={'normal'} content={error}
          onConfirm={() => {
            setOpen(false)
          }}
          onClose={() => {
            setOpen(false)
          }}>
        </ModalComponents>
        <Box css={styles.sub_cont02}>
          {/* 상세 list 리스트 */}
          <div css={styles.detal_list}>
            <div className="content">
              {/* 텍스트 상단 */}
              <Box css={styles.detal_txtBox}>
                <Typography variant="h5" component="div">
                  {data.title}
                </Typography>
                <div className="date">
                  <span>조회 <em>{data.readCnt}</em></span>
                  <span><em className="ml0">{dayjs(data.updatedDt).format('YYYY-MM-DD')}</em></span>
                  <span><em className="ml0">{data.updaterNm}</em></span>
                  {/* 작성자영역추가 */}
                </div>
              </Box>

              {
                modify ? <Box css={styles.inputBox} sx={{paddingTop: '20px'}}>
                  <TextField
                    id="outlined-multiline-static"
                    className="scrollBox"
                    multiline
                    rows={6}
                    value={modifyContent}
                    onChange={(e) => {
                      setModifyContent(e.target.value)
                    }}
                    inputProps={{
                      maxLength: 1000,
                    }}
                  />
                  <span className="count"><em>{modifyContent.length}</em>/1000</span>
                </Box> : <Box css={styles.detal_img}><Typography color="text.secondary" className="txt_box">
                  <p style={{whiteSpace: 'pre-line'}}>{data.article}</p>
                </Typography>
                </Box>
              }
            </div>

            {/*<div className="content">*/}
            {
              modify ? <Fragment>
                <Box css={styles.fileupload}>
                  <FileUpload1
                    files={files}
                    handleDelete={(i: number) => {
                      const update = [...files]
                      update.splice(i, 1)
                      setFiles(update);
                    }}
                    handleUpload={(e: React.ChangeEvent<HTMLInputElement>) => {
                      let upfile: any = e.target.files;
                      const update = [...files]
                      for (var i = 0; i < upfile.length; i++) {
                        update.push(upfile[i]);
                      }
                      setFiles(update)
                    }}
                    files1={data?.attachmentList}
                    handleDelete2={(attachmentId: string, i: number) => {
                      const update = [...deleteAttachFileList]
                      update.push({
                        attachmentId: attachmentId
                      })
                      setDeleteAttachFileList(update)
                      const update1 = [...data?.attachmentList]
                      update1.splice(i, 1)
                      setData({...data, attachmentList: update1})
                    }}
                  />
                </Box>
                <Stack direction="row" justifyContent={"center"} sx={{mb: "40px"}}>
                  <CustomButton label={'저장'} type={'modalBtn'} color={'primary'} onClick={() => {
                    modifyBoard()
                  }}/>
                </Stack>
              </Fragment> : <Fragment>
                <Box css={styles.box_type}>
                  <Stack direction="row" alignItems="center" flexWrap="wrap">
                    <strong>첨부파일</strong>
                    {!!attachmentList
                      ? attachmentList.map((item: any, i: number) => (
                        <Stack className="flexmo" css={styles.btnDown}>
                          <div key={i}>
                            <Button onClick={() => download(item.attachmentId)}>
                              <span>{item.fileNm}</span>
                            </Button>
                          </div>
                        </Stack>
                      ))
                      : (
                        <div className="filenone">첨부파일 없습니다.</div>
                      )}
                  </Stack>
                </Box>
                {/* 수정삭제버튼추가 */}
                {
                  authentication.getUserNm() == data.updaterNm &&
                  <Stack direction="row" justifyContent="end" spacing={1} css={styles.fileBtn}>
                  <CustomButton label={'삭제'} type={'modalBtn'} color={'outlinedblack'} onClick={deleteBoard}/>
                  <CustomButton label={'수정'} type={'modalBtn'} color={'outlined'} onClick={() => {
                    window.scrollTo(0, 5)
                    setModifyContent(data?.article || '')
                    setModify(true)
                  }}/>
                </Stack>
                }
              </Fragment>
            }
            <div css={styles.bottom_list}>
              {data1.prevArticleId ?
                <NavLink to='' onClick={() => {
                  setModify(false)
                  setArticleId(data1.prevArticleId)
                }}>
                  <div className="txt01">
                    <div className="prev">
                      이전글
                    </div>
                  </div>
                  <div className="txt02">
                    {data1.prevTitle}
                  </div>
                </NavLink>
                : null}
              {data1.nextArticleId ?
                <NavLink to='' onClick={() => {
                  setModify(false)
                  setArticleId(data1.nextArticleId)
                }}>
                  <div className="txt01">
                    <div className="next">
                      다음글
                    </div>
                  </div>
                  <div className="txt02">
                    {data1.nextTitle}
                  </div>
                </NavLink>
                : null}
            </div>
            <Stack direction="row" justifyContent="center" css={styles.btnGroup}>
              <CustomButton label={'목록'} type={'listBack'} color={'outlined'} onClick={() => {
                navigate('/EventNews/ResInfoSharing')
              }}/>
            </Stack>
            {/*</div>*/}
          </div>
        </Box>
      </div>
    </Banner>
  );
}

export default ResInfoSharingDetail;
