export { default } from './HonsaEventDetail';
//
