import * as styles from '~/styles/styles';
import React, {useState, useRef, useEffect} from 'react';
import {Box, TextField, Stack, useMediaQuery, useTheme} from '@mui/material';
import {CustomButton} from '~/components/ButtonComponents';
import {useNavigate} from "react-router-dom";
import {fetchGetCommCode, fetchQnaQuest} from '~/fetches';
import {FileUpload} from "./FileUpload";
import {intialErrorCategoryCd, intialErrorQuestion, intialErrorTitle, intialInputValues} from "~/models/ModelTreadmill";
import {CustomSelect} from '~/components/SelectBoxComponents';
import {ModalComponents} from '~/components/ModalComponents';
import authentication from '~/../../shared/src/authentication';
import {useScrollStore} from "shared/store/ScrollStore";
import {Banner} from '~/components/Banner';
import {useQueries, useQuery} from "react-query";
import {useGlobalModalStore} from "~/pages/store/GlobalModalStore";
import {fetchQnAAccept} from "~/fetches/fetchGetCommCode";
import {Color} from "shared/components/StyleUtils";

function Treadmill() {
  const [open, setOpen] = useState(false);
  const [error, setError] = useState("");
  const {addModal} = useGlobalModalStore();
  const theme = useTheme();
  const {scrollDirection, isContraction} = useScrollStore()
  const navigate = useNavigate();
  const titleInput: any = useRef("");
  const questionInput: any = useRef("");
  const [title, setTitle] = useState("");
  const [question, setQuestion] = useState("");
  const [categoryCd, setCategoryCd] = useState("CATE-STEP-01");
  const [files, setFiles]: any = useState([]);
  const [categoryCdError, setCategoryCdError] = useState(intialErrorCategoryCd);
  const [titleError, setTitleError] = useState(intialErrorTitle);
  const [questionError, setQuestionError] = useState(intialErrorQuestion);
  const [qnaQuest, setQnaQuest] = useState(intialInputValues);
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [loading, setLoading] = useState(true);
  const [acceptValue, setAcceptValue] = useState('*.*')

  const changeTitle = () => {
    setTitle(titleInput.current.value);
  }
  const changeQuestion = () => {
    setQuestion(questionInput.current.value);
  }

  useEffect(() => {
    if (!!!authentication.getToken()) {
      addModal({
        open: true,
        content: '로그인이 필요한 서비스입니다.',
        onConfirm: () => {
          const domain = process.env.REACT_APP_SSO_CHECK_PATH
          window.location.href = `${domain}?nextUrl=${window.btoa(window.location.href)}`
        },
        onClose: () => {
          const domain = process.env.REACT_APP_SSO_CHECK_PATH
          window.location.href = `${domain}?nextUrl=${window.btoa(window.location.href)}`
        }
      })
    }
  }, [])

  useEffect(() => {
    setQnaQuest({
      categoryCd: categoryCd,
      title: title,
      question: question,
    })
  }, [categoryCd, title, question])

  // 공통코드 조회
  const userQueries: any = useQueries(
    [
      'CATEGORY_STEP',    // 디딤널 문의게시판
    ].map(TermsType => {
      return {
        queryKey: [TermsType],
        queryFn: () => fetchGetCommCode(TermsType),
      }
    })
  )

  const accept = useQuery('accept', () => fetchQnAAccept('step-flat'))

  useEffect(() => {
    if (!accept.isLoading && !accept.isFetching) {
        // setAcceptValue(accept.data.atchmnflExtsnSet)
        if (accept.data.atchmnflExtsnSet && accept.data.atchmnflExtsnSet.length > 0) {
          if (accept.data.atchmnflExtsnSet != '*.*') {
            setAcceptValue('.'.concat(accept.data.atchmnflExtsnSet.replaceAll('/', ',.')))
          }
        }
      }
  }, [accept.data, accept.isLoading, accept.isFetching])

  const send = (event: any) => {
    if (!validate(event, qnaQuest)) {
      return;
    }
    try {
      const form = new FormData();
      console.log('qnaQuest - ' + JSON.stringify(qnaQuest))
      form.append("qnaQuest", new Blob([JSON.stringify(qnaQuest)], {type: "application/json"}));
      for (let i = 0; i < files.length; i++) {
        form.append("file", files[i])
      }

      fetchQnaQuest(form, `${process.env.REACT_APP_STEP_FLAT}`).then(() => {
        return navigate('../MyPage/UsageMmt/TreadmillMmt');
      }).catch((e) => {
        setOpen(true);
        if (e.response.data.message == 'errors') {
          setError(e.response.data.errors.at(0)?.message)
        } else {
          setError(e.response.data.message)
        }
      });
      // .catch((e)=>{
      //   addModal({
      //     open: true,
      //     content: e.response.data.message
      //   });
      // })
    } catch (e: any) {
      if (!!e.response && e.response.data) return alert(e.response.data.message);
    }

  }

  const validate = (event: any, qnaQuest: any) => {
    let check = true;
    //문의구분 확인
    if (qnaQuest.categoryCd === "") {
      setCategoryCdError({
        errorCategoryCd: true, helperCategoryCd: "문의구분을 선택하세요"
      });
      check = false;
    } else {
      setCategoryCdError({
        errorCategoryCd: false, helperCategoryCd: ""
      });
      check = true;
    }
    //제목 확인
    if (qnaQuest.title === "") {
      setTitleError({
        errorTitle: true, helperTitle: "제목을 입력하세요"
      })
      check = false;
    } else {
      setTitleError({
        errorTitle: false, helperTitle: ""
      })
      check = true;
    }
    //문의내용 확인
    if (qnaQuest.question === "") {
      setQuestionError({
        errorQuestion: true, helperQuestion: "문의내용을 입력하세요"
      })
      check = false;
    } else {
      setQuestionError({
        errorQuestion: false, helperQuestion: ""
      })
      check = true;
    }
    return check;
  }
  const handleDelete = (i: number) => {
    const update = [...files]
    update.splice(i, 1)
    setFiles(update);
  };

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    let upfile: any = e.target.files;
    const update = [...files]
    for (var i = 0; i < upfile.length; i++) {
      update.push(upfile[i]);
    }
    setFiles(update)
  }

  const goEventNews = () => {
    navigate('/EventNews');
  };
  return (
    <Banner
      title={'디딤널 문의 작성'}
      summary={<p>AICA에게서 바라는 점이나 제안하고 싶은 내용을 접수하는<br className="mo"/> 곳입니다.<br className="pc"/> 구인 및 구직 뿐만 아니라<br
        className="mo"/> 사업제안, AI 관련 사업에 필요한 도움을 전달하실 수 있습니다.</p>}
    >
      <div css={styles.container}>
        <ModalComponents open={open} type={'normal'} content={error}
                         onConfirm={() => {
                           setOpen(false)
                         }}
                         onClose={() => {
                           setOpen(false)
                         }}>
        </ModalComponents>
        <Box css={styles.sub_cont02}>
          {/* 상세 list 리스트 */}
          <div className="content">
            <div css={styles.detal_list}>
              <Box css={styles.inputBox}>
                <div className="inputtxt">문의구분<em>*</em></div>
                <div className='selbox'>
                  {
                    userQueries[0].status === 'success' && <CustomSelect
                      value={categoryCd}
                      data={userQueries[0].data?.list || []}
                      onClick={(selected) => {
                        setCategoryCd(selected)
                      }}
                    />}
                </div>
              </Box>
              <Box css={styles.inputBox}>
                <div className="inputtxt">제목<em>*</em></div>
                <TextField
                  id="name"
                  variant="outlined"
                  fullWidth
                  onChange={changeTitle}
                  inputRef={titleInput}
                  error={titleError.errorTitle}
                  helperText={titleError.helperTitle}
                />
              </Box>
              <Box css={styles.inputBox}>
                <div className="inputtxt">문의내용<em>*</em></div>
                <TextField
                  id="outlined-multiline-static"
                  className="scrollBox"
                  multiline
                  rows={4}
                  onChange={changeQuestion}
                  inputRef={questionInput}
                  error={questionError.errorQuestion}
                  helperText={questionError.helperQuestion}
                  inputProps={{
                    maxLength: 1000,
                  }}
                />
                <span className="count"><em>{question.length}</em>/1000</span>
              </Box>
              {/* 답변받을 이메일 부분 화면설계서에서 삭제 */}
              {/* <Box css={styles.inputBox}>
                <div className="inputtxt">답변받을 이메일<em>*</em></div>
                <TextField
                  id="name" 
                  variant="outlined"
                  fullWidth
                />
              </Box> */}
              <Box css={styles.inputBox}>
                <Stack direction={"row"} alignItems={'center'} spacing={'10px'}>
                  <div className="inputtxt">파일첨부</div>
                  <Box sx={{color: Color.textGray, fontSize: '14px'}} style={{marginBottom: '10px'}}>
                    {`가능 확장자 (${acceptValue.replaceAll(',', ', ').toLowerCase()})`}
                  </Box>
                </Stack>
                <FileUpload
                  files={files}
                  accept={acceptValue}
                  handleDelete={handleDelete}
                  handleUpload={handleUpload}
                />
              </Box>
              <hr className="m20"/>
              <Stack direction="row" justifyContent="center" spacing={2} css={styles.btnGroup}>
                <CustomButton label={'취소'} type={'listBack'} color={'outlinedblack'} onClick={() => goEventNews()}/>
                <CustomButton label={'저장'} type={'listBack'} color={'primary'} onClick={send}/>
              </Stack>
            </div>
          </div>
        </Box>
      </div>
    </Banner>
  );


}

export default Treadmill;
