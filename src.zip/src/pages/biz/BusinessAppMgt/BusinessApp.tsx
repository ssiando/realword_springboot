// 사업신청/menu-PMS010100 -> 사업신청
import {Fragment, useEffect} from "react"
import {useState} from 'react';
import * as styles from './styles';
import Box from '@mui/material/Box';
import {Stack, Step, Stepper, StepLabel} from '@mui/material';
import {CustomButton, CustomRadioButtons} from '~/components/ButtonComponents';
import {business_request} from '~/models/Model';
import fetchBusiness from "~/fetches/fetchBusiness";
import {useGlobalModalStore} from "~/pages/store/GlobalModalStore";
import {NavLink, useLocation, useNavigate} from "react-router-dom";
import {ModalComponents} from '~/components/ModalComponents';
import {Banner} from "~/components/Banner";

/*
  작성일    :   2022/06/22
  화면명    :   사업신청
  회면ID    :   UI-USP-FRN-0130101
  프로그램ID:   사업신청 필수확인사항 조회 (PRG-USP-SPA-01)
  화면/개발 :   Seongeonjoo / seok
*/

function BusinessApp() {
  const navigate = useNavigate();
  const receive: any = useLocation();
  const {addModal} = useGlobalModalStore();
  const [open, setOpen] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true)
  //체크리스트 항목
  const [checkList, setCheckList]: any = useState([]);
  const [applyCheck, setApplyCheck] = useState(0);
  //내가 체크한 리스트
  const [chkList, setChkList] = useState<any[]>([]);

  // 체크리스트 필수 항목 조회
  const getList = async () => {
    setLoading(true)
    await fetchBusiness(receive.state.pblancId).then((res: any) => {
      setCheckList(res.list)
      if (!!receive.state.chkList) {
        setChkList(receive.state.chkList)
      } else {
        setChkList(res.list.map((item: any) => {
          return {
            chklstId: item.chklstId,
            ceckResultDivCd: 'Y'
          }
        }));
      }
      setLoading(false)
    }).catch((e) => {
      // setOpen(true);
      // setError(e.response.data.message)
      let {message, status} = e.response.data;
      addModal({
        type: 'normal',
        open: true,
        content: message,
        onConfirm: () => {
          switch (status) {
            case 401:
              const domain = process.env.REACT_APP_SSO_CHECK_PATH
              window.location.href = `${domain}?nextUrl=${window.btoa(window.location.href)}`
              break;
            default:
              navigate('/Notice/Notice')
              break;
          }
        },
      })
      setApplyCheck(1);
      setLoading(false)
    })
  }

  useEffect(() => {
    if (!!receive.state) {
      getList();
    }else {
      navigate('/Notice/Notice')
    }
  }, [])

  return (
    <Banner
      title={'사업 신청'}
      summaryStep={
        <Stepper activeStep={0} alternativeLabel className="step02">
          {business_request.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
      }
    >
      <div css={styles.container}>
        <ModalComponents open={open} type={'normal'} content={error}
                         onConfirm={() => {
                           setOpen(false);
                           navigate(-1);
                         }}
                         onClose={() => {
                           setOpen(false);
                           navigate(-1);
                         }}>
        </ModalComponents>
        <Box className='content_body02'>
          <div className="content">
            <h1 className="sub_title_top">{!!receive.state ? receive.state.pblancNm : ''}</h1>
            <Box className="box_guide">
              <ul>
                <li>필수확인사항을 꼼꼼하게 확인한 후 해당 부분에 체크하시기 바랍니다.</li>
                <li>아니오 선택 시 심사 및 선정에 제한이 있을 수 있으며, 아래 사항을 제대로 검토하지 않음으로 발생하는 불이익에 대한 책임은 전적으로 지원자에게 있습니다.</li>
                <li><span className="must">*</span> 표시는 필수입력 항목입니다.</li>
              </ul>
            </Box>

            {
              checkList && checkList.length > 0 && <Fragment>
                <h4 className="sub_title">필수확인사항 <span className="must">*</span></h4>
                <Box css={styles.table2}>
                  <div className="detail_table">
                    <dl className="header">
                      <dt className="num">번호</dt>
                      <dt className="tac">체크사항</dt>
                      <dt className="check">체크</dt>
                    </dl>
                    {
                      checkList.map((item: any, i: number) => (
                        <dl key={i}>
                          <dd className="num">{i + 1}</dd>
                          <dd className="cnt">
                            <p>{item.chklstCn}</p>
                            <dd className="check">
                              <CustomRadioButtons
                                row data={[{codeNm: '예', code: '예'}, {codeNm: '아니오', code: '아니오'}]}
                                defaultData={
                                  chkList[i]?.ceckResultDivCd == 'Y' ? '예' : '아니오'}
                                onClick={(selected) => {
                                  setChkList(chkList.map((m, j) => {
                                    const result = i == j ? selected == '예' ? 'Y' : 'N' : m.ceckResultDivCd
                                    return {
                                      ...m,
                                      ceckResultDivCd: result
                                    }
                                  }));
                                }}
                              /></dd>
                          </dd>
                        </dl>
                      ))}
                  </div>
                </Box>
              </Fragment>
            }

            <Stack direction="row" justifyContent="center" sx={{marginTop: '40px'}} css={styles.btn_next}>
              <NavLink
                to={`/biz/BusinessAppMgt/BusinessAppInfo/${!!receive.state ? receive.state.pblancId : ''}`}
                state={{
                  ...receive.state,
                  chkList: chkList,
                  pblancId: !!receive.state ? receive.state.pblancId : '',
                  title: !!receive.state ? receive.state.pblancNm : ''
                }}
              >
                <CustomButton label={'다음'} type={'listBack'} color={'primary'}/>
              </NavLink>
            </Stack>
          </div>
        </Box>
      </div>
    </Banner>
  );
}

export default BusinessApp;