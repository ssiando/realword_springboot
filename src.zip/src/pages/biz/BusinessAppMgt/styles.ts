import { css } from '@emotion/react';
export const container = css`
  padding-bottom: 120px;
  .content {
    position: relative;
    max-width: 1280px;
    width: 100%;
    margin: 0 auto;
  }
  .txtblue {
    color: #4063ec;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    margin-top: 0;
    padding-bottom: 80px;
  }
`;

export const title_set = css`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin-top: 50px;
  @media (min-width: 320px) and (max-width: 768px) {
    flex-direction:column;
    .tbl_desc {margin-bottom:10px;}
  }
`;

export const tagstyle = css`
  position: relative;
  justify-content: space-between;
  width: 100%;
  margin-bottom: 10px;
  .MuiChip-root {
    margin-left: 10px;
    border-radius: 5px;
    &:first-of-type {
      margin-left: 0;
    }
  }
  .wh {
    background-color: #fff;
    color: #333;
  }
  .blue {
    background-color: #4063ec;
    color: #fff;
  }
  .green {
    background-color: #1ccdcc;
    color: #fff;
  }
`;


export const sub_cont02 = css`
  //min-height: 840px;
  background-color: #fff;
  color: #333;
  .MuiTypography-h5 {
    height: auto;
    font-family: Noto Sans CJK KR;
    font-size: 28px;
    font-weight: 700;
    line-height: 1;
    letter-spacing: -1.12px;
    margin-bottom: 20px;
  }
  .md_btn {
    color: #333;
    border: 1px solid #333;
    width: 220px;
    height: 55px;
    border-radius: 0;
    margin-top: 10px;
  }
  .data {
    display: inline-block;
    height: 24px;
    font-size: 16px;
    font-style: normal;
    font-weight: 400;
    line-height: 3;
    letter-spacing: -4px;
    margin-left: 10px;
    
    > em {
      height: 19px;
      font-size: 16px;
      font-weight: 700;
      letter-spacing: -0.64px;
      color: #4063ec;
    }
  }
  .MuiSelect-select {
    padding: 8px 40px 8px 20px;
    margin-right: 10px;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .MuiTypography-h5 {
      font-size: 22px;
      margin-bottom: 10px;
    }
    .MuiSelect-select {
      font-size: 14px;
    }
  }
`;


export const table05 = css`
  max-width: 100%;
  letter-spacing: -0.64px;
  margin-top: 24px;
  .MuiTypography-h6{
    font-size: 18px;
    margin-bottom: 15px;
  }
  .detail_table{
    border-top: 1px solid #1f2437;
  }
  dl {
    display: flex;
    border-spacing: 0;
    width: 100%;
    & .noline{
      border-bottom: none;
    }
    dt {
      display: flex;
      align-items: center;
      flex: 0 0 156px;
      padding: 16px 20px;
      text-align: left;
      background-color: #f5f5f5;
      border-bottom: 1px solid #e0e0e0;
      &.wh{
        background-color: #fff;
      }
    }
    dd {
      flex: 1;
      display: flex;
      justify-content: space-between;
      padding: 6px 8px;
      line-height: 1.75;
      align-items: center;
      border-bottom: 1px solid #e0e0e0;
      margin-left: 0;
      font-weight: 400;
      .MuiInputBase-input-MuiOutlinedInput-input{
        padding: 12px 14px;
      }
      .MuiOutlinedInput-root{
        min-height: 48px;
        .MuiOutlinedInput-input{
          height: auto;
          padding: 12px 14px;
        }
      }
      > span{
        &.ml8{
          margin-left: 8px;
        }
      }
      
      p{
        &:first-of-type{margin-top:0;}
        margin-top: 16px;
      }
    }
  }
  .MuiInputBase-root-MuiOutlinedInput-root.Mui-disabled{
    color: #ccc;
    background-color: #f5f5f5;
  }
  
  @media (min-width: 320px) and (max-width: 768px) {
    .MuiTypography-h6{
      font-size: 16px;
      margin-bottom: 10px;
    }
    dl {
      flex-wrap: wrap;
      dt {
        flex: 0 0 35%;
        padding: 15px 18px;
        font-size: 14px;
      }
      dd {
        flex: 0 0 65%;
        padding: 6px 8px;
        font-size: 14px;
      }
    }
  }
`;


// 버튼속성그룹
export const btnGroup = css`
  justify-content: center;
  margin-top: 60px;
  > button {
    height: 60px;
    border-radius: 40px;
    width: 220px;
    font-size: 18px;
    font-weight: 700;
    line-height: 1.5;
    background-color: #fff;
    padding: 17px 36px;
    &.blue {
      background-color: #4063ec;
      width: 100%;
      color: #fff;
    }
    &.linebtn {
      border: 1px solid #4063ec;
      background-color: #fff;
      &.mini {
        width: 140px;
      }
    }
    &.linebtn02 {
      border: 1px solid #222;
      color: #222;
      background-color: #fff;
    }
    &.blue02 {
      background-color: #4063ec;
      color: #fff;
      min-width: 140px;
      width: auto;
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    > button {
      font-size: 16px !important; 
      &.blue02 {
        width: 100%;
        height: 52px;
      }
    }
  }
`;

// 더보기 버튼 컴포넌트랑 같이
export const bottom_btn = css`
  button{
    &:after {
      content: '';
      background: url('/images/common/arr_row.png') no-repeat;
      width: 12px;
      height: 8px;
      margin-left: 10px;
    }
  }
`;

export const picker_card = css`
  display: flex;
  max-width: 780px;
  margin: 20px auto 0;
  background-color: #fff;
  border-radius: 10px;
  border: solid 1px #e0e0e0;
  color: #333;
  text-align: center;
  dl {
    border-right: 1px solid #e0e0e0;
    width: 100%;
    &:last-of-type{
      border: none;
      dd{
        .MuiFormGroup-root{
          margin-bottom: -10px;
        }
      }
    }
    dt{
      border-bottom: 1px solid #e0e0e0;
      font-size: 18px;
      padding: 14px 0;
      font-weight: 700;
      letter-spacing: -0.72px;
    }
    dd{
      text-align: center;
      margin-left: 0;
      display: inline-block;
      padding: 6px;
      width: 100%;
      .box_scroll{
        padding: 14px;
        max-height: 120px;
        overflow-y: auto;
        &::-webkit-scrollbar {
          width: 6px;
        }
        &::-webkit-scrollbar-track {
          background-color: transparent;
        }
        &::-webkit-scrollbar-thumb {
          background-color: #d7dae6;
          border-radius: 10px;
        }
        &::-webkit-scrollbar-button {
          width: 0;
          height: 0;
        }
      }
      .MuiFormControl-root{
        width: 100%;
        .MuiFormControlLabel-root{
          flex: 0 0 48%;
          margin: 0;
          margin-bottom: 10px;
          &:nth-of-type(2n){padding-left:20px;}
          /* &:nth-last-of-type(-n + 2){
            margin-bottom: 0;
          } */
        }
      }
      .MuiInputBase-root{
        height: 48px;
      }
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    border: none;
    flex-direction: column;
    .MuiInputBase-root{
      height: 46px;
    }
    dl {
      border: none;
      dt{
        border-bottom: none;
        font-size: 16px;
        padding: 10px 0;
        text-align: left;
      }
      dd{
        padding: 16px 0 0;
        margin-bottom: 16px;
      }
    }
  }
`;


export const inputBox = css`
  position: relative;
  display: flex;
  flex-direction: row;
  .inputtxt{
    font-family: Noto Sans CJK KR;
    font-size: 18px;
    margin-bottom: 10px;
    line-height: 1.67;
    letter-spacing: -0.72px;
    font-weight: 700;
    & em{
      color: #1ccdcc;
      margin-left: 4px;
    }
  }
  label{
    color: #222;
    &.Mui-focused {
      color: #222;
    }
  }
  .MuiFormControl-root {margin-left:8px;}
  .MuiSelect-select {padding-top: 13px;padding-bottom: 12px;}
  .MuiOutlinedInput-root {
    color: #222;
    fieldset {
      border-color: #ccc;
    }
    &.Mui-disabled{
      background-color: #f5f5f5;
      color: #ccc;
    }
    &:hover{
      fieldset {
        border-color: #1976d2;
      }
    }
  }
  .MuiFormLabel-asterisk{
    color: #1CCDCC;
  }
  textarea{
    &::-webkit-scrollbar {
      width: 5px;
    }
    &::-webkit-scrollbar-thumb {
      background-color: #d7dae6;
      border-radius: 10px;
    }
    &::-webkit-scrollbar-track {
      background-color: #fff;
      border-radius: 10px;
    }
    > div {
      margin-bottom: 10px;
    }
    .MuiRadio-root {
      padding: 5px;
    }
    .MuiFormControlLabel-root{
      margin-right: 0;
      margin-bottom: 10px;
      padding-left: 5px;
    }
  }
  .count{
    margin-top: 8px;
    text-align: right;
    font-size: 14px;
    color: #666;
  }
  Button{
    margin: 0;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    flex-direction:column;
    .MuiFormControl-root {
      width:100%;
      margin-left:0;
      padding:8px 0;
      .MuiOutlinedInput-root{
        width:100%;
        &:nth-of-type(2){margin-top:8px;}
      }
    }
    label{
      font-size: 14px;
    }
    input {
      padding: 15px 14px;
    }
    .inputtxt{
      font-size: 16px;
    }
    .css-7gyhhp-MuiStack-root-deletTag>:not(style)+:not(style) {
        margin-left: 0;
    }
    
  }
`;

export const tooltip = css`
  padding-bottom: 20px;
  .MuiTypography-body1{font-size:16px !important;}
  @media (min-width: 320px) and (max-width: 768px) { 
    .MuiTypography-body1{font-size:14px !important;}
  }
  .MuiTypography-root{
    margin: 0;
    padding-bottom: 0;
    font-weight: 400 !important;
  }
  .MuiIconButton-root{
    margin:0 0 0 1px;
    padding:0 0 0 5px;
    .icon_question{
      width:18px;
      height: 18px;
      background: url('/images/common/icon_question_off.png') no-repeat center;
    }
    &:hover{
      .icon_question{
        background-image: url('/images/common/icon_question_on.png');
      }
    }
  }
`;

export const sub_cont01 = css`
  position: relative;
  display: block;
  color: #fff;
  .benner {
    text-align: center;
    background-color: #1f2437;
    width: 100%;
  }
  .txtbox {
    margin: 0 auto;
    max-width: 1080px;
    width: 100%;
    .tit {
      font-size: 48px;
      font-weight: 700;
      margin-bottom: 10px;
      margin-top: 0;
      letter-spacing: -1.92px;
    }
    p {
      margin-top: 10px;
      line-height: 1.8;
      letter-spacing: -0.64px;
    }
  }
  .bottom_card {
    height: 60px;
    max-width: 1260px;
    width: 100%;
    padding: 14px 18px 14px 20px;
    margin: 0 auto;
    border-radius: 15px 15px 0 0;
    background-color: #f5f5f5;
    > p {
      line-height: 1.75;
      font-family: Noto Sans CJK KR;
      margin: 4px 0;
      font-weight: 700;
      color: #222;
      letter-spacing: -0.64px;
    }
    .tag {
      .MuiChip-root {
        border-radius: 5px;
        font-size: 14px;
        &.blue {
          background-color: #4063ec;
          color: #fff;
        }
        &.wh {
          background-color: #fff;
          color: #707070;
          border: 1px solid #ccc;
        }
      }
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .tab_wrap {
      width:calc(100% - 15px);

      .MuiTabs-root{
        min-height: 40px;
      }
      .MuiButtonBase-root{
        min-width: 73px;
        min-height: 40px;
        padding: 0 17px;
      }
    }
    .txtbox {
      .tit {
        font-size: 28px;
        line-height: 41px;
      }
      p {
        font-size: 14px;
        line-height: 2;
        padding:0 20px 32px;
      }
    }
    .bottom_card {
      height: 48px;
      padding: 9px 15px 9px 15px;
      > p {
        margin: 4px 0;
        letter-spacing: -0.56px;
        font-size: 14px;
        line-height: 1.5;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
        margin-right: 10px;
      }
      .tag {
        .MuiChip-root {
          font-size: 12px;
          height: 30px;
        }
      }
    }
    .sub_tit {
      .MuiTypography-root{
        font-size: 24px;
      }
    }
  }
`;
export const btn_next = css`
  button{
    font-weight: normal !important;
    &+button{margin-left:20px;}
  }
  @media (min-width: 320px) and (max-width: 768px) {
    display: block;
    button{
      font-size: 16px !important;
      
      height: 52px !important;
      &:first-of-type{
        width:48.5% !important;
      }
      &:nth-of-type(2){
        width:48.5% !important;
        margin-left: 3%;
      }
      &:last-of-type{
        width:100% !important;
        margin-top: 16px;
        margin-left: 0;
      }
    }
  }
  
`;

export const table = css`
  max-width: 100%;
  letter-spacing: -0.64px;
  .MuiTypography-h6{
    font-size: 18px;
    margin-bottom: 15px;
  }
  .detail_table{
    border-top: 1px solid #1f2437;
    .MuiFormControlLabel-root{
      margin: 0 22px 0 0;
    }
  }
  dl {
    display: flex;
    border-spacing: 0;
    width: 100%;
    min-height: 60px;
    & .noline{
      border-bottom: none;
    }
    dt {
      display: flex;
      align-items: center;
      flex: 0 0 220px;
      padding: 15px 20px;
      text-align: left;
      background-color: #f5f5f5;
      border-bottom: 1px solid #e0e0e0;
      font-weight: 500;
      &.wh{
        background-color: #fff;
      }
    }
    dd {
      flex: 1;
      display: flex;
      justify-content: space-between;
      padding: 6px 20px;
      line-height: 1.75;
      align-items: center;
      border-bottom: 1px solid #e0e0e0;
      margin-left: 0;
      font-weight: 400;
      .datepicker{
        margin-left: -12px;
        .MuiOutlinedInput-root{margin-left:0; margin-right:0; width: 100%;}
      }
      .MuiOutlinedInput-root{margin-left:-12px; margin-right:-12px; width: calc(100% + 24px); min-height:48px;
        .MuiOutlinedInput-input{
          padding: 12.5px 14px;
        }
      }
      .MuiOutlinedInput-notchedOutline{
        border-color: #ccc;
      }
      &.withLink{
        justify-content: flex-start;
        a {margin-left:10px;padding-right:15px;color:#4063ec;font-weight:400;background:url(/images/common/gt_blue.png) no-repeat right center;}
      }
      p{
        &:first-of-type{margin-top:0;}
        margin-top:16px;
      }
    }
  }
  .progName{
    dl{
      dt{
        flex: 0 0 470px;
        padding: 8px;
        .MuiInputBase-root{
          background-color: #fff;
        }
        &.chk{
          flex: 0 0 4%;
          background-color: #fff;
          border-left: 1px solid #e0e0e0;
          border-right: 1px solid #e0e0e0;
          &:first-of-type{border-left-color:transparent;}
        }
      }
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .MuiTypography-h6{
      font-size: 16px;
      margin-bottom: 10px;
    }
    .datepicker {
      .MuiFormControl-root {
        width: 100%;
      }
    }
    .detail_table{
      margin-bottom: 30px;
      .MuiOutlinedInput-root{height:48px}
    }
    .MuiFormControl-root{width:100%;}
    .MuiFormGroup-root{justify-content: flex-start;}
    .MuiFormControlLabel-root{margin-right:0;}
    dl {
      flex-wrap: wrap;
      font-size: 14px;
      min-height: auto;
      dt {
        flex: 0 0 27%;
        line-height: 26px;
        padding: 16px 10px;
        word-break: keep-all;
      }
      dd {
        flex: 0 0 73%;
        padding: 8px;
        .MuiRadio-root {padding:0 2px;margin: 0 5px 0 0;}
        .pickertwo {margin: 0 5px;}
        .MuiOutlinedInput-root{margin-left:0; margin-right:0; width: 100%;}
      }
      &.horz{
        flex-direction: column;
        dt{
          border-bottom: 0;
          justify-content: center;
        }
        dd{
          padding:0 8px;
        }
      }
    }
    .type2{
    }
    .progName{
      dl{
        dt{
          flex: 1 0 50%;
        }
        dd{
          flex: 0 0 30%;
        }
      }
    }
  }
`;


export const table2 = css`
  max-width: 100%;
  letter-spacing: -0.64px;
  .MuiTypography-h6{
    font-size: 18px;
    margin-bottom: 15px;
  }
  .detail_table{
    border-top: 1px solid #1f2437;
    margin-bottom: 40px;
  }
  dl {
    display: flex;
    border-spacing: 0;
    width: 100%;
    & .noline{
      border-bottom: none;
    }
    dt {
      display: flex;
      align-items: center;
      flex: 0 0 220px;
      padding: 20px 20px;
      text-align: left;
      background-color: #f5f5f5;
      border-bottom: 1px solid #e0e0e0;
      font-weight: 500;
      &.wh{
        background-color: #fff;
      }
    }
    dd {
      flex: 1;
      display: flex;
      justify-content: space-between;
      line-height: 1.75;
      align-items: center;
      border-bottom: 1px solid #e0e0e0;
      margin-left: 0;
      padding: 18px 0;
      dd{padding:0;margin: -18px 0;}
      p{padding:0 20px;}
      &.num{
        flex : 0 0 6.2%;
        border-right: 1px solid #e0e0e0;
        justify-content: center;
      }
      &.check{
          flex: 0 0 18.99%;
          border-left: 1px solid #e0e0e0;
          border-bottom: 0;
          justify-content: center;
          align-self: stretch;
          .MuiFormControlLabel-root{
            &:last-child{
              margin-left:14px;
              margin-right: 0;
            }
          }
        }
    }
    &.header{
      dt{
        flex : 0 0 33.3%;
        &.num{
          flex : 0 0 6.2%;
          justify-content: center;
          border-right: 1px solid #e0e0e0;
          &+dt{
            flex: 1;
          }
        }
        &.check{
          flex: 0 0 17.8%;
          justify-content: center;
          border-left: 1px solid #e0e0e0;
        }
      }
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .MuiTypography-h6{
      font-size: 16px;
      margin-bottom: 10px;
    }
    .detail_table{
      margin-bottom: 30px;
    }
    dl {
      border-bottom: 1px solid #e0e0e0;
      &.header{
        display:flex;
        border-bottom: 0;
        dt{
          &.num{flex: 0 0 38px;padding:0;}
          &.check{display:none}
        }
      }
      dt {
        flex: 0 0 30%;
        padding: 15px 18px;
      }
      dd {
        flex: 0 0 89.5%;
        padding: 14px 20px;
        p{padding:0;margin:0;}
        &.num{
          padding:0;
          flex: 0 0 38px;
          border-bottom: 0;
          align-self: stretch;
          &.long{
            height: 201px;
          }
          &.middle{
            height: 176px;
          }
          &.short{
            height: 127px;
          }
        }
        &.cnt{
          flex:1;
          display: block;
          padding-bottom: 5px;
          font-size: 14px;
          border-bottom: 0;
        }
        &.check{
          justify-content: flex-start;
          margin: 10px 0;
          padding:0;
          border-left: 0;
          .MuiFormControlLabel-label{font-size: 14px;}
        }
      }
    }
  }
`;

// 파일 다운로드 버튼
export const btnDown = css`
  justify-content: center;
  flex-direction: row;
  button {
    min-width: 124px;
    height: 48px;
    border-radius: 24px;
    padding: 14px 20px;
    font-size: 14px;
    line-height: 1.5;
    background-color: #fff;
    border: solid 1px #ccc;
    color: #333;
    letter-spacing: -0.56px;
    > span {
      max-width: 200px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    &:before {
      content: '';
      width: 20px;
      height: 20px;
      margin-right: 6px;
      background: url('/images/common/icon_download.png') no-repeat;
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    button {
      margin-bottom: 10px;
      > span {
        max-width: 200px;
      }
    }
  }
`;

export const fileupload = css`
  >div{
    flex-wrap: wrap;
    justify-content: left;
    .MuiButtonBase-root{
      border: 1px solid #bdbdbd;
      margin-left: 0;
      margin-right: 10px;
      margin-bottom: 10px;
    }
  }
`;

export const signbtn = css`
  margin: 0 -30px -30px;
  padding: 24px 0;
  box-shadow: 0 -2px 6px 0 rgba(0, 0, 0, 0.08);
  &.btncont2{
      button{
        &:first-of-type{
        background-color: none;
        &:hover{
          box-shadow: 3px 3px 8px 0 rgb(0 0 0 / 10%);
        }
      }
    }
  }
  button{
    font-size: 18px;
    line-height: 1;
    border-radius: 50px;
    width: 140px;
    height: 48px;
    font-weight: 300;
    box-shadow: none;
    letter-spacing: -0.72px;
    color:#fff;
    font-size: 14px;
    &:hover{
      box-shadow: 3px 3px 8px rgba(64, 99, 236, 0.44);
    } 
    &.primary{
      background-color: #4063ec;
    }
    &.linebtn {
      border: 1px solid #fff;
      background-color: #1f2437;
      &:hover{
        box-shadow: 3px 3px 8px 0 rgb(0 0 0 / 10%);
      }
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    margin-top: 40px;
    border-top: 0;
    button{width:100%;height:52px;}
  }
`;

export const attatchedFile = css`
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  padding:24px 20px;
  background-color: #f5f5f5;
  border-radius: 10px;
  >div{
    &:first-of-type{padding-left:0;}
    padding-left:6px;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    flex-direction: column;
    margin:0 -15px;
    padding:20px 15px;
    border-radius: 0;
    >div{
      padding-left:0;
      button{
        margin-top:10px;
      }
      &:first-of-type{
        button{margin-top:0;}
      }
    }
  }
`