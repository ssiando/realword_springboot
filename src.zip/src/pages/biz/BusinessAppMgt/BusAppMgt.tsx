import React, {Fragment, useEffect, useState} from 'react';
import * as styles from './styles';
import * as comstyles from '~/styles/styles';
import Box from '@mui/material/Box';
import {Stack, useMediaQuery, List, ListItem, ListItemText, TooltipProps, Tooltip, tooltipClasses} from '@mui/material';
import Typography from '@mui/material/Typography';
import {useTheme} from '@mui/material';
import {CustomButton} from '~/components/ButtonComponents';
import {CustomRadioButtons} from '~/components/NoticeCustomCheckBoxs';
import {NavLink, useNavigate} from 'react-router-dom';
import {fetchGetCommCode} from '~/fetches';
import dayjs from 'dayjs';
import {styled} from '@mui/material/styles';
import {useQuery} from "react-query";
import IconButton from '@material-ui/core/IconButton';
import {QuestionIcon} from '~/components/IconComponents';
import DatePicker from '~/components/DatePicker';
import {fetchBusinessList} from '~/fetches/biz/fetchBusinessAppMgt';
import {TypeReqMgnt} from '~/models/biz/BusinessAppMgt';
import {SearchModal} from '~/components/BizCommon/SearchModal';
import {ModalReasonConfirm} from './PopComp/ModalReasonConfirm';
import RceptStus from './PopComp/RceptStus';
import NoData from '~/components/Loading/NoData';
import authentication from 'shared/authentication';
import {SelectSearchBar} from '~/components/BizCommon/SearchBar';
import {Banner} from "~/components/Banner";

/* 
  작성일    :   2022/07/01
  화면명    :   사업신청관리 -> 사업신청관리
  회면ID    :   UI-USP-FRN-0140101
  화면/개발 :   Seongeonjoo / navycui
*/

const BusAppMgt = () => {
  const theme = useTheme();
  const navigate = useNavigate();
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true)

  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  // const [params, setParams] = useState({
  //   posting: true,
  //   articleSrchCd: "ALL",
  //   articleSrchWord: "",
  //   page: 1,
  //   itemsPerPage: 10,
  //   categoryCd: "",
  // })
  const [quests, setQuests] = useState({
    rceptDtStart: '',
    rceptDtEnd: '',
    rceptSttusCd: '',
    keywordDiv: 'pblancNm',
    keyword: ''
  })
  const [params, setParams] = useState<TypeReqMgnt>({
    rceptDtStart: '',
    rceptDtEnd: '',
    rceptSttusCd: '',
    keywordDiv: '',
    keyword: '',
    page: 1,
    itemsPerPage: 10
  })

  //Tooltip Open
  const [open, setOpen] = React.useState(false);
  const handleTooltipClose = () => {
    setOpen(false);
  };
  const handleTooltipOpen = () => {
    setOpen(true);
  }

  // 공통 코드 조회
  const {data: assign_box} = useQuery("getCode", async () => await fetchGetCommCode("RCEPT_STTUS"));

  // 사업신청관리 목록 조회
  const {
    data: list,
    status,
    refetch
  } = useQuery(["getDetail", params], async () => await fetchBusinessList(params), { // fetchBusiness
    onSuccess: (res: any) => {
      setLoading(false)
      return res.list.map((item: any, key: number) => {
        Object.assign(item, {rowNum: key});
      })
    },
    onError: (res: any) => {
      setLoading(false)
    }
  });

  // 더보기
  const moreInfo = () => {
    const itemsPerPage: any = params.itemsPerPage + 10;
    setParams((state) => ({...state, itemsPerPage}));
    setQuests((state) => ({...state, itemsPerPage}));
  }

  useEffect(() => {
    if (!!!authentication.getToken()) {
      navigate(`/signin?nextUrl=${window.btoa(window.location.href)}`)
    }
  }, []);

  // useEffect(() => {
  //   setLoading(true)
  //   refetch()
  // }, [quests]);

  return <Banner
    title={'사업신청 관리'} loading={loading}
    summary={<p>
      지원하는 사업의 신청정보를 조회 및 수정하고,<br className='mo'/> 현재 신청상태를 확인할 수 있습니다.
    </p>}
    searchContent={<SelectSearchBar
      placehold='현재 상태를 확인해보세요!'
      defaultValue={quests.keyword}
      curr={quests.keywordDiv}
      selectData={[{code: 'taskNm', codeNm: '과제명'}, {code: 'pblancNm', codeNm: '공고명'}]}
      onChange={(keyword: string) => setQuests({...quests, keyword: keyword})}
      onChangeDiv={(div: string) => setQuests({...quests, keywordDiv: div})}
      handleSearch={(val: any, sel: any) => {
        if (!!sel) {
          setParams({...params, ...quests})
        }
      }}
    />}
    detailContent={<Fragment>
      {isMobile ? <SearchModal
        placehold='현재 상태를 확인해보세요!'
        handleSearch={(s: string | undefined) => {
          console.log(s)
        }}
        assign_box={assign_box ? assign_box.list : []}
      /> : <Box css={styles.picker_card}>
        <dl>
          <dt>신청일</dt>
          <dd>
            <Box className="box_scroll">
              <DatePicker
                pickerType='two'
                questBeginDay={!!quests.rceptDtStart ? dayjs(quests.rceptDtStart, 'YYYYMMDD').toString() : ''}
                questEndDay={!!quests.rceptDtEnd ? dayjs(quests.rceptDtEnd, 'YYYYMMDD').toString() : ''}
                changeStart={(startNewTime: Date | null) => {
                  if (startNewTime) {
                    if (quests.rceptDtEnd) {
                      const end = new Date(Number(quests.rceptDtEnd.slice(0, 4)),
                        Number(quests.rceptDtEnd.slice(4, 6)) - 1, Number(quests.rceptDtEnd.slice(6, 8)))
                      if (startNewTime.getTime() > end.getTime()) {
                        setQuests({...quests, rceptDtStart: dayjs(end).format('YYYYMMDD')})
                        return
                      }
                    }

                    setQuests({...quests, rceptDtStart: dayjs(startNewTime).format('YYYYMMDD')})
                  }
                }}
                changeEnd={(endNewTime: Date | null) => {
                  if (endNewTime) {
                    if (quests.rceptDtStart) {
                      const begin = new Date(Number(quests.rceptDtStart.slice(0, 4)),
                        Number(quests.rceptDtStart.slice(4, 6)) - 1, Number(quests.rceptDtStart.slice(6, 8)))
                      if (endNewTime.getTime() < begin.getTime()) {
                        setQuests({...quests, rceptDtEnd: dayjs(begin).format('YYYYMMDD')})
                        return
                      }
                    }

                    setQuests({...quests, rceptDtEnd: dayjs(endNewTime).format('YYYYMMDD')})
                  }
                }}
              />
            </Box>
          </dd>
        </dl>
        <dl>
          <dt>신청상태</dt>
          <dd>
            <Box className="box_scroll">
              <CustomRadioButtons
                row data={assign_box ? assign_box.list : []}
                val={quests.rceptSttusCd}
                onClick={(s) => {
                  setQuests({...quests, rceptSttusCd: s})
                }}/>
            </Box>
          </dd>
        </dl>
      </Box>
      }
    </Fragment>}>
    <Box css={comstyles.container}>
      <Box css={comstyles.sub_cont02}>
        <div className="content list">
          {/* className="list02" 클래스는 사유확인버튼이 있을시에만 추가 */}
          <div css={comstyles.detal_list} className="list02">
            <Stack
              spacing={6}
              direction="row"
              className="sub_tit"
              justifyContent="space-between"
            >
              <Typography variant="h4" component="div">
                수행계획서
                <span className='data'><em>{list ? list.totalItems : 0}</em> 건</span>
              </Typography>
              <Stack style={{alignSelf: 'center'}} flexDirection={'row'} css={comstyles.tooltip}>
                <Typography> 신청상태 안내</Typography>
                <HtmlTooltip
                  open={open}
                  onClose={handleTooltipClose}
                  leaveTouchDelay={30000}
                  title={
                    <React.Fragment>
                      {/* <Typography color="inherit">신청상태 안내</Typography> */}
                      <ul className='tooltip_list'>
                        <li><span className='clr01'>임시저장</span> 신청 전 임시저장 상태</li>
                        <li><span className='clr02'>신청</span> 사업담당자가 발표자료 보완을 요청한 상태</li>
                        <li><span className='clr03'>보완요청</span> 사업담당자가 발표자료 보완을 요청한 상태</li>
                        <li><span className='clr04'>반려</span> 신청에 탈락한 상태</li>
                        <li><span className='clr05'>접수완료</span> 사업담당자가 신청에 대해 접수완료 처리한 상태</li>
                        <li><span className='clr06'>신청취소</span> 신청자 또는 관리자에 의해 신청이 취소된 상태</li>
                      </ul>
                    </React.Fragment>
                  }
                  placement="bottom"
                >
                  <IconButton onClick={handleTooltipOpen}>
                    <QuestionIcon/>
                  </IconButton>
                </HtmlTooltip>
              </Stack>
            </Stack>
            <List>
              {(status == 'success') ? list.list.map((item: any, i: number) => (
                <div className="btn_cont" key={i}>
                  <NavLink to={`/biz/BusinessAppMgt/BusAppMgtDetail/${item.applyId}`}
                           state={{
                             item: item,
                             total: total
                           }}>
                    <ListItem>
                      <ListItemText
                        secondary={
                          <React.Fragment>
                        <span className="tit_body">
                          <Typography variant="body1" component="span">
                          {item.pblancNm}
                          </Typography>
                        </span>
                            <div className='subject'>
                              <span>과제명</span><em> {item.taskNmKo}</em>
                            </div>
                            <span className="date date_block">
                          <span>접수기간 <em>{dayjs(item.rceptBgnde).format('YYYY-MM-DD')}</em> ~ <em>{dayjs(item.rceptEndde).format('YYYY-MM-DD')}</em></span>
                              {!!item.rceptDt ?
                                <span>제출일 <em>{dayjs(item.rceptDt).format('YYYY-MM-DD')}</em></span>
                                : ''
                              }
                        </span>
                            <RceptStus stus={!!item.rceptSttus ? item.rceptSttus : '접수상태'}/>
                          </React.Fragment>
                        }
                      />
                    </ListItem>
                  </NavLink>
                  <div className="right_btn">
                    {(item.rceptSttusCd == 'REJECT' || item.rceptSttusCd == 'MAKEUP') ?
                      <ModalReasonConfirm
                        applyId={item.applyId}
                        viewNm='BusAppMgt'
                        title='사유확인'
                        variant='text'
                        label='사유 확인'
                        type='modalBtn2'
                        color='outlinedgray'
                      />
                      : null
                    }
                  </div>
                </div>
              )) : <NoData/>}
            </List>
            {(params.itemsPerPage) < total ?
              // 더보기
              <Stack css={styles.bottom_btn}>
                <CustomButton label={'더보기'} type={'full'} color={'item'} style={{margin: '10px 0'}}
                              onClick={() => moreInfo()}/>
              </Stack>
              : null}
          </div>
        </div>
      </Box>
    </Box>
  </Banner>
}

const HtmlTooltip = styled(({className, ...props}: TooltipProps) => (
  <Tooltip {...props} classes={{popper: className}}/>
))(({theme}) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    backgroundColor: '#f5f5f9',
    color: 'rgba(0, 0, 0, 0.87)',
    maxWidth: 220,
    fontSize: theme.typography.pxToRem(12),
    border: '1px solid #dadde9',
  },
}));

export default BusAppMgt;