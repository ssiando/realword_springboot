import React,{useEffect,useState} from "react";

/*
  공통: 접수상태 관리
  작성자: navycui
*/
const RceptStus:React.FC<{
  stus:string
  children?: React.ReactNode
}> = (props) =>  {
  const [colors,setColors] = useState('')

  useEffect(() => {
    if(!!props.stus){
      switch (props.stus) {
        case '제출':
        case '임시저장':
          setColors('purple')
        break;
        case '신청':
        case '승인':
        case '서명완료':
        case '제출요청':
        case '예약신청':
        case '접수':
          setColors('blue')
        break;
        case '보완요청':
        case '심의완료':
        case '서명요청':
          setColors('green')
        break;
        case '반려':
          setColors('red')
        break;
        case '접수완료':
        case '협약완료':
        case '예약확정':
        case '답변완료':
          setColors('black')
        break;
        case '신청취소':
        case '미제출':
        case '협약해지':
        case '예약취소':
          setColors('gray')
        break;     
        default:
          setColors('gray')
          break;
      }
    }
  }, [props.stus]);

return (    
    <>
      <div className={`right_tag ` + colors}>
        <em>{props.stus ? props.stus : ''}</em>
      </div>
    </>
  )
}

export default RceptStus;
