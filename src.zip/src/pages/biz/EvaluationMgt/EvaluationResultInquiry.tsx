import * as styles from './styles';
import * as comstyles from '~/styles/styles';
import Box from '@mui/material/Box';
import {Stack, useMediaQuery, List, ListItem, ListItemText, Link, Paper} from '@mui/material';
import React, {Fragment, useState} from 'react';
import Typography from '@mui/material/Typography';
import {useTheme} from '@mui/material';
import {CustomButton} from '~/components/ButtonComponents';
import {CustomRadioButtons} from '~/components/NoticeCustomCheckBoxs';
import dayjs from 'dayjs';
import {useQuery} from "react-query";
import {SearchModal} from '~/components/BizCommon/SearchModal';
import {SelectSearchBar} from '~/components/BizCommon/SearchBar';
import DatePicker from '~/components/DatePicker';
import {ModalReasonConfirm} from '../BusinessAppMgt/PopComp/ModalReasonConfirm';
import {fetchEvlResultChk, fetchEvlResultListGet} from '~/fetches/fetchEvlResult';
import {Modalfront} from '~/components/SharedModalComponents';
import {useGlobalModalStore, useScroll} from '~/pages/store/GlobalModalStore';
import NoData from '~/components/Loading/NoData';
import {useScrollStore} from "shared/store/ScrollStore";
import {Banner} from "~/components/Banner";
import Chip from "@mui/material/Chip";
import {useNavigate} from "react-router-dom";

/* 
  작성일    :   2022/06/26
  화면명    :   사업관리 -> 평가관리 -> 평가결과조회
  회면ID    :   UI-USP-FRN-0160501
  화면/개발 :   Seongeonjoo / navycui
*/
const EvaluationResultInquiry = () => {
  const begin = new Date();
  const theme = useTheme();
  begin.setDate(begin.getDate() - 30)
  const [total, setTotal] = useState(0);
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()
  const [quests, setQuests] = useState({
    slctnBgnde: '',
    slctnEndde: '',
    slctnResult: "",
    keywordDiv: 'pblancNm',
    keyword: ''
  })
  const [input, setInput] = useState({
    slctnBgnde: '',
    slctnEndde: '',
    slctnResult: "",
    keyword: "",
    keywordDiv: "pblancNm",
    page: 1,
    itemsPerPage: 10,
  })


  const assign_box = [{code: "Y", codeNm: "선정"}, {code: "N", codeNm: "탈락"}]
  // const {data:assign_box} = useQuery("getCode", () => fetchGetCommCode("RCEPT_STTUS"))

  // 수행계획서 목록 조회
  const {
    data: list,
    status,
    refetch: reSearchList
  } = useQuery(["fetchEvlResultListGet", input], () => fetchEvlResultListGet(input), {
    onSuccess: (res: any) => {
      console.log('res - ' + JSON.stringify(res))
      setLoading(false)
      setTotal(res.totalItems)
    }
  });
  // useEffect(()=>{
  //   setLoading(true)
  //   reSearchList();
  // },[input])

  const moreInfo = () => {
    const itemsPerPage: any = input.itemsPerPage + 10;
    setInput((state) => ({...state, itemsPerPage}));
  }

  const checkSlctnAt = (slctnAt: string) => {
    if (slctnAt === "Y") {
      return "선정"
    } else if (slctnAt === "N") {
      return "탈락"
    }
  }
  const [open, setOpen] = useState(false);
  const [type, setType] = useState<'normal' | 'confirm'>('normal');
  const [data, setData] = useState(false);
  const [resVal, setResVal]: any = useState()
  const {addModal} = useGlobalModalStore();
  const [applyId, setApplyId] = useState("");
  const reasonConfirm = (id: string) => {
    setOpen(true);
    setType(type);
    fetchEvlResultChk(id).then((res: any) => {
      setApplyId(id);
      setResVal(res)
    }).catch((e) => {
      let message = e.response.data.message;
      addModal({
        open: true,
        content: message
      })
    })
  }
  return <Banner
    title={'평가결과조회'} loading={loading}
    summary={'평가가 완료된 과제의 평가결과와 의견을 조회할 수 있습니다.'}
    searchContent={
      <SelectSearchBar
        placehold='평가결과를 조회해보세요!'
        defaultValue={quests.keyword}
        curr={quests.keywordDiv}
        selectData={[{code: 'taskNmKo', codeNm: '과제명'}, {code: 'pblancNm', codeNm: '공고명'}]}
        onChange={(keyword: string) => setQuests({...quests, keyword: keyword})}
        onChangeDiv={(div: string) => setQuests({...quests, keywordDiv: div})}
        handleSearch={(val: any, sel: any) => {
          if (!!sel) {
            setInput({...input, ...quests})
            console.log('res - ' + JSON.stringify({...input, ...quests}))
          }
        }}
      />}
    detailContent={<>
      {isMobile ? (
        <SearchModal
          placehold='평가결과를 조회해보세요!'
          handleSearch={(s: string | undefined) => {
            console.log(s)
          }}
          assign_box={assign_box ? assign_box : []}
        />
      ) : (
        <Box css={styles.teble_detal}>
          <Box component={Paper} css={styles.table02}>
            <dl>
              <dt>평가일</dt>
              <dd>
                <Box className="box_scroll">
                  <DatePicker
                    pickerType='two'
                    questBeginDay={!!quests.slctnBgnde ? dayjs(quests.slctnBgnde, 'YYYYMMDD').toString() : ''}
                    questEndDay={!!quests.slctnEndde ? dayjs(quests.slctnEndde, 'YYYYMMDD').toString() : ''}
                    changeStart={(startNewTime: Date | null) => {
                      if (startNewTime) {
                        if (quests.slctnEndde) {
                          const end = new Date(Number(quests.slctnEndde.slice(0, 4)),
                            Number(quests.slctnEndde.slice(4, 6)) - 1, Number(quests.slctnEndde.slice(6, 8)))
                          if (startNewTime.getTime() > end.getTime()) {
                            setQuests({...quests, slctnBgnde: dayjs(end).format('YYYYMMDD')})
                            return
                          }
                        }

                        setQuests({...quests, slctnBgnde: dayjs(startNewTime).format('YYYYMMDD')})
                      }
                    }}
                    changeEnd={(endNewTime: Date | null) => {
                      if (endNewTime) {
                        if (quests.slctnBgnde) {
                          const begin = new Date(Number(quests.slctnBgnde.slice(0, 4)),
                            Number(quests.slctnBgnde.slice(4, 6)) - 1, Number(quests.slctnBgnde.slice(6, 8)))
                          if (endNewTime.getTime() < begin.getTime()) {
                            setQuests({...quests, slctnEndde: dayjs(begin).format('YYYYMMDD')})
                            return
                          }
                        }

                        setQuests({...quests, slctnEndde: dayjs(endNewTime).format('YYYYMMDD')})
                      }
                    }}
                  />
                </Box>
              </dd>
            </dl>
            <dl>
              <dt>평가결과</dt>
              <dd>
                <Box className="box_scroll">
                  <CustomRadioButtons
                    row data={assign_box ? assign_box : []}
                    val={quests.slctnResult}
                    onClick={(s: string) => {
                      setQuests((state) => ({...state, slctnResult: s}))
                    }}
                  />
                </Box>
              </dd>
            </dl>
          </Box>
        </Box>
      )}
    </>}
  >
    <>
      <div css={comstyles.container}>
        <Box css={comstyles.sub_cont02}>
          <div className="content list">
            {/* className="list02" 클래스는 사유확인버튼이 있을시에만 추가 */}
            <div css={comstyles.detal_list} className="list02">
              <Stack
                spacing={6}
                direction="row"
                className="sub_tit"
                justifyContent="space-between"
              >
                <Typography variant="h4" component="div">
                  평가결과
                  <span className='data'><em>{list ? list.totalItems : 0}</em> 건</span>
                </Typography>
              </Stack>
              <List>
                {(status == 'success') ? list.list.map((item: any, i: number) => (
                  <div className="btn_cont" key={i}>
                    <Link onClick={() => reasonConfirm(item.evlTrgetId)} underline="none">
                      <ListItem>
                        <ListItemText
                          secondary={
                            <React.Fragment>
                              <span className="tit_body">
                                <Typography variant="body1" component="span">
                                  {item.pblancNm}
                                </Typography>
                              </span>
                              <span className="date">
                                <span>평가단계<em>{item.evlStepNm}</em></span>
                                <span>평가일<em>{item.evlDe ? dayjs(item.evlDe).format('YYYY-MM-DD') : null}</em></span>
                              </span>
                              <div className="right_tag">
                                <em className={item.slctnAt === "Y" ? 'blue' : ''}>{checkSlctnAt(item.slctnAt)}</em>
                              </div>
                            </React.Fragment>
                          }
                        />
                      </ListItem>
                    </Link>
                    {item.objcReqstAt === "Y" ?
                      <div className="right_btn">
                        {/*<ModalReasonConfirm applyId={item.objcReqstAt} viewNm="PresentationDataMgt" label={'이의신청'}/>*/}
                        <CustomButton
                          variant='outlined' label={'이의신청'}
                          type={'modalBtn2'}
                          color={'outlinedgray'}
                          onClick={() => {
                            navigate('/biz/EvaluationMgt/Objection')
                          }}/>

                      </div>
                      : null}
                  </div>
                )) : <NoData/>}
              </List>
              {(input.itemsPerPage) < total ?
                // 더보기
                <Stack css={styles.bottom_btn}>
                  <CustomButton label={'더보기'} type={'full'} color={'item'} style={{margin: '10px 0'}}
                                onClick={() => moreInfo()}/>
                </Stack>
                : null}
            </div>
          </div>
        </Box>
      </div>
      <Modalfront
        open={open}
        type={type}
        title={'평가의견 확인'}
        content={type.toString() + ' 모달'}
        onConfirm={() => {
          setOpen(false);
        }}
        onClose={() => {
          setOpen(false);
          if (data) setData(false);
        }}
      >
        <Box css={styles.table} style={{width: '932px', marginTop: '24px'}}>
          <div className="detail_table">
            <dl>
              <dt>공고명</dt>
              <dd>{resVal?.pblancNm}</dd>
            </dl>
            <dl>
              <dt>과제명</dt>
              <dd>{resVal?.taskNmKo}</dd>
            </dl>
            <dl>
              <dt>접수번호</dt>
              <dd>{resVal?.receiptNo}</dd>
              <dt>처리상태</dt>
              <dd className="withLink">{resVal?.slctnAt === 'Y' ? '선정' : '탈락'}
                {
                  resVal && resVal.objcReqstAt == 'N'?
                    resVal.objcReqstposblAt == 'Y'? <ModalReasonConfirm
                    applyId={applyId} viewNm="ObjectionApply"
                    title='결과이의신청' label='이의신청' variant='text'
                    onConfirm={() => {
                      addModal({
                        open: true,
                        content: '이의 신청했습니다.',
                        onClose: () => {
                          setOpen(false)
                          reSearchList()
                        },
                        onConfirm: () => {
                          setOpen(false)
                          reSearchList()
                        }
                      })
                    }}/> :
                      <p></p> : <p>(이의 신청중)</p>
                }
              </dd>
            </dl>
          </div>
        </Box>
        {
          resVal && resVal.evlOpinionList?.length > 0 && <Fragment>
            <Typography
              gutterBottom variant="h6" className="pop_title" component="div"
              sx={{marginTop: '25px'}}>{'평가위원 의견'}
            </Typography>
            <Box css={styles.table}>
              <div className="detail_table">
                {
                  resVal.evlOpinionList.map((item: any) => (
                    <dl>
                      <dt>{item.expertNm}</dt>
                      <dd>{item.evlOpinion}</dd>
                    </dl>
                  ))}
              </div>
            </Box>
          </Fragment>
        }

        <Stack direction="row" css={styles.btn_next} justifyContent="center" spacing={2}>
          <CustomButton label={'확인'} type={'modalBtn'} color={'primary'} onClick={() => setOpen(false)}/>
        </Stack>
      </Modalfront>
    </>
  </Banner>
}

export default EvaluationResultInquiry;