import React, {useEffect, useRef} from "react"
import {useState} from 'react';
import * as styles from '../styles';
import * as comstyles from '~/styles/styles';
import {Box, TextField, Stack,} from '@mui/material';
import {FileUpload, FileUpload1} from "../../../EventNews/FileUpload";
import {CustomButton} from '~/components/ButtonComponents';
import {ModalReasonConfirm} from "../../BusinessAppMgt/PopComp/ModalReasonConfirm";
import {useScrollStore} from "shared/store/ScrollStore";
import {useQuery} from "react-query";
import {fetchPresentationDetail, fetchPresentationIn} from "~/fetches/biz/fetchBusinessAppMgt";
import {useParams} from "react-router-dom";
import {Banner} from "~/components/Banner";
import fetchDownload from "~/fetches/fetchDownload";
import {useGlobalModalStore} from "~/pages/store/GlobalModalStore";

/* 
  작성일    :   2022/07/06
  화면명    :   사업관리 -> 평가관리 -> 발표자료 제출
  회면ID    :   UI-USP-FRN-0160301
  화면/개발 :   Seongeonjoo / navycui ...todo 대기 api 차주
*/

const SubmissionMaterials = () => {
  const [files, setFiles]: any = useState([]);
  const [data, setData] = useState<any | null>(null)
  const params = useParams()
  const [loading, setLoading] = useState(true)
  const [textLength, setLength] = useState(0)
  const textInput: any = useRef("");
  const {addModal} = useGlobalModalStore()

  const [attachmentFileList, setAttachmentFileList] = useState<never[]>([]);
  const [deleteAttachFileList, setDeleteAttachFileList] = useState<any[]>([]);

  const report = useQuery(['presentationDetail', params.id!], () => fetchPresentationDetail(params.id!))

  useEffect(() => {
    if (!report.isLoading && !report.isFetching) {
      if (!!report.data) {
        console.log('presentation.data - ' + JSON.stringify(report.data))
        setData(report.data)
        // setContent(report.data.)
        setAttachmentFileList(report.data.attachFileList)
      }
    }
    setLoading(false)
  }, [report.data, report.isLoading, report.isFetching])

  const handleDelete = (i: number) => {
    if (data.presnatnProcessDivCd == 'PRPR04' || data.presnatnProcessDivCd == 'PRPR02') return
    const update = [...files]
    update.splice(i, 1)
    setFiles(update);
  }

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (data.presnatnProcessDivCd == 'PRPR04' || data.presnatnProcessDivCd == 'PRPR02') return
    let upfile: any = e.target.files;
    const update = [...files]
    for (var i = 0; i < upfile.length; i++) {
      update.push(upfile[i]);
    }
    setFiles(update)
  }

  const deleteAttach = (attachmentId: string, i: number) => {
    if (data.presnatnProcessDivCd == 'PRPR04' || data.presnatnProcessDivCd == 'PRPR02') return
    const update = [...deleteAttachFileList]
    update.push({
      attachmentId: attachmentId
    })
    setDeleteAttachFileList(update);
    const update1 = [...attachmentFileList]
    update1.splice(i, 1)
    setAttachmentFileList(update1);
  }

  const handleDownLoad = async (attachmentId: string) => {
    try {
      const result = await fetchDownload(`${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/evl-presnatn/atchmnfl/${attachmentId}`)
    } catch (e: any) {
      let status = e.response.status;

      if (status === 400) {
        addModal({
          open: true,
          content: "파일이 없습니다."
        })
      }
    }
  }

  const submit = async () => {
    const form = new FormData();
    const paramJson = {
      evlTrgetId: data.evlTrgetId,
      attachmentGroupId: data.attachmentGroupId,
      attachFileDeleteList: deleteAttachFileList,
    }
    console.log('info - ' + JSON.stringify(paramJson))
    form.append("info", new Blob([JSON.stringify(paramJson)], {type: 'application/json'}));
    for (let i = 0; i < files.length; i++) {
      form.append("fileList", files[i])
    }
    try {
      const result = await fetchPresentationIn(form)
      addModal({
        open: true,
        content: `${data.presnatnProcessDivCd == 'PRPR03'? '수정':'제출'} 되었습니다.`,
        onClose: () => {
          setFiles([])
          report.refetch()
        },
        onConfirm: () => {
          setFiles([])
          report.refetch()
        }
      })
    } catch (e) {
      console.log(e)
    }

  }
  const changeText = () => {
    setLength(textInput.current.value.length)
  }

  return (
    <Banner
      title={'발표자료 제출'}
      summary={<p>평가예정인 과제의 발표자료를 조회하고 제출할 수 있습니다.</p>}
      loading={loading}>
      <div css={comstyles.container}>
        {data && <Box className="content_body">
          <div className="content">
            <Box css={comstyles.box_graylist}>
              • <span className="must">*</span> 표시는 필수입력 항목입니다.
            </Box>
            <h4 className="tbl_title">기본정보</h4>
            <Box css={styles.table}>
              <div className="detail_table">
                <dl>
                  <dt>공고명</dt>
                  <dd>{data.pblancNm}</dd>
                </dl>
                <dl>
                  <dt>평가예정일시</dt>
                  <dd>{data.evlPrarndt}</dd>
                  <dt>과제명</dt>
                  <dd>{data.taskNmKo}</dd>
                </dl>
                <dl>
                  <dt>제출일</dt>
                  <dd>{data.fmtPresentnDt}</dd>
                  <dt>제출상태</dt>
                  <dd className="withLink">{data.presnatnProcessDivNm}
                    {
                      data.presnatnProcessDivCd == "PRPR03" &&
                      <ModalReasonConfirm
                        applyId={data.evlTrgetId}
                        viewNm='PresentationDataMgt'
                        variant='text' type='modify' color='outlined'
                        label='사유확인'/>
                    }
                  </dd>
                </dl>
              </div>
            </Box>
            {/*<h4 className="tbl_title">보고서 요약</h4>*/}
            {/*<TextField*/}
            {/*  id="outlined-multiline-static"*/}
            {/*  onChange={changeText}*/}
            {/*  inputRef={textInput}*/}
            {/*  // error={questionError.errorQuestion}*/}
            {/*  // helperText={questionError.helperQuestion}*/}
            {/*  multiline rows={5.2}*/}
            {/*  className="textfield_tp01"*/}
            {/*  inputProps={{*/}
            {/*    maxLength: 1000,*/}
            {/*  }}*/}
            {/*/>*/}
            {/*<div className='tf_count'>{textLength}/1000</div>*/}
            <h4 className="tbl_title">파일첨부 <span className="must">*</span></h4>
            <Box css={styles.fileupload}>
              <FileUpload1
                files={files}
                handleDelete={handleDelete}
                handleUpload={handleUpload}
                files1={attachmentFileList}
                handleDelete2={deleteAttach}
                handleDownLoad={handleDownLoad}
              />
            </Box>
            {
              data.presnatnProcessDivCd && data.presnatnProcessDivCd != 'PRPR04' && data.presnatnProcessDivCd != 'PRPR02' &&
              <Stack direction="row" justifyContent="center" spacing={2} sx={{marginTop: '40px'}} css={styles.btn_next}>
                <CustomButton label={data.presnatnProcessDivCd == 'PRPR03'? '수정':'제출'} type={'listBack'} color={'primary'} onClick={submit}/>
              </Stack>
            }
          </div>
        </Box>
        }
      </div>
    </Banner>
  );
}


interface AttachFile {
  attachmentId: string,
  fileNm: string,
  fileSize: string
}

interface ReportData {
  reprtId: string,
  reprtTypeCd: string,
  reprtType: string,
  reprtSttusCd: string,
  reprtSttus: string,
  taskNm: string,
  receiptNo: string,
  rspnberNm: string,
  pblancNm: string,
  presentnDate: string,
  reprtSumryCn: string,
  attachFileList: AttachFile[]
}

export default SubmissionMaterials;