import React, {Fragment, useEffect, useState} from 'react';
import * as styles from './styles';
import * as comstyles from '~/styles/styles';
import Box from '@mui/material/Box';
import {
  Stack,
  useMediaQuery,
  List,
  ListItem,
  ListItemText,
  TooltipProps,
  Tooltip,
  tooltipClasses,
  Collapse
} from '@mui/material';
import Typography from '@mui/material/Typography';
import {useTheme} from '@mui/material';
import {CustomButton} from '~/components/ButtonComponents';
import {CustomRadioButtons} from '~/components/NoticeCustomCheckBoxs';
import {NavLink} from 'react-router-dom';
import {fetchGetCommCode} from '~/fetches';
import dayjs from 'dayjs';
import {styled} from '@mui/material/styles';
import {useQuery} from "react-query";
import IconButton from '@material-ui/core/IconButton';
import {QuestionIcon} from '~/components/IconComponents';
import DatePicker from '~/components/DatePicker';
import {fetchPresentationList} from '~/fetches/biz/fetchBusinessAppMgt';
import {SelectSearchBar} from '~/components/BizCommon/SearchBar';
import {SearchModal} from '~/components/BizCommon/SearchModal';
import {ModalReasonConfirm} from '../BusinessAppMgt/PopComp/ModalReasonConfirm';
import RceptStus from '../BusinessAppMgt/PopComp/RceptStus';
import NoData from '~/components/Loading/NoData';
import {Banner} from "~/components/Banner";

/* 
  작성일    :   2022/06/26
  화면명    :   사업관리 -> 평가관리 -> 발표자료관리
  회면ID    :   (UI-USP-FRN-0160101) /(UI-USP-FRN-0160102) 
  화면/개발 :   Seongeonjoo / navycui
*/
const PresentationDataMgt = () => {
  const today = new Date();
  today.setHours(today.getHours() - 24);
  const theme = useTheme();
  const [total, setTotal] = useState(0);
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [list, setList] = useState<any>();
  // const [quests, setQuests] = useState({
  //   presnatnBgnde: '',
  //   presnatnEndde: '',
  //   presnatnProcessDivCd: '',
  //   keywordDiv: '01',
  //   keyword: ''
  // })

  const [params, setParams] = useState({
    presnatnBgnde: '',
    presnatnEndde: '',
    presnatnProcessDivCd: '',
    keywordDiv: 'pblancNm',
    keyword: '',
    page: 1,
    itemsPerPage: 10
  })

  const [loading, setLoading] = useState(true)

  //Tooltip Open
  const [open, setOpen] = React.useState(false);
  const handleTooltipClose = () => {
    setOpen(false);
  };
  const handleTooltipOpen = () => {
    setOpen(true);
  }

  // 공통 코드 조회
  const {data: assign_box} = useQuery("getCode", () => fetchGetCommCode("REPRT_STTUS"))
  // 사업신청관리 목록 조회

  const getList = async () => {
    setLoading(true)
    await fetchPresentationList(params).then((res: any) => {
      setList(res)
      console.log('res - ' + JSON.stringify(res))
    }).catch((e) => {
      // addModal({
      //   open:true,
      //   content:message
      // })
      setLoading(false)
    })
    setLoading(false)
  }

  // 더보기
  const moreInfo = () => {
    const itemsPerPage: any = params.itemsPerPage + 10;
    setParams((state) => ({...state, itemsPerPage}));
  }

  useEffect(() => {
    getList()
  }, [params.itemsPerPage]);

  return <Banner
    title={'발표자료 관리'} loading={loading}
    summary={'평가예정인 과제의 발표자료를 조회하고 제출할 수 있습니다.'}
    searchContent={<SelectSearchBar
      placehold='어떤 발표 자료를 찾고 계신가요?'
      defaultValue={params.keyword}
      curr={params.keywordDiv}
      selectData={[ {code: 'taskNmKo', codeNm: '과제명'}, {code: 'pblancNm', codeNm: '공고명'}]}
      onChange={(keyword: string) => setParams({...params, keyword: keyword})}
      onChangeDiv={(div: string) => setParams({...params, keywordDiv: div})}
      handleSearch={(val: any, sel: any) => {
        getList()
      }}
    />}
    detailContent={<Fragment>
      {isMobile ? <SearchModal
        placehold='어떤 발표 자료를 찾고 계신가요?'
        handleSearch={(s: string | undefined) => {
          console.log(s)
        }}
        assign_box={assign_box ? assign_box.list : []}
      /> : <Box css={styles.picker_card}>
        <dl>
          <dt>제출일</dt>
          <dd>
            <Box className="box_scroll">
              <DatePicker
                pickerType='two'
                questBeginDay={!!params.presnatnBgnde ? dayjs(params.presnatnBgnde, 'YYYYMMDD').toString() : ''}
                questEndDay={!!params.presnatnEndde ? dayjs(params.presnatnEndde, 'YYYYMMDD').toString() : ''}
                changeStart={(startNewTime: Date | null) => {
                  if (startNewTime) {
                    if (params.presnatnEndde) {
                      const end = new Date(Number(params.presnatnEndde.slice(0, 4)),
                        Number(params.presnatnEndde.slice(4, 6)) - 1, Number(params.presnatnEndde.slice(6, 8)))
                      if (startNewTime.getTime() > end.getTime()) {
                        setParams({...params, presnatnBgnde: dayjs(end).format('YYYYMMDD')})
                        return
                      }
                    }

                    setParams({...params, presnatnBgnde: dayjs(startNewTime).format('YYYYMMDD')})
                  }
                }}
                changeEnd={(endNewTime: Date | null) => {
                  if (endNewTime) {
                    if (params.presnatnBgnde) {
                      const begin = new Date(Number(params.presnatnBgnde.slice(0, 4)),
                        Number(params.presnatnBgnde.slice(4, 6)) - 1, Number(params.presnatnBgnde.slice(6, 8)))
                      if (endNewTime.getTime() < begin.getTime()) {
                        setParams({...params, presnatnEndde: dayjs(begin).format('YYYYMMDD')})
                        return
                      }
                    }

                    setParams({...params, presnatnEndde: dayjs(endNewTime).format('YYYYMMDD')})
                  }
                }}
              />
            </Box>
          </dd>
        </dl>
        <dl>
          <dt>제출상태</dt>
          <dd>
            <Box className="box_scroll">
              <CustomRadioButtons
                row data={assign_box ? assign_box.list : []}
                val={params.presnatnProcessDivCd}
                onClick={(s) => {
                  setParams({...params, presnatnProcessDivCd: s})
                }}/>
            </Box>
          </dd>
        </dl>
      </Box>
      }
    </Fragment>}>
    <div css={comstyles.container}>
      <Box css={comstyles.sub_cont02}>
        <div className="content list">
          {/* className="list02" 클래스는 사유확인버튼이 있을시에만 추가 */}
          <div css={comstyles.detal_list} className="list02">
            <Stack
              spacing={6}
              direction="row"
              className="sub_tit"
              justifyContent="space-between"
            >
              <Typography variant="h4" component="div">
                발표자료
                <span className='data'><em>{list ? list.totalItems : 0}</em> 건</span>
              </Typography>
              <Stack style={{alignSelf: 'center'}} flexDirection={'row'} css={comstyles.tooltip}>
                <Typography> 제출상태 안내</Typography>
                <HtmlTooltip
                  open={open}
                  onClose={handleTooltipClose}
                  leaveTouchDelay={30000}
                  title={
                    <React.Fragment>
                      {/* <Typography color="inherit">신청상태 안내</Typography> */}
                      <ul className='tooltip_list'>
                        <li><span className='clr02'>제출요청</span> 제출요청인증메일은 최대 10분까지 유효합니다.</li>
                        <li><span className='clr01'>제출</span> 발표자료가 제출된 상태</li>
                        <li><span className='clr03'>보완요청</span> 사업담당자가 발표자료 보완을 요청한 상태</li>
                        <li><span className='clr05'>접수완료</span> 사업담당자가 발표자료에 대해 접수완료 처리한 상태</li>
                      </ul>
                    </React.Fragment>
                  }
                  placement="bottom"
                >
                  <IconButton onClick={handleTooltipOpen}>
                    <QuestionIcon/>
                  </IconButton>
                </HtmlTooltip>
              </Stack>
            </Stack>
            <List>
              {!!list ? list.list.length > 0 ? list.list.map((item: any, i: number) => (
                <div className="btn_cont" key={i}>
                  <NavLink to={`/biz/EvaluationMgt/SubmissionMaterials/${item.evlTrgetId}`}
                           state={{
                             item: item,
                             total: total
                           }}>
                    <ListItem>
                      <ListItemText
                        secondary={
                          <React.Fragment>
                            <div>{item.reprtType}</div>
                            <span className="tit_body">
                              <Typography variant="body1" component="span">
                                {item.pblancNm}
                              </Typography>
                            </span>
                            <span className="date">
                              <span>평가예정일시<em>{item.evlPrarndt}</em></span>
                              <span>제출일<em>{item.fmtPresentnDt}</em></span>
                            </span>
                            <RceptStus stus={!!item.presnatnProcessDivNm ? item.presnatnProcessDivNm : ''}/>
                          </React.Fragment>
                        }
                      />
                    </ListItem>
                  </NavLink>
                  {
                    item.presnatnProcessDivCd == 'PRPR03' &&
                    <div className="right_btn">
                      <ModalReasonConfirm
                        applyId={item.evlTrgetId}
                        viewNm="PresentationDataMgt"
                        title={' '}
                      />
                    </div>
                  }
                </div>
              )) : <NoData/> : ''}
            </List>
            {(params.itemsPerPage) < total ?
              // 더보기
              <Stack css={styles.bottom_btn}>
                <CustomButton label={'더보기'} type={'full'} color={'item'} style={{margin: '10px 0'}} onClick={() => moreInfo()}/>
              </Stack>
              : null}
          </div>
        </div>
      </Box>
    </div>
  </Banner>
}

const HtmlTooltip = styled(({className, ...props}: TooltipProps) => (
  <Tooltip {...props} classes={{popper: className}}/>
))(({theme}) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    backgroundColor: '#f5f5f9',
    color: 'rgba(0, 0, 0, 0.87)',
    maxWidth: 220,
    fontSize: theme.typography.pxToRem(12),
    border: '1px solid #dadde9',
  },
}));

export default PresentationDataMgt;