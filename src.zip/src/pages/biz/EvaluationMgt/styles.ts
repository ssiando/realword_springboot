import { css } from '@emotion/react';
import {Color} from "~/components/StyleUtils";

export const detal_list = css`
  margin: 0 auto;
  max-width: 1260px;
  &.taglist{
    .MuiListItemText-root{
      padding-right: 80px;
    }
  }
  &.list02{
    .right_tag{
      width:60px;
      right: 190px;
      text-align: center;
    }
    .btn_cont{
      position: relative;
    }
    .right_btn{
      position:absolute;
      right: 30px;
      top: 50%;
      transform: translateY(-50%);
      color: #222;
      font-size: 16px;
      font-weight: 500;
      letter-spacing: -0.64px;
      button{
        letter-spacing: -0.56px;
        z-index: 999;
      }
    }
  }
  .mb10{
    margin-bottom: 10px;
  }
  .modalbtn{
    background-color:#ccc;
  }
  .subject{
    span{font-weight:400;color: #707070;}
    em{margin-left:6px;font-style:normal;color: #222;font-weight:400;}
  }
  .date{
    display:flex;
    margin-top: 5px;
    letter-spacing: -0.56px;
    span {
      position: relative;
      display:flex;
      height: 20px;
      align-items: center;
      color:#707070;
      font-weight: 400;
      /* &+span{
        margin-left: 6px;
        padding-left: 6px;
        &:before{
          content:'';
          position: absolute;
          left:0;
          top:5px;
          width:1px;
          height: 12px;
          background-color: #ccc;
        }
      } */
      em{
        font-style:normal;color: #222;font-weight:400;
        &:first-of-type{
          margin-left:6px;
        }
      }
    }
  }

  .pl5{
    padding-left: 5px;
  }
  .right_tag{
    position:absolute;
    right: 30px;
    top: 50%;
    transform: translateY(-50%);
    color: #222;
    font-size: 16px;
    font-weight: 700;
    letter-spacing: -0.64px;
    em {font-style:normal;font-weight:400;}
    &.purple{
      color:#6e58ff;
    }
    &.blue{
      color: #4063ec;
    }
    &.green{
      color: #1ccdcc;
    }
    &.red{
      color: #ee1a1a;
    }
    &.black{
      color: #222;
    }
    &.gray{
      color: #707070;
    }
  }
  .sub_tit {
    .MuiTypography-root {
      font-size: 28px;
      font-weight: 700;
      line-height: 1.71;
      letter-spacing: -1.12px;
    }
  }
  .MuiList-root {
    //margin-top: 20px;
    padding-top: 0;
    border-top: 1px solid #1f2437;
    .MuiListItem-root {
      padding: 30px 20px;
      border-bottom: 1px solid #e0e0e0;
      // &:last-child {
      //   border: none;
      // }
    }
  }
  .css-w4z10b-MuiStack-root {
    display: inline-block;
    .MuiChip-root {
      border-radius: 5px;
      .MuiChip-label {
        padding: 6px 10px;
      }
    }
    .new {
      background-color: #1ccdcc;
      color: #fff;
    }
    .blue {
      background-color: #4063ec;
      color: #fff;
    }
    .item{
      background-color: #f5f5f5;
    }
    .wh{
      background-color: #fff;
      border: 1px solid #ccc;
    }
  }
  .tit_body {
    display: flex;
    .MuiTypography-body1 {
      font-weight: 700;
      font-size: 20px;
      margin-bottom: 12px;
      color: #333;
      display: block;
      letter-spacing: -0.8px;
    }
  }
  .body2 {
    line-height: 1.75;
    letter-spacing: -0.64px;
    font-size: 16px;
    color: #707070;
    margin-bottom: 15px;
  }
  .body3{
    display: inline-block;
    margin-top: 20px;
    font-size: 14px;
    font-weight: normal;
    line-height: normal;
    letter-spacing: -0.56px;
    text-align: left;
    color: #707070;
    em{
      color: #222222;
    }
  }
  .MuiButton-root:hover {
    background-color: #ccc;
  }
  .MuiListItem-root {
    padding: 10px 0;
  }
  .Check_listbox {
    .MuiFormControl-root{
      width: 100%;
      .MuiFormGroup-root {
        .MuiFormControlLabel-root {
          flex: 0 0 12.1%;
          margin-left: 0;
          margin-right: 5px;
          height: 50px;
         align-items: flex-start;
        }
        .MuiCheckbox-root {
          padding: 5px 15px 0 0;
        }
        .MuiTypography-root {
          letter-spacing: -0.64px;
        }
      }
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .date{
      span{
        &+span{
          margin-left: 0;
          padding-left: 0;
          &:before{
            display:none;
          }
        }
      }
    }
    .right_btn {top:auto !important;right:15px !important;bottom:0;}
    .right_tag{
      position: relative;
      width:auto !important;
      left: 0;
      top: auto;
      right: auto !important;
      text-align: left !important;
      margin-top: 16px;
      transform: translateY(0);
    }
    .sub_tit {
      .MuiTypography-root {
        font-size: 24px;
        line-height: 1.6;
        letter-spacing: -0.96px;
      }
    }
    .MuiChip-root {
      .MuiChip-label {
        padding: 6px 10px;
      }
    }
    .MuiList-root {
      .MuiListItem-root {
        flex-wrap: wrap;
        padding: 23px 0;
      }
      .MuiListItemText-root {
        flex: 0 0 100%;
        padding: 0 15px;
      }
      .MuiListItemAvatar-root {
        flex: 0 0 100%;
        margin: 0 auto 10px;
        text-align: center;
        img {
          height: 230px;
        }
      }
    }
    .tit_body {
      display: flex;
      align-items: baseline;
      .MuiTypography-body1 {
        font-size: 16px;
        margin-bottom: 12px;
        padding-top: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-weight: 700;
      }
    }
    .body2 {
      font-size: 14px;
    }
    .body3{
      margin-top: 16px;
    }
    .Check_listbox {
      .MuiFormControl-root{
        .MuiFormGroup-root {
          .MuiFormControlLabel-root {
            flex: 0 0 48%;
            height: 40px;
          }
          .MuiCheckbox-root {
            padding: 3px 10px 0 0;
          }
          .MuiTypography-root {
            letter-spacing: -0.56px;
            font-size: 14px;
            line-height: 1.8;
          }
        }
      }
    }
  }
`;


export const teble_detal = css`
  text-align: right;
  max-width: 780px;
  margin: 0 auto;
  margin-top: 20px;
  width: 100%;
  overflow: hidden;
  height: 180px;
`;

export const table02 = css`
  display: flex;
  height: 181px;
  border-radius: 15px;
  overflow: hidden;
  .MuiTableCell-root {
    border: 0;
    padding: 0;
  }
  dl {
    flex: 1;
    &:first-of-type {
      dd, dt {
        border-left: none;
      }
    }
    dt {
      font-weight: 700;
      letter-spacing: -0.72px;
      padding: 12px;
      font-size: 18px;
      line-height: 1.4;
      text-align: center;
      border-bottom: 1px solid ${Color.line};
      border-left: 1px solid ${Color.line};
    }
    dd {
      margin-left: 0;
      text-align: left;
      display: inline-block;
      width: 100%;
      border-left: 1px solid ${Color.line};
      letter-spacing: -0.64px;
      padding: 6px;
      .box_scroll{
        padding: 12px 14px 0 14px;
        height: 120px;
        overflow: auto;
        &::-webkit-scrollbar {
          width: 5px;
          padding: 5px;
        }
        &::-webkit-scrollbar-thumb {
          background-color: #d7dae6;
          border-radius: 10px;
          width: 3px;
        }
        &::-webkit-scrollbar-track {
          background-color: ${Color.white};
          border-radius: 10px;
          width: 10px;
        }
      }
      .MuiFormControl-root{
        width: 100%;
        .MuiFormControlLabel-root{
          flex: 0 0 48%;
          margin: 0;
          margin-bottom: 10px;
          &:nth-of-type(2n){padding-left:20px;}
          /* &:nth-last-of-type(-n + 2){
            margin-bottom: 0;
          } */
        }
      }
      > div {
        margin-bottom: 10px;
      }
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .table_form {
      th {
        font-size: 14px;
        letter-spacing: -0.56px;
      }
      td {
        padding: 10px;
      }
    }
    .MuiTableCell-root {
      padding: 8px;
    }
  }
`;


export const sub_cont02 = css`
  background-color: #fff;
  color: #333;
  .MuiTypography-h5 {
    height: auto;
    font-family: Noto Sans CJK KR;
    font-size: 28px;
    font-weight: 700;
    line-height: 1;
    letter-spacing: -1.12px;
    margin-bottom: 20px;
  }
  .md_btn {
    color: #333;
    border: 1px solid #333;
    width: 220px;
    height: 55px;
    border-radius: 0;
    margin-top: 10px;
  }
  .data {
    height: 24px;
    font-size: 16px;
    font-style: normal;
    line-height: 3;
    letter-spacing: -4px;
    margin-left: 10px;
    > em {
      height: 19px;
      font-size: 16px;
      font-weight: 700;
      letter-spacing: -0.64px;
      color: #4063ec;
    }
  }
  .MuiSelect-select {
    padding: 8px 40px 8px 20px;
    margin-right: 10px;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .MuiTypography-h5 {
      font-size: 22px;
      margin-bottom: 10px;
    }
    .MuiSelect-select {
      font-size: 14px;
    }
  }
`;


// 버튼속성그룹
export const btnGroup = css`
  justify-content: center;
  margin-top: 60px;
  > button {
    height: 60px;
    border-radius: 40px;
    width: 220px;
    font-size: 18px;
    font-weight: 700;
    line-height: 1.5;
    background-color: #fff;
    padding: 17px 36px;
    &.blue {
      background-color: #4063ec;
      width: 100%;
      color: #fff;
    }
    &.linebtn {
      border: 1px solid #4063ec;
      background-color: #fff;
      &.mini {
        width: 140px;
      }
    }
    &.linebtn02 {
      border: 1px solid #222;
      color: #222;
      background-color: #fff;
    }
    &.blue02 {
      background-color: #4063ec;
      color: #fff;
      min-width: 140px;
      width: auto;
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    > button {
      font-size: 16px !important; 
      &.blue02 {
        width: 100%;
        height: 52px;
      }
    }
  }
`;
export const modalpop = css`
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 100%;
  max-width: 780px;
  background-color: #fff;
  box-shadow: 24;
  padding: 24px 15px 20px;
  border-radius: 20px 20px 0 0;
  h2 {
    font-size: 20px;
    font-weight: 700;
    > button {
      color: #707070;
      position: absolute;
      right: 20px;
    }
  }
  h3 {
    font-size: 16px;
    font-weight: 700;
  }
  .MuiTabs-indicator{
    background-color: #000;
  }
  .css-275fjj-stylesFactory {
    position: relative;
    max-width: 470px;
    margin: 30px auto 0;
    .MuiFormControlLabel-root {
      right: 0;
      top: 0;
      position: absolute;
    }
    .MuiCheckbox-root {
      padding: 0 5px 0 0;
    }
  }
`;

// 더보기 버튼 컴포넌트랑 같이
export const bottom_btn = css`
  button{
    &:after {
      content: '';
      background: url('/images/common/arr_row.png') no-repeat;
      width: 12px;
      height: 8px;
      margin-left: 10px;
    }
  }
`;

export const btnstyle = css`
  button {
    border-radius: 0;
    font-weight: 700;
    font-size: 16px;
    padding: 16px 36px;
    letter-spacing: -0.4px;
  }
  button.lg {
    min-width: 200px;
  }
  button.md {
    border-radius: 4px;
    font-weight: normal;
    padding: 8px 16px;
  }
  .blue {
    background-color: #4063ec;
  }
  .gray {
    background-color: #adaeb2;
  }
  .gray:hover {
    background-color: #9b9b9b;
  }
  .sky {
    background-color: #ebeffd;
    color: #4063ec;
  }
  .sky:hover {
    background-color: #d4deff;
  }
`;
export const picker_card = css`
  display: flex;
  max-width: 780px;
  margin: 20px auto 0;
  background-color: #fff;
  border-radius: 10px;
  border: solid 1px #e0e0e0;
  color: #333;
  text-align: center;
  dl {
    border-right: 1px solid #e0e0e0;
    width: 100%;
    &:last-of-type{
      border: none;
      dd{
        .MuiFormGroup-root{
          margin-bottom: -10px;
        }
      }
    }
    dt{
      border-bottom: 1px solid #e0e0e0;
      font-size: 18px;
      padding: 14px 0;
      font-weight: 700;
      letter-spacing: -0.72px;
    }
    dd{
      text-align: center;
      margin-left: 0;
      display: inline-block;
      padding: 6px;
      width: 100%;
      .box_scroll{
        padding: 14px;
        max-height: 120px;
        overflow-y: auto;
        &::-webkit-scrollbar {
        width: 6px;
        }
        &::-webkit-scrollbar-track {
          background-color: transparent;
        }
        &::-webkit-scrollbar-thumb {
          background-color: #d7dae6;
          border-radius: 10px;
        }
        &::-webkit-scrollbar-button {
          width: 0;
          height: 0;
        }
      }
      .MuiFormControl-root{
        width: 100%;
        .MuiFormControlLabel-root{
          flex: 0 0 48%;
          margin: 0;
          margin-bottom: 10px;
          &:nth-of-type(2n){padding-left:20px;}
          /* &:nth-last-of-type(-n + 2){
            margin-bottom: 0;
          } */
        }
      }
      .MuiInputBase-root{
        height: 48px;
      }
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    border: none;
    flex-direction: column;
    .MuiInputBase-root{
      height: 46px;
    }
    dl {
      border: none;
      dt{
        border-bottom: none;
        font-size: 16px;
        padding: 10px 0;
        text-align: left;
      }
      dd{
        padding: 16px 0 0;
        margin-bottom: 16px;
      }
    }
  }
`;


export const inputBox = css`
  position: relative;
  display: flex;
  flex-direction: column;
  margin-bottom: 40px;
  border:1px solid #ccc;
  
  .inputtxt{
    font-family: Noto Sans CJK KR;
    font-size: 18px;
    margin-bottom: 10px;
    line-height: 1.67;
    letter-spacing: -0.72px;
    font-weight: 700;
    & em{
      color: #1ccdcc;
      margin-left: 4px;
    }
  }
  label{
    color: #222;
    &.Mui-focused {
      color: #222;
    }
  }
  .MuiOutlinedInput-root {
    color: #222;
    fieldset {
      border-color: #ccc;
    }
    &:hover{
      fieldset {
        border-color: #1976d2;
      }
    }
  }
  .MuiFormLabel-asterisk{
    color: #1CCDCC;
  }
  textarea{
    &::-webkit-scrollbar {
      width: 8px;
    }
    &::-webkit-scrollbar-thumb {
      background-color: #d7dae6;
      border-radius: 10px;
    }
    &::-webkit-scrollbar-track {
      background-color: #fff;
      border-radius: 10px;
    }
    > div {
      margin-bottom: 10px;
    }
    .MuiRadio-root {
      padding: 5px;
    }
    .MuiFormControlLabel-root{
      margin-right: 0;
      margin-bottom: 10px;
      padding-left: 5px;
    }
  }
  .count{
    margin-top: 8px;
    text-align: right;
    font-size: 16px;
    color: #666;
    font-weight: normal;
    letter-spacing: normal;
  }
  Button{
    margin: 0;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    margin-bottom: 25px;
    label{
      font-size: 14px;
    }
    input {
      padding: 15px 14px;
    }
    .inputtxt{
      font-size: 16px;
    }
    .css-7gyhhp-MuiStack-root-deletTag>:not(style)+:not(style) {
        margin-left: 0;
    }
  }
`;
export const deletTag = css`
  flex-wrap: wrap;
  > :not(style)+:not(style){
    margin-left: 0;
    margin-right: 10px;
    margin-top: 5px;
  }
  Button{
    &:first-of-type{
      margin-left: 0;
    }
  }
  .MuiChip-root{
    height: 48px;
    border-radius: 30px;
    padding: 0 15px;
    border: 1px solid #ccc;
  }
  .MuiChip-label{
    padding-right: 16px;
    line-height: 1;
    font-size: 14px;
    height: 17px;
  }
  .css-1e6alsu-MuiButtonBase-root-MuiChip-root .MuiChip-deleteIcon{
    margin-top: 2px;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    Button{
      &:first-of-type{
        margin-left: 0;
        display: block;
        margin-right: 70%;
      }
    }
    .MuiChip-root{
      &:first-of-type{
        margin-left: 0;
      }
    }
    .MuiChip-label{
      padding-right: 10px;
    }
  }
`;
export const tooltip = css`
  padding-bottom: 20px;
  .MuiTypography-body1{font-size:16px !important;}
  @media (min-width: 320px) and (max-width: 768px) { 
    .MuiTypography-body1{font-size:14px !important;}
  }
  .MuiTypography-root{
    margin: 0;
    padding-bottom: 0;
    font-weight: 400 !important;
  }
  .MuiIconButton-root{
    margin:0 0 0 1px;
    padding:0 0 0 5px;
    .icon_question{
      width:18px;
      height: 18px;
      background: url('/images/common/icon_question_off.png') no-repeat center;
    }
    &:hover{
      .icon_question{
        background-image: url('/images/common/icon_question_on.png');
      }
    }
  }
`;

export const btn_next = css`
  @media (min-width: 320px) and (max-width: 768px) {
    button,a{
      font-size: 16px !important;
      width: 100% !important;
      height: 52px !important;
      min-width: 104px;
    }
  }
  
`;

export const objection_content = css`
  line-height: 26px;padding:21px 20px;border-top:1px solid #1f2437;border-bottom:1px solid #e0e0e0;font-weight:300;
  `

export const table = css`
  max-width: 100%;
  letter-spacing: -0.64px;
  .MuiTypography-h6{
    font-size: 18px;
    margin-bottom: 15px;
  }
  .detail_table{
    border-top: 1px solid #1f2437;
    margin-bottom: 40px;
  }
  dl {
    display: flex;
    border-spacing: 0;
    width: 100%;
    & .noline{
      border-bottom: none;
    }
    dt {
      display: flex;
      align-items: center;
      flex: 0 0 220px;
      padding: 20px 20px;
      text-align: left;
      background-color: #f5f5f5;
      border-bottom: 1px solid #e0e0e0;
      font-weight: 500;
      &.wh{
        background-color: #fff;
      }
    }
    dd {
      flex: 1;
      display: flex;
      justify-content: space-between;
      padding: 7px 20px;
      line-height: 1.75;
      align-items: center;
      border-bottom: 1px solid #e0e0e0;
      margin-left: 0;
      font-weight: 400;
      .MuiOutlinedInput-notchedOutline{
        border-color: #ccc;
      }
      &.withLink{
        justify-content: flex-start;
        gap:10px;
        a {padding-right:15px;color:#4063ec;font-weight:400;background:url(/images/common/gt_blue.png) no-repeat right center;}
      }
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .MuiTypography-h6{
      font-size: 16px;
      margin-bottom: 10px;
    }
    .detail_table{
      margin-bottom: 30px;
      .MuiOutlinedInput-root{height:48px}
    }
    .MuiFormControl-root{width:100%;}
    .MuiFormGroup-root{justify-content: space-around;}
    .MuiFormControlLabel-root{margin-right:0;}
    dl {
      flex-wrap: wrap;
      font-size: 14px;
      dt {
        flex: 0 0 35%;
        line-height: 26px;
        padding: 19px 0 19px 10px;
      }
      dd {
        flex: 0 0 65%;
        padding: 10px 0 10px 10px;
      }
      &.horz{
        flex-direction: column;
        dt{
          border-bottom: 0;
          justify-content: center;
        }
        dd{
          padding:0 8px;
        }
      }
    }
    .type2{
    }
  }
`;

// 파일 다운로드 버튼
export const btnDown = css`
  justify-content: center;
  flex-direction: row;
  button {
    min-width: 124px;
    height: 48px;
    border-radius: 24px;
    padding: 14px 20px;
    font-size: 14px;
    line-height: 1.5;
    background-color: #fff;
    border: solid 1px #ccc;
    color: #333;
    letter-spacing: -0.56px;
    > span {
      max-width: 200px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    &:before {
      content: '';
      width: 20px;
      height: 20px;
      margin-right: 6px;
      background: url('/images/common/icon_download.png') no-repeat;
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    button {
      > span {
        max-width: 200px;
      }
    }
  }
`;
export const fileupload = css`
  padding-bottom: 30px;
  border-bottom:1px solid #e0e0e0;
  >div{
    flex-wrap: wrap;
    justify-content: left;
  }
`;
export const box_graylist = css`
  padding: 30px;
  border-radius: 5px;
  background-color: #f5f5f5;
  margin-bottom: 40px;
  line-height: 28px;
  .terms{margin-top:14px;font-weight:400;}
  @media (min-width: 320px) and (max-width: 768px) {
    padding: 15px;
  }
`;

export const attatchedFile = css`
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  padding:20px 20px;
  background-color: #f5f5f5;
  border-radius: 10px;
  >div{
    justify-content: left;
    &:first-of-type{padding-left:0;}
    padding-left:6px;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    flex-direction: column;
    margin:0 -15px;
    padding:20px 15px 10px;
    border-radius: 0;
    >div{
      padding-left:0;
      button{
        margin:0 0 10px 0;
      }
      &:first-of-type{
        button{margin-top:0;}
      }
    }
  }
`