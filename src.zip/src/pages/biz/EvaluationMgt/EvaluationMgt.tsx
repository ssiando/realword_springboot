// 평가관리 -> 평가관리
// import React from "react"
import * as styles from './styles';
import {CssBaseline,Container} from '@mui/material';
// import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
function EvaluationMgt() {

  return (
      <Container component="main" maxWidth="xs">
        <CssBaseline />
        <h1>평가관리</h1>
      </Container>
  );
}

export default EvaluationMgt;