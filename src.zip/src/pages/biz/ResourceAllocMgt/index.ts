// export { default } from './ResourceAllocMgt';
export { default as ResourceAllocDet } from './ResourceAllocDet';