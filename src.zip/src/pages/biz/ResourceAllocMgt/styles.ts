import { css } from '@emotion/react';

export const tagstyle = css`
  position: relative;
  justify-content: space-between;
  width: 100%;
  margin-bottom: 10px;
  .MuiChip-root {
    margin-left: 10px;
    border-radius: 5px;
    &:first-of-type {
      margin-left: 0;
    }
  }
  .wh {
    background-color: #fff;
    color: #333;
  }
  .blue {
    background-color: #4063ec;
    color: #fff;
  }
  .green {
    background-color: #1ccdcc;
    color: #fff;
  }
`;

export const qna_list = css`
  margin: 0 auto;
  max-width: 1260px;
  .sub_tit {
    .MuiTypography-root {
      font-size: 28px;
      font-weight: 700;
      line-height: 1.71;
      letter-spacing: -1.12px;
    }
  }
  .MuiList-root {
    //margin-top: 20px;
    padding-top: 0;
    border-top: 1px solid #1f2437;
    .MuiListItem-root {
      padding: 30px 20px;
      border-bottom: 1px solid #e0e0e0;
      // &:last-child {
      //   border: none;
      // }
    }
  }
  .tit_body {
    display: flex;
    flex-direction: row;
    align-items: center;
    .MuiTypography-body1 {
      letter-spacing: -0.64px;
      font-size: 16px;
      color: #222;
      flex: 1;
    }
    .MuiTypography-body2 {
      font-weight: 700;
      font-size: 20px;
      color: #222;
      display: block;
      flex: 3;
      &:before {
        content: 'Q';
        font-family: Roboto;
        width: 15px;
        margin-right: 10px;
        display: inline-block;
        font-size: 22px;
        font-weight: 700;
        letter-spacing: -0.88px;
        color: #4063ec;
      }
    }
  }
  .MuiButton-root:hover {
    background-color: #ccc;
  }
  .MuiListItem-root {
    padding: 10px 0;
  }
  .MuiListItemText-root {
    padding-right: 80px;
  }
  
  @media (min-width: 320px) and (max-width: 768px) {
    .sub_tit {
      .MuiTypography-root {
        font-size: 22px;
        line-height: 1;
        letter-spacing: -0.96px;
      }
    }
    .MuiList-root {
      .MuiListItem-root {
        flex-wrap: wrap;
        padding: 15px 0;
      }
      .MuiListItemText-root {
        flex: 0 0 100%;
      }
      .MuiListItemAvatar-root {
        flex: 0 0 100%;
        margin: 0 auto 10px;
        text-align: center;
        img {
          height: 230px;
        }
      }
    }
    .tit_body {
      display: flex;
      align-items: baseline;
      .MuiTypography-body1 {
        font-size: 14px;
        > span {
          margin-bottom: 10px;
        }
      }
      .MuiTypography-body2 {
        font-size: 16px;
        padding-top: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        &:before {
          content: 'Q';
          font-family: Roboto;
          width: 15px;
          margin-right: 6px;
          display: inline-block;
          font-size: 16px;
          font-weight: 700;
          letter-spacing: -0.88px;
          color: #4063ec;
        }
      }
    }
  }
`;


export const login_cont = css`
  max-width: 460px;
  margin: 0 auto;
  .mt40{
    margin-top: 40px;
  }
  .input_form{
    dl{
      display: flex;
      height: 48px;
      margin-top: 100px;
      margin-bottom: 10px;
      align-items: center;
      max-width: 100%;
      dt{
        flex: 0 0 30%;
      }
      dd{
        flex: 0 0 60%;
        margin: 0;
        .MuiOutlinedInput-root{
          height: 48px;
          min-width: 100%;
        }
      }
    }
  }
  .txt_line{
    display: flex;
    color: #e0e0e0;
    margin: 40px 0;
    hr{
      border-top: 1px solid #e0e0e0;
      flex: 1;
      border-bottom: 0;
    }
    span{
      display: inline-block;
      margin: 0 10px;
      height: 24px;
      width: 32px;
      letter-spacing: -0.64px;
    }
  }
`;

export const step03 = css`
  max-width: 400px;
  margin: 30px auto 0;
  align-items: center;
  .MuiStepLabel-label{
    letter-spacing: -1.4px;
  }
  .MuiStep-root{
    padding: 0;
    width: 110px;
    .Mui-active{
      color: #1CCDCC;
      border: none;
    }
    .Mui-completed{
      color: #707070;
      border: none;
      .MuiStepConnector-line{
        border-color: #000;
      }
    }
    .Mui-disabled{
      color: #ccc;
      .MuiStepIcon-root{
        border: 1px solid #fff;
        border-radius: 50px;
        color: rgba(0, 0, 0, 0);
      }
    }
  }
  .MuiStepConnector-root{
    left: calc(-50% + 17px);
    right: calc(50% + 17px);
    top: 17px;
  }
  .MuiStepIcon-root{
    width: 34px;
    height: 34px;
    &.Mui-completed{
      color: #000;
    }
    &.Mui-active{
      color: #1CCDCC;
    }
  }
  .MuiStepIcon-text{
    font-size: 0.6rem;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    max-width: 100%;
    .css-nen11g-MuiStack-root{
      flex-direction: column;
    }
  }
`;

export const input_w = css`
  position: relative;
  max-width: 780px;
  margin: 0 auto;
  padding-top: 40px;
  .select_plus{
    .MuiTextField-root {
      .MuiOutlinedInput-root{
        padding: 7.5px 4px 7.5px 110px;
      }
    }
  }
  .input_select{
    position: absolute;
    z-index: 2;
    margin: 2px;
    .MuiOutlinedInput-root{
      height: 56px;
      border: none;
    }
    .MuiOutlinedInput-notchedOutline{
      border: none;
    }
  }
  .MuiOutlinedInput-root {
    background-color: #fff;
    border-radius: 30px;
    height: 60px;
    width: 100%;
  }
  .MuiInputLabel-root {
    line-height: 1.8em;
    padding-left: 30px;
    color: #707070;
  }
  .Mui-ficused {
    display: none;
    .MuiInputLabel-root {
      display: none;
      font-size: 0;
    }
    .MuiOutlinedInput-root {
      font-size: 0;
    }
  }
  .MuiAutocomplete-root {
    width: 100%;
  }
  .css-16awh2u-MuiAutocomplete-root
    .MuiOutlinedInput-root
    .MuiAutocomplete-input {
    padding: 7.5px 4px 7.5px 30px;
    font-family: Noto Sans CJK KR;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    padding: 32px 0 0;
    .MuiOutlinedInput-root {
      height: 50px;
    }
    .css-16awh2u-MuiAutocomplete-root
      .MuiOutlinedInput-root
      .MuiAutocomplete-input {
      padding: 5px 4px 8px 15px;
      font-size: 14px;
    }
  }
`;
export const detal_btn = css`
  max-width: 780px;
  margin: 0 auto;
  text-align: center;
  button {
    margin-top: 20px;
    background-color: rgba(0 0 0 /0);
    color: #fff;
    border: none;
    font-size: 14px;
    border-radius: 0;
    line-height: 1;
    text-decoration: underline;
  }
`;

export const teble_detal = css`
  text-align: right;
  max-width: 780px;
  margin: 0 auto;
  margin-top: 20px;
  width: 100%;
  overflow: hidden;
`;

export const table02 = css`
  display: flex;
  height: 210px;
  border-radius: 15px;
  overflow: hidden;
  .MuiTableCell-root {
    border: 0;
    padding: 0;
  }
  dl {
    flex: 1;
    &:first-of-type {
      dd, dt {
        border-left: none;
      }
    }
    dt {
      font-weight: 700;
      letter-spacing: -0.72px;
      padding: 12px;
      font-size: 18px;
      line-height: 1.4;
      text-align: center;
      border-bottom: 1px solid #e0e0e0;
      border-left: 1px solid #e0e0e0;
    }
    dd {
      margin-left: 0;
      text-align: left;
      border-left: 1px solid #e0e0e0;
      letter-spacing: -0.64px;
      padding: 6px;
      .box_scroll{
        padding: 14px;
        height: 166px;
        overflow: auto;
        &::-webkit-scrollbar {
          width: 5px;
          padding: 5px;
        }
        &::-webkit-scrollbar-thumb {
          background-color: #d7dae6;
          border-radius: 10px;
          width: 3px;
        }
        &::-webkit-scrollbar-track {
          background-color: #fff;
          border-radius: 10px;
          width: 10px;
        }
      }
      > div {
        margin-bottom: 10px;
      }
      .MuiRadio-root {
        padding: 5px;
      }
      .MuiFormControlLabel-root{
        margin-right: 0;
        margin-bottom: 10px;
        padding-left: 10px;
      }
      .MuiFormGroup-root{
        flex-direction: column;
      }
    }
  }
  .MuiCheckbox-root {
    padding: 0;
    margin-right: 10px;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .table_form {
      th {
        font-size: 14px;
      }
      td {
        padding: 10px;
      }
    }
    .MuiTableCell-root {
      padding: 8px;
    }
  }
`;

export const bread = css`
  position: relative;
  max-width: 1260px;
  margin: 0 auto;
  .css-1wuw8dw-MuiBreadcrumbs-separator {
    color: #707070;
  }
  ol {
    position: absolute;
    top: 30px;
    right: 0;
    justify-content: flex-end;
  }
  .home {
    display: block;
    width: 15px;
    height: 15px;
    background: url('/images/common/home.png') no-repeat;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    display: none;
  }
`;

export const detal_tab = css`
  background-color: #1f2437;
  width: 100%;
  &.fixed{
    position: relative;
    top: 335px;
    .back{
      background-color: #1f2437;
      width:100%;
      position: fixed;
      top: 217px;
      z-index: 2;
    }
  }
  .back{
    top: 250px;
    transition: 0.5s;
  }
  .MuiTabs-indicator{
    display: none;
  }
  .MuiBox-root {
    padding: 0;
  }
  .MuiTabs-root {
    max-width: 1260px;
    margin: 0 auto;
  }
  .MuiTabs-flexContainer {
    .MuiButtonBase-root {
      display: flex;
      padding: 11px 32px 15px;
      font-family: Noto Sans CJK KR;
      line-height: 1;
      border-radius: 10px 10px 0 0;
      color: #707070;
      background-color: #e0e0e0;
      border-right: 1px solid #000;
      flex-direction: row;
      letter-spacing: -0.64px;
      font-weight: 700;
      align-items: flex-end;
      >span{
        font-size: 16px;
      }
      > em{
        margin-left: 4px;
        font-size: 13px;
      }
    }
    .Mui-selected {
      color: #222;
      background-color: #fff;
      > em{
        color: #4063ec;
      }
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .MuiTabs-flexContainer {
      padding: 0 15px;
      > button {
        flex: 1;
        font-size: 16px;
      }
    }
    .MuiTabs-flexContainer {
    .MuiButtonBase-root {
      font-size: 14px;
    }}
    .MuiTabs-root {
      min-height: 40px;
    }
    &.fixed{
    top: 250px;
    .back{
      top: 80px;
    }
  }
  }
`;

export const clause_check = css`
  font-size: 16px;
  letter-spacing: -0.64px;
  flex-direction: row;
  align-items: center;
  .point_txt{
    font-size: 14px;
    line-height: 2;
    letter-spacing: -0.56px;
    color: #1ccdcc;
    
  }
  .MuiFormControlLabel-root{
    margin-left: -10px;
    margin-right: 2px;
    .MuiFormControlLabel-label{
      font-weight: 700;
    }
  }
`;
// 약관박스
export const clause_Box = css`
  height: 401px;
  margin: 0 0 3px;
  padding: 16px 6px 25px 16px;
  border-radius: 20px;
  border: solid 1px #ccc;
  margin-top: 2px; 
  overflow: hidden;
  .scroll{
    overflow: auto;
    height: 400px;
    &::-webkit-scrollbar {
      width: 5px;
    }
    &::-webkit-scrollbar-thumb {
      background-color: #d7dae6;
      border-radius: 10px;
    }
    &::-webkit-scrollbar-track {
      background-color: #fff;
      border-radius: 10px;
    }
  }
  > div {
    margin-bottom: 10px;
  }
  .MuiRadio-root {
    padding: 5px;
  }
  .MuiFormControlLabel-root{
    margin-right: 0;
    margin-bottom: 10px;
    padding-left: 5px;
  }
  .MuiTypography-h6 {
    font-size: 16px;
    font-weight: 700;
    line-height: 1;
    letter-spacing: -0.64px;
    margin-bottom: 16px;
  }
  p{
    font-size: 14px;
    font-weight: 700;
    line-height: 1.14;
    letter-spacing: -0.56px;
    text-align: left;
    color: #222;
    margin-bottom: 8px;
    margin-top: 35px;
    &.fisttit{
      margin-top: 16px;
    }
  }
  .text_box{
    color: #707070;
    font-size: 14px;
    line-height: 1.71;
    letter-spacing: -0.14px;
    font-weight: normal;
    ul{
      li{
        margin-left: 20px;
      }
    }
  }
`;

export const sub_list = css`
  margin-top: 60px;
  .css-w4z10b-MuiStack-root {
    .MuiChip-root {
      border-radius: 5px;
      .MuiChip-label {
        padding: 6px 10px;
      }
    }
    .new {
      background-color: #1ccdcc;
      color: #fff;
    }
    .blue {
      background-color: #4063ec;
      color: #fff;
    }
  }
  .MuiList-root {
    width: 100%;
    height: 100%;
    .MuiListItemText-root {
      position: relative;
      flex: 0 0 70%;
      margin: 0;
    }
  }
  .MuiTypography-body1 {
    display: block;
    font-weight: 700;
    font-size: 20px;
    margin-bottom: 5px;
    padding-top: 10px;
    color: #333;
  }
  .MuiTypography-body2 {
    .body2 {
      font-family: Noto Sans CJK KR;
      line-height: 1.75;
      letter-spacing: -0.64px;
      font-size: 16px;
      display: block;
      color: #707070;
      margin-bottom: 15px;
    }
    .MuiTypography-root{
      display: block;
      margin-bottom: 15px;
    }
  }
  .MuiButton-root:hover {
    background-color: #ccc;
  }
  .MuiListItem-root {
    padding: 10px 0;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    margin-top: 40px;
    .MuiChip-root {
      margin-top: 10px;
      .MuiChip-label {
        padding: 6px 10px;
      }
    }
    .MuiList-root {
      .MuiListItem-root {
        margin-bottom: 20px;
        flex-wrap: wrap;
      }
      .MuiListItemText-root {
        flex: 0 0 100%;
      }
      .MuiListItemAvatar-root {
        flex: 0 0 100%;
        margin: 0 auto 10px;
        img {
          height: 230px;
        }
      }
    }
    .MuiTypography-body1 {
      font-size: 18px;
      margin-bottom: 12px;
      padding-top: 20px;
    }
    .MuiTypography-body2 {
      font-size: 14px;
      > span {
        margin-bottom: 0;
      }
    }
  }
  .css-11k5jid-MuiStack-root > :not(style) + :not(style) {
    margin: 0;
  }
`;
export const slide_cont02 = css`
  .swiper-button-prev,
  .swiper-button-next {
    display: none;
  }
  .swiper-container {
    padding: 10px 0 50px;
  }
  .swiper-pagination-bullets {
    position: absolute;
    bottom: 0;
    display: block;
    z-index: 99;
    width: 100%;
    text-align: center;
    height: 20px;
    .swiper-pagination-bullet {
      display: inline-block;
      width: 60px;
      height: 2px;
      background-color: #ccc;
      margin-right: 10px;
      opacity: 1;
      border-radius: 0;
    }
    .swiper-pagination-bullet-active {
      background-color: #1ccdcc;
    }
  }
  .MuiCard-root-hotslide .MuiTypography-root {
    color: #000;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .swiper-pagination-bullets {
      display: none;
      .swiper-pagination-bullet {
        width: 40px;
      }
    }
  }
`;
export const hotslide = css`
  display: flex;
  background-color: rgba(0, 0, 0, 0);
  border-radius: 15px;
  color: #fff;
  max-width: 380px;
  box-shadow: none;
  // box-shadow: 0px 2px 3px 1px rgb(0, 0, 0, 0.3);
  .black {
    color: #222;
  }
  .MuiCardContent-root {
    padding: 16px 3px;
  }
  .sub_txt {
    color: #8f929b;
    line-height: 1;
    font-size: 14px;
    margin: 7px 0;
  }
  .MuiTypography-root {
    font-weight: 700;
    font-size: 20px;
    letter-spacing: -1.2px;
    color: #333;
    margin-bottom: 16px;
  }
  .tag {
    position: absolute;
    top: 0;
    z-index: 2;
    justify-content: space-between;
    width: 100%;
    border: solid 1px var(--pinkish-grey);
    .wh {
      background-color: #fff;
      color: #333;
      border-radius: 0 15px 0 10px;
    }
    .blue {
      background-color: #4063ec;
      color: #fff;
      border-radius: 15px 0 10px 0;
    }
  }
  .MuiCardActionArea-root {
    > img {
      border-radius: 15px;
      border: solid 1px rgba(204, 204, 204, 0.35);
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .MuiTypography-h5 {
      font-size: 22px;
    }
    .MuiSelect-select {
      font-size: 14px;
    }
    .MuiTypography-root {
      font-size: 16px;
    }
    .swiper-pagination-bullets {
      .swiper-pagination-bullet {
        width: 40px;
      }
    }
  }
`;
// 모달부분
export const modalCard = css`
  display: flex;
  background-color: rgba(0, 0, 0, 0);
  border-radius: 15px;
  color: #fff;
  max-width: 100%;
  box-shadow: none;
  .black {
    color: #222;
  }
  .MuiCardContent-root {
    padding: 16px 3px;
  }
  .sub_txt {
    color: #222;
    line-height: 1;
    font-size: 14px;
    margin: 7px 0;
    &.icon01 {
      &:before {
        content: '';
        width: 16px;
        height: 16px;
        margin-right: 10px;
        display: inline-block;
        background: url('/images/common/card_icon01.png') center bottom
          no-repeat;
      }
    }
    &.icon02 {
      &:before {
        content: '';
        width: 16px;
        height: 16px;
        margin-right: 10px;
        display: inline-block;
        background: url('/images/common/card_icon02.png') center center
          no-repeat;
      }
    }
    &.icon03 {
      &:before {
        content: '';
        width: 16px;
        height: 16px;
        margin-right: 10px;
        display: inline-block;
        background: url('/images/common/card_icon03.png') center center
          no-repeat;
      }
    }
  }
  .MuiTypography-root {
    font-weight: 700;
    font-size: 20px;
    letter-spacing: -1.2px;
    color: #333;
    margin-bottom: 16px;
  }
  .tag {
    position: absolute;
    top: 0;
    z-index: 2;
    justify-content: space-between;
    width: 100%;
    padding: 15px;
    .MuiChip-root {
      margin-left: 10px;
      border-radius: 5px;
      &:first-of-type {
        margin-left: 0;
      }
    }
    .wh {
      background-color: #fff;
      color: #333;
    }
    .blue {
      background-color: #4063ec;
      color: #fff;
    }
    .green {
      background-color: #1ccdcc;
      color: #fff;
    }
  }
  .MuiCardActionArea-root {
    > img {
      border-radius: 15px;
      border: solid 1px rgba(204, 204, 204, 0.35);
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .MuiTypography-h5 {
      font-size: 22px;
    }
    .MuiSelect-select {
      font-size: 14px;
    }
    .MuiTypography-root {
      font-size: 16px;
    }
    .swiper-pagination-bullets {
      .swiper-pagination-bullet {
        width: 40px;
      }
    }
  }
`;

export const detal_txtBox = css`
  padding-bottom: 30px;
  border-bottom: 1px solid #e0e0e0;
  text-align: center;
  line-height: 1.89;
  .MuiTypography-h5 {
    line-height: 1.71;
    font-size: 28px;
  }
  .text01 {
    margin-top: 32px;
    margin-bottom: 50px;
  }
  > p {
    font-size: 18px;
    margin: 0;
  }
  .bold {
    font-weight: 700;
  }
  .q_icon{
    color: #4063ec;
    font-size: 28px;
    font-family: Roboto;
    line-height: 1.71;
    letter-spacing: -1.12px;
    text-align: center;
    font-weight: 700;
    height: 34px;
    margin-bottom: 5px;
  }
  
  @media (min-width: 320px) and (max-width: 768px) {
    padding-bottom: 30px;
    margin-bottom: 30px;
    .MuiTypography-h5 {
      line-height: 1.5;
      font-size: 20px;
    }
    .text01 {
      margin-top: 24px;
      margin-bottom: 30px;
      font-size: 14px;
    }
    > p {
      font-size: 14px;
    }
  }
`;

export const box_gray = css`
  padding: 30px;
  border-radius: 5px;
  background-color: #f5f5f5;
  .MuiTypography-h3{
    font-size: 20px;
    font-weight: 700;
    line-height: 1.4;
    letter-spacing: -0.8px;
  }
  ul{
    li{
      padding: 0;
      margin-top: 5px;
      .MuiTypography-body2 {
        margin-top: 8px;
        &:before{
          content: '';
          display: inline-block;
          width: 4px;
          height: 4px;
          margin: 6px 8px 4px 0;
          background-color: #707070;
          border-radius: 10px;
        }
      }
    }
  }
`;

export const table01 = css`
  margin-top: 60px;
  margin-bottom: 63px;
  letter-spacing: -0.64px;
  table {
    border-top: 1px solid #222;
    width: 100%;
    border-spacing: 0;
    tr {
      display: flex;
      border-bottom: 1px solid #e0e0e0;
    }
    th {
      padding: 20px 20px;
      text-align: left;
      width: 20%;
      background-color: #f5f5f5;
    }
    td {
      width: 30%;
      padding: 18px 20px;
      &.table_input{
        padding: 6px 8px;
        .MuiInputBase-root{
          height: 48px;
        }
      }
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    overflow: scroll;
    margin-bottom: 40px;
    table {
      width: 200%;
      margin-bottom: 15px;
    }
  }
`;
export const table_02 = css`
  margin-top: 12px;
  table {
    border-top: 1px solid #1f2437;
    max-width: 540px;
    width: 100%;
    border-spacing: 0;
    text-align: center;
    tr {
      display: flex;
      border-bottom: 1px solid #e0e0e0;
    }
    th {
      padding: 18px 20px;
      background-color: #f5f5f5;
      width: 70%;
      text-align: center;
      &:first-of-type {
        width: 30%;
        border-right: 1px solid #e0e0e0;
      }
    }
    td {
      padding: 18px 20px;
      width: 70%;
      &:first-of-type {
        width: 30%;
        border-right: 1px solid #e0e0e0;
      }
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    overflow: scroll;
    margin-bottom: 40px;
    table {
      width: 200%;
      margin-bottom: 15px;
    }
  }
`;

export const table05 = css`
  max-width: 100%;
  letter-spacing: -0.64px;
  .MuiTypography-h6{
    font-size: 18px;
    margin-bottom: 15px;
  }
  .detail_table{
    border-top: 1px solid #1f2437;
    margin-bottom: 40px;
  }
  dl {
    display: flex;
    border-spacing: 0;
    width: 100%;
    & .noline{
      border-bottom: none;
    }
    dt {
      display: flex;
      align-items: center;
      flex: 0 0 220px;
      padding: 20px 20px;
      text-align: left;
      background-color: #f5f5f5;
      border-bottom: 1px solid #e0e0e0;
      &.wh{
        background-color: #fff;
      }
    }
    dd {
      flex: 1;
      display: flex;
      justify-content: space-between;
      padding: 18px 20px;
      line-height: 1.75;
      align-items: center;
      border-bottom: 1px solid #e0e0e0;
      margin-left: 0;
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .MuiTypography-h6{
      font-size: 16px;
      margin-bottom: 10px;
    }
    .detail_table{
      margin-bottom: 30px;
    }
    dl {
      flex-wrap: wrap;
      dt {
        flex: 0 0 30%;
        padding: 15px 18px;
      }
      dd {
        flex: 0 0 70%;
        padding: 15px 18px;
      }
    }
  }
`;

export const table04 = css`
  max-width: 100%;
  letter-spacing: -0.64px;
  .MuiTypography-h6{
    font-size: 18px;
    margin-bottom: 15px;
  }
  table, dl {
    border-top: 1px solid #222;
    border-spacing: 0;
    margin-bottom: 40px;
    width: 100%;
    & .noline{
      border-bottom: none;
    }
    & .table_input{
      padding: 6px 8px;
      .MuiInputBase-root{
        height: 48px;
      }
    }
    th, dt {
      height: 60px;
      padding: 20px 20px;
      text-align: left;
      background-color: #f5f5f5;
      border-bottom: 1px solid #e0e0e0;
      &.wh{
        background-color: #fff;
      }
      &.table_input{
        padding: 6px 8px 6px 0;
        .MuiInputBase-root{
          height: 48px;
        }
      }
    }
    td, dd {
      height: 60px;
      display: flex;
      justify-content: space-between;
      padding: 0 20px;
      line-height: 3.5;
      align-items: center;
      border-bottom: 1px solid #e0e0e0;
      margin-left: 0;
      .blue{
        color:#4063ec;
        &:after {
          content: '';
          width: 8px;
          height: 11px;
          margin-left: 9px;
          display: inline-block;
          background: url('/images/common/gt_blue.png') no-repeat;
        }
      }
      .MuiFormGroup-root{
        width: 250px;
        justify-content: space-between;
      }
      .ml8{
       margin-left: 8px; 
      }
    }
  }
  .blue{
    color:#4063ec;
    &:after {
      content: '';
      width: 8px;
      height: 11px;
      margin-left: 9px;
      display: inline-block;
      background: url('/images/common/gt_blue.png') no-repeat;
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    table {
      th {
      
      }
      td {
        
      }
    }
  }
`;

export const table03 = css`
  max-width: 940px;
  margin: 0 auto;
  letter-spacing: -0.64px;
  .MuiTypography-h6{
    font-size: 18px;
    margin-bottom: 15px;
  }
  table {
    border-top: 1px solid #222;
    width: 100%;
    border-spacing: 0;
    margin-bottom: 40px;
    tr {
      display: flex;
      border-bottom: 1px solid #e0e0e0;
    }
    th {
      padding: 20px 20px;
      text-align: left;
      width: 20%;
      background-color: #f5f5f5;
    }
    td {
      display: flex;
      justify-content: space-between;
      width: 80%;
      padding: 0 20px;
      line-height: 3.5;
      align-items: center;
      &.table_input{
        padding: 6px 8px;
        .MuiInputBase-root{
          height: 48px;
        }
      }
      .blue{
        color:#4063ec;
        &:after {
          content: '';
          width: 8px;
          height: 11px;
          margin-left: 9px;
          display: inline-block;
          background: url('/images/common/gt_blue.png') no-repeat;
        }
      }
      .MuiFormGroup-root{
        width: 250px;
        justify-content: space-between;
      }
    }
  }
  .blue{
    color:#4063ec;
    &:after {
      content: '';
      width: 8px;
      height: 11px;
      margin-left: 9px;
      display: inline-block;
      background: url('/images/common/gt_blue.png') no-repeat;
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    margin-bottom: 40px;
    table {
      margin-bottom: 15px;
      th {
      width: 40%;
      }
      td {
        width: 60%;
        &.table_input{
          padding: 6px 8px;
          .MuiInputBase-root{
            height: 48px;
          }
        }
      }
    }
  }
`;
export const memout = css`
  margin-top: 40px;
  text-align: right;
  a {
    &:after {
      content: '';
      width: 8px;
      height: 11px;
      color: #707070;
      margin-left: 9px;
      display: inline-block;
      background: url('/images/common/gt_gray.png') no-repeat;
    }
  }
`;

export const table06 = css`
  .MuiTableContainer-root{
    box-shadow: none;
    border-top: 1px solid #1f2437;
    border-radius: 0;
    th, td{
      border-right: 1px solid #e0e0e0;
      &:last-child{
        border-right: none;
      }
    }
    th{
      background-color: #f5f5f5;
      font-weight: 700;
    }
    td{
      padding: 20px;
    }
  }

`;
export const text_list01 = css`
  margin-bottom: 60px;
  dl {
    margin-bottom: 40px;
    dt {
      line-height: 1.67;
      letter-spacing: -0.72px;
      font-weight: 700;
      margin-bottom: 8px;
      font-size: 18px;
      &:before {
        content: '';
        display: inline-block;
        width: 6px;
        height: 6px;
        margin: 3px 10px 3px 0;
        border-radius: 100%;
        background-color: #707070;
      }
    }
    dd {
      margin-inline-start: 15px;
      line-height: 1.75;
      margin-left: 0;
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    margin-bottom: 40px;
    dl {
      dt {
        letter-spacing: -0.64px;
        margin-bottom: 8px;
        font-size: 16px;
        &:before {
          background-color: rgba(28, 205, 204);
        }
      }
      dd {
        font-size: 14px;
        line-height: 26px;
      }
    }
  }
`;

export const detal_img = css`
  margin-top: 20px;
  .img_box {
    width: 100%;
    min-height: 200px;
    height: auto;
    margin-bottom: 16px;
    background-color: #ccc;
    // back 색깔 임시
  }
  .txt_box {
    margin-top: 30px;
    margin-bottom: 60px;
    line-height: 1.63;
    letter-spacing: -0.64px;
  }
`;

//sns icon
export const snsicon = css`
  margin: 0 auto;
  width: max-content;
  button{
    border-radius: 50px;
    min-width:50px;
    width: 50px;
    height: 50px;
    background-color: #fff;
    &.kakao{background: url('/images/common/kakao_icon.png')}
    &.naver{background: url('/images/common/naver_icon.png')}
    &.google{background: url('/images/common/google_icon.png'); border: 1px solid #e0e0e0;}
  }
`;

//답변박스
export const qna_box = css`
  background-color: #f2f3f8;
  padding: 30px 40px;
  border-top: 1px solid #1f2437;
  dl{
    display: flex;
    &+ dl {
      margin-top: 10px;
    }
    dt {
      min-width: 62px;
      font-weight: 700;
      font-size: 18px;
      letter-spacing: -0.72px;
      &:before {
        content: '';
        width: 20px;
        height: 20px;
        margin-right: 6px;
        display: inline-block;
        background: url('/images/common/icon_gna.png') no-repeat;
      }
    }
    dd{
      margin-left: 62px;
      line-height: 1.75;
      letter-spacing: -0.64px;
      .date{
        margin-top: 33px;
      }
    }
  }
  
`;

export const sns_switch = css`
  border: 1px solid #e0e0e0;
  padding: 20px 33px 20px 20px;
  height: 90px;
  border-radius: 10px;
  width: 460px;
  font-family: Noto Sans CJK KR;
  .textbox{
    font-weight: 700;
    color: #222;
    line-height: 1.75;
    letter-spacing: -0.64px;
    
    em, span{
      color: #707070;
      font-weight: 300;
    }
    em{margin-left: 4px;}
  }
  .MuiFormControlLabel-root{
    margin-left: 0;
    width: 100%;
    justify-content: space-between;
  }
  .MuiSwitch-root{
    box-shadow: inset 1px 1px 3px 0 rgba(0, 0, 0, 0.2);
    width: 42px;
    height: 24px;
    padding: 0;
    border-radius: 12px;
    display: flex;
    &:active {
      & .MuiSwitch-thumb {
        width: 12px;
      }
      & .MuiSwitch-switchBase.Mui-checked {
        transform: translateX(18px);
      }
    }
    & .MuiSwitch-switchBase {
      padding: 6px;
      &.Mui-checked {
        transform: translateX(18px);
        color: #fff;
        & + .MuiSwitch-track {
          opacity: 1;
          background-color: #4063ec;
        }
      }
    }
    & .MuiSwitch-thumb {
      box-shadow: 1px 1px 3px 0 rgba(0, 0, 0, 0.2);
      width: 12px;
      height: 12px;
      border-radius: 12px;
    }
    & .MuiSwitch-track {
      border-radius: 16px;
      opacity: 1;
      background-color: #ccc;
      box-sizing: border-box;
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    width: 350px;
    padding: 15px;
    .textbox{
      margin-right: 20px;
    }
  }
`;

// 이전 다음 리스트 페이지네이션 버튼
export const bottom_list = css`
  margin-bottom: 40px;
  padding-top: 0;
  border-top: 1px solid #ccc;
  > a, .pagelist{
    display: flex;
    align-items: center;
    padding: 28px 20px;
    border-bottom: 1px solid #e0e0e0;
    .txt01 {
      margin-right: 48px;
    }
    .txt02 {
      margin: 0;
      font-weight: 400;
      font-size: 0.875rem;
      line-height: 1.43;
      letter-spacing: 0.01071em;
      color: rgba(0, 0, 0, 0.6);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
  .next {
    &:before {
      content: '';
      width: 15px;
      height: 10px;
      margin-right: 18px;
      display: inline-block;
      background: url('/images/common/arrow_next.png') no-repeat;
    }
  }
  .prev {
    &:before {
      content: '';
      width: 15px;
      height: 10px;
      margin-right: 18px;
      display: inline-block;
      background: url('/images/common/arrow_prev.png') no-repeat;
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    border-top: 1px solid #e0e0e0;
    > a, .pagelist{
      padding: 28px 15px;
      .txt01 {
        margin-right: 20px;
        min-width: 85px;
        font-size: 14px;
      }
      .txt02 {
        margin-right: 20px;
        min-width: 85px;
        font-size: 14px;
      }
    }
    button {
      min-width: 14px;
      height: 8px;
      margin-right: 15px;
      padding: 0;
    }
    .next, .prev {
      font-size: 14px;
    }
  }
`;

//sns 아이콘버튼
export const btnMinSns = css`
  justify-content: end;
  margin-top: 40px;
  > button {
    height: 40px;
    border-radius: 40px;
    min-width: 40px;
    &.face {
      background: url('/images/common/pace_icon_min.png') no-repeat;
    }
    &.kakao {
      background: url('/images/common/kakao_icon_min.png') no-repeat;
    }
    &.insta {
      background: url('/images/common/insta_icon_min.png') no-repeat;
    }
    &.nomal {
      padding: 11px 26px 10px;
      border-radius: 20px;
      border: 1px solid #ccc;
      font-size: 13px;
      font-weight: normal;
      line-height: 2;
      letter-spacing: -0.52px;
      color: #707070;
    }
    & + button {
      margin-left: 10px;
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    justify-content: center;
    > button {
      font-size: 16px;
    }
  }
`;

// 버튼속성그룹
export const btnGroup = css`
  justify-content: center;
  margin-top: 60px;
  > button {
    height: 60px;
    border-radius: 40px;
    width: 220px;
    font-size: 18px;
    font-weight: 700;
    line-height: 1.5;
    background-color: #fff;
    padding: 17px 36px;
    &.blue {
      background-color: #4063ec;
      width: 100%;
      color: #fff;
    }
    &.linebtn {
      border: 1px solid #4063ec;
      background-color: #fff;
      &.mini {
        width: 140px;
      }
    }
    &.linebtn02 {
      border: 1px solid #222;
      color: #222;
      background-color: #fff;
    }
    &.blue02 {
      background-color: #4063ec;
      color: #fff;
      min-width: 140px;
      width: auto;
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    > button {
      font-size: 16px !important; 
      &.blue02 {
        width: 100%;
        height: 52px;
      }
    }
  }
`;

export const table = css`
  max-width: 100%;
  letter-spacing: -0.64px;
  .MuiTypography-h6{
    font-size: 18px;
    margin-bottom: 15px;
  }
  .tbl_title{margin-top:48px;}
  .detail_table{
    border-top: 1px solid #1f2437;
    margin-bottom: 40px;
    &.type2{
      dt{
        background-color: #fff;
      }
    }
    &.type3{
      dt{min-height:60px;padding: 6px 20px;letter-spacing: -1.5px;}
      dd{min-height:60px;padding: 6px 20px;}
      .MuiFormControlLabel-root{
        margin-right:100px;
      }
    }
    @media (min-width: 320px) and (max-width: 768px) {
      dd{padding-left:20px;padding-right:20px;}
      &.tbl_01{
        dt {flex:0 0 59%;}
        dd {flex:0 0 40%;}
      }
    }
  }
  .tableDefault_scroll{width:100%;}
  .MuiOutlinedInput-input {font-weight:300;}
  dl {
    display: flex;
    border-spacing: 0;
    width: 100%;
    & .noline{
      border-bottom: none;
    }
    dt {
      display: flex;
      align-items: center;
      flex: 0 0 220px;
      padding: 20px 20px;
      text-align: left;
      background-color: #f5f5f5;
      border-bottom: 1px solid #e0e0e0;
      &.wh{
        background-color: #fff;
      }
    }
    dd {
      flex: 1;
      display: flex;
      justify-content: space-between;
      padding: 19px 20px;
      line-height: 1.75;
      align-items: center;
      border-bottom: 1px solid #e0e0e0;
      margin-left: 0;
      font-weight: 400;
      .MuiOutlinedInput-notchedOutline{
        border-color: #ccc;
      }
      &.address{
        flex-direction: column;
        align-items: flex-start;
        >div{
          width:100%;
        }
        .MuiOutlinedInput-input{height:48px;padding: 0 14px;}
      }
      .regNum {width:38.5%;}
    }
    .withLink{
      color:#4063ec;
      justify-content: flex-start;
      a {margin-left:10px;padding-right:15px;color:#4063ec;font-weight:400;background:url(/images/common/gt_blue.png) no-repeat right center;}
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .MuiTypography-h6{
      font-size: 16px;
      margin-bottom: 10px;
    }
    .detail_table{
      margin-bottom: 30px;
      .MuiOutlinedInput-root{height:48px}
    }
    .MuiFormControl-root{width:100%;}
    .MuiFormGroup-root{justify-content: space-around;}
    .MuiFormControlLabel-root{margin-right:0;}
    dl {
      flex-wrap: wrap;
      font-size: 14px;
      dt {
        flex: 0 0 35%;
        line-height: 26px;
        padding: 19px 0 19px 10px;
      }
      dd {
        flex: 0 0 65%;
        padding: 10px 0 10px 10px;
        &.address{
          .MuiButton-root {line-height:1;}
          >div{
            &:nth-of-type(2){
              flex-direction:column;
              .MuiOutlinedInput-root{
                width:100%;
                &:first-of-type{margin-bottom:10px;}
              }
            }
          }
        }
        .regNum {width:100%;}
      }
      &.horz{
        flex-direction: column;
        dt{
          border-bottom: 0;
          justify-content: center;
        }
        dd{
          padding:0 8px;
        }
      }
    }
    .type2{
      dl{
        &.horz{
          flex-wrap: nowrap;
          dt{
            justify-content: left;
          }
          dd{
            padding-bottom: 20px;
            .tableDefault_scroll{
            margin-right: -23px;
          }
          }
        }
      }
    }
  }
`;


export const table2 = css`
  max-width: 100%;
  letter-spacing: -0.64px;
  .MuiTypography-h6{
    font-size: 18px;
    margin-bottom: 15px;
  }
  .detail_table{
    border-top: 1px solid #1f2437;
    margin-bottom: 40px;
  }
  dl {
    display: flex;
    border-spacing: 0;
    width: 100%;
    & .noline{
      border-bottom: none;
    }
    dt {
      display: flex;
      align-items: center;
      flex: 0 0 220px;
      padding: 20px 20px;
      text-align: left;
      background-color: #f5f5f5;
      border-bottom: 1px solid #e0e0e0;
      &.wh{
        background-color: #fff;
      }
    }
    dd {
      flex: 1;
      display: flex;
      justify-content: space-between;
      line-height: 1.75;
      align-items: center;
      border-bottom: 1px solid #e0e0e0;
      margin-left: 0;
      p{padding:0 20px;}
      &.num{
        flex : 0 0 6.2%;
        border-right: 1px solid #e0e0e0;
        justify-content: center;
      }
      &.check{
          flex: 0 0 19%;
          border-left: 1px solid #e0e0e0;
          border-bottom: 0;
          justify-content: center;
          align-self: stretch;
          .MuiFormControlLabel-root{
            &:last-child{
              margin-left:14px;
              margin-right: 0;
            }
          }
        }
    }
    &.header{
      dt{
        flex : 0 0 33.3%;
        &.num{
          flex : 0 0 6.2%;
          justify-content: center;
          border-right: 1px solid #e0e0e0;
          &+dt{
            flex: 1;
          }
        }
        &.check{
          flex: 0 0 17.8%;
          justify-content: center;
          border-left: 1px solid #e0e0e0;
        }
      }
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .MuiTypography-h6{
      font-size: 16px;
      margin-bottom: 10px;
    }
    .detail_table{
      margin-bottom: 30px;
    }
    dl {
      border-bottom: 1px solid #e0e0e0;
      &.header{
        display:flex;
        border-bottom: 0;
        dt{
          &.num{flex: 0 0 38px;padding:0;}
          &.check{display:none}
        }
      }
      dt {
        flex: 0 0 30%;
        padding: 15px 18px;
      }
      dd {
        flex: 0 0 89.5%;
        padding: 14px 20px;
        p{padding:0;margin:0;}
        &.num{
          padding:0;
          flex: 0 0 38px;
          border-bottom: 0;
          align-self: stretch;
          &.long{
            height: 201px;
          }
          &.middle{
            height: 176px;
          }
          &.short{
            height: 127px;
          }
        }
        &.cnt{
          flex:1;
          display: block;
          padding-bottom: 5px;
          font-size: 14px;
          border-bottom: 0;
        }
        &.check{
          justify-content: flex-start;
          margin: 10px 0;
          padding:0;
          border-left: 0;
          .MuiFormControlLabel-label{font-size: 14px;}
        }
      }
    }
  }
`;


export const attatchedFile = css`
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  padding:24px 20px;
  background-color: #f5f5f5;
  border-radius: 10px;
  >div{
    &:first-of-type{padding-left:0;}
    padding-left:6px;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    flex-direction: column;
    margin:0 -15px;
    padding:20px 15px;
    border-radius: 0;
    >div{
      padding-left:0;
      button{
        margin-top:10px;
      }
      &:first-of-type{
        button{margin-top:0;}
      }
    }
  }
`