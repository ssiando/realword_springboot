import React, {Fragment, useEffect, useState} from 'react';
import * as styles from './styles';
import * as comstyles from '~/styles/styles';
import Box from '@mui/material/Box';
import {
  Stack,
  useMediaQuery,
  List,
  ListItem,
  ListItemText,
  TooltipProps,
  Tooltip,
  tooltipClasses, Button
} from '@mui/material';
import Typography from '@mui/material/Typography';
import {useTheme} from '@mui/material';
import {CustomButton} from '~/components/ButtonComponents';
import {CustomRadioButtons} from '~/components/NoticeCustomCheckBoxs';
import {NavLink} from 'react-router-dom';
import {fetchGetCommCode} from '~/fetches';
import dayjs from 'dayjs';
import {styled} from '@mui/material/styles';
import {useQuery} from "react-query";
import DatePicker from "~/components/DatePicker";
import {SearchModal} from '~/components/BizCommon/SearchModal';
import {initPlanInput, initResourceInput, planInput, ResourceInput} from '~/models/ModelBizPlanMgt';
import {fetchUserResourceDetailGet, fetechUserResourceGet} from '~/fetches/fetchResource';
import NoData from '~/components/Loading/NoData';
import RceptStus from '../BusinessAppMgt/PopComp/RceptStus';
import {Banner} from "~/components/Banner";
import {Modalfront} from "~/components/SharedModalComponents";

/* 
  작성일    :   2022/07/21
  화면명    :   사업관리 -> 자원 할당 관리 -> 자원할당내역
  회면ID    :   (UI-USP-FRN-0260101)
  화면/개발 :   YongheeKim / navycui
*/
const ResourceAllocDet = () => {
  const today = new Date()
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  const [input, setInput] = useState<ResourceInput>({
    ...initResourceInput,
    alrsrcBgngDay: dayjs(new Date().setDate(today.getDate() - 15)).format('YYYYMMDD'),
    alrsrcEndDay: dayjs(new Date().setDate(today.getDate() + 15)).format('YYYYMMDD'),
  })
  const [loading, setLoading] = useState(true)
  const [open, setOpen] = useState(false)
  const [selectId, setSelectId] = useState('')

  // 공통 코드 조회
  const {data: assign_box} = useQuery("getCode", async () => await fetchGetCommCode("ALRSRC_ST"));
  const {
    data: list,
    isLoading,
    isFetching
  } = useQuery(["fetechUserResourceGet", input], async () => await fetechUserResourceGet(input));

  useEffect(() => {
    if (!isLoading && !isFetching) {
      if (!!list) {
        console.log('list - ' + JSON.stringify(list))
      }
      setLoading(false)
    }
  }, [list, isLoading, isFetching])

  const moreInfo = () => {
    const itemsPerPage: any = input.itemsPerPage + 10;
    setInput((state) => ({...state, itemsPerPage}));
  }

  function modalClick() {
    let myInput: any = document.getElementById("modalHidden");
    myInput.click();
  }

  return <Banner
    title={'자원할당내역'} loading={loading}
    summary={'자원할당 사업을 통해 할당받은 자원을 조회할 수 있습니다.'}
    // searchContent={<SelectSearchBar
    //   placehold='할당 받은 자원을 조회해보세요!'
    //   onChange={(keyword) => setQuests({...quests,keyword: keyword })}
    //   handleSearch={(val: any) => {
    //     setInput({...input, ...quests});
    //   }}
    // />}
    detailContent={<Fragment>{
      isMobile ?
        <SearchModal
          placehold='할당 받은 자원을 조회해보세요!'
          handleSearch={(s: string | undefined) => {
            console.log(s)
          }}
          assign_box={assign_box?.list}
        /> : <Box css={comstyles.picker_card}>
          <dl>
            <dt>이용시작일</dt>
            <dd>
              <Box className="box_scroll">
                <DatePicker
                  pickerType='two'
                  questBeginDay={!!input.alrsrcBgngDay? dayjs(input.alrsrcBgngDay, 'YYYYMMDD').toString() : ''}
                  questEndDay={!!input.alrsrcEndDay? dayjs(input.alrsrcEndDay, 'YYYYMMDD').toString() : ''}
                  changeStart={(startNewTime: Date | null) => {
                    if (startNewTime) {
                      if (input.alrsrcEndDay) {
                        const end = new Date(Number(input.alrsrcEndDay.slice(0, 4)),
                          Number(input.alrsrcEndDay.slice(4, 6)) - 1, Number(input.alrsrcEndDay.slice(6, 8)))
                        if (startNewTime.getTime() > end.getTime()) {
                          setInput({...input, alrsrcBgngDay: dayjs(end).format('YYYYMMDD')})
                          return
                        }
                      }

                      setInput({...input, alrsrcBgngDay: dayjs(startNewTime).format('YYYYMMDD')})
                    }
                  }}
                  changeEnd={(endNewTime: Date | null) => {
                    if (endNewTime) {
                      if (input.alrsrcBgngDay) {
                        const begin = new Date(Number(input.alrsrcBgngDay.slice(0, 4)),
                          Number(input.alrsrcBgngDay.slice(4, 6)) - 1, Number(input.alrsrcBgngDay.slice(6, 8)))
                        if (endNewTime.getTime() < begin.getTime()) {
                          setInput({...input, alrsrcEndDay: dayjs(begin).format('YYYYMMDD')})
                          return
                        }
                      }

                      setInput({...input, alrsrcEndDay: dayjs(endNewTime).format('YYYYMMDD')})
                    }
                  }}
                />
              </Box>
            </dd>
          </dl>
          <dl>
            <dt>자원할당상태</dt>
            <dd>
              <Box className="box_scroll">
                <CustomRadioButtons
                  row
                  data={assign_box ? assign_box.list : []}
                  onClick={(s: string) => {
                    setInput({...input, alrsrcSt: s})
                    // setPlanPresentnSttusCd(s);
                    // if (s.length > 0) console.log(s);
                  }}
                />
              </Box>
            </dd>
          </dl>
        </Box>
    }</Fragment>}>
    <div css={comstyles.container}>
      <Box css={comstyles.sub_cont02}>
        <div className="content list">
          {/* className="list02" 클래스는 사유확인버튼이 있을시에만 추가 */}
          <div css={comstyles.detal_list} className="list02">
            <Stack
              spacing={6}
              direction="row"
              className="sub_tit"
              justifyContent="space-between"
            >
              <Typography variant="h4" component="div">
                자원할당내역
                <span className='data'><em>{list ? list.totalItems : 0}</em> 건</span>
              </Typography>
            </Stack>
            <List>
              {!!list ? list.list.length > 0 ? list.list.map((item: any, i: number) => (
                <div className="btn_cont" key={i} onClick={modalClick}>
                  <NavLink to={''} onClick={() => {
                    setSelectId(item.alrsrcId)
                    setOpen(true)
                  }}>
                    <ListItem>
                      <ListItemText
                        secondary={
                          <React.Fragment>
                        <span className="tit_body">
                          <Typography variant="body1" component="span">
                            {item.pblancNm}
                          </Typography>
                        </span>
                            <span className="date">
                          <span>이용기간 <em>{dayjs(item.alrscsBgngDay).format('YYYY-MM-DD') + " ~ " + dayjs(item.alrscsEndDay).format('YYYY-MM-DD')}</em></span>
                        </span>
                            <RceptStus stus={!!item.alrsrcStNm ? item.alrsrcStNm : '접수상태'}/>
                          </React.Fragment>
                        }
                      />
                    </ListItem>
                  </NavLink>
                  {/*{open && <ModalReasonConfirm applyId={item.alrsrcId} viewNm="ModalResAlloc"/>}*/}
                  {
                    open && <ResAllocModal open={open} alrsrcId={selectId} onClose={() => setOpen(false)}
                                           onConfirm={() => setOpen(false)}/>
                  }
                </div>
              )) : <NoData/> : <NoData/>}
            </List>
            {(input.itemsPerPage) < list?.totalItems ?
              // 더보기
              <Stack css={comstyles.bottom_btn}>
                <CustomButton label={'더보기'} type={'full'} color={'item'} style={{margin: '10px 0'}}
                              onClick={() => moreInfo()}/>
              </Stack>
              : null}
          </div>
        </div>
      </Box>
    </div>
  </Banner>
}

const ResAllocModal = (props: {
  alrsrcId: string
  open: boolean
  onConfirm: () => void
  onClose: () => void
}) => {
  const alrscs = useQuery(['resourceAlloc', props.alrsrcId], () => fetchUserResourceDetailGet(props.alrsrcId))
  const [data, setData] = useState<any>()
  const [tableHeader, setTableHeader] = useState<string[]>([])
  const [tableColumn, setTableColumn] = useState<any[]>([])

  useEffect(() => {
    if (!alrscs.isLoading && !alrscs.isFetching) {
      if (!!alrscs.data) {
        setData(alrscs.data)
        if (alrscs.data.alrsrcDstbUserList) {
          const headNames = alrscs.data.alrsrcDstbUserList.flatMap((m: any) => m.rsrcGroupNm)
            .reduce((ac: string[], v: string) => ac.includes(v) ? ac : [...ac, v], [])
          const columnData = headNames.map((m: any) => {
            return alrscs.data.alrsrcDstbUserList.filter((f: any) => f.rsrcGroupNm == m)
          })
          setTableHeader(headNames)
          setTableColumn(columnData)
        }
      }
    }
  }, [alrscs.data, alrscs.isLoading, alrscs.isFetching])

  return <Modalfront
    open={props.open}
    type={'normal'}
    title={'자원할당내역'}
    content={''}
    onConfirm={props.onConfirm}
    onClose={props.onClose}
  >
    <Box css={styles.table05} sx={{mt: 3}}>
      <Typography
        gutterBottom
        variant="h6"
        component="div"
        style={{width: '932px'}}
      >
        {'기본정보'}
      </Typography>
      <div className="detail_table">
        <dl>
          <dt>공고명</dt>
          <dd>{data?.pblancNm}</dd>
          <dt>접수번호</dt>
          <dd>{data?.receiptNo}</dd>
        </dl>
        <dl>
          <dt>이용상태</dt>
          <dd>{data?.alrsrcStNm}</dd>
          <dt>이용기간</dt>
          {
            data ?
              <dd>{`${dayjs(data.alrscsBgngDay).format('YYYY-MM-DD')} ~ ${dayjs(data.alrsrcEndDay).format('YYYY-MM-DD')}`}</dd>
              : <dd></dd>
          }
        </dl>
      </div>
    </Box>
    <div className="tbl_title">할당자원</div>
    <table className="tableDefault type2">
      <thead>
      <tr>
        {tableHeader && tableHeader.map(header => <th>{header}</th>)}
      </tr>
      </thead>
      <tbody>
      {
        tableColumn[0] && tableColumn[0].map((m: any, i: number) => {
          const row = tableColumn.reduce((ac: any, c: any) => {
            return [...ac, c[i]]
          }, [])
          return <tr>{
            tableHeader.map((h, j) => {
              return <Fragment>
                <td>
                  {
                    row[j].rsrcUseYn ?
                      `${row[j].rsrcTypeNm == h ? '' : row[j].rsrcTypeNm} ${row[j].rsrcDstbQy} ${row[j].rsrcTypeUnitNm}`
                      : '사용안함'
                  }
                </td>
              </Fragment>
            })
          }</tr>
        })
      }
      {/*{*/}
      {/*  headNames&& headNames.map((m,i) => {*/}
      {/*    return <tr>*/}
      {/*      {*/}
      {/*        headNames*/}
      {/*      }*/}
      {/*    </tr>*/}
      {/*  })*/}
      {/*}*/}
      {/*<tr>*/}
      {/*  <td>A100 (8개)</td>*/}
      {/*  <td>50 GB</td>*/}
      {/*  <td>사용 (음성인식(STT))</td>*/}
      {/*  <td>사용안함</td>*/}
      {/*</tr>*/}
      </tbody>
    </table>

    {/*<Stack spacing={2} direction="row" justifyContent="center" css={styles.signbtn}>*/}
    {/*  <Button fullWidth variant="contained" type="button" className="primary"*/}
    {/*          onClick={() => setOpen(false)}>확인</Button>*/}
    {/*</Stack>*/}
  </Modalfront>
}

const HtmlTooltip = styled(({className, ...props}: TooltipProps) => (
  <Tooltip {...props} classes={{popper: className}}/>
))(({theme}) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    backgroundColor: '#f5f5f9',
    color: 'rgba(0, 0, 0, 0.87)',
    maxWidth: 220,
    fontSize: theme.typography.pxToRem(12),
    border: '1px solid #dadde9',
  },
}));

export default ResourceAllocDet;