// 성과관리 -> 성과관리
// import React from "react"
import React, {useState, useEffect, Fragment} from 'react';
import * as styles from './styles';
import Box from '@mui/material/Box';
import {
  Tabs,
  Tab,
  Stack,
  Button,
  OutlinedInput,
  TextField,IconButton, Checkbox
} from '@mui/material';
import {FileUpload1} from "../../EventNews/FileUpload";
import {
  fetchPerformanceDetailGet,
  fetchPerformanceHistGet,
  fetchPerformancePresentnGet,
  fetchPerformanceSubmit
} from '~/fetches/fetchPerformanceMgt';
import {useGlobalModalStore} from '~/pages/store/GlobalModalStore';
import {resultHistoryList, resultList, rsltIdxIem, rsltIdxIemList} from '~/models/ModelPerformanceMgt';
import fetchDownload from '~/fetches/fetchDownload';
import {useLocation, useNavigate, useParams} from 'react-router-dom';
import {CustomButton} from "~/components/ButtonComponents";
import {CustomSelectSubmitDay} from '~/components/SelectBoxComponents';
import {PlusIcon} from "~/components/IconComponents";
import {TrashIcon} from "~/components/IconComponents";
import {Banner} from "~/components/Banner";


// import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const {children, value, index, ...other} = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{p: 3}}>
          {children}
        </Box>
      )}
    </div>
  );
}

function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

function PerformanceMgtDetail() {
  const navigate = useNavigate();
  const receive: any = useLocation();
  const params = useParams();
  const {addModal} = useGlobalModalStore();
  const [value, setValue] = useState(0);
  const [data, setData] = useState<resultList>();
  const [data2, setData2] = useState<resultHistoryList>();
  const [files, setFiles]: any = useState([]);
  const [files1, setFiles1]: any = useState([]);

  const [fileList, setFileList] = useState<{ rsltIdxIemId: string, file: any }[]>([])

  // const []
  const [rsltIdxIemCnList, setRsltIdxIemCnList] = useState<rsltIdxIem[]>();
  const [attachmentFileList, setAttachmentFileList]: any = useState();
  const [attachmentFileList2, setAttachmentFileList2]: any = useState();
  const [deleteAttachFileList, setDeleteAttachFileList]: any = useState([]);
  const [histList, setHistList]: any = useState();
  const [histId, setHistId] = useState<string>('');
  const [rsltIdxFileList, setRsltIdxFileList]: any = useState([]);
  const [deleteAttachmentId, setDeleteAttachmentId] = useState<string>();
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!loading) window.scrollTo(0,5)
  },[value])

  const getData = async() => {
    setLoading(true)
    await fetchPerformanceDetailGet(receive.state.item.rsltId).then((res: any) => {
      console.log('res - ' + JSON.stringify(res))
      // list타입일경우 flag값을 U로 변경
      setData({
        ...res,
        rsltIdxIemList: res.rsltIdxIemList.map((m: any) => {
          const isList = m.rsltIdxTypeCd == "LIST"
          return {
            ...m,
            rsltIdxIemCnList: isList ? m.rsltIdxIemCnList.map((n: any) => {
              return {
                ...n,
                flag: 'U'
              }
            }).sort((a: rsltIdxIem, b: rsltIdxIem) => {
              return a.sortOrder - b.sortOrder
            }) : m.rsltIdxIemCnList
          }
        })
      });
      setAttachmentFileList(res.attachFileList);
      setRsltIdxIemCnList(res.rsltIdxIemList[0].rsltIdxIemCnList);

      if (res.rsltIdxIemList[0].prufFile) {
        setRsltIdxFileList([res.rsltIdxIemList[0].prufFile]);
      }
    })
    setLoading(false)

    fetchPerformancePresentnGet(receive.state.item.rsltId).then((res: any) => {
      setHistList(res.list);
      setHistId(res.list[0].rsltHistId);
      getData2(res.list[0].rsltHistId)
    })
  }

  const getData2 = (histId: string) => {
    if (histId.length > 0) {
      fetchPerformanceHistGet(params.id!, histId).then((res: any) => {
        console.log('hist - ' + JSON.stringify(res))
        setData2({
          ...res,
          rsltIdxIemList: res.rsltIdxIemList.map((m: any) => {
            const isList = m.rsltIdxTypeCd == "LIST"
            return {
              ...m,
              rsltIdxIemCnList: isList ? m.rsltIdxIemCnList.sort((a: rsltIdxIem, b: rsltIdxIem) => {
                return a.sortOrder - b.sortOrder
              }) : m.rsltIdxIemCnList
            }
          })
        })

        setAttachmentFileList2(res.attachFileList);
        // setRsltIdxIemCnList2(res.rsltIdxIemList[0]?.rsltIdxIemCnList)
        // if (res.rsltIdxIemList[0]?.prufFile) {
        //   setRsltIdxFileList2([res.rsltIdxIemList[0]?.prufFile]);
        // }
      })
    }
  }

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };
  useEffect(() => {
    getData();
  }, [])

  //조회된 첨부파일 삭제
  const deleteAttach1 = (attachmentId: string, i: number) => {
    const update = [...deleteAttachFileList]
    update.push({
      attachmentId: attachmentId
    })
    setDeleteAttachFileList(update);
    const update1 = [...attachmentFileList]
    update1.splice(i, 1)
    setAttachmentFileList(update1);
  }
  //조회된 증빙자료첨부파일삭제
  const deleteAttach2 = (attachmentId: string, i: number) => {
    setDeleteAttachmentId(attachmentId);
    const update1 = [...rsltIdxFileList]
    update1.splice(i, 1)
    setRsltIdxFileList(update1);
  }
  //파일첨부 삭제
  const handleDelete = (i: number) => {
    const update = [...files]
    update.splice(i, 1)
    setFiles(update);
  };
  //등록하려는 증빙자료첨부파일삭제
  const handleDelete1 = (i: number) => {
    const update = [...files1]
    update.splice(i, 1)
    setFiles1(update);
  };

  //파일첨부
  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    let upfile: any = e.target.files;
    const update = [...files]
    for (var i = 0; i < upfile.length; i++) {
      update.push(upfile[i]);
    }
    setFiles(update)
  }
  //증빙자료첨부
  const handleUpload1 = (e: React.ChangeEvent<HTMLInputElement>) => {
    let upfile: any = e.target.files;
    const update = [...files1]
    for (var i = 0; i < 1; i++) {
      update.push(upfile[i]);
    }
    if (rsltIdxFileList.length !== 1) {
      setFiles1(update)
    }
  }

  const checkIemUnit = (item: string | null) => {
    if (item === "WON") {
      return "원"
    } else if (item === "PT") {
      return "%"
    } else if (item === "NM") {
      return "명"
    } else if (item === "CO") {
      return "개"
    } else if (item === "POINT") {
      return "점"
    } else if (item == "TEXT") {
      return ""
    }
  }
  const submit = () => {
    try {
      const form = new FormData();
      if (data) {
        let a = 0;
        form.append("deleteAttachFileList", new Blob([JSON.stringify(deleteAttachFileList)], {type: "application/json"}));

        for (let i = 0; i < files.length; i++) {
          form.append("attachFileList", files[i])
        }
        // for (let i = 0; i < files1.length; i++) {
        //   form.append("rsltIdxFileList", files1[i])
        //   a++;
        // }

        fileList.map(m => form.append("rsltIdxFileList", m.file[0]))

        // const infoList = [{
        //   rsltIdxIemId: data.rsltIdxIemList[0].rsltIdxIemId,
        //   attachFileOrder: a,
        //   rsltIdxIemCnList: rsltIdxIemCnList,
        //   deleteAttachmentId: deleteAttachmentId,
        // }]
        const infoList = data.rsltIdxIemList.map(m => {
          const attachfileIndx = fileList.flatMap(m => m.rsltIdxIemId).indexOf(m.rsltIdxIemId)
          return {
            rsltIdxIemId: m.rsltIdxIemId,
            rsltIdxIemCnList: m.rsltIdxIemCnList,
            attachFileOrder: attachfileIndx,
            deleteAttachmentId: deleteAttachmentId,
          }
        })
        console.log('infoList - ' + JSON.stringify(infoList))
        form.append("infoList", new Blob([JSON.stringify(infoList)], {type: "application/json"}));
        fetchPerformanceSubmit(params.id!, form).then(() => {
          navigate('../biz/TaskManagement/PerformanceMgt')
          // getData();
          // getData2();
        }).catch((e: { response: { data: { message: any; }; }; }) => {
          addModal({
            open: true,
            content: e.response.data.message
          });
        })
      }
    } catch (e: any) {
      if (!!e.response && e.response.data) return alert(e.response.data.message);
    }
  }

  //다운로드
  const download = async (attachmentId: string) => {
    fetchDownload(`${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/rslt/${params.id!}/hist/atchmnfl/${attachmentId}?rsltHistId=${histId}`)
      .then()
      .catch((e) => {
        let status = e.response.status;

        if (status === 400) {
          addModal({
            open: true,
            content: "파일이 없습니다."
          })
        }
      });
  }
  const downloadAll = async (rsltId: string) => {
    fetchDownload(`${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/rslt/${rsltId}/hist/atchmnfl?rsltHistId=${histId}`)
      .then()
      .catch((e) => {
        let status = e.response.status;

        if (status === 400) {
          addModal({
            open: true,
            content: "파일이 없습니다."
          })
        }
      });
  }

  return <Banner
    title={'성과 상세'} loading={loading}
    summary={'성과를 제출하고 이력을 조회할 수 있습니다.'}
    tabContent={
        <Tabs value={value} onChange={handleChange} variant="scrollable" scrollButtons="auto"
              aria-label="basic tabs example">
          <Tab label="제출" {...a11yProps(0)} />
          <Tab label="제출이력" {...a11yProps(1)} />
        </Tabs>
    }>
    <div css={styles.container}>
      <Box className='content_body'>
        <div className="content">
          <TabPanel value={value} index={0}>
            <h4 className='tbl_title'>기본정보</h4>
            <Box css={styles.table}>
              {data && data.basicInfo ?
                <div className="detail_table">
                  <dl>
                    <dt>공고명</dt>
                    <dd>{data.basicInfo.pblancNm}</dd>
                  </dl>
                  <dl>
                    <dt>과제명</dt>
                    <dd>{data.basicInfo.taskNm}</dd>
                    <dt>접수번호</dt>
                    <dd>{data.basicInfo.receiptNo}</dd>
                  </dl>
                  <dl>
                    <dt>사업기간</dt>
                    <dd>{data.basicInfo.bsnsBgnde.substring(0, 4) + "-" + data.basicInfo.bsnsBgnde.substring(4, 6) + "-" + data.basicInfo.bsnsBgnde.substring(6, 8) + "~" + data.basicInfo.bsnsEndde.substring(0, 4) + "-" + data.basicInfo.bsnsEndde.substring(4, 6) + "-" + data.basicInfo.bsnsEndde.substring(6, 8)}</dd>
                    <dt>성과년도</dt>
                    <dd>{data.basicInfo.bsnsYear}</dd>
                  </dl>
                </div>
                : null}
            </Box>

            {
              data ? data.rsltIdxIemList.map((m: rsltIdxIemList, index: number) => {
                const itemNm = m.rsltIdxIemCnList.flatMap(m => m.stdIemNm)
                  .reduce((ac: string[], v: string) => ac.includes(v) ? ac : [...ac, v], [])
                const detailIemNm = m.rsltIdxIemCnList.flatMap(m => m.detailIemNm)
                  .reduce((ac: string[], v: string) => ac.includes(v) ? ac : [...ac, v], [])

                // 목록형 여부
                const isStandard = itemNm.filter(f => f != null).length > 0

                if (m.rsltIdxTypeCd == "LIST") {
                  return <TableListType
                    data={m}
                    stdIemNm={itemNm}
                    detailIemNm={detailIemNm}
                    checkIemUnit={checkIemUnit}
                    onUpdateFiles={(id: string, file: any) => {
                      if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                      if (!!file) {
                        if (fileList.flatMap(m => m.rsltIdxIemId).includes(id)){
                          setFileList(fileList.map(m => {
                            const update = m.rsltIdxIemId == id? file: m.file
                            return {
                              ...m,
                              file: update
                            }
                          }))
                        }else {
                          setFileList(fileList.concat({rsltIdxIemId: id, file: file}))
                        }
                      } else {
                        setFileList(fileList.filter(f => f.rsltIdxIemId != id))
                      }
                    }}
                    onDeletePreufFile={(attachmentFileId: string) => {
                      if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                      setDeleteAttachmentId(attachmentFileId);
                    }}
                    onRemoveRow={(removeRow: number[]) => {
                      if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                      const update = m.rsltIdxIemCnList.filter((f) => !removeRow.includes(f.sortOrder - 1))
                      const deleteItem = m.rsltIdxIemCnList.filter(f => removeRow.includes(f.sortOrder - 1) && f.flag == 'U').map(m => {
                        return {
                          ...m,
                          sortOrder: -1,
                          flag: 'D'
                        }
                      })

                      const newItem = [...data?.rsltIdxIemList]
                      newItem[index] = {
                        ...newItem[index],
                        rsltIdxIemCnList: [...update, ...deleteItem]
                      }

                      setData({
                        ...data,
                        rsltIdxIemList: newItem
                      })
                    }}
                    onAddRow={() => {
                      if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                      const addRow = detailIemNm.map((detailNm) => {
                        const count = m.rsltIdxIemCnList.flatMap(m => m.sortOrder).sort((a, b) => {
                          return b - a
                        }).shift() || -1
                        // const totalRow = m.rsltIdxIemCnList.filter(f => f.flag != 'D')
                        //   .filter(f => f.detailIemNm == detailIemNm.at(0)).length
                        const item = m.rsltIdxIemCnList.find(f => f.detailIemNm == detailNm)
                        return {
                          rsltIdxIemCnId: '',
                          rsltIdxDetailIemId: item?.rsltIdxDetailIemId || '',
                          detailIemNm: detailNm,
                          iemUnitCd: item?.iemUnitCd || '',
                          rsltIdxIemCn: '',
                          rsltIdxStdIemId: '',
                          stdIemNm: '',
                          sortOrder: count + 1,
                          flag: 'I'
                        }
                      })
                      const update = m.rsltIdxIemCnList.concat(addRow).sort((a, b) => {
                        return a.sortOrder - b.sortOrder
                      });

                      const newItem = [...data?.rsltIdxIemList]
                      newItem[index] = {
                        ...newItem[index],
                        rsltIdxIemCnList: update
                      }

                      setData({
                        ...data,
                        rsltIdxIemList: newItem
                      })
                    }}
                    onChange={(e: any, i: number) => {
                      if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                      if (m.rsltIdxIemCnList) {
                        const update = [...m.rsltIdxIemCnList.filter(f => f.flag != 'D')];
                        update[i] = {
                          ...update[i],
                          [e.currentTarget.name]: e.currentTarget.value
                        }

                        const newItem = [...data?.rsltIdxIemList]
                        newItem[index] = {
                          ...newItem[index],
                          rsltIdxIemCnList: [...update, ...m.rsltIdxIemCnList.filter(f => f.flag == 'D')]
                        }

                        setData({
                          ...data,
                          rsltIdxIemList: newItem
                        })
                      }
                    }}
                  />
                }

                if (isStandard) {
                  return <TableStandardType
                    data={m}
                    stdIemNm={itemNm}
                    detailIemNm={detailIemNm}
                    checkIemUnit={checkIemUnit}
                    onUpdateFiles={(id: string, file: any) => {
                      if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                      if (!!file) {
                        if (fileList.flatMap(m => m.rsltIdxIemId).includes(id)){
                          setFileList(fileList.map(m => {
                            const update = m.rsltIdxIemId == id? file: m.file
                            return {
                              ...m,
                              file: update
                            }
                          }))
                        }else {
                          setFileList(fileList.concat({rsltIdxIemId: id, file: file}))
                        }
                      } else {
                        setFileList(fileList.filter(f => f.rsltIdxIemId != id))
                      }
                    }}
                    onDeletePreufFile={(attachmentFileId: string) => {
                      if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                      setDeleteAttachmentId(attachmentFileId);
                    }}
                    onChange={(e: any, i: number) => {
                      if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                      if (m.rsltIdxIemCnList) {
                        const update = [...m.rsltIdxIemCnList];
                        update[i] = {
                          ...update[i],
                          [e.currentTarget.name]: e.currentTarget.value
                        }

                        const newItem = [...data?.rsltIdxIemList]
                        newItem[index] = {
                          ...newItem[index],
                          rsltIdxIemCnList: update
                        }

                        setData({
                          ...data,
                          rsltIdxIemList: newItem
                        })
                      }
                    }}
                  />
                } else {
                  return <TableNotStandardType
                    data={m}
                    checkIemUnit={checkIemUnit}
                    onUpdateFiles={(id: string, file: any) => {
                      if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                      if (!!file) {
                        if (fileList.flatMap(m => m.rsltIdxIemId).includes(id)){
                          setFileList(fileList.map(m => {
                            const update = m.rsltIdxIemId == id? file: m.file
                            return {
                              ...m,
                              file: update
                            }
                          }))
                        }else {
                          setFileList(fileList.concat({rsltIdxIemId: id, file: file}))
                        }
                      } else {
                        setFileList(fileList.filter(f => f.rsltIdxIemId != id))
                      }
                    }}
                    onDeletePreufFile={(attachmentFileId: string) => {
                      if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                      setDeleteAttachmentId(attachmentFileId);
                    }}
                    onChange={(e: any, id: string) => {
                      if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                      if (m.rsltIdxIemCnList) {
                        const update = m.rsltIdxIemCnList.map((item: rsltIdxIem) => {
                          if (item.rsltIdxIemCnId === id) {
                            return {
                              ...item,
                              [e.currentTarget.name]: e.currentTarget.value
                            }
                          }
                          return item
                        })
                        const newItem = [...data?.rsltIdxIemList]
                        newItem[index] = {
                          ...newItem[index],
                          rsltIdxIemCnList: update
                        }

                        setData({
                          ...data,
                          rsltIdxIemList: newItem
                        })
                      }
                    }}
                  />
                }
              }) : null
            }

            <h4 className='tbl_title' style={{marginTop: '40px'}}>파일첨부</h4>
            <Box css={styles.fileupload}>
              <FileUpload1
                keyValue={'attachment'}
                files={files}
                handleDelete={handleDelete}
                handleUpload={handleUpload}
                files1={attachmentFileList}
                handleDelete2={deleteAttach1}
              />
            </Box>
            {
              data && (data.rsltSttusCd == 'SR' || data.rsltSttusCd == 'PR') &&
              <Stack spacing={2} direction="row" justifyContent="center" css={styles.signbtn}>
                <Button fullWidth variant="contained" type="button" className="primary" onClick={submit}>
                  {data.rsltSttusCd == 'PR' ? '제출' : '수정'}
                </Button>
              </Stack>
            }
          </TabPanel>

          <TabPanel value={value} index={1}>
            <Stack css={styles.submission_date}>
              <div className='tit'>제출일</div>
              <div className='selectLine'>
                <CustomSelectSubmitDay
                  value={histId ? histId : ''}
                  data={histList}
                  onClick={(selected) => {
                    console.log('selected - ' + selected)
                    setHistId(selected)
                  }}
                />
                <CustomButton type={'modalBtn'} label={'선택'} onClick={() => getData2(histId)}/>
              </div>
            </Stack>
            <h4 className='tbl_title'>기본정보</h4>
            <Box css={styles.table}>
              {data2 && data2.basicInfo ?
                <div className="detail_table">
                  <dl>
                    <dt>공고명</dt>
                    <dd>{data2.basicInfo.pblancNm}</dd>
                  </dl>
                  <dl>
                    <dt>과제명</dt>
                    <dd>{data2.basicInfo.taskNm}</dd>
                    <dt>접수번호</dt>
                    <dd>{data2.basicInfo.receiptNo}</dd>
                  </dl>
                  <dl>
                    <dt>사업기간</dt>
                    <dd>{data2.basicInfo.bsnsBgnde.substring(0, 4) + "-" + data2.basicInfo.bsnsBgnde.substring(4, 6) + "-" + data2.basicInfo.bsnsBgnde.substring(6, 8) + "~" + data2.basicInfo.bsnsEndde.substring(0, 4) + "-" + data2.basicInfo.bsnsEndde.substring(4, 6) + "-" + data2.basicInfo.bsnsEndde.substring(6, 8)}</dd>
                    <dt>성과년도</dt>
                    <dd>{data2.basicInfo.bsnsYear}</dd>
                  </dl>
                </div>
                : null}
            </Box>
            {
              data2 ? data2.rsltIdxIemList.map((m: rsltIdxIemList, index: number) => {
                const itemNm = m.rsltIdxIemCnList.flatMap(m => m.stdIemNm)
                  .reduce((ac: string[], v: string) => ac.includes(v) ? ac : [...ac, v], [])
                const detailIemNm = m.rsltIdxIemCnList.flatMap(m => m.detailIemNm)
                  .reduce((ac: string[], v: string) => ac.includes(v) ? ac : [...ac, v], [])

                // 목록형 여부

                const isStandard = itemNm.filter(f => f != null).length > 0
                // const isStandard = itemNm.length != 0 && detailIemNm.length != 0

                if (m.rsltIdxTypeCd == "LIST") {
                  return <TableListType
                    isHistory data={m}
                    stdIemNm={itemNm}
                    detailIemNm={detailIemNm}
                    checkIemUnit={checkIemUnit}
                    onDownload={download}
                  />
                }

                if (isStandard) {
                  return <TableStandardType
                    isHistory data={m}
                    stdIemNm={itemNm}
                    detailIemNm={detailIemNm}
                    checkIemUnit={checkIemUnit}
                    onDownload={download}
                  />
                } else {
                  return <TableNotStandardType
                    isHistory data={m}
                    checkIemUnit={checkIemUnit}
                    onDownload={download}
                  />
                }
              }) : null
            }
            <Stack flexDirection={'row'} justifyContent={'space-between'} alignItems={'center'} className='tbl_title'
                   sx={{marginBottom: '10px'}}>
              <h4>파일첨부</h4>
              {!(Array.isArray(attachmentFileList2) && attachmentFileList2.length === 0) ?
                <Stack css={styles.btnDown}>
                  <Button onClick={() => downloadAll(receive.state.item.rsltId)}>
                    <span>일괄다운로드</span>
                  </Button>
                </Stack>
                : null}
            </Stack>
            <Stack css={styles.attatchedFile}>
              <Stack css={styles.btnDown}>
                {!(Array.isArray(attachmentFileList2) && attachmentFileList2.length === 0) ?
                  attachmentFileList2?.map((item: any, i: number) => (
                    <Button key={i} onClick={() => download(item.attachmentId)}>
                      <span>{item.fileNm}</span>
                    </Button>
                  ))
                  : "첨부파일 없습니다."}
              </Stack>
            </Stack>
          </TabPanel>
        </div>
      </Box>
    </div>
  </Banner>
}

export const TableNotStandardType = (props: {
  data: rsltIdxIemList
  isHistory?: boolean
  onChange?: (event: any, id: string) => void
  checkIemUnit: (item: string | null) => void
  onUpdateFiles?: (id: string, files: any) => void
  onDeletePreufFile?: (attachmentId: string) => void
  onDownload?: (attachmentId: string) => void
}) => {
  const [files, setFiles]: any = useState([]);
  const [preufFile, setPreufFile] = useState<any>(props.data.prufFile ? [props.data.prufFile] : []);
  useEffect(() => {
    setPreufFile(props.data.prufFile ? [props.data.prufFile] : [])
  },[props.data.prufFile])

  //등록하려는 증빙자료첨부파일삭제
  const handleDelete = (i: number) => {
    const update = [...files]
    update.splice(i, 1)
    setFiles(update);

    if (props.onUpdateFiles) props.onUpdateFiles(props.data.rsltIdxIemId, update)
  }

  const handlePreufFileDelete = (attachmentId: string, i: number) => {
    // setDeleteAttachmentId(attachmentId);
    const update1 = [...preufFile]
    update1.splice(i, 1)
    setPreufFile(update1);

    if (props.onDeletePreufFile) props.onDeletePreufFile(attachmentId)
  }

  //증빙자료첨부
  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    let upfile: any = e.target.files;
    const update = []
    for (var i = 0; i < 1; i++) {
      update.push(upfile[i]);
    }
    if (props.data.rsltIdxIemCnList.length !== 1) {
      setFiles(update)
      setPreufFile([])
    }
    if (props.onUpdateFiles) props.onUpdateFiles(props.data.rsltIdxIemId, update)
  }

  const itemList = props.data.rsltIdxIemCnList.filter(f => f.iemUnitCd != 'DSCRP')
  const dscrpList = props.data.rsltIdxIemCnList.filter(f => f.iemUnitCd == 'DSCRP')
  return <Fragment>
    <h4 className='tbl_title'>{props.data.rsltIdxNm}</h4>
    <Box css={styles.table}>
      <div className="detail_table">
        {itemList.map((item: any, i: number) => (
          i * 2 < itemList.length ?
            <dl>
              <dt>{itemList[i * 2].detailIemNm}</dt>
              <dd>
                <OutlinedInput
                  size="small"
                  className="ipt_tp01 tar"
                  sx={{width: '93.5%', marginRight: '10px'}}
                  name="rsltIdxIemCn"
                  value={itemList[i * 2].iemUnitCd == "TEXT"? itemList[i * 2].rsltIdxIemCn :
                    inputPriceFormat(itemList[i * 2].rsltIdxIemCn)}
                  onChange={(e) => {
                    if (props.onChange) props.onChange(e, itemList[i * 2].rsltIdxIemCnId)
                  }}
                />{props.checkIemUnit(itemList[i * 2].iemUnitCd)}
              </dd>
              <dt>{itemList[i * 2 + 1]?.detailIemNm}</dt>
              <dd>
                {
                  itemList[i * 2 + 1] && <Fragment>
                    <OutlinedInput
                      size="small"
                      className="ipt_tp01 tar"
                      sx={{width: '93.5%', marginRight: '10px'}}
                      name="rsltIdxIemCn"
                      value={itemList[i * 2 + 1].iemUnitCd == "TEXT" ? itemList[i * 2 + 1].rsltIdxIemCn :
                        inputPriceFormat(itemList[i * 2 + 1].rsltIdxIemCn)}
                      onChange={(e) => {
                        if (props.onChange) props.onChange(e, itemList[i * 2 + 1].rsltIdxIemCnId)
                      }}
                    />
                    {props.checkIemUnit(itemList[i * 2 + 1].iemUnitCd)}
                  </Fragment>
                }
              </dd>
            </dl>
            : null
        ))}
        {dscrpList.map((item: any, i: number) => (
          <dl>
            <dt>{item.detailIemNm}</dt>
            <dd>
              <Stack sx={{width: '100%'}} alignItems={'flex-end'}>
                <TextField
                  id="outlined-multiline-static"
                  className="scrollBox"
                  name="rsltIdxIemCn"
                  value={item.rsltIdxIemCn}
                  multiline
                  rows={4}
                  onChange={(e) => {
                    if (props.onChange) props.onChange(e, item.rsltIdxIemCnId)
                  }}
                  inputProps={{
                    maxLength: 1000,
                  }}
                />
                <span className="count"><em>{item.rsltIdxIemCn.length}</em>/1000</span>
              </Stack>
              {/*<OutlinedInput*/}
              {/*  size="small"*/}
              {/*  className="ipt_tp01 tar"*/}
              {/*  sx={{width: '93.5%', marginRight: '10px'}}*/}
              {/*  name="rsltIdxIemCn"*/}
              {/*  value={item.rsltIdxIemCn}*/}
              {/*  onChange={(e) => {*/}
              {/*    if (props.onChange) props.onChange(e, item.rsltIdxIemCnId)*/}
              {/*  }}*/}
              {/*/>*/}
            </dd>
          </dl>
        ))}
        {
          props.isHistory ? <dl className='horz file'>
            <dt className="tal pl-20">증빙자료첨부</dt>
            <dd>
              <Stack css={styles.btnDown}>
                {preufFile.map((item: any, i: number) => (
                  <Button key={i} onClick={() => {
                    if (props.onDownload) props.onDownload(item.attachmentId)
                  }}>
                    <span>{item.fileNm}</span>
                  </Button>
                ))}
              </Stack>
            </dd>
          </dl> : <dl className='horz file'>
            <dt className="tal pl-20">증빙자료첨부</dt>
            {
              props.data.rsltIdxIemId && <dd>
                <Box css={styles.fileupload}>
                  <FileUpload1
                    keyValue={props.data.rsltIdxIemId}
                    files={files}
                    handleDelete={handleDelete}
                    handleUpload1={handleUpload}
                    files1={preufFile}
                    handleDelete2={handlePreufFileDelete}
                  />
                </Box>
              </dd>}
          </dl>
        }
      </div>
    </Box>
  </Fragment>
}

export const TableStandardType = (props: {
  data: rsltIdxIemList
  isHistory?: boolean
  detailIemNm: string[]
  stdIemNm: string[]
  onChange?: (event: any, i: number) => void
  checkIemUnit: (item: string | null) => void
  onUpdateFiles?: (id: string, file: any) => void
  onDeletePreufFile?: (attachmentId: string) => void
  onDownload?: (attachmentId: string) => void
}) => {
  const [files, setFiles]: any = useState([]);
  const [preufFile, setPreufFile]: any = useState(props.data.prufFile ? [props.data.prufFile] : []);
  useEffect(() => {
    setPreufFile(props.data.prufFile ? [props.data.prufFile] : [])
  },[props.data.prufFile])

  //등록하려는 증빙자료첨부파일삭제
  const handleDelete = (i: number) => {
    const update = [...files]
    update.splice(i, 1)
    setFiles(update);

    if (props.onUpdateFiles) props.onUpdateFiles(props.data.rsltIdxIemId, update)
  }

  const handlePreufFileDelete = (attachmentId: string, i: number) => {
    // setDeleteAttachmentId(attachmentId);
    const update1 = [...preufFile]
    update1.splice(i, 1)
    setPreufFile(update1);

    if (props.onDeletePreufFile) props.onDeletePreufFile(attachmentId)
  }

  //증빙자료첨부
  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    let upfile: any = e.target.files;
    const update = []
    for (var i = 0; i < 1; i++) {
      update.push(upfile[i]);
    }
    if (props.data.rsltIdxIemCnList.length !== 1) {
      setFiles(update)
      setPreufFile([])
    }

    if (props.onUpdateFiles) props.onUpdateFiles(props.data.rsltIdxIemId, update)
  }

  return <Fragment>
    <h4 className='tbl_title'>{props.data.rsltIdxNm}</h4>
    {props.detailIemNm.length > 0 ?
      <div className="tableDefault_scroll">
        <table className="tableDefault type5 w_triple">
          <thead>
          <tr>
            <th>구분</th>
            {props.stdIemNm.map((item: any) => (
              <th>{item}</th>
            ))}
          </tr>
          </thead>
          <tbody>
          {props.detailIemNm?.map((item: any) => (
            <tr>
              <td className="tal pl-20">{item}</td>
              {props.data.rsltIdxIemCnList?.map((res: any, i: number) => (
                props.stdIemNm?.map((k: any) => (
                  res.stdIemNm === k && res.detailIemNm === item ?
                    <td>
                      <OutlinedInput
                        size="small"
                        className="ipt_tp01 tar unit"
                        sx={{width: '93.5%', marginRight: '10px'}}
                        name="rsltIdxIemCn"
                        value={res.iemUnitCd == "TEXT" || res.iemUnitCd == "DSCRP" ?
                          res.rsltIdxIemCn : inputPriceFormat(res.rsltIdxIemCn)}
                        onChange={(e) => {
                          if (props.onChange) props.onChange(e, i)
                        }}
                      />{props.checkIemUnit(res.iemUnitCd)}
                    </td>
                    : null
                ))
              ))}
            </tr>
          ))}

          {
            props.isHistory ? <tr className='horz file'>
              <td className="tal pl-20">증빙자료첨부</td>
              <td colSpan={2}>
                <Stack css={styles.btnDown}>
                  {preufFile.map((item: any, i: number) => (
                    <Button key={i} onClick={() => {
                      if (props.onDownload) props.onDownload(item.attachmentId)
                    }}>
                      <span>{item.fileNm}</span>
                    </Button>
                  ))}
                </Stack>
              </td>
            </tr> : <tr>
              <td className="tal pl-20">증빙자료첨부</td>
              {
                props.data.rsltIdxIemId && <td colSpan={2}>
                  <Box css={styles.fileupload}>
                    <FileUpload1
                      keyValue={props.data.rsltIdxIemId}
                      files={files}
                      handleDelete={handleDelete}
                      handleUpload1={handleUpload}
                      files1={preufFile}
                      handleDelete2={handlePreufFileDelete}
                    />
                  </Box>
                </td>}
            </tr>
          }
          </tbody>
        </table>
      </div>
      : null}
  </Fragment>
}

export const TableListType = (props: {
  data: rsltIdxIemList
  isHistory?: boolean
  detailIemNm: string[]
  stdIemNm: string[]
  onChange?: (event: any, i: number) => void
  checkIemUnit: (item: string | null) => void
  onUpdateFiles?: (id: string, file: any) => void
  onDeletePreufFile?: (attachmentId: string) => void
  onDownload?: (attachmentId: string) => void
  onAddRow?: () => void
  onRemoveRow?: (check: number[]) => void
}) => {
  const [files, setFiles]: any = useState([]);
  const [check, setCheck] = useState<number[]>([])
  const [preufFile, setPreufFile]: any = useState(props.data.prufFile ? [props.data.prufFile] : []);
  useEffect(() => {
    setPreufFile(props.data.prufFile ? [props.data.prufFile] : [])
  },[props.data.prufFile])

  //등록하려는 증빙자료첨부파일삭제
  const handleDelete = (i: number) => {
    const update = [...files]
    update.splice(i, 1)
    setFiles(update);

    if (props.onUpdateFiles) props.onUpdateFiles(props.data.rsltIdxIemId, update)
  }

  const handlePreufFileDelete = (attachmentId: string, i: number) => {
    // setDeleteAttachmentId(attachmentId);
    const update1 = [...preufFile]
    update1.splice(i, 1)
    setPreufFile(update1);

    if (props.onDeletePreufFile) props.onDeletePreufFile(attachmentId)
  }

  //증빙자료첨부
  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    let upfile: any = e.target.files;
    const update = []
    for (var i = 0; i < 1; i++) {
      update.push(upfile[i]);
    }
    if (props.data.rsltIdxIemCnList.length !== 1) {
      setFiles(update)
      setPreufFile([])
    }

    if (props.onUpdateFiles) props.onUpdateFiles(props.data.rsltIdxIemId, update)
  }

  const columnData = props.detailIemNm.map(m => {
    return props.data.rsltIdxIemCnList.filter(f => f.flag != 'D').filter(f => f.detailIemNm == m)
  })

  return <Fragment>
    <Stack className='tbl_title' direction={'row'} justifyContent={'space-between'} alignItems={'center'}>
      <h4>{props.data.rsltIdxNm}</h4>
      {/*<CustomButton label={'추가'} type={'small'} color={"outlinedgdark"}/>*/}
      {
        props.onAddRow && <Stack direction={'row'} spacing={'20px'}>
          <IconButton
            size="large" edge="start" color="inherit" sx={{padding: 0}}
            onClick={(e) => {
              if (props.onRemoveRow) props.onRemoveRow(check)
            }}>
            <TrashIcon/>
          </IconButton>
          <IconButton
            size="large" edge="start" color="inherit" sx={{padding: 0}}
            onClick={(e) => {
              if (props.onAddRow) props.onAddRow()
            }}>
            <PlusIcon/>
          </IconButton>
        </Stack>
      }
    </Stack>
    {props.detailIemNm.length > 0 ?
      <div className="tableDefault_scroll">
        <table className="tableDefault type5 ">
          <thead>
          <tr>
            <th style={{width: '20px'}}/>
            {props.detailIemNm.map((item: any) => (
              <th>{item}</th>
            ))}
          </tr>
          </thead>
          <tbody>
          {
            columnData[0] && columnData[0].map((m, i) => {
              const test = columnData.reduce((ac, c) => {
                return [...ac, c[i]]
              }, [])
              return <tr>{
                props.detailIemNm.map((nm, j) => {
                  return <Fragment>
                    {
                      // test[j].rsltIdxIemCnId == '' &&
                      j == 0 && <td>
                        <Box className="checkbox">
                          <Checkbox
                            checked={check.includes(i)}
                            onClick={(e) => {
                              if (i == 0) return
                              if (check.includes(i)) {
                                setCheck(check.filter(f => f != i))
                              } else {
                                setCheck(check.concat(i))
                              }
                            }}
                          />
                        </Box>
                      </td>
                    }
                    <td>
                      <OutlinedInput
                        size="small"
                        className="ipt_tp01 tar"
                        sx={{width: '100%', marginRight: '10px'}}
                        name="rsltIdxIemCn"
                        value={test[j].iemUnitCd == "TEXT" || test[j].iemUnitCd == "DSCRP" ?
                          test[j].rsltIdxIemCn : inputPriceFormat(test[j].rsltIdxIemCn)}
                        onChange={(e) => {
                          if (props.onChange) props.onChange(e, (i * props.detailIemNm.length) + j)
                        }}
                      />{props.checkIemUnit(test[j].iemUnitCd)}
                    </td>
                  </Fragment>
                })
              }</tr>
            })
          }
          {/*<tr>*/}
          {/*  {*/}
          {/*    props.data.rsltIdxIemCnList ?*/}
          {/*      props.data.rsltIdxIemCnList.map((item: any, i: number) => (*/}
          {/*        <td>*/}
          {/*          <OutlinedInput*/}
          {/*            size="small"*/}
          {/*            className="ipt_tp01 tar"*/}
          {/*            sx={{width: '91%', marginRight: '10px'}}*/}
          {/*            name="rsltIdxIemCn"*/}
          {/*            value={inputPriceFormat(item.rsltIdxIemCn)}*/}
          {/*            onChange={(e) => {*/}
          {/*              if (props.onChange) props.onChange(e, i)*/}
          {/*            }}*/}
          {/*          />{props.checkIemUnit(item.iemUnitCd)}*/}
          {/*        </td>*/}
          {/*      )) : null}*/}
          {/*</tr>*/}

          {
            props.isHistory ? <tr className='horz file'>
              <td className="tal pl-20" colSpan={2}>증빙자료첨부</td>
              <td colSpan={props.data.rsltIdxIemCnList.length - 1}>
                <Stack css={styles.btnDown}>
                  {preufFile.map((item: any, i: number) => (
                    <Button key={i} onClick={() => {
                      if (props.onDownload) props.onDownload(item.attachmentId)
                    }}>
                      <span>{item.fileNm}</span>
                    </Button>
                  ))}
                </Stack>
              </td>
            </tr> : <tr>
              <td className="tal pl-20" colSpan={2}>증빙자료첨부</td>
              {
                props.data.rsltIdxIemId && <td colSpan={props.data.rsltIdxIemCnList.length - 1}>
                  <Box css={styles.fileupload}>
                    <FileUpload1
                      keyValue={props.data.rsltIdxIemId}
                      files={files}
                      handleDelete={handleDelete}
                      handleUpload1={handleUpload}
                      files1={preufFile}
                      handleDelete2={handlePreufFileDelete}
                    />
                  </Box>
                </td>}
            </tr>
          }
          </tbody>
        </table>
      </div>
      : null}
  </Fragment>
}


export default PerformanceMgtDetail;

export const inputPriceFormat = (str: any) => {
  const comma = (str: any) => {
    str = String(str);
    return str.replace(/(\d)(?=(?:\d{3})+(?!\d))/g, "$1,");
  };
  const uncomma = (str: any) => {
    str = String(str);
    return str.replace(/[^\d]+/g, "");
  };
  return comma(uncomma(str));
};

export const uncomma2 = (str: any) => {
  str = String(str);
  return str.replace(/[^\d]+/g, "");
};