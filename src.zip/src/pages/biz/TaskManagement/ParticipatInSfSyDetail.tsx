import React, {Dispatch, Fragment, SetStateAction, useEffect, useRef, useState} from "react";
import {Banner} from "~/components/Banner";
import {useQuery} from "react-query";
import {fetchGetCommCode} from "~/fetches";
import {CustomRadioButtons} from "~/components/NoticeCustomCheckBoxs";
import {Box, Stack, TextField} from "@mui/material";
import {
  fetchSurveyInfo,
  fetchSurveyResult,
  fetchSurveySave
} from "~/fetches/fetchSurvey";
import {useNavigate, useParams} from "react-router-dom";
import * as comstyles from '~/styles/styles';
import {CustomButton, CustomCheckBoxs} from "shared/components/ButtonComponents";
import dayjs from "dayjs";
import {VerticalInterval} from "shared/components/LayoutComponents";
import {useGlobalModalStore} from "~/pages/store/GlobalModalStore";

function ParticipatInSfSyDetail() {
  const params = useParams()
  const navigator = useNavigate()
  const {addModal} = useGlobalModalStore()
  const [loading, setLoading] = useState(true)
  const [basicInfo, setBasicInfo] = useState<any>()
  const [list, setList] = useState<SurveyQuestion[]>([])
  const [sheet, setSheet] = useState<SurveySheet>()
console.log('detail init - ' + params.id!)
  // const {data: basicInfo} = useQuery(["fetchSurveyInfo", params.id!], () => fetchSurveyInfo(params.id!))
  // const questions = useQuery(["fetchSurveyQuestions", params.id!], () => fetchSurveyQuestions(params.id!))
  const questions = useQuery(["result", params.id!], () => fetchSurveyResult(params.id!),{
    onError: (err:any) => {
      addModal({
        open: true,
        content: err.response.data.message,
        onClose: () => navigator('/biz/TaskManagement/ParticipatInSfSy'),
        onConfirm: () => navigator('/biz/TaskManagement/ParticipatInSfSy')
      })
    }
  })

  // {tt.data && console.log('tt - ' + JSON.stringify(tt.data))}

  useEffect(() => {
    if (!questions.isLoading && !questions.isFetching) {
      if (!!questions.data) {
        setBasicInfo(questions.data)
        // console.log('questions - ' + JSON.stringify(questions.data))
        if (questions.data.questionList) {
          setList(questions.data.questionList)
          if (!sheet) {
            setSheet({
              surveyId: params.id!,
              questions: questions.data.questionList.map((m: Answer) => {
                return {
                  questionId: m.questionId,
                  answers: []
                }
              })
            })
          }
        }
      }
      setLoading(false)
    }
  }, [questions.data, questions.isLoading, questions.isFetching])

  const changeInput = (id: string, selectedAnswer: {
    answerId: string
    shortAnswer?: string
  }[]) => {
    if (sheet) {
      const update = {...sheet}
      const index = update.questions.findIndex(f => f.questionId == id)
      if (index >= 0 && JSON.stringify(update.questions[index].answers) != JSON.stringify(selectedAnswer)) {
        update.questions[index].answers = selectedAnswer
        setSheet(update)
      }
    }
  }

  const send = async () => {
    console.log('answer - ' + JSON.stringify(sheet))
    try {
      const res = await fetchSurveySave(sheet).then(res => {
        navigator('/biz/TaskManagement/ParticipatInSfSy')
      })
    }catch (err:any) {
      addModal({
        type:'normal',
        open: true,
        content: err.response.data.message
      })
    }

  }

  return <Banner
    title={'만족도 조사'} loading={loading}
    summary={<p>AICA에서 주관하는 사업 또는 행사 등의 프로그램에 참여하신 후기를 작성하시면 됩니다.<br/>
      보내주신 의견이 더 좋은 프로그램과 시스템을 만드는 데 기여합니다.</p>}>
    <div css={comstyles.container}>
      <div css={comstyles.sub_cont02}>
        {basicInfo &&
          <Stack spacing={'40px'} className={"content"}>
            <Box>
              <h2>창업지원사업 참여 만족도 설문조사</h2>
              <VerticalInterval size={'12px'}/>
              <Box sx={{padding: '30px', backgroundColor: '#f5f5f5', borderRadius: '5px', lineHeight: '28px'}}>
                <p>창업지업사업에 참여하신 분들을 대상으로 본 사업의 프로그램에 대한 만족도를 조사하고 있습니다. <br/>
                  의견을 보내주시면 향후 사업의 프로그램을 보완하는데 참고하겠습니다.</p>
                {/*<p>의견을 보내주시면 향후 사업의 프로그램을 보완하는데 참고하겠습니다.</p>*/}
                <p style={{fontWeight: 500}}>진행기간
                  <span style={{
                    fontWeight: 300,
                    paddingLeft: '5px'
                  }}>{`${dayjs(basicInfo.beginDay).format('YYYY-MM-DD')} ~ ${dayjs(basicInfo.endDay).format('YYYY-MM-DD')}`}</span>
                </p>
              </Box>
            </Box>
            {
              list && list.map((m, i) => <Survey question={m} changeInput={changeInput}/>)
            }
            <Stack direction="row" justifyContent="center" spacing={2}>
              <CustomButton label={'취소'} type={'listBack'} color={'outlinedblack'}
                            onClick={() => {navigator('/biz/TaskManagement/ParticipatInSfSy')}}/>
              <CustomButton label={'제출'} type={'listBack'} color={'primary'} onClick={send}/>
            </Stack>
          </Stack>
        }
      </div>
    </div>
  </Banner>
}

const Survey = (props: {
  question: SurveyQuestion
  changeInput: (id: string, selectedAnswer: {
    answerId: string
    shortAnswer?: string
  }[]) => void
}) => {
  const [shortAnswer, setShortAnswer] = useState('')

  return <Box>
    <p style={{fontWeight: 500, paddingBottom: '12px'}}>
      <i style={{color: '#4063ec'}}>{`Q ${props.question.questionNo.toString().padStart(2, '0')}`}</i>
      {props.question.questionCn}
      {props.question.questionType === 'CHECKBOX' && <span style={{color: '#4063ec'}}>{'(복수선택 가능)'}</span>}
      {props.question.required && <span style={{color: '#4063ec', fontSize: '14px'}}>{'(필수)'}</span>}
      {props.question.required || <span style={{color: '#707070', fontSize: '14px'}}>{'(선택)'}</span>}
    </p>
    {
      props.question.questionType === 'CHECKBOX' && <CustomCheckBoxs
        checkbox={props.question.answerList.map(m => {
          return {
            label: m.answerCn
          }
        })}
        onClick={(selected: string[]) => {
          const answerList = props.question.answerList.filter(f => selected.includes(f.answerCn))
          props.changeInput(props.question.questionId, answerList.map(m => {
            return {answerId: m.answerId}
          }))
        }}
      />
    }
    {
      props.question.questionType === 'RADIO' && <CustomRadioButtons
        style={{paddingLeft: '25px'}}
        hideAll data={props.question.answerList.map(m => {
        return {
          code: m.answerId,
          codeNm: m.answerCn
        }
      })}
        onClick={(selected) => {
          // const answer = props.question.answerList.filter(f => selected == f.answerId)
          props.changeInput(props.question.questionId, [{answerId: selected}])
        }}
      />
    }
    {
      props.question.questionType === 'SHORT_ANSWER' && <Fragment>
        <TextField
          id="outlined-multiline-static"
          value={shortAnswer}
          onChange={(e) => {
            setShortAnswer(e.target.value)
            props.changeInput(props.question.questionId, [{
              answerId: props.question.answerList[0].answerId,
              shortAnswer: e.target.value
            }])
          }}
          multiline rows={4}
          className="textfield_tp01"
          inputProps={{
            maxLength: 1000,
          }}
        />
        <div className='tf_count'>{`${shortAnswer.length} / 1000`}</div>
      </Fragment>
    }
  </Box>
};

interface SurveyQuestion {
  surveyId: string,
  questionId: string,
  questionNo: number,
  questionType: string,
  required: boolean,
  questionCn: string,
  answerList: Answer[]
}

interface Answer {
  surveyId: string
  questionId: string
  answerId: string
  answerNo: number
  answerCn: string
}

interface SurveySheet {
  surveyId: string
  questions: SelectedAnswer[]
}

interface SelectedAnswer {
  questionId: string
  answers: {
    answerId: string
    shortAnswer?: string
  }[]
}

export default ParticipatInSfSyDetail;