// 만족도조사참여 -> 만족도조사참여
// import React from "react"
import * as comstyles from '~/styles/styles';
import Box from '@mui/material/Box';
import {Stack, Typography, TextField, useMediaQuery, useTheme, List, ListItem, ListItemText} from '@mui/material';
import {CustomButton, CustomCheckBoxs} from '~/components/ButtonComponents';
import {CustomRadioButtons} from '~/components/NoticeCustomCheckBoxs';
import {useGlobalModalStore} from '~/pages/store/GlobalModalStore';
import {useQuery} from 'react-query';
import {fetchSurveyList, fetchSurveySave} from '~/fetches/fetchSurvey';
import {fetchGetCommCode} from '~/fetches';
import React, {Fragment, useEffect, useRef, useState} from 'react';
import {initSurveyInput, surveyInput} from '~/models/ModelSurvey';
import {NavLink, useNavigate} from 'react-router-dom';
import {Banner} from "~/components/Banner";
import NoData from "~/components/Loading/NoData";
import dayjs from "dayjs";
import {SearchModal} from "~/components/BizCommon/SearchModal";
import DatePicker from "~/components/DatePicker";
import RceptStus from "~/pages/biz/BusinessAppMgt/PopComp/RceptStus";

function ParticipatInSfSy() {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const {addModal} = useGlobalModalStore();
  const today = new Date()
  const [input, setInput] = useState<surveyInput>({
    ...initSurveyInput,
    beginDay: dayjs(new Date().setMonth(today.getMonth()-1)).format('YYYYMMDD'),
    endDay: dayjs(today).format('YYYYMMDD')
  })
  const [open, setOpen] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true)
  const navigator = useNavigate()

  // 공통 코드 조회
  const {data: assign_box} = useQuery("getCode", () => fetchGetCommCode("SURVEY_ST"));
  // 설문지 조회
  const {data: surveyList} = useQuery("fetchSurveyGet", () => fetchSurveyList(input), {
    onSuccess: (data: any) => {
      console.log('data - ' + JSON.stringify(data))
      // const questions: any = [];
      // // eslint-disable-next-line array-callback-return
      // data.questionList.map((item: any, i: number) => {
      //   const answers: { answerId: any; shortAnswer: string; }[] = [];
      //   // eslint-disable-next-line array-callback-return
      //   item.answerList.map((ans: any) => {
      //     answers.push({answerId: ans.answerId, shortAnswer: ""})
      //   })
      //   questions.push({questionId: data.questionList[i].questionId, answers: []})
      // })
      // setSurveyAnsParam({surveyId: data.surveyId, questions: questions});
      setLoading(false)
    },
    onError: (e: any) => {
      // setOpen(true);
      // setError(e.response.data.message)
      addModal({
        open: true,
        content: e.response.data.message,
        type: 'normal'
      });
      setLoading(false)
    }
  });


  const moreInfo = () => {
    const itemsPerPage: any = input.itemsPerPage + 10;
    setInput((state) => ({...state, itemsPerPage}));
  }

  return <Banner
    title={'만족도 조사'} loading={loading}
    summary={<p>AICA에서 주관하는 사업 또는 행사 등의 프로그램에 참여하신 후기를 작성하시면 됩니다.<br/>
      보내주신 의견이 더 좋은 프로그램과 시스템을 만드는 데 기여합니다.</p>}
    detailContent={<Fragment>{
      isMobile ?
        <SearchModal
          placehold=''
          handleSearch={(s: string | undefined) => {
            console.log(s)
          }}
          assign_box={assign_box?.list}
        /> : <Box css={comstyles.picker_card}>
          <dl>
            <dt>이용시작일</dt>
            <dd>
              <Box className="box_scroll">
                <DatePicker
                  pickerType='two'
                  questBeginDay={!!input.beginDay? dayjs(input.beginDay, 'YYYYMMDD').toString() : ''}
                  questEndDay={!!input.endDay? dayjs(input.endDay, 'YYYYMMDD').toString() : ''}
                  changeStart={(startNewTime: Date | null) => {
                    if (startNewTime) {
                      if (input.endDay) {
                        const end = new Date(Number(input.endDay.slice(0, 4)),
                          Number(input.endDay.slice(4, 6)) - 1, Number(input.endDay.slice(6, 8)))
                        if (startNewTime.getTime() > end.getTime()) {
                          setInput({...input, beginDay: dayjs(end).format('YYYYMMDD')})
                          return
                        }
                      }

                      setInput({...input, beginDay: dayjs(startNewTime).format('YYYYMMDD')})
                    }
                  }}
                  changeEnd={(endNewTime: Date | null) => {
                    if (endNewTime) {
                      if (input.beginDay) {
                        const begin = new Date(Number(input.beginDay.slice(0, 4)),
                          Number(input.beginDay.slice(4, 6)) - 1, Number(input.beginDay.slice(6, 8)))
                        if (endNewTime.getTime() < begin.getTime()) {
                          setInput({...input, endDay: dayjs(begin).format('YYYYMMDD')})
                          return
                        }
                      }

                      setInput({...input, endDay: dayjs(endNewTime).format('YYYYMMDD')})
                    }
                  }}
                />
              </Box>
            </dd>
          </dl>
          <dl>
            <dt>설문상태</dt>
            <dd>
              <Box className="box_scroll">
                <CustomRadioButtons
                  row data={assign_box ? assign_box.list : []}
                  val={input.surveySt}
                  onClick={(s: string) => {
                    setInput({...input, surveySt: s})
                    // setPlanPresentnSttusCd(s);
                    // if (s.length > 0) console.log(s);
                  }}
                />
              </Box>
            </dd>
          </dl>
        </Box>
    }</Fragment>}>
    <div css={comstyles.container}>
      <Box css={comstyles.sub_cont02}>
        <div className="content list">
          {/* className="list02" 클래스는 사유확인버튼이 있을시에만 추가 */}
          <div css={comstyles.detal_list} className="list02">
            <Stack
              spacing={6}
              direction="row"
              className="sub_tit"
              justifyContent="space-between"
            >
              <Typography variant="h4" component="div">
                만족도 조사 내역
                <span className='data'><em>{surveyList ? surveyList.totalItems : 0}</em> 건</span>
              </Typography>
            </Stack>
            <List>
              {!!surveyList ? surveyList.list.length > 0 ? surveyList.list.map((item: any, i: number) => (
                <div className="btn_cont" key={i}>
                  <Box  onClick={() => {
                    if (item.duplicated || !item.partcptnAt) {
                      console.log('detail page - ' + item.surveyId)
                      navigator(`/biz/TaskManagement/ParticipatInSfSy/${item.surveyId}`)
                    }else {
                      addModal({
                        open: true,
                        content: '이미 참여하셨습니다.'
                      })
                    }
                  }}>
                    <ListItem>
                      <ListItemText
                        secondary={
                          <React.Fragment>
                            {/*<span className="tit_body">*/}
                            <span className="tit_body">
                          <Typography variant="body1" component="span">
                            {item.surveyNm}
                          </Typography>
                        </span>
                            <span className="date">
                          <span>설문기간 : <em>{dayjs(item.beginDay).format('YYYY-MM-DD') + " ~ " + dayjs(item.endDay).format('YYYY-MM-DD')}</em></span>
                        </span>
                            <RceptStus stus={!!item.surveyStNm ? item.surveyStNm : '접수상태'}/>
                          </React.Fragment>
                        }
                      />
                    </ListItem>
                  </Box>
                </div>
              )) : <NoData/> : <NoData/>}
            </List>
            {(input.itemsPerPage) < surveyList?.totalItems ?
              // 더보기
              <Stack css={comstyles.bottom_btn}>
                <CustomButton label={'더보기'} type={'full'} color={'item'} style={{margin: '10px 0'}}
                              onClick={() => moreInfo()}/>
              </Stack>
              : null}
          </div>
        </div>
      </Box>
    </div>
  </Banner>
}

export default ParticipatInSfSy;
//
// return <Banner
//   title={'만족도 조사'} loading={loading}
//   summary={<p>AICA에서 주관하는 사업 또는 행사 등의 프로그램에 참여하신 후기를 작성하시면 됩니다.<br />
//     보내주신 의견이 더 좋은 프로그램과 시스템을 만드는 데 기여합니다.</p>}>
//   <div css={comstyles.container}>
//     <div css={comstyles.sub_cont02}>
//       {survey?
//         <div className="content mt120">
//           <Stack spacing={6} direction="column" className="sub_tit">
//             <Typography variant="h4" component="div">
//               창업지원사업 참여 만족도 설문조사
//             </Typography>
//           </Stack>
//           <Box css={styles.box_graylist}>
//             창업지업사업에 참여하신 분들을 대상으로 본 사업의 프로그램에 대한 만족도를 조사하고 있습니다.<br />
//             의견을 보내주시면 향후 사업의 프로그램을 보완하는데 참고하겠습니다.<br />
//             <p className='terms'>진행기간 2021-10-01 ~ 2021-12-31</p>
//           </Box>
//           <Stack css={styles.list_select}>
//             <ul>
//               {survey?survey.questionList.map((item:any,i:number)=>(
//                   <Survey question={item} key={i} changeInput={changeInput} number={i}/>
//                 )
//               ):null}
//             </ul>
//           </Stack>
//           {survey?
//             <Stack direction="row" justifyContent="center" spacing={2} sx={{marginTop: '40px'}} css={styles.btn_next}>
//               <CustomButton label={'취소'} type={'listBack'} color={'outlinedblack'} />
//               <CustomButton label={'제출'} type={'listBack'} color={'primary'} onClick={send} />
//             </Stack>
//             :null}
//         </div> :
//         <div className="content mt120">
//           <NoData message={'참여 가능 설문조사가 없습니다.'}/>
//         </div>}
//     </div>
//     <ModalComponents open={open} type={'normal'} content={error}
//                      onConfirm={() => { setOpen(false);navigate(-1); }}
//                      onClose={() => { setOpen(false);navigate(-1);}}>
//     </ModalComponents>
//   </div>
// </Banner>
