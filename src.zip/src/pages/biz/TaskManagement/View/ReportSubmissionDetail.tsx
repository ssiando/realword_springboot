import React from "react";
import {useState, useEffect, useRef} from 'react';
import * as styles from '../styles';
import * as comstyles from '~/styles/styles';
import {Box, TextField, Stack,} from '@mui/material';
import {FileUpload1} from "../../../EventNews/FileUpload";
import {CustomButton} from '~/components/ButtonComponents';
import {fetchReportDetailGet, fetchReportSubmit} from "~/fetches/fetchReport";
import {useLocation, useNavigate, useParams} from "react-router-dom";
import {useQuery} from "react-query";
import {ModalReasonConfirm} from "../../BusinessAppMgt/PopComp/ModalReasonConfirm";
import {intialErrorQuestion} from "~/models/ModelTreadmill";
import {useGlobalModalStore} from "~/pages/store/GlobalModalStore";
import {Banner} from "~/components/Banner";
import fetchDownload from "~/fetches/fetchDownload";

/* 
  작성일    :   2022/07/06
  화면명    :   사업관리 -> 평가관리 -> 발표자료 제출
  회면ID    :   UI-USP-FRN-0160301
  화면/개발 :   Seongeonjoo / navycui ...todo 대기 api 차주
*/
const ReportSubmissionDetail = () => {
  const navigate = useNavigate();
  const textInput: any = useRef("");
  const receive: any = useLocation();
  const [data, setData] = useState<any>(null)
  const [files, setFiles]: any = useState([]);
  const [textLength, setLength] = useState(0)
  const [loading, setLoading] = useState(true)
  const params = useParams()
  const {addModal} = useGlobalModalStore()

  const [attachmentFileList, setAttachmentFileList]: any = useState([]);
  const [deleteAttachFileList, setDeleteAttachFileList]: any = useState([]);


  const handleDelete = (i: number) => {
    const update = [...files]
    update.splice(i, 1)
    setFiles(update);
  };

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    let upfile: any = e.target.files;
    const update = [...files]
    for (var i = 0; i < upfile.length; i++) {
      update.push(upfile[i]);
    }
    setFiles(update)
  }

  const deleteAttach1 = (attachmentId: string, i: number) => {
    const update = [...deleteAttachFileList]
    update.push({
      attachmentId: attachmentId
    })
    setDeleteAttachFileList(update);
    const update1 = [...attachmentFileList]
    update1.splice(i, 1)
    setAttachmentFileList(update1)
  }

  const handleDownLoad = async (attachmentId: string) => {
    try {
      const result = await fetchDownload(`${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/reprt-presentn/${params.id!}/atchmnfl/${attachmentId}`)
    } catch (e: any) {
      let status = e.response.status;

      if (status === 400) {
        addModal({
          open: true,
          content: "파일이 없습니다."
        })
      }
    }
  }

  const changeText = () => {
    setLength(textInput.current.value.length)
  }
  const report = useQuery("fetchReportDetailGet", () => fetchReportDetailGet(receive.state.item.reprtId));
  useEffect(() => {
    if (!report.isLoading && !report.isFetching) {
      if (!!report.data) {
        console.log('res - ' + JSON.stringify(report.data))
        setData(report.data)
        textInput.current.value = report.data.reprtSumryCn
        changeText()
        setAttachmentFileList(report.data.attachFileList);
      }
      setLoading(false)
    }
  }, [report.data, report.isLoading, report.isFetching])

  const [questionError, setQuestionError] = useState(intialErrorQuestion);

  const validate = () => {
    let check = true;
    //이의신청 내용 확인
    if (textInput.current.value === "") {
      setQuestionError({
        errorQuestion: true, helperQuestion: "문의내용을 입력하세요."
      })
      check = false;
    } else {
      setQuestionError({
        errorQuestion: false, helperQuestion: ""
      })
    }
    return check;
  }

  const send = (event: any) => {
    if (!validate()) {
      return;
    }
    ;
    try {
      const info = {
        reprtSumryCn: textInput.current.value,
        attachFileDeleteList: deleteAttachFileList,
      }
      const form = new FormData();
      form.append("info", new Blob([JSON.stringify(info)], {type: "application/json"}));
      for (let i = 0; i < files.length; i++) {
        form.append("fileList", files[i])
      }

      fetchReportSubmit(receive.state.item.reprtId, form).then(
        () => navigate('../biz/TaskManagement/ReportSubmission')
      ).catch((e) => {
        addModal({
          open: true,
          content: e.response.data.message
        });
      })
    } catch (e: any) {
      if (!!e.response && e.response.data) return alert(e.response.data.message);
    }
  }

  return <Banner
    title={'보고서 제출'} loading={loading}
    summary={'중간보고서 및 결과보고서 제출대상 과제를 조회하고, 제출할 수 있습니다.'}>
    <div css={comstyles.container}>
      <Box className="content_body">
        <div className="content">
          <Box css={comstyles.box_graylist}>
            • <span className="must">*</span> 표시는 필수입력 항목입니다.
          </Box>
          <h4 className="tbl_title">기본정보</h4>
          {data ?
            <Box css={styles.table}>
              <div className="detail_table">
                <dl>
                  <dt>공고명</dt>
                  <dd>{data.pblancNm}</dd>
                </dl>
                <dl>
                  <dt>과제명</dt>
                  <dd>{data.taskNm}</dd>
                  <dt>접수번호</dt>
                  <dd>{data.receiptNo}</dd>
                </dl>
                <dl>
                  <dt>제출구분</dt>
                  <dd>{data.reprtType}</dd>
                  <dt>제출상태</dt>
                  <dd className="withLink">{data.reprtSttus}
                    {
                      data.reprtSttusCd == "SR" &&
                      <ModalReasonConfirm
                        applyId={params.id!}
                        viewNm='ReportSubmission'
                        title='보고서 제출'
                        variant='text'
                        label='사유확인'
                        type='modify'
                        color='outlined'
                      />
                      // <ModalReasonConfirm applyId={receive.state.item.reprtId} viewNm="ReportSubmission" variant="text"/>
                    }
                    {/* <ModalReasonConfirm applyId={receive.state.item.reprtId} viewNm='ReportSubmissionDetail' title='보고서 제출'/> */}
                  </dd>
                </dl>
                <dl>
                  <dt>제출일</dt>
                  <dd>{data.presentnDate}</dd>
                </dl>
              </div>
            </Box>
            : null}
          <h4 className="tbl_title">보고서 요약</h4>
          <TextField
            id="outlined-multiline-static"
            onChange={changeText}
            inputRef={textInput}
            error={questionError.errorQuestion}
            helperText={questionError.helperQuestion}
            multiline rows={5.2}
            className="textfield_tp01"
            inputProps={{
              maxLength: 1000,
            }}
          />
          <div className='tf_count'>{textLength}/1000</div>
          <h4 className="tbl_title">파일첨부 <span className="must">*</span></h4>
          <Box css={styles.fileupload}>
            {/*<FileUpload*/}
            {/*  files={files}*/}
            {/*  handleDelete={handleDelete}*/}
            {/*  handleUpload={handleUpload}*/}
            {/*/>*/}
            <FileUpload1
              files={files}
              handleDelete={handleDelete}
              handleUpload1={handleUpload}
              files1={attachmentFileList}
              handleDelete2={deleteAttach1}
              handleDownLoad={handleDownLoad}
            />
          </Box>
          {
            data && (data.reprtSttusCd == "SR" || data.reprtSttusCd == "PR") &&
            <Stack direction="row" justifyContent="center" spacing={2} sx={{marginTop: '40px'}} css={comstyles.btn_next}>
              <CustomButton label={'제출'} type={'listBack'} color={'primary'} onClick={send}/>
            </Stack>
          }
        </div>
      </Box>
    </div>
  </Banner>
}

export default ReportSubmissionDetail;

// function addModal(arg0: { open: boolean; content: any; }) {
//   throw new Error("Function not implemented.");
// }
