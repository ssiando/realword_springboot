import * as styles from './styles';
import * as comstyles from '~/styles/styles';
import Box from '@mui/material/Box';
import {
  Stack,
  useMediaQuery,
  List,
  ListItem,
  ListItemText,
  TooltipProps,
  Tooltip,
  tooltipClasses,
  Collapse, Paper, Chip
} from '@mui/material';
import React, {Fragment, useCallback, useEffect, useRef, useState} from 'react';
import Typography from '@mui/material/Typography';
import {useTheme} from '@mui/material';
import {CustomButton} from '~/components/ButtonComponents';
import {NavLink} from 'react-router-dom';
import {fetchGetCommCode} from '~/fetches';
import dayjs from 'dayjs';
import {styled} from '@mui/material/styles';
import {useQueries, useQuery} from "react-query";
import IconButton from '@material-ui/core/IconButton';
import {QuestionIcon} from '~/components/IconComponents';
import {SelectSearchBar} from '~/components/BizCommon/SearchBar';
import {SearchModal} from '~/components/BizCommon/SearchModal';
import DatePicker from '~/components/DatePicker';
import {ModalReasonConfirm} from '../BusinessAppMgt/PopComp/ModalReasonConfirm';
import {fetchReportListGet} from '~/fetches/fetchReport';
import {reportListInput} from '~/models/ModelReport';
import RceptStus from '../BusinessAppMgt/PopComp/RceptStus';
import NoData from '~/components/Loading/NoData';
import {CustomRadioButtons} from '~/components/NoticeCustomCheckBoxs';
import {Banner} from "~/components/Banner";

const ReportSubmission = () => {
  const today = new Date();
  const begin = new Date();
  begin.setDate(begin.getDate() - 30)
  const theme = useTheme();
  const [total, setTotal] = useState(0);
  const [list, setList] = useState<any>();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [loading, setLoading] = useState(true)
  const [mobileSearch, setMobileSearch] = useState(false)


  const [input, setInput] = useState<reportListInput>({
    presentnStartDate: '',
    presentnEndDate: '',
    reprtTypeCd: '',
    reprtSttusCd: "",
    keyword: '',
    keywordDiv: 'pblancNm',
    page: 1,
    itemsPerPage: 10
  })
  // 공통 코드 조회
  const userQueries = useQueries(
    ['REPRT_STTUS', 'REPRT_TYPE'].map(groupType => {
      return {
        queryKey: [groupType],
        queryFn: () => fetchGetCommCode(groupType),
      }
    }))

  // 보고서 제출 목록 조회
  const getList = async () => {
    setLoading(true)
    await fetchReportListGet(input).then((res: any) => {
      console.log('res.list - ' + JSON.stringify(res))
      setList(res.list);
      setTotal(res.totalItems);
    }).catch(e => {
      setLoading(false)
    })
    setLoading(false)
  }
  const moreInfo = () => {
    const itemsPerPage: any = input.itemsPerPage + 10;
    setInput((state) => ({...state, itemsPerPage}));
  }

  useEffect(() => {
    getList()
  }, [])

  useEffect(() => {
    getList()
  }, [input.itemsPerPage])

  useEffect(() => {
    if (mobileSearch) {
      getList()
      setMobileSearch(false)
    }
  }, [mobileSearch])

  return <Banner
    title={'보고서 제출'} loading={loading}
    summary={'중간보고서 및 결과보고서 제출대상 과제를 조회하고, 제출할 수 있습니다.'}
    searchContent={<SelectSearchBar
      placehold='보고서를 찾고 계신가요?'
      defaultValue={input.keyword}
      curr={input.keywordDiv}
      selectData={[{code: 'taskNmKo', codeNm: '과제명'}, {code: 'pblancNm', codeNm: '공고명'}]}
      onChange={(keyword: string) => setInput({...input, keyword: keyword})}
      onChangeDiv={(div: string) => setInput({...input, keywordDiv: div})}
      handleSearch={(val: any) => {
        getList()
      }}
    />}
    detailContent={<Fragment>
      {isMobile ? <SearchModal
        placehold='보고서를 찾고 계신가요?'
        defaultBeginDay={input.presentnStartDate}
        defaultEndDay={input.presentnEndDate}
        selectList={[{title: '제출구분', list: (userQueries[1].status == 'success') ? userQueries[1].data.list : []},
          {title: '제출상태', list: (userQueries[0].status == 'success') ? userQueries[0].data.list : []}
        ]}
        handleSearch={(searchInput, sdt, edt) => {}}
        onSearch={(date, selectedList) => {
          setInput({
            ...input,
            presentnStartDate: date?.beginDay || '',
            presentnEndDate: date?.beginDay || '',
            reprtTypeCd: selectedList?.find(f => f.title == '제출구분')?.value || '',
            reprtSttusCd: selectedList?.find(f => f.title == '제출상태')?.value || ''
          })
          setMobileSearch(true)
        }}
      /> : <Box css={styles.teble_detal}>
        <Box component={Paper} css={styles.table02}>
          <dl>
            <dt>제출일</dt>
            <dd>
              <Box className="box_scroll">
                <DatePicker
                  pickerType='two'
                  questBeginDay={!!input.presentnStartDate? dayjs(input.presentnStartDate, 'YYYYMMDD').toString() : ''}
                  questEndDay={!!input.presentnEndDate? dayjs(input.presentnEndDate, 'YYYYMMDD').toString() : ''}
                  changeStart={(startNewTime: Date | null) => {
                    if (startNewTime) {
                      if (input.presentnEndDate) {
                        const end = new Date(Number(input.presentnEndDate.slice(0, 4)),
                          Number(input.presentnEndDate.slice(4, 6)) - 1, Number(input.presentnEndDate.slice(6, 8)))
                        if (startNewTime.getTime() > end.getTime()) {
                          setInput({...input, presentnStartDate: dayjs(end).format('YYYYMMDD')})
                          return
                        }
                      }

                      setInput({...input, presentnStartDate: dayjs(startNewTime).format('YYYYMMDD')})
                    }
                  }}
                  changeEnd={(endNewTime: Date | null) => {
                    if (endNewTime) {
                      if (input.presentnStartDate) {
                        const begin = new Date(Number(input.presentnStartDate.slice(0, 4)),
                          Number(input.presentnStartDate.slice(4, 6)) - 1, Number(input.presentnStartDate.slice(6, 8)))
                        if (endNewTime.getTime() < begin.getTime()) {
                          setInput({...input, presentnEndDate: dayjs(begin).format('YYYYMMDD')})
                          return
                        }
                      }

                      setInput({...input, presentnEndDate: dayjs(endNewTime).format('YYYYMMDD')})
                    }
                  }}
                />
              </Box>
            </dd>
          </dl>
          <dl>
            <dt>제출구분</dt>
            <dd>
              <Box className="box_scroll">
                <CustomRadioButtons
                  row data={(userQueries[1].status == 'success') ? userQueries[1].data.list : []}
                  val={input.reprtTypeCd}
                  onClick={(s: string) => {
                    setInput({...input, reprtTypeCd: s})
                  }}
                />
              </Box>
            </dd>
          </dl>
          <dl>
            <dt>제출상태</dt>
            <dd>
              <Box className="box_scroll">
                <CustomRadioButtons
                  row data={(userQueries[0].status == 'success') ? userQueries[0].data.list : []}
                  val={input.reprtSttusCd}
                  onClick={(s: string) => {
                    setInput({...input, reprtSttusCd: s})
                  }}
                />
              </Box>
            </dd>
          </dl>
        </Box>
      </Box>
      }
    </Fragment>}>
    <div css={comstyles.container}>
      <Box css={comstyles.sub_cont02}>
        <div className="content list">
          {/* className="list02" 클래스는 사유확인버튼이 있을시에만 추가 */}
          <div css={comstyles.detal_list} className="list02">
            <Stack
              spacing={6}
              direction="row"
              className="sub_tit"
              justifyContent="space-between"
            >
              <Typography variant="h4" component="div">
                보고서
                <span className='data'><em>{total ? total : 0}</em> 건</span>
              </Typography>
              <Stack style={{alignSelf: 'center'}} flexDirection={'row'} css={comstyles.tooltip}>
                <Typography style={{fontSize: '16px'}}>제출상태 안내</Typography>
                <HtmlTooltip
                  title={
                    <React.Fragment>
                      {/* <Typography color="inherit">신청상태 안내</Typography> */}
                      <ul className='tooltip_list'>
                        <li><span className='clr02'>제출요청</span> 사업담당자가 보고서 제출을 요청한 상태</li>
                        <li><span className='clr01'>제출</span> 보고서가 제출된 상태</li>
                        <li><span className='clr03'>보완요청</span> 사업담당자가 보고서 보완을 요청한 상태</li>
                        <li><span className='clr05'>접수완료</span> 사업담당자가 보고서에 대해 접수완료 처리한 상태</li>
                      </ul>
                    </React.Fragment>
                  }
                  placement="bottom-start"
                >
                  <IconButton>
                    <QuestionIcon/>
                  </IconButton>
                </HtmlTooltip>
              </Stack>
            </Stack>
            <List>
              {list ? list.length > 0 ? list.map((item: any, i: number) => (
                <div className="btn_cont" key={i}>
                  <NavLink to={`/biz/TaskManagement/ReportSubmissionDetail/${item.reprtId}`}
                           state={{
                             item: item,
                             total: total
                           }}>
                    <ListItem>
                      <ListItemText
                        secondary={<React.Fragment>
                        <span className="tit_body">
                          <Chip label={(item.reprtType)} className='item ml0'
                                sx={{mr: 1, borderRadius: '5px', height: '30px', mb: '5px'}} component="span"/>
                          <Typography variant="body1" component="span">
                            {`[${item.receiptNo}]${item.taskNm}`}
                          </Typography>
                        </span>
                          <span className="date">
                            <span>공고명 <em>{item.pblancNm}</em></span>
                          </span>
                          <span className="date">
                          <span>과제책임자 <em>{item.rspnberNm}</em></span>
                            {item.presentnDate ?
                              <span>{`제출일시`}<em>{(item.presentnDate)}</em></span>
                              : null}
                        </span>
                          <RceptStus stus={!!item.reprtSttus ? item.reprtSttus : '제출요청'}/>
                        </React.Fragment>
                        }
                      />
                    </ListItem>
                  </NavLink>
                  {
                    item.reprtSttusCd == "SR" &&
                    <div className="right_btn">
                      <ModalReasonConfirm applyId={item.reprtId} viewNm="ReportSubmission"/>
                    </div>
                  }
                </div>
              )) : <NoData/> : ''}
            </List>
            {(input.itemsPerPage) < total ?
              // 더보기
              <Stack css={comstyles.bottom_btn}>
                <CustomButton label={'더보기'} type={'full'} color={'item'} style={{margin: '10px 0'}}
                              onClick={() => moreInfo()}/>
              </Stack>
              : null}
          </div>
        </div>
      </Box>
    </div>
  </Banner>
}

const HtmlTooltip = styled(({className, ...props}: TooltipProps) => (
  <Tooltip {...props} classes={{popper: className}}/>
))(({theme}) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    backgroundColor: '#f5f5f9',
    color: 'rgba(0, 0, 0, 0.87)',
    maxWidth: 220,
    fontSize: theme.typography.pxToRem(12),
    border: '1px solid #dadde9',
  },
}));

export default ReportSubmission;