import { css } from '@emotion/react';
export const container = css`
  padding-bottom: 120px;
  .content {
    position: relative;
    max-width: 1260px;
    width: 100%;
    margin: 0 auto;
    &.pt120{
      padding-top:120px;
      padding-bottom: 60px
    }
  }
  .txtblue {
    color: #4063ec;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    margin-top: 0;
    padding-bottom: 80px;
  }
`;

export const teble_detal = css`
  text-align: right;
  max-width: 780px;
  margin: 0 auto;
  margin-top: 20px;
  width: 100%;
  overflow: hidden;
`;

export const table02 = css`
  display: flex;
  height: 181px;
  border-radius: 15px;
  overflow: hidden;
  .MuiTableCell-root {
    border: 0;
    padding: 0;
  }
  dl {
    flex: 1;
    &:first-of-type {
      dd, dt {
        border-left: none;
      }
    }
    dt {
      font-weight: 700;
      letter-spacing: -0.72px;
      padding: 12px;
      font-size: 18px;
      line-height: 1.4;
      text-align: center;
      border-bottom: 1px solid #e0e0e0;
      border-left: 1px solid #e0e0e0;
    }
    dd {
      margin-left: 0;
      text-align: left;
      border-left: 1px solid #e0e0e0;
      letter-spacing: -0.64px;
      padding: 6px;
      .box_scroll{
        padding: 14px;
        height: 120px;
        overflow: auto;
        &::-webkit-scrollbar {
          width: 5px;
          padding: 5px;
        }
        &::-webkit-scrollbar-thumb {
          background-color: #d7dae6;
          border-radius: 10px;
          width: 3px;
        }
        &::-webkit-scrollbar-track {
          background-color: #fff;
          border-radius: 10px;
          width: 10px;
        }
      }
      > div {
        margin-bottom: 10px;
      }
      .MuiRadio-root {
        padding: 5px;
      }
      .MuiFormControlLabel-root{
        margin-right: 0;
        margin-bottom: 10px;
        padding-left: 10px;
        height: 24px;
      }
      .MuiFormGroup-root{
        flex-direction: column;
      }
    }
  }
  .MuiCheckbox-root {
    padding: 0;
    margin-right: 10px;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .table_form {
      th {
        font-size: 14px;
      }
      td {
        padding: 10px;
      }
    }
    .MuiTableCell-root {
      padding: 8px;
    }
  }
`;

export const table = css`
  max-width: 100%;
  letter-spacing: -0.64px;
  .MuiTypography-h6{
    font-size: 18px;
    margin-bottom: 15px;
  }
  .detail_table{
    border-top: 1px solid #1f2437;
    margin-bottom: 40px;
  }
  dl {
    display: flex;
    border-spacing: 0;
    width: 100%;
    & .noline{
      border-bottom: none;
    }
    dt {
      display: flex;
      align-items: center;
      flex: 0 0 220px;
      padding: 20px 20px;
      text-align: left;
      background-color: #f5f5f5;
      border-bottom: 1px solid #e0e0e0;
      &.wh{
        background-color: #fff;
      }
    }
    dd {
      flex: 1;
      display: flex;
      justify-content: space-between;
      padding: 8px 20px;
      line-height: 1.75;
      align-items: center;
      border-bottom: 1px solid #e0e0e0;
      margin-left: 0;
      font-weight: 400;
      .MuiOutlinedInput-notchedOutline{
        border-color: #ccc;
      }
    }
    .withLink{
      justify-content: flex-start;
      a {color:#4063ec;margin-left:10px;padding-right:15px;color:#4063ec;font-weight:400;background:url(/images/common/gt_blue.png) no-repeat right center;}
    }
    .txt_view{padding:10px 0;}
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .MuiTypography-h6{
      font-size: 16px;
      margin-bottom: 10px;
    }
    .detail_table{
      margin-bottom: 30px;
      .MuiOutlinedInput-root{height:48px}
    }
    .MuiFormControl-root{width:100%;}
    .MuiFormGroup-root{justify-content: space-around;}
    .MuiFormControlLabel-root{margin-right:0;}
    dl {
      flex-wrap: wrap;
      font-size: 14px;
      dt {
        flex: 0 0 35%;
        line-height: 26px;
        padding: 19px 0 19px 10px;
      }
      dd {
        flex: 0 0 65%;
        padding: 10px 20px 10px 20px;
      }
      &.horz{
        flex-direction: column;
        dt{
          padding: 13px 0 13px 10px;
          border-bottom: 0;
          justify-content: center;
        }
        dd{
          min-height: 60px;
          border-bottom: 0;
          padding:7px 8px;
          p{padding:0 12px;}
          .txt_view{
            p{
              &:first-of-type{margin-top:0;}
              margin-top:20px;
            }
          }
        }
        &:first-of-type{
          dt{
            &:first-of-type{
              border-bottom:1px solid #d7dae6;
            }
          }
        }
        &.file{
          dd{
            border-bottom: 1px solid #e0e0e0;
          }
        }
        &+.file{
          dt{
            border-top: 1px solid #e0e0e0;
          }
        }
      }
    }
    .type2{
    }
  }
`;


export const signbtn = css`
  margin: 40px auto 0;
  padding-top: 40px;
  border-top: 1px solid #e0e0e0;
  &.btncont2{
      button{
        &:first-of-type{
        background-color: none;
        &:hover{
          box-shadow: 3px 3px 8px 0 rgb(0 0 0 / 10%);
        }
      }
    }
  }
  button{
    font-size: 18px;
    line-height: 1;
    border-radius: 50px;
    width: 140px;
    height: 60px;
    font-weight: 300;
    box-shadow: none;
    letter-spacing: -0.72px;
    &:hover{
      box-shadow: 3px 3px 8px 0 rgba(64, 99, 236, 0.44);
    } 
    &.primary{
      background-color: #4063ec;
    }
    &.linebtn {
      border: 1px solid #fff;
      background-color: #1f2437;
      &:hover{
        box-shadow: 3px 3px 8px 0 rgb(0 0 0 / 10%);
      }
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    margin-top: 0%;
    border-top: 0;
    button{width:100%;height:52px;}
  }
`

// 파일 다운로드 버튼
export const btnDown = css`
  justify-content: left;
  flex-direction: row;
  padding-left: 10px;
  button {
    min-width: 124px;
    height: 48px;
    border-radius: 24px;
    padding: 14px 25px;
    font-size: 14px;
    line-height: 1.5;
    background-color: #fff;
    border: solid 1px #ccc;
    color: #333;
    letter-spacing: -0.56px;
    font-weight: 400;
    > span {
      max-width: 200px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    &:before {
      content: '';
      width: 20px;
      height: 20px;
      margin-right: 6px;
      background: url('/images/common/icon_download.png') no-repeat;
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    button {
      > span {
        max-width: 200px;
      }
    }
  }
`;
export const fileupload = css`
  >div{
    flex-wrap: wrap;
    justify-content: left;
    .MuiButton-root:first-of-type {
      margin-right: 20px;
    }
  }
  
`;
export const submission_date = css`
  height: 144px;
  margin-bottom: 40px;
  padding:30px 30px 0;
  border:1px solid #e0e0e0;
  border-radius: 5px;
  .tit {margin-bottom:10px;font-size:18px;letter-spacing:-0.72px;}
  .selectLine {
    display:flex;
    flex-direction:row;
    .MuiFormControl-root {width:220px;}
  }
  .MuiBox-root {flex-direction:row !important;}
  .MuiFormControl-root{
    margin-right:20px;
    .MuiSelect-select{font-family: 'Noto Sans CJK KR','Roboto';padding: 12px 16px 13px;}
  }
  @media (min-width: 320px) and (max-width: 768px) {
    height:auto;
    border:0;
    padding:0;
    .MuiBox-root{
      margin-bottom:0;
    }
    .MuiFormControl-root{
      width:76%;
      margin-right: 8px;
    }
    Button{
      width: 21%;
    }
  }
`;
export const attatchedFile = css`
  display: flex;
  flex-direction: row;
  padding:24px 20px;
  background-color: #f5f5f5;
  border-radius: 10px;
  >div{
    &:first-of-type{padding-left:0;}
    padding-left:6px
  }
  @media (min-width: 320px) and (max-width: 768px) {
    flex-direction: column;
    margin:0 -15px;
    padding:20px 15px;
    border-radius: 0;
    >div{
      padding-left:0;
      button{
        margin-top:10px;
      }
      &:first-of-type{
        button{margin-top:0;}
      }
    }
  }
`