 import * as styles from './styles';
import * as comstyles from '~/styles/styles';
import Box from '@mui/material/Box';
import {
  Stack,
  useMediaQuery,
  List,
  ListItem,
  ListItemText,
  TooltipProps,
  Tooltip,
  tooltipClasses,
  Collapse
} from '@mui/material';
import React, {Fragment, useEffect, useState} from 'react';
import Typography from '@mui/material/Typography';
import {useTheme} from '@mui/material';
import {CustomButton} from '~/components/ButtonComponents';
import {NavLink} from 'react-router-dom';
import {fetchGetCommCode} from '~/fetches';
import {styled} from '@mui/material/styles';
import {useQuery} from "react-query";
import IconButton from '@material-ui/core/IconButton';
import {QuestionIcon} from '~/components/IconComponents';
import {SearchBar, SelectSearchBar} from '~/components/BizCommon/SearchBar';
import {SearchModal} from '~/components/BizCommon/SearchModal';
import {ModalReasonConfirm} from '../BusinessAppMgt/PopComp/ModalReasonConfirm';
import { CustomRadioButtons} from '~/components/NoticeCustomCheckBoxs';
import {fetchPerformanceListGet} from '~/fetches/fetchPerformanceMgt';
import {initPerformanceInput, performanceListInput} from '~/models/ModelPerformanceMgt';
import NoData from '~/components/Loading/NoData';
import RceptStus from '../BusinessAppMgt/PopComp/RceptStus';
import {fetchBsnsYearList} from "./../../../fetches/fetchBusiness";
import {Banner} from "~/components/Banner";

/* 
  작성일    :   2022/06/26
  화면명    :   사업관리 -> 평가관리 -> 평가결과조회
  회면ID    :   UI-USP-FRN-0160501
  화면/개발 :   Seongeonjoo / navycui
*/
const PerformanceMgt = () => {
  const today = new Date();
  today.setHours(today.getHours() - 24);
  const theme = useTheme();
  const [total, setTotal] = useState(0);
  const [list, setList] = useState<any>();
  const [loading, setLoading] = useState(true)
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [mobileSearch, setMobileSearch] = useState(false)

  const [input, setInput] = useState<performanceListInput>(initPerformanceInput)

  // 공통 코드 조회
  const {data: assign_box} = useQuery("getCode", async () => await fetchGetCommCode("RSLT_STTUS"));

  const [bsns_box, setBsnsBox]: any = useState([]);

  const {data: bsnsYearList} = useQuery("getYearList", async () => await fetchBsnsYearList(), {
    // onSuccess: (res:any)=>{
    //   console.log(1)
    //   const update: { code: any; codeNm: any; }[] = [];
    //   // eslint-disable-next-line array-callback-return
    //   res.map((item:any)=>{
    //     update.push({code:item,codeNm:item})
    //     console.log(update);
    //   })
    //   console.log(update);
    //   setBsnsBox(update);
    // }
  });

  useEffect(() => {
    if (!!bsnsYearList) {
      const update: { code: any; codeNm: any; }[] = [];
      bsnsYearList.list.map((item: any) => {
        update.push({code: item, codeNm: item})
      })
      setBsnsBox(update);
    }
  }, [bsnsYearList])

  // 성과 관리 목록 조회
  const getList = async() => {
    setLoading(true)
    await fetchPerformanceListGet(input).then((res: any) => {
      console.log("res.list - " + JSON.stringify(res.list))
      setList(res.list);
      setTotal(res.totalItems);
    })
    setLoading(false)
  }

  const moreInfo = () => {
    const itemsPerPage: any = input.itemsPerPage + 10;
    setInput((state) => ({...state, itemsPerPage}));
  }

  useEffect(() => {
    getList()
  }, []);


  useEffect(() => {
    getList()
  }, [input.itemsPerPage]);

  useEffect(() => {
    if (mobileSearch) {
      getList()
      setMobileSearch(false)
    }
  }, [mobileSearch])

  return <Banner
    title={'성과 관리'} loading={loading}
    summary={'성과제출 대상을 확인하고 성과를 제출할 수 있습니다.'}
    searchContent={<SelectSearchBar
      placehold='성과관리 조회해보세요!'
      defaultValue={input.keyword}
      curr={input.keywordDiv}
      selectData={[{code: 'pblancNm', codeNm: '공고명'}, {code: 'taskNm', codeNm: '과제명'}, {code: 'receiptNo', codeNm: '접수번호'}]}
      onChange={(keyword: string) => setInput({...input, keyword: keyword})}
      onChangeDiv={(div: string) => setInput({...input, keywordDiv: div})}
      handleSearch={(val: any) => {
        getList()
        // const update = {...input, keyword: val, bsnsYear: bsnsYear, rsltSttusCd: rsltSttusCd};
        // setInput(update);
      }}
    />}
    detailContent={<Fragment>
      {isMobile ? <SearchModal
        hideDate placehold='성과관리 조회해보세요!'
        selectList={[{title: '사업연도', list: bsns_box ? bsns_box : []},
          {title: '제출상태', list: assign_box ? assign_box.list : []}
        ]}
        onSearch={(data, selectedList)=> {
          setInput({
            ...input,
            bsnsYear: selectedList?.find(f => f.title == '사업연도')?.value || '',
            rsltSttusCd: selectedList?.find(f => f.title == '제출상태')?.value || ''
          })
          setMobileSearch(true)
        }}
      /> : <Box css={comstyles.picker_card}>
        <dl>
          <dt>사업연도</dt>
          <dd>
            <Box className="box_scroll">
              <CustomRadioButtons
                row
                data={bsns_box ? bsns_box : []}
                val={input.bsnsYear}
                onClick={(s: string) => {
                  setInput({...input, bsnsYear:s})
                }}
              />
            </Box>
          </dd>
        </dl>
        <dl>
          <dt>제출상태</dt>
          <dd>
            <Box className="box_scroll">
              <CustomRadioButtons
                row
                data={assign_box ? assign_box.list : []}
                val={input.rsltSttusCd}
                onClick={(s: string) => {
                  setInput({...input, rsltSttusCd:s})
                }}
              />
            </Box>
          </dd>
        </dl>
      </Box>
      }
    </Fragment>}>
    <div css={comstyles.container}>
      <Box css={comstyles.sub_cont02}>
        <div className="content list">
          {/* className="list02" 클래스는 사유확인버튼이 있을시에만 추가 */}
          <div css={comstyles.detal_list} className="list02">
            <Stack
              spacing={6}
              direction="row"
              className="sub_tit"
              justifyContent="space-between"
            >
              <Typography variant="h4" component="div">
                성과
                <span className='data'><em>{total ? total : 0}</em> 건</span>
              </Typography>
              <Stack style={{alignSelf: 'center'}} flexDirection={'row'} css={comstyles.tooltip}>
                <Typography style={{fontSize: '16px'}}>제출상태 안내</Typography>
                <HtmlTooltip
                  title={
                    <React.Fragment>
                      {/* <Typography color="inherit">신청상태 안내</Typography> */}
                      <ul className='tooltip_list'>
                        <li><span className='clr02'>제출요청</span> 사업담당자가 보고서 제출을 요청한 상태</li>
                        <li><span className='clr01'>제출</span> 보고서가 제출된 상태</li>
                        <li><span className='clr03'>보완요청</span> 사업담당자가 보고서 보완을 요청한 상태</li>
                        <li><span className='clr05'>접수완료</span> 사업담당자가 보고서에 대해 접수완료 처리한 상태</li>
                      </ul>
                    </React.Fragment>
                  }
                  placement="bottom-start"
                >
                  <IconButton>
                    <QuestionIcon/>
                  </IconButton>
                </HtmlTooltip>
              </Stack>
            </Stack>
            <List>
              {list ? list.length > 0 ? list.map((item: any, i: number) => (
                <div className="btn_cont" key={i}>
                  <NavLink to={`/biz/TaskManagement/PerformanceMgtDetail/${item.rsltId}`}
                    state={{
                      item: item,
                      total: total
                    }}>
                    <ListItem>
                      <ListItemText
                        secondary={
                          <React.Fragment>
                        <span className="tit_body">
                          <Typography variant="body1" component="span">
                            {item.taskNm}
                          </Typography>
                        </span>
                        <span className="date">
                            <span>공고명 <em>{item.pblancNm}</em></span>
                        </span>
                        <span className="date">
                          {item.presentnDate ?
                          <span>제출일시 <em>{(item.presentnDate)}</em></span>
                            : null}
                        </span>
                            <RceptStus stus={!!item.rsltSttus ? item.rsltSttus : '접수상태'}/>
                          </React.Fragment>
                        }
                      />
                    </ListItem>
                  </NavLink>
                  {
                    item.rsltSttusCd == 'SR' && <div className="right_btn">
                      <ModalReasonConfirm applyId={item.rsltId} title={' '} viewNm="PerformanceMgt"/>
                    </div>
                  }
                </div>
              )) : <NoData/> : <NoData/>}
            </List>
            {(input.itemsPerPage) < total ?
              // 더보기
              <Stack css={comstyles.bottom_btn}>
                <CustomButton label={'더보기'} type={'full'} color={'item'} style={{margin: '10px 0'}}
                              onClick={() => moreInfo()}/>
              </Stack>
              : null}
          </div>
        </div>
      </Box>
    </div>
  </Banner>
}

const HtmlTooltip = styled(({className, ...props}: TooltipProps) => (
  <Tooltip {...props} classes={{popper: className}}/>
))(({theme}) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    backgroundColor: '#f5f5f9',
    color: 'rgba(0, 0, 0, 0.87)',
    maxWidth: 220,
    fontSize: theme.typography.pxToRem(12),
    border: '1px solid #dadde9',
  },
}));

export default PerformanceMgt;