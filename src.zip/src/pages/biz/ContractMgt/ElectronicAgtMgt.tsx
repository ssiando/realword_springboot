import React, {Fragment, useCallback, useEffect, useRef, useState} from 'react';
import * as styles from './styles';
import * as comstyles from '~/styles/styles';
import { Stack, Box, useMediaQuery, List, ListItem, ListItemText, TooltipProps, Tooltip, tooltipClasses, Collapse } from '@mui/material';
import Typography from '@mui/material/Typography';
import { useTheme } from '@mui/material';
import { CustomButton } from '~/components/ButtonComponents';
import { CustomRadioButtons} from '~/components/NoticeCustomCheckBoxs';
import { NavLink } from 'react-router-dom';
import { fetchGetCommCode } from '~/fetches';
import dayjs from 'dayjs';
import { reqReserveType } from '~/service/Model';
import { styled } from '@mui/material/styles';
import {useQuery} from "react-query";
import IconButton from '@material-ui/core/IconButton';
import {QuestionIcon} from '~/components/IconComponents';
import {fetchCnvnList} from '~/fetches/biz/fetchContractMgt';
import DatePicker from "~/components/DatePicker";
import { SelectSearchBar } from '~/components/BizCommon/SearchBar';
import { ModalReasonConfirm } from '../BusinessAppMgt/PopComp/ModalReasonConfirm';
import { SearchModal } from '~/components/BizCommon/SearchModal';
import NoData from '~/components/Loading/NoData';
import RceptStus from '../BusinessAppMgt/PopComp/RceptStus';
import {ElectronicInput, initElectronicInput} from '~/models/ModelBizPlanMgt';
import {Banner} from "~/components/Banner";

/* 
  작성일    :   2022/06/26
  화면명    :   사업관리 -> 협약관리 -> 전자협약 관리
  회면ID    :   UI-USP-FRN-0170701
  화면/개발 :   Seongeonjoo / navycui
*/
const  ElectronicAgtMgt = () => {
  const theme = useTheme();
  const [total, setTotal] = useState(0);
  const [list, setList] = useState<any>();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [questBeginDay, setQuestBeginDay] = React.useState<Date | null>(null);
  const [questEndDay, setQuestEndDay] = React.useState<Date | null>(null);
  const [reqReserve, setReqReserve] = useState<reqReserveType>({questBeginDay:dayjs(questBeginDay).format('YYYY-MM-DD'), questEndDay:dayjs(questEndDay).format('YYYY-MM-DD'), reserveSt: "",  page: 1, itemsPerPage: 10})
  // const [quests, setQuests] = useState<questsType>({
  //   title : "",
  //   qnaId : process.env.REACT_APP_USP_PERSNAL,
  //   questId:"",
  //   questBeginDay:questBeginDay,
  //   questEndDay:questEndDay,
  //   questStatus : "",
  //   memberNm:"",
  //   page : 1,
  //   itemsPerPage : 10,
  // })
  const [input, setInput] = useState<ElectronicInput>(initElectronicInput)
  //Tooltip Open
  const [open, setOpen] = React.useState(false);
  const [loading, setLoading] = useState(true)

  const handleTooltipClose = () => {
    setOpen(false);
  };
  const handleTooltipOpen = () => {
  setOpen(true);
  }

 // 공통 코드 조회
 const {data:assign_box} = useQuery("getCode", async () => await fetchGetCommCode("PLAN_PRESENTN_STTUS"));

 // 수행계획서 목록 조회  
  const getList = async () => {
    setLoading(true)
    try {
      console.log('input - ' + JSON.stringify(input))
      const searchParam = {
        ...input,
        pblancNm: input.keywordDiv == 'pblancNm'? input.keyword : '',
        taskNmKo: input.keywordDiv == 'taskNmKo'? input.keyword : ''
      }
      await fetchCnvnList(searchParam).then((res:any)=>{
        setList(res)
        setLoading(false)
      })
    }catch (e){
      setLoading(false)
    }
    setLoading(false)
  }

  const moreInfo = () => {
    const itemsPerPage:any = input.itemsPerPage + 10;
    setInput((state) => ({ ...state, itemsPerPage }));
  }
  
  useEffect(() => {
    getList()
  }, []);

  useEffect(() => {
    getList()
  }, [input.itemsPerPage]);

  return <Banner
  title={'전자협약 관리'} loading={loading}
  summary={'사업계획서 접수가 완료된 과제의 협약을 진행하고 협약서를 조회 및 다운로드 받을 수 있습니다.'}
  searchContent={<SelectSearchBar
    placehold='전자협약서를 조회해보세요!'
    defaultValue={input.keyword}
    curr={input.keywordDiv}
    selectData={[{code: 'taskNmKo', codeNm: '과제명'}, {code: 'pblancNm', codeNm: '공고명'}]}
    onChange={(keyword: string) => setInput({...input, keyword: keyword})}
    onChangeDiv={(div: string) => setInput({...input, keywordDiv: div})}
    handleSearch={(val:any)=>{
      getList()
    }}
  />}
  detailContent={<Fragment>{isMobile ? (
      <SearchModal
        placehold='전자협약서를 조회해보세요!'
        handleSearch={(s:string | undefined)=>{
          console.log(s)
        }}
        assign_box={assign_box.list}
      />
    ) : (
      <Box css={comstyles.picker_card} >
        <dl>
          <dt>협약일</dt>
          <dd>
            <Box className="box_scroll">
              <DatePicker
                pickerType='two'
                questBeginDay={!!input.cnvnDeStart? dayjs(input.cnvnDeStart, 'YYYYMMDD').toString() : ''}
                questEndDay={!!input.cnvnDeEnd? dayjs(input.cnvnDeEnd, 'YYYYMMDD').toString() : ''}
                changeStart={(startNewTime: Date | null) => {
                  if (startNewTime) {
                    if (input.cnvnDeEnd) {
                      const end = new Date(Number(input.cnvnDeEnd.slice(0, 4)),
                        Number(input.cnvnDeEnd.slice(4, 6)) - 1, Number(input.cnvnDeEnd.slice(6, 8)))
                      if (startNewTime.getTime() > end.getTime()) {
                        setInput({...input, cnvnDeStart: dayjs(end).format('YYYYMMDD')})
                        return
                      }
                    }

                    setInput({...input, cnvnDeStart: dayjs(startNewTime).format('YYYYMMDD')})
                  }
                }}
                changeEnd={(endNewTime: Date | null) => {
                  if (endNewTime) {
                    if (input.cnvnDeStart) {
                      const begin = new Date(Number(input.cnvnDeStart.slice(0, 4)),
                        Number(input.cnvnDeStart.slice(4, 6)) - 1, Number(input.cnvnDeStart.slice(6, 8)))
                      if (endNewTime.getTime() < begin.getTime()) {
                        setInput({...input, cnvnDeEnd: dayjs(begin).format('YYYYMMDD')})
                        return
                      }
                    }

                    setInput({...input, cnvnDeEnd: dayjs(endNewTime).format('YYYYMMDD')})
                  }
                }}
              />
            </Box>
          </dd>
        </dl>
        <dl>
          <dt>제출상태</dt>
          <dd>
            <Box className="box_scroll">
              <CustomRadioButtons
                row
                data={[{code: "CNST03", codeNm: "서명요청"},{code: "CNST04", codeNm: "서명완료"},{code: "CNST05", codeNm: "협약완료"}]}
                val={input.cnvnSttusCd}
                onClick={(s: string) => {
                  setInput({...input, cnvnSttusCd:s})
                }}
              />
            </Box>
          </dd>
        </dl>
      </Box>
  )}</Fragment>}
  >
    <div css={comstyles.container}>
      <Box css={comstyles.sub_cont02}>
        <div className="content list">
          {/* className="list02" 클래스는 사유확인버튼이 있을시에만 추가 */}
          <div css={comstyles.detal_list} className="list02">
            <Stack
              spacing={6}
              direction="row"
              className="sub_tit"
              justifyContent="space-between"
            >
              <Typography variant="h4" component="div">
                전자협약서
                <span className='data'><em>{list ? list.totalItems : 0}</em> 건</span>
              </Typography>
              <Stack style={{alignSelf:'center'}} flexDirection={'row'}  css={comstyles.tooltip}>
                <Typography>제출상태 안내</Typography>
                <HtmlTooltip
                  open={open}
                  onClose={handleTooltipClose}
                  leaveTouchDelay = {30000}
                  title={
                    <React.Fragment>
                      {/* <Typography color="inherit">신청상태 안내</Typography> */}
                      <ul className='tooltip_list'>
                        <li><span className='clr03'>서명요청</span> 담당자가 서명을 요청한 상태</li>
                        <li><span className='clr02'>서명완료</span> 사업단에서 서명을 진행중인 상태</li>
                        <li><span className='clr05'>협약완료</span> 서명이 완료되어 협약이 체결된 상태</li>
                        <li><span className='clr06'>협약해지</span> 협약이 해지된 상태</li>
                      </ul>
                    </React.Fragment>
                  }
                  placement="bottom"
                >
                  <IconButton onClick={handleTooltipOpen}>
                    <QuestionIcon />
                  </IconButton>
                </HtmlTooltip>
              </Stack>
            </Stack>
            <List>
              {!!list ? list.list.length > 0 ? list.list.map((item : any , i:number) => (
                <div className="btn_cont" key={i}>
                  <NavLink to={`/biz/ContractMgt/ElectronicAgtMgtDetail/${item.bsnsCnvnId}`}
                    state={{ item:item, total:total}}>
                    <ListItem>
                      <ListItemText
                        secondary={
                          <React.Fragment>
                        <span className="tit_body">
                          <Typography variant="body1" component="span">
                            {item.taskNmKo}
                          </Typography>
                        </span>
                        <span className="date">
                          <span>공고명 <em>{item.pblancNm}</em></span>
                        </span>
                        <span className="date">
                          <span>과제책임자 <em>{item.rspnberNm}</em></span>
                          <span>협약기간 <em>{dayjs(item.createdDt).format('YYYY-MM-DD')}</em></span>
                        </span>
                            <RceptStus stus={!!item.cnvnSttusNm ? item.cnvnSttusNm : '접수상태'}/>
                        </React.Fragment>
                        }
                      />
                    </ListItem>
                  </NavLink>
                  <div className="right_btn">

                    {(item.rceptSttus == 'REJECT' || item.rceptSttus == 'MAKEUP') ?
                      <ModalReasonConfirm applyId={item.applyId} viewNm="ElectronicAgtMgt" title='협약서 다운로드'/>
                      : null
                    }
                  </div>
                </div>
              )): <NoData /> : ''}
            </List>
            {(input.itemsPerPage)<total?
              // 더보기
              <Stack css={comstyles.bottom_btn} >
                <CustomButton label={'더보기'} type={'full'} color={'item'} style={{ margin: '10px 0' }} onClick={()=>moreInfo()} />
              </Stack>
              :null}
          </div>
        </div>
      </Box>
    </div>
  </Banner>
}

const HtmlTooltip = styled(({ className, ...props }: TooltipProps) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    backgroundColor: '#f5f5f9',
    color: 'rgba(0, 0, 0, 0.87)',
    maxWidth: 220,
    fontSize: theme.typography.pxToRem(12),
    border: '1px solid #dadde9',
  },
}));

export default ElectronicAgtMgt;