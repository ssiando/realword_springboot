import React, {CSSProperties, Dispatch, Fragment, SetStateAction, useEffect, useState} from 'react';
import {
  Box,
  Checkbox, FormControl,
  IconButton, MenuItem,
  OutlinedInput, Select, SelectChangeEvent,
  Stack, Table, TableCell,
  TableContainer
} from "@mui/material";
import {CheckboxStyle} from '~/components/TableComponents';
import {CustomButton} from '~/components/ButtonComponents';
import {PlusIcon, SelectIcon, TrashIcon} from "~/components/IconComponents";
import {TaskPrtcmpny, TaskPartcpts} from '~/models/ModelBizPlanMgt';
import {useNavigate} from 'react-router-dom';
import {
  CustomHeadCell,
  TableComponents,
  TableTextFieldCell,
  WithCustomRowData
} from "shared/components/TableComponents";
import {useQuery} from "react-query";
import {fetchGetBizList} from "~/fetches/biz/fetchContractMgt";
import {ModalComponents} from "shared/components/ModalComponents";
import { MenuProps } from '~/styles/styledConst';
import {validBirthday, validPhoneNumber} from "shared/utils/validUtil";
/*
    공통 컴포넌트: todo list 
    작성 : navycui
*/
export const UsptTaskPartcptsTodoList: React.FC<{
  dataList: any[]
  type: 'usptTaskPartcpts' | 'usptTaskPrtcmpny'                       // 데이터 전달
  row?: boolean
  justifyContent?: 'center' | 'right' | 'left'
  children?: React.ReactNode
  style?: CSSProperties
  planPresentnSttusCd?: string
  memberList?: { memberNm: string, memberId: string }[]
  onChangeBox?: (dataBox: TaskPrtcmpny[]) => void // 데이터 반환
  onChangeBox2?: (dataBox2: TaskPartcpts[]) => void // 데이터 반환
}> = (props) => {
  const [selected, setSelected] = useState<boolean[]>([]);
  const [checkAll, setCheckAll] = useState<boolean>(false);
  const [dataBox, setDataBox] = useState<TaskPrtcmpny[]>([]);
  const [dataBox2, setDataBox2] = useState<TaskPartcpts[]>([]);

  const [companySearchModal, setCompanySearchModal] = useState(false)
  const navigate = useNavigate();
  // data 초기화
  useEffect(() => {
    if (!!props.dataList) {
      if (props.type == 'usptTaskPrtcmpny') {
        setDataBox(props.dataList)
      } else {
        setDataBox2(props.dataList)
      }
    }
  }, []);

  // 선택한 data 변경 시
  useEffect(() => {

    if (props.type == 'usptTaskPrtcmpny') {
      if (!!dataBox) {
        let selectBox: boolean[] = [...selected];
        for (let i = selected.length; i < dataBox.length; i++) {
          selectBox = selectBox.concat(false);
        }
        setSelected(selectBox)
        if (props.onChangeBox) props.onChangeBox(dataBox);
      }
    } else {
      if (!!dataBox2) {
        let selectBox: boolean[] = [...selected];
        for (let i = selected.length; i < dataBox2.length; i++) {
          selectBox = selectBox.concat(false);
        }
        setSelected(selectBox)
        if (props.onChangeBox2) props.onChangeBox2(dataBox2);
      }
    }
  }, [dataBox, dataBox2]);

  const handelChangeInfo = (event: React.ChangeEvent<HTMLInputElement>, item: TaskPrtcmpny, idx: number) => {
    if (event.currentTarget == null || props.planPresentnSttusCd == 'PLPR04') {
      return;
    }

    event.preventDefault();
    const updated: any = [...dataBox];
    updated[idx] = {...item, [event.currentTarget.name]: event.currentTarget.value};
    setDataBox(updated)
    // setDataBox((pre:any)=>[...pre,{...pre[idx],...item}])
  };
  const handelChangeInfo2 = (event: React.ChangeEvent<HTMLInputElement>, item: TaskPartcpts, idx: number) => {
    if (event.currentTarget == null || props.planPresentnSttusCd == 'PLPR04') {
      return;
    }

    event.preventDefault();
    const updated: any = [...dataBox2];
    updated[idx] = {...item, [event.currentTarget.name]: event.currentTarget.value};
    setDataBox2(updated)
    // setDataBox((pre:any)=>[...pre,{...pre[idx],...item}])
  };
  // 참여기업
  if (props.type == 'usptTaskPrtcmpny')
    return (
      <>
        <Stack direction={'row'} justifyContent={'space-between'} alignItems={'flex-end'}>
          <h4 className="tbl_title">참여기업</h4>
          {
            props.planPresentnSttusCd && props.planPresentnSttusCd != 'PLPR04' &&
            <Box>
              {/*<CustomButton label={'기업추가'} onClick={() => setCompanySearchModal(true)} type={'modify'}*/}
              {/*              color={'outlinedblack'}*/}
              {/*              style={{margin: '10px 18px'}}/>*/}
              <IconButton size="large" edge="start" color="inherit" aria-label="delete" sx={{mr: 1}}
                          onClick={() => {
                            if (checkAll === true) {
                              setDataBox([{
                                entrpsNm: '',
                                rspnberNm: '',
                                clsfNm: '',
                                regTelno: '',
                                regMbtlnum: '',
                                regEmail: '',
                                memberId: ''
                              }]);
                              setCheckAll(false)
                              setSelected([false])
                            } else {
                              if (!!dataBox) {
                                const upBox = [...dataBox];
                                const upSelete = [...selected];
                                if (!!dataBox) {
                                  for (let i = dataBox.length - 1; i > -1; i--) {
                                    if (selected[i] === true) {
                                      upBox.splice(i, 1);
                                      setDataBox(upBox)
                                      upSelete.splice(i, 1);
                                      setSelected(upSelete);
                                    }
                                  }
                                }
                              }
                            }
                          }}
              >
                <TrashIcon/>
              </IconButton>
              <IconButton size="large" edge="start" color="inherit" aria-label="delete"
                          onClick={() => {
                            // if(!!dataBox){
                            //   setDataBox((pre:any)=>([...pre,{ entrpsNm: '', rspnberNm: '', clsfNm: '', regTelno: '', regMbtlnum: '', regEmail: ''}]))
                            //   setCheckAll(false);
                            // }
                            setCompanySearchModal(true)
                          }}
              >
                <PlusIcon/>
              </IconButton>
            </Box>
          }
        </Stack>
        <div className='tableDefault_scroll'>
          <table className="tableDefault type5 " style={{minWidth: '900px'}}>
            <colgroup>
              <col style={{width: '5%'}}/>
              <col style={{width: '16%'}}/>
              <col style={{width: '10%'}}/>
              <col style={{width: '12%'}}/>
              <col style={{width: '14%'}}/>
              <col style={{width: '14%'}}/>
              <col style={{width: '15%'}}/>
              {/* <col style={{width:'14%'}}/> */}
            </colgroup>
            <thead>
            <tr>
              <th>
                <CheckboxStyle
                  checked={checkAll}
                  onClick={(e: React.MouseEvent<HTMLButtonElement>) => {
                    let update = [...selected];
                    if (checkAll === false) {
                      for (let i = 0; i < selected.length; i++) {
                        update[i] = true;
                      }
                    } else if (checkAll === true) {
                      for (let i = 0; i < selected.length; i++) {
                        update[i] = false;
                      }
                    }
                    setSelected(update);
                    setCheckAll(!checkAll);
                  }}
                />
              </th>
              <th>업체명<span className='must'>*</span></th>
              <th>책임자명<span className='must'>*</span></th>
              <th>직위/직급<span className='must'>*</span></th>
              <th>연락처</th>
              <th>휴대전화<span className='must'>*</span></th>
              <th>이메일<span className='must'>*</span></th>
              {/* <th>국가연구자번호</th> */}
            </tr>
            </thead>
            <tbody>
            {dataBox ? dataBox.map((m, i) => {
              return (
                <tr>
                  <td>
                    <CheckboxStyle
                      {...m}
                      value={selected[i] || ''}
                      checked={selected[i] || false}
                      onChange={((e) => {
                        //체크 값 변경
                        let k = e.target.checked;
                        let update = [...selected];
                        update[i] = k;
                        setSelected(update);
                        if (k === false) {
                          setCheckAll(false)
                        }
                        let b = 0;
                        for (let i = 0; i < selected.length; i++) {
                          if (update[i] === true) {
                            b++;
                          }
                        }
                        if (b === selected.length) {
                          setCheckAll(true)
                        }
                      })}
                    />
                  </td>
                  <td><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                    name='entrpsNm'
                                    value={m.entrpsNm}
                                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                    }}
                  /></td>
                  <td><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                    name='rspnberNm'
                                    value={m.rspnberNm}
                                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                      handelChangeInfo(e, m, i)
                                    }}
                  /></td>
                  <td><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                    name='clsfNm'
                                    value={m.clsfNm}
                                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                      handelChangeInfo(e, m, i)
                                    }}
                  /></td>
                  <td><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                    name='regTelno'
                                    value={m.regTelno}
                                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                      e.currentTarget.value = validPhoneNumber(e.currentTarget.value)
                                      handelChangeInfo(e, m, i)
                                    }}
                  /></td>
                  <td><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                    name='regMbtlnum'
                                    value={m.regMbtlnum}
                                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                      e.currentTarget.value = validPhoneNumber(e.currentTarget.value)
                                      handelChangeInfo(e, m, i)
                                    }}
                  /></td>
                  <td><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                    name='regEmail'
                                    value={m.regEmail}
                                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                      handelChangeInfo(e, m, i)
                                    }}
                  /></td>
                  {/* <td><OutlinedInput size="small" className="ipt_tp01" sx={{width:'100%'}}
                      name='encEmail' 
                      value={m.encEmail}
                      onChange={()=>{handelChangeInfo(e,m,i)}}
                    /></td> */}
                </tr>
              )
            }) : null}
            </tbody>
          </table>
        </div>
        

        {
          companySearchModal && <CompanySearchModal
            open={companySearchModal}
            onClose={() => setCompanySearchModal(false)}
            onSelect={(data) => {
              if (!!dataBox) {
                setDataBox([...dataBox.filter(f => f.entrpsNm != ''), ...data.map(m => {
                  return {
                    entrpsNm: m.memberNm,
                    memberId: m.memberId,
                    rspnberNm: '',
                    clsfNm: '',
                    regTelno: '',
                    regMbtlnum: '',
                    regEmail: ''
                  }
                })])
                setCheckAll(false);
              }
              setCompanySearchModal(false)
            }}/>
        }
      </>
    );

  //참여인력
  return (
    <>
      <Stack direction={'row'} justifyContent={'space-between'} alignItems={'flex-end'}>
        <h4 className="tbl_title">참여인력</h4>
        {
          props.planPresentnSttusCd && props.planPresentnSttusCd != 'PLPR04' &&
          <Box>
            <IconButton size="large" edge="start" color="inherit" aria-label="delete" sx={{mr: 1.5}}
                        onClick={() => {
                          if (checkAll === true) {
                            setDataBox2([{
                              partcptsNm: '',
                              chrgRealmNm: '',
                              encMbtlnum: '',
                              encBrthdy: '',
                              partcptnRate: 0,
                              memberId: '',
                              memberNm: ''
                            }]);
                            setCheckAll(false)
                            setSelected([false])
                          } else {
                            if (!!dataBox2) {
                              const upBox = [...dataBox2];
                              const upSelete = [...selected];
                              if (!!dataBox2) {
                                for (let i = dataBox2.length - 1; i > -1; i--) {
                                  if (selected[i] === true) {
                                    upBox.splice(i, 1);
                                    setDataBox2(upBox)
                                    upSelete.splice(i, 1);
                                    setSelected(upSelete);
                                  }
                                }
                              }
                            }
                          }
                        }}
            >
              <TrashIcon/>
            </IconButton>
            <IconButton size="large" edge="start" color="inherit" aria-label="delete"
                        onClick={() => {
                          if (!!dataBox2) {
                            setDataBox2((pre: any) => ([...pre, {
                              partcptsNm: '',
                              chrgRealmNm: '',
                              encMbtlnum: '',
                              encBrthdy: '',
                              partcptnRate: 0,
                              memberId: '',
                              memberNm: ''
                            }]))
                            setCheckAll(false);
                          }
                        }}
            >
              <PlusIcon/>
            </IconButton>
          </Box>
        }

      </Stack>
      
      <div className='tableDefault_scroll'>
        <table className="tableDefault type5">
          <colgroup>
            <col style={{width: '5%'}}/>
            <col style={{width: '17%'}}/>
            <col style={{width: '17%'}}/>
            <col style={{width: '17%'}}/>
            <col style={{width: '17%'}}/>
            <col style={{width: '17%'}}/>
            <col style={{width: '10%'}}/>
          </colgroup>
          <thead>
          <tr>
            <th>
              <Box className="checkbox">
                <Checkbox
                  checked={checkAll}
                  onClick={(e: React.MouseEvent<HTMLButtonElement>) => {
                    let update = [...selected];
                    if (checkAll === false) {
                      for (let i = 0; i < selected.length; i++) {
                        update[i] = true;
                      }
                    } else if (checkAll === true) {
                      for (let i = 0; i < selected.length; i++) {
                        update[i] = false;
                      }
                    }
                    setSelected(update);
                    setCheckAll(!checkAll);
                  }}
                />
              </Box>
            </th>
            <th>소속 기관<span className='must'>*</span></th>
            <th>이름<span className='must'>*</span></th>
            <th>담당분야</th>
            <th>휴대폰번호</th>
            <th>생년월일</th>
            <th>참여율(%)</th>
          </tr>
          </thead>
          <tbody>
          {dataBox2 ? dataBox2.map((m, i) => {
            return (
              <tr>
                <td>
                  <Box className="checkbox">
                    <Checkbox
                      {...m}
                      value={selected[i] || ''}
                      checked={selected[i] || false}
                      onChange={((e) => {
                        //체크 값 변경
                        let k = e.target.checked;
                        let update = [...selected];
                        update[i] = k;
                        setSelected(update);
                        if (k === false) {
                          setCheckAll(false)
                        }
                        let b = 0;
                        for (let i = 0; i < selected.length; i++) {
                          if (update[i] === true) {
                            b++;
                          }
                        }
                        if (b === selected.length) {
                          setCheckAll(true)
                        }
                      })}
                    />
                  </Box>
                </td>
                <td>
                  <FormControl fullWidth>
                    {/*<InputLabel>{m.memberNm}</InputLabel>*/}
                    <Select name='memberNm' style={{height: '48px'}} value={m.memberNm}
                      onChange={(event: SelectChangeEvent) => {
                        if (props.planPresentnSttusCd == 'PLPR04') return
                        event.preventDefault();
                        const id = props.memberList?.find(f => f.memberNm == event.target.value)?.memberId
                        const updated: any = [...dataBox2];
                        updated[i] = {
                          ...m,
                          memberNm: event.target.value,
                          memberId: id || ''
                        };
                        setDataBox2(updated)
                      }}
                      IconComponent={SelectIcon}
                      MenuProps={MenuProps} >
                      {
                        props.memberList && props.memberList.flatMap(m => m.memberNm).map((m, i) => {
                          return <MenuItem key={i} value={m}>{m}</MenuItem>
                        })
                      }
                    </Select>
                  </FormControl>
                </td>
                <td><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                  name='partcptsNm'
                                  value={m.partcptsNm}
                                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                    handelChangeInfo2(e, m, i)
                                  }}
                /></td>
                <td><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                  name='chrgRealmNm'
                                  value={m.chrgRealmNm}
                                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                    handelChangeInfo2(e, m, i)
                                  }}
                /></td>
                <td><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                  name='encMbtlnum'
                                  value={m.encMbtlnum}
                                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                    e.currentTarget.value = validPhoneNumber(e.currentTarget.value)
                                    handelChangeInfo2(e, m, i)
                                  }}
                /></td>
                <td><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                  name='encBrthdy'
                                  value={m.encBrthdy}
                                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                    e.currentTarget.value = validBirthday(e.currentTarget.value)
                                    handelChangeInfo2(e, m, i)
                                  }}
                /></td>
                <td><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                  name='partcptnRate'
                                  value={m.partcptnRate}
                                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                    handelChangeInfo2(e, m, i)
                                  }}
                /></td>
              </tr>
            )
          }) : null}
          </tbody>
        </table>
      </div>
    </>
  )
};

interface bizParam {
  memberId: string,
  memberNm: string,
  ceoNm: string,
  bizrno: string
}

type WithPagination<T> = T & {
  page: number
  itemsPerPage: number
  totalItems: number
  list: T[]
}

export const CompanySearchModal = (props: {
  open: boolean
  onSelect: (data: WithCustomRowData<bizParam>[]) => void
  onClose: () => void
}) => {
  const [pagination, setPagination] = useState({
    page: 0,
    rowsPerPage: 5,
    rowCount: 0
  });
  const [searchText, setSearchText] = useState('')
  const [selected, setSelected] = useState<WithCustomRowData<bizParam>[]>([])
  const [rowList, setRowList] = useState<WithCustomRowData<bizParam>[]>([])
  const cmpy = useQuery(['bsns-plan/bizList', pagination],
    (): Promise<WithPagination<bizParam>> => fetchGetBizList({
      page: pagination.page + 1,
      itemsPerPage: pagination.rowsPerPage,
      memberNm: searchText
    }))

  useEffect(() => {
    if (!cmpy.isLoading && !cmpy.isFetching) {
      if (!!cmpy.data) {
        console.log('cmpy.data.list - ' + JSON.stringify(cmpy.data.list))
        setRowList(cmpy.data.list.map((m) => {
          return {
            key: m.memberId!,
            ...m,
          }
        }));
        setPagination((state) => ({...state, rowCount: cmpy.data.totalItems}))
      }
    }
  }, [cmpy.data, cmpy.isLoading, cmpy.isFetching])
  return <ModalComponents
    isDist open={props.open}
    type={'normal'}
    style={{maxWidth: '1140px', width: '100%'}}
    title={'기업검색'}
    confirmLabel={'선택완료'}
    onClose={props.onClose}
    onConfirm={() => {
      // const selectDiscout = rowList.filter(f => selected.includes(f.dscntId!))
      props.onSelect(selected)
    }}
    
  >
    <Stack spacing={'15px'} sx={{mt: '24px'}}>
      <Stack direction={'row'} alignItems={'center'} sx={{'input': {background: '#fff'}, backgroundColor:'#f5f5f5', padding: '20px 30px'}}>
        <TableContainer>
          <Table sx={{display: 'flex', flexDirection: 'row', alignItems: 'center', '> td': {borderBottom: 'none', width: '90px', height: 'auto', justifyContent: 'center'}, '> td:last-child': {width: '100%', mr: '10px', '> div': {width: '100%'}}}}>
            {/*<Box sx={{display: 'flex', justifyContent: 'center', width: '100%'}}>*/}
              <TableTextFieldCell label={'기업명'} onChange={(text) => {
                setSearchText(text)
              }}/>
            {/*</Box>*/}
          </Table>
        </TableContainer>
        <CustomButton label={'검색'} type={'modalBtn'} onClick={() => {
          cmpy.refetch()
        }}/>
      </Stack>
      <ListView
        isLoading={cmpy.isLoading || cmpy.isFetching}
        rowList={rowList} selected={selected} setSelected={setSelected}
        pagination={pagination} setPagination={setPagination}
      />
    </Stack>
  </ModalComponents>
}

const ListView = (props: {
  isLoading: boolean
  rowList: WithCustomRowData<bizParam>[]
  selected: WithCustomRowData<bizParam>[]
  setSelected: Dispatch<SetStateAction<WithCustomRowData<bizParam>[]>>
  pagination: { page: number, rowsPerPage: number, rowCount: number }
  setPagination: Dispatch<SetStateAction<{ page: number, rowsPerPage: number, rowCount: number }>>
}) => {

  return <TableComponents<bizParam>
    isLoading={props.isLoading} showTotal hideBoarder
    hideRowPerPage isCheckBox hideBoarderTopColor
    headCells={headCells}
    bodyRows={props.rowList}
    {...props.pagination}
    onChangePagination={(page, rowPerPage) => {
      if (!props.isLoading)
        props.setPagination((state) => ({...state, page: page, rowsPerPage: rowPerPage}))
    }}
    onSelectedKey={(keys: string[]) => {
      const selected = props.selected.map(m => m.key)

      if (selected.length < keys.length) {
        // 추가시
        const newKey = keys.find(f => !selected.includes(f))
        const data = props.rowList.find(f => f.key == newKey) as any
        props.setSelected(props.selected.concat(data))
      } else {
        // 삭제시
        const deleteKey = selected.find(f => !keys.includes(f))
        props.setSelected(props.selected.filter(f => f.key != deleteKey))
      }
      // props.setSelected(keys)
    }}
    tableCell={(item, index) => {
      return (
        <Fragment key={item.key}>
          <TableCell
            key={"nm-" + item.key}>{(props.pagination.page * props.pagination.rowsPerPage) + index + 1}</TableCell>
          <TableCell key={"memberNm-" + item.key}>{item!.memberNm}</TableCell>
          <TableCell key={"ceoNm-" + item.key}>{item!.ceoNm}</TableCell>
          <TableCell key={"bizrno-" + item.key}>{item!.bizrno}</TableCell>
        </Fragment>
      )
    }}
  />
}

const headCells: CustomHeadCell<cmpyHeadCell>[] = [
  {
    id: 'nm',
    align: "center",
    label: '번호',

  },
  {
    id: 'memberNm',
    align: 'center',
    label: '기업명',
  },
  {
    id: 'ceoNm',
    align: 'center',
    label: '대표자명',
  },
  {
    id: 'bizrno',
    align: 'center',
    label: '사업자번호',
  }
]

interface cmpyHeadCell {
  nm: number
  memberNm: string,
  ceoNm: string,
  bizrno: string
}