import React, {useState, useEffect} from 'react';
import * as styles from '../styles';
import {CustomButton, CustomLoadingButton} from '~/components/ButtonComponents';
import {ModalReasonConfirm} from '../../BusinessAppMgt/PopComp/ModalReasonConfirm';
import {useLocation, useNavigate} from 'react-router-dom';
import {fetchGetCommCode} from '~/fetches';
import {useQuery} from 'react-query';
import {fetchBsnsPlanDocInfo, fetchModifyPlan, fetchModifyPlanTmp} from '~/fetches/biz/fetchContractMgt';
import {BsnsPlanDocInfo, BsnsPlanDocInfoData, sumType, TaskReqstWct} from '~/models/ModelBizPlanMgt';
import {ModalComponents} from '~/components/SharedModalComponents';
import {useGlobalModalStore} from '~/pages/store/GlobalModalStore';
import {UsptTaskPartcptsTodoList} from './UsptTaskPartcptsTodoList';
import {FileUpload1} from '~/pages/EventNews/FileUpload';
import styled from '@emotion/styled';
import {SelectIcon} from '~/components/IconComponents';
import {
  SelectChangeEvent,
  Box,
  Tabs,
  Tab,
  Stack,
  OutlinedInput,
  FormControl,
  Select,
  FormControlLabel,
  Checkbox,
  MenuItem
} from '@mui/material';
import {Banner} from "~/components/Banner";
import fetchDownload from "~/fetches/fetchDownload";
import dayjs from "dayjs";
import {validBirthday, validPhoneNumber} from "shared/utils/validUtil";

/* 
  작성일    :   2022/06/26
  화면명    :   사업관리 -> 협약관리 -> 사업계획서 관리 상세
  회면ID    :   (UI-USP-FRN-0170201)
  화면/개발 :   Seongeonjoo / navycui
*/

const BusinessPlanMgtDetail = () => {

  const navigate = useNavigate()
  const receive: any = useLocation();
  const [value, setValue] = useState(0);
  const [tabNum, setTabNum] = useState(0);
  const [open, setOpen] = useState(false);
  const {addModal} = useGlobalModalStore()
  const [openTab, setOpenTab] = useState(false);
  const [openErr, setOpenErr] = useState(false);
  const [errMsg, setErrMsg] = useState('');
  const [changeYn, setChangeYn] = useState(false);
  const [sumVal, setSumVal] = useState<sumType>({sum1: 0, sum2: 0, sum3: 0, sum4: 0, sum5: 0});
  const [cmpnyTypebox, setCmpnyTypebox] = useState<any>();
  const [files, setFiles]: any = useState([]);
  const [attachmentFileList, setAttachmentFileList]: any = useState([]);
  const [deleteAttach, setDeleteAttach] = useState<any[]>([]);
  const [PlanDocInfo, setPlanDocInfo] = useState<BsnsPlanDocInfo>(BsnsPlanDocInfoData);
  const [loading, setLoading] = useState(true)

  // 공통 코드 조회
  const {data: assign_box} = useQuery("TASK_TYPE", async () => await fetchGetCommCode("TASK_TYPE"));

  // 사업계획서상세 조회
  const {
    data: list = [],
    isLoading,
    isFetching
  } = useQuery(["fetchBsnsPlanDocInfo", receive.state.item.bsnsSlctnId], async () =>
    await fetchBsnsPlanDocInfo({
      bsnsPlanDocId: receive.state.item.bsnsPlanDocId,
      bsnsSlctnId: receive.state.item.bsnsSlctnId
    }), {
    enabled: !!receive.state,
    onError: (err: any) => {
      setOpen(true)
      setLoading(false)
    },
  });

  useEffect(() => {
    if (!isLoading && !isFetching) {
      if (!!list) {
        console.log('list - ' + JSON.stringify(list))
        setPlanDocInfo(list)
        setLoading(false)
        if (list.attachFileList) {
          setAttachmentFileList(list.attachFileList)
        }
      }
    }
  }, [list, isLoading, isFetching])

  useEffect(() => {
    if (!isLoading) window.scrollTo(0, 5)
  }, [value])

  // 파일업로드
  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    let upfile: any = e.target.files;
    const update = [...files]
    for (var i = 0; i < upfile.length; i++) {
      update.push(upfile[i]);
    }
    setFiles(update)
  }

  const handleDownLoad = async (attachmentId: string) => {
    try {
      const result = await fetchDownload(`${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/bsns-plan/atchmnfl/${attachmentId}`)
    } catch (e: any) {
      let status = e.response.status;

      if (status === 400) {
        addModal({
          open: true,
          content: "파일이 없습니다."
        })
      }
    }
  }

  // 입력 변경
  const handelChangeInfo = (e: React.ChangeEvent<HTMLInputElement>, type: string) => {
    console.log('PlanDocInfo.usptBsnsPlanDoc.planPresentnSttusCd - ' + PlanDocInfo.usptBsnsPlanDoc.planPresentnSttusCd)
    if (PlanDocInfo.usptBsnsPlanDoc.planPresentnSttusCd === 'PLPR04') return
    const {name, value} = e.currentTarget;
    setPlanDocInfo((pre: any) => ({
      ...pre, [type]: {...pre[type], [name]: value}
    }))
  }

  // 신청예산 입력 변경
  const handelChangeTaskReqstWct = (e: React.ChangeEvent<HTMLInputElement>, item: TaskReqstWct, idx: number) => {
    if (PlanDocInfo.usptBsnsPlanDoc.planPresentnSttusCd == 'PLPR04') return
    const {name, value} = e.currentTarget;
    const updated: any = [...PlanDocInfo.usptTaskReqstWct];
    updated[idx] = {...item, [name]: value};
    setPlanDocInfo((pre: any) => ({
      ...pre, usptTaskReqstWct: updated
    }))
  }

  const handleChangeSelect = (event: SelectChangeEvent) => {
    // setAge(event.target.value as string);
    setCmpnyTypebox((state: any) => ({...state, [event.target.name as string]: event.target.value as string}));
  };
  // tab event
  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    // if (value === 1) {
    //   setOpenTab(true)
    //   setTabNum(newValue)
    // } else {
    //   // setOpenTab(true)
    //   setValue(newValue)
    // }
    setValue(newValue)
  };

  useEffect(() => {
    if (PlanDocInfo.usptTaskReqstWct.length > 0) {
      let box1: number, box2: number, box3: number, box4: number, box5: number = 0
      PlanDocInfo.usptTaskReqstWct.forEach((item: TaskReqstWct, idx: number) => {
        box1 = +parseInt(uncomma2(item.sportBudget))
        box2 = +parseInt(uncomma2(item.alotmCash))
        box3 = +parseInt(uncomma2(item.alotmActhng))
        box4 = +parseInt(uncomma2(item.alotmSum))
        box5 = +parseInt(uncomma2(item.alotmSumTot))
      })

      setSumVal((pre) => ({
        ...pre, sum1: box1, sum2: box2, sum3: box3, sum4: box4, sum5: box5
      }))
    }
  }, [PlanDocInfo.usptTaskReqstWct]);


  const handleDelete = (i: number) => {
    const update = [...files]
    update.splice(i, 1)
    setFiles(update);
  };

  const handleDelete2 = (attachmentId: string, i: number) => {
    const update = [...deleteAttach]
    update.push({
      attachmentId: attachmentId
    })
    setDeleteAttach(update);
    const update1 = [...attachmentFileList]
    update1.splice(i, 1)
    setAttachmentFileList(update1);
  }

  const validate = (isTemp?: boolean) => {
    if (PlanDocInfo) {
      let message = ''
      if (PlanDocInfo.usptTaskRspnber && !isTemp) {
        if (PlanDocInfo.usptTaskRspnber.rspnberNm == '' || PlanDocInfo.usptTaskRspnber.encMbtlnum == ''
          || PlanDocInfo.usptTaskRspnber.encEmail == '') {
          message = '일반현황에 과제책임자 인적 필수 사항을 입력해 주세요.'
        }
      }
      if (PlanDocInfo.usptTaskPrtcmpny && message == '') {
        PlanDocInfo.usptTaskPrtcmpny.map(m => {
          if (m.entrpsNm == '' || m.rspnberNm == '' || m.clsfNm == '' || m.regMbtlnum == '') {
            message = '참여기업 필수값을 입력해 주세요.'
          }
        })
      }
      if (PlanDocInfo.usptTaskPartcpts && message == '') {
        PlanDocInfo.usptTaskPartcpts.map(m => {
          if (m.memberNm == '' || m.partcptsNm == '') message = '참여인력에 필수값을 입력해 주세요.'
        })
      }
      if (PlanDocInfo.usptTaskReqstWct && !isTemp && message == '') {
        const total = PlanDocInfo.usptTaskReqstWct.flatMap(m => [
          parseInt(uncomma2(m.sportBudget)), parseInt(uncomma2(m.alotmCash)), parseInt(uncomma2(m.alotmActhng))])
          .reduce((rc, c) => {
            return rc += c
          }, 0)
        if (total != PlanDocInfo.usptBsnsPlanDoc.totalWct && PlanDocInfo.usptBsnsPlanDoc.totalWct != null)
          message = '사업비 합계를 총사업비에 맞춰주세요.'
      }

      if (message != '') {
        setErrMsg(message)
        setOpenErr(true)
        return true
      }
    }
    return false
  }

  // 임시 저장
  const saveTemp = async (step: string) => {
    if (validate(true)) return

    const formData = new FormData();
    const json = JSON.stringify({
      ...PlanDocInfo,
      attachFileDeleteList: deleteAttach
    });
    console.log('req - ' + json)
//     return
    const blob = new Blob([json], {type: "application/json"});
    formData.append('info', blob)

    for (let i = 0; i < files.length; i++) {
      formData.append("fileList", files[i])
    }
    await fetchModifyPlanTmp(formData, PlanDocInfo.usptBsnsPlanDoc.planPresentnSttusCd = 'PLPR02').then((res) => {
      setChangeYn(false)
      setValue(tabNum)
      setErrMsg('')
      addModal({
        type: 'normal',
        open: true,
        content: "임시저장 완료되었습니다.",
        onConfirm: () => {
          setValue(tabNum)
        },
      })
    }).catch((err) => {
      let msg = err.response.data.message
      setErrMsg(msg)
      setOpenErr(true)
    })
  }
  // 저장
  const saveSend = async (step: string) => {

    if (validate()) return

    const formData = new FormData();
    const json = JSON.stringify(PlanDocInfo);
    const blob = new Blob([json], {type: "application/json"});
    formData.append('info', blob)

    for (let i = 0; i < files.length; i++) {
      formData.append("fileList", files[i])
    }
    await fetchModifyPlan(formData, PlanDocInfo.usptBsnsPlanDoc.planPresentnSttusCd = 'PLPR02').then((res) => {
      setErrMsg('')
      setChangeYn(false)

      addModal({
        type: 'normal',
        open: true,
        content: "저장 되었습니다.",
        onClose: () => {navigate('/biz/ContractMgt/BusinessPlanMgt')},
        onConfirm: () => {navigate('/biz/ContractMgt/BusinessPlanMgt')}
      })
    }).catch((err) => {
      let msg = err.response.data.message
      setOpenErr(true)
      setErrMsg(msg)
    })
  }

  return <Banner
    title={'사업계획서 상세'} loading={loading}
    summary={'선정된 과제의 사업계획서 주요 정보를 입력하시고, 자료실 및 공고에서 해당 사업의 사업계획서 양식을 다운로드받아 함께 첨부해주시기 바랍니다.'}
    tabContent={<Tabs value={value} onChange={handleChange} variant="scrollable" scrollButtons="auto"
                      aria-label="basic tabs example">
      <Tab label="일반현황" {...a11yProps(0)} value={0} />
      {
        PlanDocInfo.usptBsnsPlanDoc && PlanDocInfo.usptBsnsPlanDoc.cnsrtm &&
        <Tab label="참여기업" {...a11yProps(1)} value={1}/>
      }
      {
        PlanDocInfo.usptBsnsPlanDoc && PlanDocInfo.usptBsnsPlanDoc.cnsrtm &&
        <Tab label="참여인력" {...a11yProps(2)} value={2}/>
      }
      <Tab label="신청예산" {...a11yProps(3)} value={3}/>
      <Tab label="첨부파일" {...a11yProps(4)} value={4}/>
    </Tabs>}>
    <div css={styles.container}>
      <Box className='content_body'>
        <div className="content">
          {/*  일반현황 */}
          <TabPanel value={value} index={0}>
            <Box className="box_guide">
              <ul>
                <li>신청시 입력한 신청자 정보 및 과제정보, 과제책임자 정보를 확인하시고, 변경사항이 있으면 수정해주세요.</li>
                <li>신청자정보는 마이페이지에서 수정할 수 있습니다.</li>
                <li><span className="must">*</span> 표시는 필수입력 항목입니다.</li>
              </ul>
            </Box>
            <Stack direction={'row'} justifyContent={'space-between'} alignItems={'flex-end'}
                   sx={{marginTop: '48px'}}>
              <h4 className="tbl_title">기본정보</h4>
              <CustomButton label={'회원정보 변경'} onClick={() => navigate('/MyPage/MemberInfoMmt/MemberInfoMdf')}
                            type={'modify'} color={'outlinedblack'} style={{marginBottom: '10px'}}/>
            </Stack>
            <Box css={styles.table}>
              <div className="detail_table">
                <dl>
                  <dt>제출일</dt>
                  <dd>
                    {
                      PlanDocInfo.usptBsnsPlanDoc?.presentnDt ?
                        dayjs(PlanDocInfo.usptBsnsPlanDoc?.presentnDt).format('YYYY-MM-DD') : ''
                    }</dd>
                  <dt>제출상태</dt>
                  <dd className="withLink">
                    {PlanDocInfo.usptBsnsPlanDoc?.planPresentnSttusNm || ''}
                    {/*{receive.state.item.planPresentnSttusCd == 'PLPR01' && '미제출'}*/}
                    {/*{receive.state.item.planPresentnSttusCd == 'PLPR02' && '제출'}*/}
                    {/*{receive.state.item.planPresentnSttusCd == 'PLPR03' && '보완요청'}*/}
                    {/*{receive.state.item.planPresentnSttusCd == 'PLPR04' && '승인'}*/}
                    {/*{receive.state.item.planPresentnSttusCd == 'PLPR05' && '승인취소'}*/}

                    {PlanDocInfo.usptBsnsPlanDoc?.planPresentnSttusNm == '보완요청' ?
                      <ModalReasonConfirm
                        applyId={receive.state.item.bsnsPlanDocId}
                        planPresentnSttusCd={receive.state.item.planPresentnSttusCd}
                        viewNm='BusinessPlanMgt'
                        title='사업계획서 상세'
                        variant='text'
                        label='사유확인'
                        type='modify'
                        color='outlined'
                      /> : null
                    }
                  </dd>
                </dl>
                <dl>
                  <dt>사업명</dt>
                  <dd>{PlanDocInfo.usptBsnsPlanDoc?.bsnsNm}</dd>
                  <dt>사업연도</dt>
                  <dd>{PlanDocInfo.usptBsnsPlanDoc?.bsnsYear}</dd>
                </dl>
                <dl>
                  <dt>공고명</dt>
                  <dd>{PlanDocInfo.usptBsnsPlanDoc?.pblancNm}</dd>
                  <dt>접수번호</dt>
                  <dd>{PlanDocInfo.usptBsnsPlanDoc?.receiptNo}</dd>
                </dl>
              </div>
            </Box>
            <h4 className="tbl_title">{/* css특성때문에 집어넣었어요. 삭제하지마세요. */}</h4>
            <h4 className="tbl_title">과제정보</h4>
            <Box css={styles.table}>
              <div className="detail_table">
                <dl>
                  <dt>과제명 / 프로젝트명(국문) <span className='must'>*</span></dt>
                  <dd><OutlinedInput
                    size="small"
                    className="ipt_tp01"
                    sx={{width: '100%'}}
                    name="taskNmKo"
                    value={PlanDocInfo.usptBsnsPlanDoc?.taskNmKo}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                      handelChangeInfo(e, 'usptBsnsPlanDoc')
                    }}/></dd>
                </dl>
                <dl>
                  <dt>과제명(영문)</dt>
                  <dd><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                     name="taskNmEn"
                                     value={PlanDocInfo.usptBsnsPlanDoc?.taskNmEn}
                                     onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                       handelChangeInfo(e, 'usptBsnsPlanDoc')
                                     }}/></dd>
                </dl>
                <dl>
                  <dt>과제분야 <span className='must'>*</span></dt>
                  <dd>
                    <Box css={styles.inputBox}>
                      <FormControl fullWidth>
                        <Select
                          size='small'
                          labelId="demo-simple-select-label"
                          name="applyFieNm"
                          value={PlanDocInfo.usptBsnsPlanDoc?.applyFieNm}
                          onChange={(event: SelectChangeEvent) => {
                            if (PlanDocInfo.usptBsnsPlanDoc.planPresentnSttusCd == 'PLPR04') return
                            const select = PlanDocInfo.applyRealmList.find(f => f.applyRealmNm == event.target.value)
                            if (select) {
                              setPlanDocInfo((pre: any) => ({
                                ...pre, usptBsnsPlanDoc: {
                                  ...pre.usptBsnsPlanDoc,
                                  applyFieNm: select.applyRealmNm,
                                  applyField: select.applyRealmId
                                }
                              }))
                            }
                          }}
                          IconComponent={SelectIcon}
                          MenuProps={MenuProps}
                        >
                          {(PlanDocInfo.applyRealmList !== undefined) ?
                            PlanDocInfo.applyRealmList.map((item: any) => (
                              // value에 applyRealmNm로 수정
                              <MenuItem key={item.applyRealmId}
                                        value={item.applyRealmNm}>{item.applyRealmNm}</MenuItem>
                            ))
                            : null
                          }
                          {/*{*/}
                          {/*  assign_box ? assign_box.list.map((option: any) => (*/}
                          {/*    <SelectItemStyle key={option.code} value={option.code || ''}>*/}
                          {/*      {option.codeNm}*/}
                          {/*    </SelectItemStyle>*/}
                          {/*  )) : []*/}
                          {/*}*/}
                        </Select>
                      </FormControl>
                    </Box>
                  </dd>
                  <dt>사업기간</dt>
                  <dd>{PlanDocInfo.usptBsnsPlanDoc?.bsnsPd}</dd>
                </dl>
                <dl>
                  <dt>사업기간(전체)</dt>
                  <dd>
                    {PlanDocInfo.usptBsnsPlanDoc?.bsnsPd}
                    ({PlanDocInfo.usptBsnsPlanDoc?.bsnsPdAll})
                  </dd>
                  <dt>사업기간(당해)</dt>
                  <dd>
                    {PlanDocInfo.usptBsnsPlanDoc?.bsnsPd}
                    ({PlanDocInfo.usptBsnsPlanDoc?.bsnsPdYw})
                  </dd>
                </dl>
              </div>
            </Box>
            <Stack direction={'row'} justifyContent={'space-between'} alignItems={'flex-start'}
                   sx={{marginTop: '60px'}}>
              <h4 className="tbl_title">과제책임자</h4>
              <Box className='checkbox'>
                <FormControlLabel style={{height: '30px'}} control={<Checkbox defaultChecked onClick={() => {
                  console.log('신청자와 동일')
                }}/>} label="신청자와 동일"/>
              </Box>
            </Stack>
            <Box css={styles.table}>
              <div className="detail_table">
                <dl>
                  <dt>이름<span className='must'>*</span></dt>
                  <dd><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                     name="rspnberNm"
                                     value={PlanDocInfo.usptTaskRspnber?.rspnberNm}
                                     onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                       handelChangeInfo(e, 'usptTaskRspnber')
                                     }}/></dd>
                  <dt>생년월일</dt>
                  <dd><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                     name="encBrthdy"
                                     value={PlanDocInfo.usptTaskRspnber?.encBrthdy}
                                     onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                       e.currentTarget.value = validBirthday(e.currentTarget.value)
                                       handelChangeInfo(e, 'usptTaskRspnber')
                                     }}/></dd>
                </dl>
                <dl>
                  <dt>휴대폰 번호<span className='must'>*</span></dt>
                  <dd><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                     name="encMbtlnum"
                                     value={PlanDocInfo.usptTaskRspnber?.encMbtlnum}
                                     onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                       e.currentTarget.value = validPhoneNumber(e.currentTarget.value)
                                       handelChangeInfo(e, 'usptTaskRspnber')
                                     }}/></dd>
                  <dt>이메일<span className='must'>*</span></dt>
                  <dd><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                     name="encEmail"
                                     value={PlanDocInfo.usptTaskRspnber?.encEmail}
                                     onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                       handelChangeInfo(e, 'usptTaskRspnber')
                                     }}/></dd>
                </dl>
                <dl>
                  <dt>부서/학과</dt>
                  <dd><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                     name="deptNm"
                                     value={PlanDocInfo.usptTaskRspnber?.deptNm}
                                     onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                       handelChangeInfo(e, 'usptTaskRspnber')
                                     }}/></dd>
                  <dt>직위/직급</dt>
                  <dd><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                     name="clsfNm"
                                     value={PlanDocInfo.usptTaskRspnber?.clsfNm}
                                     onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                       handelChangeInfo(e, 'usptTaskRspnber')
                                     }}/></dd>
                </dl>
                <dl>
                  <dt>주소</dt>
                  <dd className='address'>
                    <Stack flexDirection={'row'} columnGap={1}>
                      <Stack direction='row' spacing={2} sx={{width: '100%'}}>
                        <OutlinedInput
                          size="small"
                          name='adres'
                          value={PlanDocInfo.usptTaskRspnber?.adres}
                          className="ipt_tp01"
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                            handelChangeInfo(e, 'usptTaskRspnber')
                          }}
                        />
                        {/* <CustomButton label={'주소찾기'} type={'modalBtn'} color={'outlined'} onClick={searchAdrr}/> */}
                      </Stack>
                    </Stack>
                    {/* <Stack flexDirection={'row'} columnGap={1} sx={{marginTop:'10px'}}>
                        <OutlinedInput
                          size="small"
                          name='adres'
                          value={PlanDocInfo.usptTaskRspnber?.adres} 
                          sx={{width:'38.5%'}}
                          onChange={(e:React.ChangeEvent<HTMLInputElement>)=>{handelChangeInfo(e,'usptTaskRspnber')}}
                        />
                        <OutlinedInput
                          size="small"
                          sx={{width:'61.5%'}}
                          name='adresDetail' 
                          value={PlanDocInfo.usptTaskRspnber?.adres}
                          onChange={(e:React.ChangeEvent<HTMLInputElement>)=>{handelChangeInfo(e,'usptTaskRspnber')}}
                        />
                      </Stack> */}
                  </dd>
                </dl>
                <dl>
                  <dt>유선번호</dt>
                  <dd><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                     name='encTelno'
                                     value={PlanDocInfo.usptTaskRspnber?.encTelno}
                                     onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                       e.currentTarget.value = validPhoneNumber(e.currentTarget.value)
                                       handelChangeInfo(e, 'usptTaskRspnber')
                                     }}/></dd>
                  <dt>팩스번호</dt>
                  <dd><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                     name='encFxnum'
                                     value={PlanDocInfo.usptTaskRspnber?.encFxnum}
                                     onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                       e.currentTarget.value = validPhoneNumber(e.currentTarget.value)
                                       handelChangeInfo(e, 'usptTaskRspnber')
                                     }}/></dd>
                </dl>
                <dl>
                  <dt>과학기술인 등록번호</dt>
                  <dd><OutlinedInput size="small" className="ipt_tp01 regNum"
                                     name='tlsyRegistNo'
                                     value={PlanDocInfo.usptTaskRspnber?.tlsyRegistNo}
                                     onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                       handelChangeInfo(e, 'usptTaskRspnber')
                                     }}/></dd>
                </dl>
              </div>
            </Box>
            {
              PlanDocInfo.usptBsnsPlanDoc.planPresentnSttusCd != 'PLPR02' && PlanDocInfo.usptBsnsPlanDoc.planPresentnSttusCd != 'PLPR04' &&
              <Stack direction="row" justifyContent="center" spacing={2} sx={{marginTop: '40px'}} css={styles.btn_next}>
                <CustomLoadingButton label={'임시저장'} type={'listBack'} color={'outlined'}
                                     onClick={async () => {
                                       saveTemp('01')
                                     }}/>
                <CustomLoadingButton label={'제출'} type={'listBack'} color={'primary'}
                                     onClick={async () => {
                                       saveSend('01')
                                     }}/>
              </Stack>
            }

          </TabPanel>
          {/*  참여기업 */}
          {
            PlanDocInfo.usptBsnsPlanDoc && PlanDocInfo.usptBsnsPlanDoc.cnsrtm &&
            <TabPanel value={value} index={1}>
              <Box className="box_guide">
                <ul>
                  <li>공동참여기업(컨소시엄)이 있는 경우 참여기업 정보를 등록해주시기 바랍니다.</li>
                  <li><span className="must">*</span> 표시는 필수입력 항목입니다.</li>
                </ul>
              </Box>
              <Box css={styles.table}>
                <h4 className="tbl_title">참여기업 개요</h4>
                <div className="detail_table">
                  <dl>
                    <dt>참여업체 총수</dt>
                    <dd><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                       name='partcptnCompanyCnt'
                                       value={PlanDocInfo.usptBsnsPlanDoc?.partcptnCompanyCnt}
                                       onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                         handelChangeInfo(e, 'usptBsnsPlanDoc')
                                       }}
                    /></dd>
                    <dt>중소기업수</dt>
                    <dd><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                       name='smlpzCnt'
                                       value={PlanDocInfo.usptBsnsPlanDoc?.smlpzCnt}
                                       onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                         handelChangeInfo(e, 'usptBsnsPlanDoc')
                                       }}
                    /></dd>
                  </dl>
                  <dl>
                    <dt>중견기업수</dt>
                    <dd><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                       name='mspzCnt'
                                       value={PlanDocInfo.usptBsnsPlanDoc?.mspzCnt}
                                       onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                         handelChangeInfo(e, 'usptBsnsPlanDoc')
                                       }}
                    /></dd>
                    <dt>기타</dt>
                    <dd><OutlinedInput size="small" className="ipt_tp01" sx={{width: '100%'}}
                                       name='etcCnt'
                                       value={PlanDocInfo.usptBsnsPlanDoc?.etcCnt}
                                       onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                         handelChangeInfo(e, 'usptBsnsPlanDoc')
                                       }}
                    /></dd>
                  </dl>
                </div>
              </Box>
              <UsptTaskPartcptsTodoList
                dataList={PlanDocInfo.usptTaskPrtcmpny}
                planPresentnSttusCd={PlanDocInfo.usptBsnsPlanDoc?.planPresentnSttusCd}
                type="usptTaskPrtcmpny"
                onChangeBox={(s: any[]) => {
                  if (s.length > 0) {
                    let arrbox = [...s]
                    setPlanDocInfo((pre) => ({...pre, usptTaskPrtcmpny: arrbox}))
                  }
                }}
                // children={<TableTest />}
              />
              {
                PlanDocInfo.usptBsnsPlanDoc.planPresentnSttusCd != 'PLPR02' && PlanDocInfo.usptBsnsPlanDoc.planPresentnSttusCd != 'PLPR04' &&
                <Stack direction="row" justifyContent="center" spacing={2} sx={{marginTop: '40px'}}
                       css={styles.btn_next}>
                  <CustomButton label={'임시저장'} type={'listBack'} color={'outlined'} onClick={() => {
                    saveTemp('01')
                  }}/>
                  <CustomButton label={'제출'} type={'listBack'} color={'primary'} onClick={() => {
                    saveSend('01')
                  }}/>
                </Stack>
              }

            </TabPanel>
          }
          {/*  참여인력 */}
          {
            PlanDocInfo.usptBsnsPlanDoc && PlanDocInfo.usptBsnsPlanDoc.cnsrtm &&
            <TabPanel value={value} index={2}>
              <Box className="box_guide">
                <ul>
                  <li>과제책임자를 제외한 참여인원의 정보를 입력해주시기 바랍니다.</li>
                  <li><span className="must">*</span> 표시는 필수입력 항목입니다.</li>
                </ul>
              </Box>
              <h4 className="tbl_title">{/* css특성때문에 집어넣었어요. 삭제하지마세요. */}</h4>
              <UsptTaskPartcptsTodoList
                dataList={PlanDocInfo.usptTaskPartcpts}
                planPresentnSttusCd={PlanDocInfo.usptBsnsPlanDoc?.planPresentnSttusCd}
                type='usptTaskPartcpts'
                memberList={PlanDocInfo.usptTaskPrtcmpny?.map(m => {
                  return {
                    memberId: m.memberId,
                    memberNm: m.entrpsNm
                  }
                })}
                onChangeBox2={(s: any[]) => {
                  if (s.length > 0) {
                    let arrbox = [...s]
                    setPlanDocInfo((pre) => ({...pre, usptTaskPartcpts: arrbox}))
                  }
                }}
                // children={<TableTest />}
              />
              {
                PlanDocInfo.usptBsnsPlanDoc.planPresentnSttusCd != 'PLPR02' && PlanDocInfo.usptBsnsPlanDoc.planPresentnSttusCd != 'PLPR04' &&
                <Stack direction="row" justifyContent="center" spacing={2} sx={{marginTop: '40px'}}
                       css={styles.btn_next}>
                  <CustomButton label={'임시저장'} type={'listBack'} color={'outlined'} onClick={() => {
                    saveTemp('01')
                  }}/>
                  <CustomButton label={'제출'} type={'listBack'} color={'primary'} onClick={() => {
                    saveSend('01')
                  }}/>
                </Stack>
              }

            </TabPanel>
          }

          {/* 신청예산 */}
          <TabPanel value={value} index={3}>
            <Box className="box_guide">
              <ul>
                <li>사업비 신청금액을 입력 해주세요.</li>
                <li>심의를 통해 조정된 사업비가 있는 경우 조정된 사업비로 입력해 주셔야 합니다.</li>
                <li><span className="must">*</span> 표시는 필수입력 항목입니다.</li>
              </ul>
            </Box>
            <Stack css={styles.title_set}>
              <h4 className="tbl_title">신청예산 <span className='unit'>(단위:천원)</span></h4>
              <div className='tbl_desc'>각 사업년도를 클릭하여 비목별 사업비 구성정보를 작성해주세요.</div>
            </Stack>
            <Box css={styles.table}>
              <div className="detail_table type2">
                <dl>
                  <dt>총사업비</dt>
                  <dd><OutlinedInput size="small" value={inputPriceFormat(PlanDocInfo.usptBsnsPlanDoc?.totalWct) || 0}
                                     disabled={true}
                                     className="ipt_tp01 tar" style={{width: 'auto'}}/></dd>
                </dl>
                {PlanDocInfo.usptTaskReqstWct.length > 1 ?
                  <dl className='horz'>
                    <dt>사업비</dt>
                    <dd>
                      <div className='tableDefault_scroll'>
                        <table className="tableDefault type5">
                          <colgroup>
                            <col/>
                            <col/>
                            <col/>
                            <col/>
                            <col/>
                          </colgroup>
                          <thead>
                          <tr>
                            <th rowSpan={2}>사업연도</th>
                            <th rowSpan={2}>지원예산</th>
                            <th colSpan={3}>민간부담금</th>
                            <th rowSpan={2}>합계</th>
                          </tr>
                          <tr>
                            <th>현금</th>
                            <th>현물</th>
                            <th>소계</th>
                          </tr>
                          </thead>
                          <tbody>
                          {
                            PlanDocInfo.usptTaskReqstWct.length > 0 ? PlanDocInfo.usptTaskReqstWct.map((item: TaskReqstWct, idx: number) => {
                              return (
                                <tr>
                                  <td>
                                    <Stack direction={'row'}>
                                      <span style={{marginRight: '10px'}}>{item.bsnsYear}</span>
                                      <ModalReasonConfirm
                                        applyId={PlanDocInfo.usptBsnsPlanDoc?.bsnsPlanDocId}
                                        readOnly={PlanDocInfo.usptBsnsPlanDoc?.planPresentnSttusCd == 'PLPR04' || false}
                                        bsnsYear={item.bsnsYear}
                                        viewNm='BusinessPlanMgtDetail'
                                        title='비목별 사업비 구성'
                                        variant='outlined'
                                        label='등록'
                                        type='modify'
                                        color='outlined'
                                      />
                                    </Stack>
                                  </td>
                                  <td>
                                    <OutlinedInput
                                      size="small" type="number" className="ipt_tp01 tar"
                                      sx={{width: '100%'}}
                                      name='sportBudget'
                                      value={item.sportBudget}
                                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                        handelChangeTaskReqstWct(e, item, idx)
                                      }}
                                    />
                                  </td>
                                  <td>
                                    <OutlinedInput
                                      size="small" className="ipt_tp01 tar" sx={{width: '100%'}}
                                      name='alotmCash'
                                      value={item.alotmCash}
                                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                        handelChangeTaskReqstWct(e, item, idx)
                                      }}
                                    />
                                  </td>
                                  <td>
                                    <OutlinedInput
                                      size="small" className="ipt_tp01 tar" sx={{width: '100%'}}
                                      name='alotmActhng'
                                      value={item.alotmActhng}
                                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                        handelChangeTaskReqstWct(e, item, idx)
                                      }}
                                    />
                                  </td>
                                  <td>
                                    <OutlinedInput
                                      name='alotmSum' size="small" className="ipt_tp01 tar" sx={{width: '100%'}}
                                      value={inputPriceFormat((Number(uncomma2(item.alotmCash)) + Number(uncomma2(item.alotmActhng))))}
                                      // onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                      // }}
                                    />
                                  </td>
                                  <td>
                                    <OutlinedInput
                                      name='alotmSumTot' size="small" className="ipt_tp01 tar" sx={{width: '100%'}}
                                      value={inputPriceFormat((Number(uncomma2(item.sportBudget)) + Number(uncomma2(item.alotmCash))
                                        + Number(uncomma2(item.alotmActhng))))}
                                      // onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                      //   handelChangeTaskReqstWct(e, item, idx)
                                      // }}
                                    />
                                  </td>
                                </tr>
                              )
                            }) : null
                          }
                          <tr className='total'>
                            <td>합계</td>
                            <td className='tar'>{inputPriceFormat(
                              PlanDocInfo.usptTaskReqstWct.flatMap(m => m.sportBudget)
                                .reduce((ac, c) => {
                                  return ac += Number(uncomma2(c))
                                }, 0))
                            }</td>
                            <td className='tar'>{inputPriceFormat(
                              PlanDocInfo.usptTaskReqstWct.flatMap(m => m.alotmCash)
                                .reduce((ac, c) => {
                                  return ac += Number(uncomma2(c))
                                }, 0))
                            }</td>
                            <td className='tar'>{inputPriceFormat(
                              PlanDocInfo.usptTaskReqstWct.flatMap(m => m.alotmActhng)
                                .reduce((ac, c) => {
                                  return ac += Number(uncomma2(c))
                                }, 0))
                            }</td>
                            <td className='tar'>{inputPriceFormat(
                              PlanDocInfo.usptTaskReqstWct.flatMap(m => [m.alotmCash, m.alotmActhng])
                                .reduce((ac, c) => {
                                  return ac += Number(uncomma2(c))
                                }, 0))
                            }</td>
                            <td className='tar'>{inputPriceFormat(
                              PlanDocInfo.usptTaskReqstWct.flatMap(m => [m.sportBudget, m.alotmCash, m.alotmActhng])
                                .reduce((ac, c) => {
                                  return ac += Number(uncomma2(c))
                                }, 0))}</td>
                          </tr>
                          </tbody>
                        </table>
                      </div>
                    </dd>
                  </dl> :
                  <dl className='horz'>
                    <dt>사업비</dt>
                    <dd>
                      <div className='tableDefault_scroll'>
                        <table className="tableDefault type5">
                          <colgroup>
                            <col style={{width: '20%'}}/>
                            <col/>
                            <col/>
                            <col/>
                            <col/>
                            <col/>
                          </colgroup>
                          <thead>
                          <tr>
                            <th rowSpan={2}>사업연도</th>
                            <th rowSpan={2}>지원금</th>
                            <th colSpan={3}>민간부담금</th>
                            <th rowSpan={2}>합계</th>
                          </tr>
                          <tr>
                            <th>현금</th>
                            <th>현물</th>
                            <th>소계</th>
                          </tr>
                          </thead>
                          <tbody>
                          {
                            PlanDocInfo.usptTaskReqstWct.length > 0 ? PlanDocInfo.usptTaskReqstWct.map((item: TaskReqstWct, idx: number) => {
                              return (
                                <tr>
                                  <td>
                                    <span style={{marginRight: '10px'}}>{item.bsnsYear}</span>
                                    <ModalReasonConfirm
                                      applyId={PlanDocInfo.usptBsnsPlanDoc?.bsnsPlanDocId}
                                      readOnly={PlanDocInfo.usptBsnsPlanDoc?.planPresentnSttusCd == 'PLPR04' || false}
                                      bsnsYear={item.bsnsYear}
                                      viewNm='BusinessPlanMgtDetail'
                                      title='비목별 사업비 구성'
                                      variant='outlined'
                                      label='등록'
                                      type='modify'
                                      color='outlined'
                                    />
                                  </td>
                                  <td><OutlinedInput size="small" className="ipt_tp01 tar" sx={{width: '100%'}}
                                                     name='sportBudget'
                                                     value={inputPriceFormat(item.sportBudget)}
                                                     inputProps={{inputMode: 'numeric', pattern: '[0-9]*'}}
                                                     onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                                       handelChangeTaskReqstWct(e, item, idx)
                                                     }}
                                  />
                                  </td>

                                  <td><OutlinedInput size="small" className="ipt_tp01 tar" sx={{width: '100%'}}
                                                     name='alotmCash'
                                                     value={inputPriceFormat(item.alotmCash)}
                                                     onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                                       handelChangeTaskReqstWct(e, item, idx)
                                                     }}
                                  /></td>
                                  <td><OutlinedInput size="small" className="ipt_tp01 tar" sx={{width: '100%'}}
                                                     name='alotmActhng'
                                                     value={inputPriceFormat(item.alotmActhng)}
                                                     onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                                       handelChangeTaskReqstWct(e, item, idx)
                                                     }}
                                  /></td>
                                  <td><OutlinedInput size="small" className="ipt_tp01 tar" sx={{width: '100%'}}
                                                     name='alotmSum'
                                                     value={inputPriceFormat(Number(uncomma2(item.alotmCash)) + Number(uncomma2(item.alotmActhng)))}
                                                     onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                                       // handelChangeTaskReqstWct(e, item, idx)
                                                     }}
                                  /></td>
                                  <td><OutlinedInput size="small" className="ipt_tp01 tar" sx={{width: '100%'}}
                                                     name='alotmSumTot'
                                                     value={inputPriceFormat(Number(uncomma2(item.sportBudget)) + Number(uncomma2(item.alotmCash))
                                                       + Number(uncomma2(item.alotmActhng)))}
                                                     onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                                       // handelChangeTaskReqstWct(e, item, idx)
                                                     }}
                                  /></td>
                                </tr>
                              )
                            }) : null
                          }
                          <tr className='total'>
                            <td>합계</td>
                            <td className='tar'>{inputPriceFormat(
                              PlanDocInfo.usptTaskReqstWct.flatMap(m => m.sportBudget)
                                .reduce((ac, c) => {
                                  return ac += Number(uncomma2(c))
                                }, 0))
                            }</td>
                            <td className='tar'>{inputPriceFormat(
                              PlanDocInfo.usptTaskReqstWct.flatMap(m => m.alotmCash)
                                .reduce((ac, c) => {
                                  return ac += Number(uncomma2(c))
                                }, 0))
                            }</td>
                            <td className='tar'>{inputPriceFormat(
                              PlanDocInfo.usptTaskReqstWct.flatMap(m => m.alotmActhng)
                                .reduce((ac, c) => {
                                  return ac += Number(uncomma2(c))
                                }, 0))
                            }</td>
                            <td className='tar'>{inputPriceFormat(
                              PlanDocInfo.usptTaskReqstWct.flatMap(m => [m.alotmCash, m.alotmActhng])
                                .reduce((ac, c) => {
                                  return ac += Number(uncomma2(c))
                                }, 0))
                            }</td>
                            <td className='tar'>{inputPriceFormat(
                              PlanDocInfo.usptTaskReqstWct.flatMap(m => [m.sportBudget, m.alotmCash, m.alotmActhng])
                                .reduce((ac, c) => {
                                  return ac += Number(uncomma2(c))
                                }, 0))}</td>
                          </tr>
                          </tbody>
                        </table>
                      </div>
                    </dd>
                  </dl>
                }
                {/*<dl>*/}
                {/*  <dt>비목별 사업비</dt>*/}
                {/*  <dd>*/}
                {/*    <ModalReasonConfirm*/}
                {/*      applyId='item.taskReqstWctId'*/}
                {/*      viewNm='BusinessPlanMgtDetail'*/}
                {/*      title='사업계획서 상세'*/}
                {/*      variant='outlined'*/}
                {/*      label='등록'*/}
                {/*      type='modify'*/}
                {/*      color='outlined'*/}
                {/*    />*/}
                {/*  </dd>*/}
                {/*</dl>*/}
              </div>
            </Box>
            {
              PlanDocInfo.usptBsnsPlanDoc.planPresentnSttusCd != 'PLPR02' && PlanDocInfo.usptBsnsPlanDoc.planPresentnSttusCd != 'PLPR04' &&
              <Stack direction="row" justifyContent="center" spacing={2} sx={{marginTop: '40px'}} css={styles.btn_next}>
                <CustomButton label={'임시저장'} type={'listBack'} color={'outlined'} onClick={() => {
                  saveTemp('01')
                }}/>
                <CustomButton label={'제출'} type={'listBack'} color={'primary'} onClick={() => {
                  saveSend('01')
                }}/>
              </Stack>
            }

          </TabPanel>
          {/*  파일첨부 */}
          <TabPanel value={value} index={4}>
            <Box className="box_guide">
              <ul>
                <li>공고 및 자료실에 업로드된 해당 사업의 사업계획서 양식을 다운로드 받아 첨부해주시기 바랍니다.</li>
                <li>사업계획서 내용과 시스템에 입력한 정보는 모두 동일해야합니다.</li>
                <li><span className="must">*</span> 표시는 필수입력 항목입니다.</li>
              </ul>
            </Box>
            <h4 className='tbl_title'>파일첨부</h4>
            <Box css={styles.fileupload}>
              <FileUpload1
                files={files}
                handleDelete={handleDelete}
                handleUpload={handleUpload}
                files1={attachmentFileList}
                handleDelete2={handleDelete2}
                handleDownLoad={handleDownLoad}
              />
            </Box>
            {
              PlanDocInfo.usptBsnsPlanDoc.planPresentnSttusCd != 'PLPR02' && PlanDocInfo.usptBsnsPlanDoc.planPresentnSttusCd != 'PLPR04' &&
              <Stack direction="row" justifyContent="center" spacing={2} sx={{marginTop: '40px'}} css={styles.btn_next}>
                <CustomButton label={'임시저장'} type={'listBack'} color={'outlined'} onClick={() => {
                  saveTemp('01')
                }}/>
                <CustomButton label={'제출'} type={'listBack'} color={'primary'} onClick={() => {
                  saveSend('01')
                }}/>
              </Stack>
            }

          </TabPanel>
        </div>
      </Box>

      <ModalComponents open={openTab} type={'confirm'} content={'변경된 정보를 저장하시겠습니까?'}
                       onConfirm={() => {
                         setOpenTab(false)
                         saveTemp('01')
                       }}
                       onClose={() => {
                         setOpenTab(false)
                         setValue(tabNum)
                       }}>
      </ModalComponents>
      <ModalComponents open={openErr} type={'normal'} content={errMsg}
                       onConfirm={() => {
                         setOpenErr(false)
                       }}
                       onClose={() => {
                         setOpenErr(false)
                       }}>
      </ModalComponents>
    </div>
  </Banner>
}

export default BusinessPlanMgtDetail;

export const uncomma2 = (str: any) => {
  str = String(str);
  return str.replace(/[^\d]+/g, "");
};

export const inputPriceFormat = (str: any) => {
  const comma = (str: any) => {
    str = String(str);
    return str.replace(/(\d)(?=(?:\d{3})+(?!\d))/g, "$1,");
  };
  const uncomma = (str: any) => {
    str = String(str);
    return str.replace(/[^\d]+/g, "");
  };
  return comma(uncomma(str));
};

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const {children, value, index, ...other} = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{p: 3}}>
          {children}
        </Box>
      )}
    </div>
  );
}

function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

const MenuProps = {
  PaperProps: {
    style: {
      width: 'auto',
      marginTop: '4px',
      padding: '4px',
      boxShadow: 'none',
      border: '1px solid #ccc',
      borderRadius: '5px',
    },
  },
};

const SelectItemStyle = styled(MenuItem)`
  font-size: 16px;
  letter-spacing: -0.64px;
  font-family: Noto Sans CJK KR;
  padding: 0 12px;
  min-height: 40px !important;
  border-radius: 3px;
  margin-bottom: 4px;
  height: 44px;
  line-height: 2.2;

  &:first-of-type {
    margin-top: -8px;
  }

  &:last-of-type {
    margin-bottom: -8px;
  }

  &.Mui-selected {
    background-color: #f5f5f5;

    &:hover, &:focus-visible {
      background-color: #f5f5f5;
    }
  }
`;
