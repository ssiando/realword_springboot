import React, {useState, useEffect, Fragment} from 'react';
import * as styles from '../styles';
import * as comstyles from '~/styles/styles';
import Box from '@mui/material/Box';
import {Stack, Button} from '@mui/material';
import fetchDownload from '~/fetches/fetchDownload';
import {useGlobalModalStore} from '~/pages/store/GlobalModalStore';
import {CustomButton} from 'shared/components/ButtonComponents';
import {ModalReasonConfirm} from '../../BusinessAppMgt/PopComp/ModalReasonConfirm';
import {useLocation} from "react-router-dom";
import {useQuery} from "react-query";
import {fetchCnvnCnclsDocInfo, fetchSign} from "~/fetches/biz/fetchContractMgt";
import {Banner} from "~/components/Banner";
import {Body2} from "shared/components/TextComponents";
import {Color} from "shared/components/StyleUtils";
import $ from "jquery";
import {FetchAccountCertBzmn} from "~/fetches/fetchTerms";
import {dayFormat} from "shared/utils/stringUtils";

const _global = (window /* browser */ || global /* node */) as any

// 전자협약상세
function ElectronicAgtMgtDetail() {
  const isDetail = true;
  const {addModal} = useGlobalModalStore();
  const [attachmentFileList2, setAttachmentFileList2]: any = useState();
  const [data, setData] = useState<any>()
  const [loading, setLoading] = useState(true)
  const receive: any = useLocation();

  const query = useQuery(["agtMgtDetail", receive.state.item.bsnsCnvnId], () => fetchCnvnCnclsDocInfo({
    bsnsCnvnId: receive.state.item.bsnsCnvnId,
    applyId: receive.state.item.applyId,
  }));

  useEffect(() => {
    $("#pkiContainer").hide();
    window.addEventListener("message", receiveMessage, false);
  }, [])

  //iframe 으로부터 메시지 수신 이벤트 함수
  function receiveMessage(e: any) {
    if (!!e && e.data && typeof e.data == 'string') {
      let data = JSON.parse(e.data);
      //console.log(data);

      // iframe 숨김 처리
      $("#pkiContainer").hide();
      $("#pki-frame").prop("src", "about:blank");

      if (data.code == "0") {
        // 콜백 함수 실행
        new Function(`${data.funcNm}("${data.sessionKey}");`)();
      }
    }
  }

  // MagicLine JS 모듈 호출
  const doSignData = async () => {
    if (!!window && data?.bizrno) {
      let $form = $("form[name='reqForm']");
      $form.find("input[type='hidden'][name='bizrno']").val(data.bizrno);  // 사업자등록번호
      $form.find("input[type='hidden'][name='callback']").val('pkiCert');   // 콜백으로 받을 함수명

      $form.prop("method", "POST");
      $form.prop("target", "pki-frame");
      $form.prop("action", process.env.REACT_APP_PKI_CERT_URL);         // PKI Monolithic was 서버 공동인증서 페이지 URL

      $form.submit();
      $("#pkiContainer").show();
    }
  }

  _global.pkiCert = (pkiCertSessionId: string) => {
    // console.log('pkiCertSessionId - ' + pkiCertSessionId)
    fetchSign({
      bsnsCnvnId: receive.state.item.bsnsCnvnId,
      applyId: receive.state.item.applyId,
      certSessionId: pkiCertSessionId
    }).then(res => {
      query.refetch()
    }).catch(e => {
      console.log('catch e - ', e)
    })
  }

  useEffect(() => {
    if (!query.isLoading && !query.isFetching) {
      if (!!query.data) {
        setData(query.data)
        console.log('query.data - ' + JSON.stringify(query.data))
      }
      setLoading(false)
    }
  }, [query.data, query.isLoading, query.isFetching])

  //배너 scroll
  const download = async (rsltId: string, attachmentId: string) => {
    fetchDownload(`${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/rslt/${rsltId}/hist/atchmnfl/${attachmentId}`)
      .then()
      .catch((e) => {
        let status = e.response.status;
        console.log(status);

        if (status === 400) {
          addModal({
            open: true,
            content: "파일이 없습니다."
          })
        }
      });
  }
  const downloadAll = async (rsltId: string) => {
    fetchDownload(`${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/rslt/${rsltId}/hist/atchmnfl`)
      .then()
      .catch((e) => {
        let status = e.response.status;
        console.log(status);

        if (status === 400) {
          addModal({
            open: true,
            content: "파일이 없습니다."
          })
        }
      });
  }

  const post = (path: string, params: any, method = 'post') => {
    // The rest of this code assumes you are not using a library.
    // It can be made less verbose if you use one.
    const form = document.createElement('form');
    form.method = method;
    form.action = path;
    form.target = "_blank";
    for (const key in params) {
      if (params.hasOwnProperty(key)) {
        const hiddenField = document.createElement('input');
        hiddenField.type = 'hidden';
        hiddenField.name = key;
        if ((typeof params[key]) == 'object')
          hiddenField.value = JSON.stringify(params[key])
        else
          hiddenField.value = params[key]

        form.appendChild(hiddenField);
      }
    }
    document.body.appendChild(form);
    form.submit();

    $("#ozrView").show();
  }

  return <Banner
    title={'전자협약 상세'} loading={loading}
    summary={'사업계획서 접수가 완료된 과제의 협약을 진행하고 협약서를 조회 및 다운로드 받을 수 있습니다.'}>
    <div css={styles.container}>
      {
        data &&
        <Box className='content_body'>
          <div className="content">
            <Box css={styles.table}>
              <div className="detail_table">
                <dl>
                  <dt>협약상태</dt>
                  <dd className='blue'>{data.usptBsnsCnvn?.cnvnSttusNm}</dd>
                </dl>
              </div>
            </Box>
            <h4 className="tbl_title">협약서 정보</h4>
            <Box css={styles.table}>
              <div className="detail_table type2">
                <dl>
                  <dt>과제명</dt>
                  <dd>{data.usptBsnsCnvn?.taskNmKo}</dd>
                </dl>
                <dl>
                  <dt>협약일자</dt>
                  <dd>{data.usptBsnsCnvn?.cnvnDe?.replace(/(\d{4})(\d{2})(\d{2})/g, '$1-$2-$3') || ''}</dd>
                </dl>
                <dl>
                  <dt>협약기간</dt>
                  <dd>
                    {
                      data.usptBsnsCnvn?.cnvnBgnde && data.usptBsnsCnvn?.cnvnEndde ?
                        `${data.usptBsnsCnvn?.cnvnBgnde?.replace(/(\d{4})(\d{2})(\d{2})/g, '$1-$2-$3')} ~ ${data.usptBsnsCnvn?.cnvnEndde?.replace(/(\d{4})(\d{2})(\d{2})/g, '$1-$2-$3')}`
                        : ''
                    }
                  </dd>
                </dl>
                <dl className='horz'>
                  <dt>협약금액<span className='unit'>(단위:천원)</span></dt>
                  <dd>
                    <div className='tableDefault_scroll'>
                      <table className="tableDefault type5">
                        <colgroup>
                          <col/>
                          <col/>
                          <col/>
                          <col/>
                          <col/>
                          <col/>
                        </colgroup>
                        <thead>
                        <tr>
                          <th rowSpan={2}>사업연도</th>
                          <th rowSpan={2}>지원금</th>
                          <th colSpan={3}>민간부담금</th>
                          <th rowSpan={2}>합계</th>
                        </tr>
                        <tr>
                          <th>현금</th>
                          <th>현물</th>
                          <th>소계</th>
                        </tr>
                        </thead>
                        <tbody>
                        {
                          data.usptTaskReqstWct?.map((m: any, i: number) => {
                            return <tr key={i}>
                              <td className="tar">{m.bsnsYear}</td>
                              <td className="tar">{m.sportBudget.toLocaleString('ko-KR')}</td>
                              <td className="tar">{m.alotmCash.toLocaleString('ko-KR')}</td>
                              <td className="tar">{m.alotmActhng.toLocaleString('ko-KR')}</td>
                              <td className="tar">{m.alotmSum.toLocaleString('ko-KR')}</td>
                              <td className="tar">{m.alotmSumTot.toLocaleString('ko-KR')}</td>
                            </tr>
                          })
                        }
                        </tbody>
                      </table>
                    </div>
                  </dd>
                </dl>
                <dl className='horz'>
                  <dt>협약주체</dt>
                  <dd>
                    <div className='tableDefault_scroll'>
                      <table className="tableDefault type5">
                        <colgroup>
                          <col style={{width: '20%'}}/>
                          <col style={{width: '20%'}}/>
                          <col style={{width: '20%'}}/>
                          <col/>
                        </colgroup>
                        <thead>
                        <tr>
                          <th>기업명</th>
                          <th>대표자명</th>
                          <th>사업자등록번호</th>
                          <th>서명</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                          <td>{data.usptBsnsCnvn?.bsnsMgcNm}</td>
                          <td>{data.usptBsnsCnvn?.bsnsMgcCeoNm}</td>
                          <td>
                            {
                              data.usptBsnsCnvn?.bsnsMgcBizrno ?
                                data.usptBsnsCnvn?.bsnsMgcBizrno.replace(/(\d{3})(\d{2})(\d{5})/g, '$1-$2-$3') : ''
                            }
                          </td>
                          {
                            data.usptBsnsCnvn?.charBsnsMgcSignDt ?
                              <td className='blue'>{`서명완료 ${data.usptBsnsCnvn?.charBsnsMgcSignDt}`}</td> :
                              <td>{''}</td>
                          }
                        </tr>
                        <tr>
                          <td>{data.usptBsnsCnvn?.memberNm}</td>
                          <td>{data.usptBsnsCnvn?.ceoNm}</td>
                          <td>
                            {
                              data.usptBsnsCnvn?.bizrno ?
                                data.usptBsnsCnvn?.bizrno.replace(/(\d{3})(\d{2})(\d{5})/g, '$1-$2-$3') : ''
                            }
                          </td>
                          {
                            data.usptBsnsCnvn?.charBsnmSignDt ?
                              <td className='blue'>{`서명완료 ${data.usptBsnsCnvn?.charBsnmSignDt}`}</td> :
                              <td>{''}</td>
                          }
                        </tr>
                        </tbody>
                      </table>
                    </div>
                  </dd>
                </dl>
                <dl className='horz'>
                  <dt>참여기업</dt>
                  <dd>
                    <div className='tableDefault_scroll'>
                      <table className="tableDefault type5">
                        <colgroup>
                          <col style={{width: '20%'}}/>
                          <col style={{width: '20%'}}/>
                          <col style={{width: '20%'}}/>
                          <col/>
                        </colgroup>
                        <thead>
                        <tr>
                          <th>기업명</th>
                          <th>대표자명</th>
                          <th>사업자등록번호</th>
                          <th>서명</th>
                        </tr>
                        </thead>
                        <tbody>
                        {
                          data.usptBsnsCnvnPrtcmpnySign?.map((m: any, i: number) => {
                            return <tr key={i}>
                              <td>{m.memberNm}</td>
                              <td>{m.ceoNm}</td>
                              <td>{m.bizrno ? m.bizrno.replace(/(\d{3})(\d{2})(\d{5})/g, '$1-$2-$3') : ''}</td>
                              {
                                m.charBsnmSignDt ?
                                  <td
                                    className='blue'>{`서명완료 ${m.charBsnmSignDt.replace(/(\d{4})(\d{2})(\d{2})/g, '$1-$2-$3')}`}</td> :
                                  <td>{''}</td>
                              }
                            </tr>
                          })
                        }
                        </tbody>
                      </table>
                    </div>
                  </dd>
                </dl>
                <dl className='horz'>
                  <dt>협약서본문</dt>
                  <dd>{data.usptBsnsCnvn?.cnvnBdt}</dd>
                </dl>
              </div>
            </Box>
            {/*<Stack flexDirection={'row'} justifyContent={'space-between'} alignItems={'center'} className='tbl_title'>*/}
            {/*  <h4>첨부파일</h4>*/}
            {/*</Stack>*/}
            {/*<Stack css={styles.attatchedFile}>*/}
            {/*  {attachmentFileList2 ? attachmentFileList2.map((item: any) => (*/}
            {/*      <Stack css={comstyles.btnDown}>*/}
            {/*        <Button onClick={() => download("rslt-6f894bba44fb426c8a5327a44ef76bbe", item.attachmentId)}>*/}
            {/*          <span>{item.fileNm}</span>*/}
            {/*        </Button>*/}
            {/*      </Stack>*/}
            {/*    ))*/}
            {/*    : null}*/}
            {/*</Stack>*/}
            {
              data.usptBsnsCnvn && data.usptBsnsCnvn?.cnvnSttusCd == "CNST06" && <Fragment>
                <h4 className="tbl_title">해지정보</h4>
                <Box css={styles.table}>
                  <div className="detail_table">
                    <dl>
                      <dt>해지일</dt>
                      <dd>{data.usptBsnsCnvn?.cnvnTrmnatDe || ''}</dd>
                    </dl>
                    <dl>
                      <dt>해지사유</dt>
                      <dd>{data.usptBsnsCnvn?.cnvnTrmnatResnCn || ''}</dd>
                    </dl>
                  </div>
                </Box>
              </Fragment>
            }
            {
              data?.usptBsnsCnvn?.cnvnSttusCd == 'CNST03' &&
              <Stack direction="row" justifyContent="center" spacing={2} sx={{marginTop: '40px'}} css={styles.btn_next}>
                <CustomButton label={'서명'} type={'listBack'} color={'primary'} onClick={() => {
                  // addModal({
                  //   open: true,
                  //   content: '솔루션 연동중입니다.'
                  // })
                  doSignData()
                }}/>
              </Stack>
            }
            <Stack css={comstyles.btnDown} sx={{paddingTop: '36px', alignItems: 'center'}}>
              {/*<ModalReasonConfirm*/}
              {/*  applyId='lastsor-a4de44b79ccf42649b878ddc3a2d88a4'*/}
              {/*  viewNm='ElectronicAgtMgtDetail'*/}
              {/*  title='협약서 다운로드'*/}
              {/*  variant='outlined'*/}
              {/*  label='협약서 다운로드'*/}
              {/*  type='frontNomal'*/}
              {/*  color='outlined'*/}
              {/*/>*/}
              <CustomButton
                type={'frontNomal'}
                color={'outlinedgray'}
                label={'협약서 다운로드'}
                onClick={async () => {
                  const url = `https://portal.atops.or.kr/ozreport/testviewer.jsp`
                  if (data) {
                    console.log('data - ' + JSON.stringify(data))
                    if (data.usptBsnsCnvn.charBsnmSignDt && !data.usptBsnsCnvnPrtcmpnySign.flatMap((m: any) => m.charBsnmSignDt).includes(null)){
                      post(url, {
                        fileName: 'test',
                        ozrName: 'agreement.ozr',
                        jsonData: {
                          ...data,
                          usptBsnsCnvn: {
                            ...data.usptBsnsCnvn,
                            cnvnBdt: data.usptBsnsCnvn?.cnvnBdt?.replace("\n", '\\n') || '',
                            cnvnDe: data.usptBsnsCnvn?.cnvnDe? dayFormat(data.usptBsnsCnvn?.cnvnDe) : '',
                            cnvnBgnde: data.usptBsnsCnvn?.cnvnBgnde? dayFormat(data.usptBsnsCnvn?.cnvnBgnde) : '',
                            cnvnEndde: data.usptBsnsCnvn?.cnvnEndde? dayFormat(data.usptBsnsCnvn?.cnvnEndde) : '',
                            bsnsMgcBizrno: data.usptBsnsCnvn?.bsnsMgcBizrno?.replace(/(\d{3})(\d{2})(\d{5})/g, '$1-$2-$3') || '',
                            bizrno: data.usptBsnsCnvn?.bizrno?.replace(/(\d{3})(\d{2})(\d{5})/g, '$1-$2-$3') || ''
                          },
                          usptBsnsCnvnPrtcmpnySign: data.usptBsnsCnvnPrtcmpnySign.map((m:any) => {
                            return{
                              ...m,
                              bizrno: m?.bizrno?.replace(/(\d{3})(\d{2})(\d{5})/g, '$1-$2-$3') || ''
                            }})
                        }
                      })
                    } else {
                      addModal({
                        open: true,
                        content: '모든 기업의 서명을 완료해 주세요.'
                      })
                    }
                  }
                }}/>
            </Stack>
          </div>
        </Box>
      }

      <form name="reqForm">
        <input type="hidden" id='bizrno' name='bizrno'/>
        <input type="hidden" id="callback" name="callback"/>
      </form>
      <div id="pkiContainer">
        <iframe
          id="pki-frame" name="pki-frame" src="" scrolling="no" width="100%" height="100%" frameBorder="0"
          style={{
            position: 'fixed',
            zIndex: 100010,
            top: 0, left: 0,
            width: '100%', height: '100%'
          }}>
        </iframe>
      </div>

    </div>
  </Banner>
}

export default ElectronicAgtMgtDetail;