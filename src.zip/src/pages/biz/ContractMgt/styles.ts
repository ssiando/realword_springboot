import { css } from '@emotion/react';
export const container = css`
  padding-bottom: 120px;
  .content {
    position: relative;
    max-width: 1280px;
    width: 100%;
    margin: 0 auto;
  }
  .txtblue {
    color: #4063ec;
  }
  
  @media (min-width: 320px) and (max-width: 768px) {
    margin-top: 0;
    padding-bottom: 80px;
  }
`;

export const sub_cont02 = css`
  min-height: 840px;
  background-color: #fff;
  color: #333;
  .MuiTypography-h5 {
    height: auto;
    font-size: 28px;
    font-weight: 700;
    line-height: 1;
    letter-spacing: -1.12px;
    margin-bottom: 20px;
  }
  .MuiTypography-h6{
    font-size: 20px;
    letter-spacing: -0.8px;
    font-weight: 700;
    margin-top: 40px;
  }
  .md_btn {
    color: #333;
    border: 1px solid #333;
    width: 220px;
    height: 55px;
    border-radius: 0;
    margin-top: 10px;
  }
  .data {
    height: 24px;
    font-size: 16px;
    font-style: normal;
    line-height: 3;
    letter-spacing: -4px;
    margin-left: 10px;
    display: inline-block;
    > em {
      height: 19px;
      font-size: 16px;
      font-weight: 700;
      letter-spacing: -0.64px;
      color: #4063ec;
    }
  }
  .MuiSelect-select {
    padding: 8px 40px 8px 20px;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    min-height: auto;
    .MuiTypography-h5 {
      font-size: 22px;
      margin-bottom: 10px;
    }
    .MuiSelect-select {
      font-size: 14px;
    }
    .MuiTypography-h6{
      font-size: 18px;
      letter-spacing: -0.64px;
    }
  }
`;


export const inputBox = css`
  position: relative;
  display: flex;
  flex-direction: column;
  width:100%;
  .MuiTextField-root{
    &.scrollBox{
      .MuiOutlinedInput-root{
        padding: 6px;
        textarea{
          font-family: "Noto Sans CJK KR", "Roboto";
          padding: 9px;
        }
      }
    }
  }
  .count{
    margin-top: 8px;
    text-align: right;
    font-size: 14px;
    letter-spacing:normal;
    color: #666;
    font-weight: 300;
    line-height: normal;
    margin-right: -11px;
    em{
      font-style: normal;
    }
  }
  .inputtxt{
    font-family: Noto Sans CJK KR;
    font-size: 18px;
    margin-bottom: 10px;
    line-height: 1.67;
    letter-spacing: -0.72px;
    font-weight: 700;
    & em{
      color: #1ccdcc;
      margin-left: 4px;
    }
  }
  label{
    color: #222;
    &.Mui-focused {
      color: #222;
    }
  }
  .MuiOutlinedInput-root {
    color: #222;
    fieldset {
      border-color: #ccc;
    }
    &:hover{
      fieldset {
        border-color: #1976d2;
      }
    }
  }
  .MuiFormLabel-asterisk{
    color: #1CCDCC;
  }
  textarea{
    &::-webkit-scrollbar {
      width: 8px;
    }
    &::-webkit-scrollbar-thumb {
      background-color: #d7dae6;
      border-radius: 10px;
    }
    &::-webkit-scrollbar-track {
      background-color: #fff;
      border-radius: 10px;
    }
    > div {
      margin-bottom: 10px;
    }
    .MuiRadio-root {
      padding: 5px;
    }
    .MuiFormControlLabel-root{
      margin-right: 0;
      margin-bottom: 10px;
      padding-left: 5px;
    }
  }
  Button{
    margin: 0;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    label{
      font-size: 14px;
    }
    input {
      padding: 15px 14px;
    }
    .inputtxt{
      font-size: 16px;
    }
    .css-7gyhhp-MuiStack-root-deletTag>:not(style)+:not(style) {
        margin-left: 0;
    }
    .count{
      margin-top: 5px;
      font-size: 12px;
      margin-right: 0;
    }
  }
`;
export const modal_Box = css`
  width: 560px;
  padding: 30px 50px 0;
  .tit_text{
    text-align: center;
    letter-spacing: -0.64px;
    margin-bottom: 30px;
  }
  .modal_Card{
    border: 1px solid #e0e0e0;
    border-radius: 20px;
    padding: 32px 30px 30px;
    .tit{
      letter-spacing: -0.64px;
      font-weight: 700;
      margin-bottom: 20px;
      display: flex;
      align-items: center;
      &:before{
        content: '';
        display: inline-block;
        background: url('/images/common/icon_info.png') no-repeat;
        width: 24px;
        height: 24px;
        margin-right: 10px;
        background-size: 100%;
      }
    }
    > ul{
        li{
          font-size: 14px;
          letter-spacing: -0.56px;
          line-height: 1.86;
          margin-bottom: 6px;
          &:before{
            content: '';
            display: inline-block;
            width: 4px;
            height: 4px;
            margin: 5px 8px 4px 0;
            background-color: #707070;
            border-radius: 10px;
          }
        }
      }
  }
`;

export const btn_next = css`
  button{
    font-weight: normal !important;
    &+button{
      margin-left:20px;
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    button,a{
      font-size: 16px !important;
      width: 100% !important;
      height: 52px !important;
      min-width: 104px;
      &+button{
      margin-left:10px;
    }
    }
  }
  
`;

export const title_set = css`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin-top: 50px;
  @media (min-width: 320px) and (max-width: 768px) {
    flex-direction:column;
    .tbl_desc {margin-bottom:10px;}
  }
`;

export const table = css`
  max-width: 100%;
  letter-spacing: -0.64px;
  & .star{
    &:after{
      content:'*';
      display: inline-block;
      width: 5px;
      height: 5px;
      margin-left: 5px;
      margin-bottom: 15px;
      color: #1CCDCC;
    }
  }
  &:first-of-type{
    margin-top: 48px;
  }
  .tbl_title{
    margin: 40px 0 10px;
    &.mt20{
      margin-top: 20px;
    }
  }
  .delete_icon{
    margin-bottom: 5px;
  }
  .detailtab_02{
    .scrollTab {
      button{
        padding-bottom: 26px;
        color: #707070;
        font-size: 16px;
        letter-spacing: -0.64px;
        &.Mui-selected{
          color: #1f2437;
          font-weight: 700 !important;
        }
      }
    }
  }
  .detail_table{
    border-top: 1px solid #1f2437;
    margin-bottom: 40px;
    &.type2{
      dt{
        background-color: #fff;
      }
      dd{
        .MuiOutlinedInput-root,.MuiButton-root {margin:-15px 0;}
      }
    }
    &.type3{
      dt{min-height:60px;padding: 6px 20px;letter-spacing: -1.5px;}
      dd{min-height:60px;padding: 6px 20px;}
      .MuiFormControlLabel-root{
        margin-right:100px;
      }
    }
    @media (min-width: 320px) and (max-width: 768px) {
      dd{padding-left:20px;padding-right:20px;}
      &.tbl_01{
        dt {flex:0 0 59%;}
        dd {flex:0 0 40%;}
      }
    }
  }
  .tableDefault_scroll{width:100%;}
  .MuiInputBase-root{width:100%; min-height: 48px;}
  .MuiOutlinedInput-input {font-weight:400;font-size:16px;padding: 11.5px 14px; letter-spacing: -0.64px;}
  .MuiOutlinedInput-notchedOutline {
    border-radius: 5px;
    border-color: #ccc;
  }

  dl {
    display: flex;
    border-spacing: 0;
    width: 100%;
    min-height: 60px;
    &.noline{
      border-bottom: none;
    }
    dt {
      display: flex;
      align-items: center;
      flex: 0 0 220px;
      padding: 15px 20px;
      text-align: left;
      background-color: #f5f5f5;
      border-bottom: 1px solid #e0e0e0;
      font-weight: 500;
      &.wh{
        background-color: #fff;
      }
    }
    dd {
      flex: 1;
      display: flex;
      justify-content: space-between;
      padding: 6px 20px;
      line-height: 1.75;
      align-items: center;
      border-bottom: 1px solid #e0e0e0;
      margin-left: 0;
      font-weight: 400;
      &.address{
        flex-direction: column;
        align-items: flex-start;
        >div{
          width:100%;
        }
        .MuiOutlinedInput-root{
          /* width:90%; */
          
          &+.MuiOutlinedInput-root{
            margin-left: 0;
          }
        }
        .MuiOutlinedInput-input{height:48px;padding: 0 14px;}
      }
      &.radio_grup{
        .MuiFormControlLabel-root{
          margin-left: 0;
        }
        .MuiFormControlLabel-root{
          margin-right: 60px;
          &:last-of-type{
            margin-right: 0;
          }
        }
      }
      .regNum {width:38.5%;}
      .MuiButton-outlinedPrimary {width:auto !important;min-width:73px !important;}
      .tableDefault_scroll{margin: 14px 0;}
      .tableDefault{
        .MuiOutlinedInput-root{width:100%;}
      }
      .MuiOutlinedInput-root{margin-left:-12px; margin-right:-12px; width: calc(100% + 24px); min-height:49px;
        .MuiOutlinedInput-input{
          padding: 12.5px 14px;
        }
      }
      
    }
    .withLink{
      justify-content: flex-start;
      a {color:#4063ec;margin-left:10px;padding-right:15px;color:#4063ec;font-weight:400;background:url(/images/common/gt_blue.png) no-repeat right center;}
    }
  }
  @media (min-width: 320px) and (max-width: 768px) {
    .detailtab_02{
      .scrollTab {
        button{
          padding-bottom: 16px;
          font-size: 14px;
          letter-spacing: -0.56px;
        }
      }
    }
    .table_rowScroll{
      max-height: 510px;
      overflow-y: auto;
      overflow-x: hidden;
      min-width: 750px;
      &::-webkit-scrollbar {
        width: 8px;
      }
      &::-webkit-scrollbar-track {
        background-color: transparent;
      }
      &::-webkit-scrollbar-thumb {
        background-color: #d7dae6;
        border-radius: 10px;
      }
      &::-webkit-scrollbar-button {
        width: 0;
        height: 0;
      }
    }
    .tableDefault_scroll{
      padding-right: 0;
      .tableDefault{
        min-width: 750px;
      }
    }
    .MuiTypography-h6{
      font-size: 16px;
    }
    .detail_table{
      margin-bottom: 30px;
      .MuiOutlinedInput-root{min-height:48px}
      dd{padding-left:20px; padding-right:6px;}
    }
    .delete_icon{
      margin-bottom: 0;
      height: 43px;
    }
    .MuiFormControl-root{width:100%;}
    /* .MuiFormGroup-root{justify-content: space-around;}
    .MuiFormControlLabel-root{margin-right:0;} */
    dl {
      flex-wrap: wrap;
      font-size: 14px;
      min-height: 60px;
      dt {
        flex: 0 0 35%;
        line-height: 26px;
        padding: 16px 10px 16px 20px;
        word-break: keep-all;
      }
      dd {
        flex: 0 0 65%;
        padding: 6px 0 6px 6px;
        word-break: keep-all;
        &.address{
          .MuiButton-root {line-height:1;}
          >div{
            &:nth-of-type(2){
              flex-direction:column;
              .MuiOutlinedInput-root{
                width:100%;
                &:first-of-type{margin-bottom:10px;}
              }
            }
          }
        }
        .regNum {width:100%;}
        .MuiOutlinedInput-root{margin-left:-12px; width: calc(100% + 12px);}
        &.radio_grup{
          .MuiFormGroup-root{
            justify-content: flex-start;
          }
          .MuiFormControlLabel-root{
            margin-right: 20px;
          }
        }
      }
      &.horz{
        flex-direction: column;
        dt{
          border-bottom: 0;
          justify-content: center;
        }
        dd{
          padding:0 8px;
        }
      }
    }
    .type7{
      td{
        font-size: 14px;
      }
    }
    .type6{
      th{
        font-size: 14px;
        &.lfnoline{
          border-left: 0;
        }
      }
    }
    .type2{
      dl{
        &.horz{
          flex-wrap: nowrap;
          dt{
            justify-content: left;
            padding-bottom: 0;
          }
          dd{
            padding-bottom: 20px;
            .tableDefault_scroll{
            margin-right: -23px;
          }
          }
        }
      }
    }
  }
`;

export const fileupload = css`
  padding-bottom:40px;
  border-bottom:1px solid #e0e0e0;
  >div{
    justify-content: left;
    flex-wrap: wrap;
  }
`;


export const attatchedFile = css`
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  padding:24px 20px;
  background-color: #f5f5f5;
  border-radius: 10px;
  >div{
    &:first-of-type{padding-left:0;}
    padding-left:6px;
  }
  @media (min-width: 320px) and (max-width: 768px) {
    flex-direction: column;
    margin:0 -15px;
    padding:20px 15px;
    border-radius: 0;
    >div{
      padding-left:0;
      button{
        margin-top:10px;
      }
      &:first-of-type{
        button{margin-top:0;}
      }
    }
  }
`
export const selectBox = css`
  border:1px solid #e0e0e0;
  border-radius: 5px;
  padding:30px;
  .tbl_title {margin-bottom:10px;}
  .item1{
    width:18%;
  }
  .item2{
    width:66%;
    margin:0 1.6%;
  }
  .MuiButton-root{
    align-self: flex-end;
  }
  .MuiSelect-select {
    min-height: auto;
    font-family:'Noto Sans CJK KR','Roboto';
  }
  @media (min-width: 320px) and (max-width: 768px) {
    flex-direction: column;
    .item1{width:100%;}
    .item2{width:100%;margin:10px 0;}
    .MuiButton-root {align-self:center;max-width:75px;}
  }
`;