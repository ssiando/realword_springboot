import React, {Fragment, useEffect, useRef, useState} from 'react';
import * as styles from './styles';
import * as comstyles from '~/styles/styles';
import {Tabs, Tab, Stack, Box, Button} from '@mui/material';
import dayjs from 'dayjs';
import {useQuery} from 'react-query';
import {fetchMovinGet} from '~/fetches/fetchMoveIn';
import {useGlobalModalStore} from '~/pages/store/GlobalModalStore';
import {
  fetchCompanyResult,
  fetchPerformanceDetailGet, fetchPerformanceHistGet,
  fetchPerformanceSubmit,
  fetchRsltIdGet
} from '~/fetches/fetchPerformanceMgt';
import {resultList, rsltIdxIem, rsltIdxIemList} from '~/models/ModelPerformanceMgt';
import {FileUpload1} from '~/pages/EventNews/FileUpload';
import fetchDownload from '~/fetches/fetchDownload';
import {CustomSelect} from '~/components/SelectBoxComponents';
import {fetchBsnsYearList} from '~/fetches/fetchBusiness';
import {ModalComponents} from '~/components/ModalComponents';
import {useNavigate, useParams} from 'react-router-dom';
import {TableListType, TableNotStandardType, TableStandardType} from "~/pages/biz/TaskManagement/PerformanceMgtDetail";
import {Banner} from "~/components/Banner";
import NoData from "~/components/Loading/NoData";
import CompleteData from "~/components/Loading/CompleteData";

/*
  // 입주기업성과관리 -> 입주기업성과관리
*/
function TenantCompPerforMgt() {
  const {addModal} = useGlobalModalStore();
  const [year, setYear] = useState(dayjs(new Date()).format('YYYY').toString())
  const [month, setMonth] = useState(dayjs(new Date()).format('MM').toString())
  const [year2, setYear2] = useState(dayjs(new Date()).format('YYYY').toString())
  const [month2, setMonth2] = useState(dayjs(new Date()).format('MM').toString())
  const [monthList, setmonthList] = useState<{ code: string, codeNm: string }[]>([]);

  const [value, setValue] = useState(0);
  const [rsltId, setRsltId] = useState<string>('');
  const [open, setOpen] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate()
  //사용자입주현황조회
  const movin = useQuery("fetchMovinGet", async () => await fetchMovinGet(false), {
    onError: (e: any) => {
      addModal({
        open: true,
        content: '입주 이력이 없습니다.'
      })
      // setOpen(true);
      // setError(e.response.data.message)
      setLoading(false)
    }
  })
  useEffect(() => {
    if (!movin.isFetching && !movin.isLoading) {
      if (!!movin.data) {
        console.log('movin.data - ' + JSON.stringify(movin.data))
        getRsltId2()
        monthSetting();
      }
      setLoading(false)
    }
  }, [movin.data, movin.isLoading, movin.isFetching])

  const [bsns_box, setBsnsBox]: any = useState([]);
  const bsnsYearList = useQuery("getYearList", async () => await fetchBsnsYearList(), {
    onError: (e: any) => {
      addModal({
        open: true,
        content: '입주 이력이 없습니다.'
      })
      setLoading(false)
      // setOpen(true);
      // setError(e.response.data.message)
    }
  });

  useEffect(() => {
    if (!bsnsYearList.isLoading && !bsnsYearList.isFetching) {
      if (!!bsnsYearList.data) {
        const update: { code: any; codeNm: any; }[] = [];
        bsnsYearList.data.list.map((item: any) => {
          update.push({code: item, codeNm: item})
        })
        console.log('bsnsYearList - ' + JSON.stringify(update))
        setBsnsBox(update);
        monthSetting();
      }
      setLoading(false)
    }
  }, [bsnsYearList.data, bsnsYearList.isLoading, bsnsYearList.isFetching])

  useEffect(() => {
    if (!loading) window.scrollTo(0, 5)
  }, [value])

  //성과ID
  const getRsltId = () => {
    if (!!movin.data) {
      const data = {
        applyId: movin.data?.applyId,
        rsltYm: value == 0 ? year + month : year2 + month2,
      }
      console.log('req - ' + JSON.stringify(data))
      value == 0 ? setData(null) : setData2(null)
      fetchRsltIdGet(data).then((res: any) => {
        setRsltId(res.rsltId);
      });
    }
  }
  //제출이력조회용성과ID
  const getRsltId2 = () => {
    if (!!movin.data) {
      const data = {
        applyId: movin.data?.applyId,
        rsltYm: year2 + month2,
      }
    }
  }

  const [data, setData] = useState<resultList | null>(null);
  const [data2, setData2]: any = useState();
  const [files, setFiles]: any = useState([]);
  const [rsltIdxIemCnList, setRsltIdxIemCnList] = useState<rsltIdxIem[]>();
  const [attachmentFileList, setAttachmentFileList]: any = useState();
  const [rsltIdxIemCnList2, setRsltIdxIemCnList2] = useState<rsltIdxIem[]>();
  const [attachmentFileList2, setAttachmentFileList2]: any = useState();
  const [deleteAttachFileList, setDeleteAttachFileList]: any = useState([]);
  const [rsltIdxFileList, setRsltIdxFileList]: any = useState([]);
  const [rsltIdxFileList2, setRsltIdxFileList2]: any = useState([]);
  const [deleteAttachmentId, setDeleteAttachmentId] = useState<string>();
  const [histId, setHistId] = useState<string>('');
  const [fileList, setFileList] = useState<{ rsltIdxIemId: string, file: any }[]>([])
  const [loading, setLoading] = useState(true)
  const params = useParams();

  //성과제출데이터
  const getData = async () => {
    setLoading(true)
    if (rsltId) {
      try {
        await fetchPerformanceDetailGet(rsltId).then((res: any) => {
          console.log('res - ' + JSON.stringify(res))

          // list타입일경우 flag값을 U로 변경
          const update = {
            ...res,
            rsltIdxIemList: res.rsltIdxIemList.map((m: any) => {
              const isList = m.rsltIdxTypeCd == "LIST"
              return {
                ...m,
                rsltIdxIemCnList: isList ? m.rsltIdxIemCnList.map((n: any) => {
                  return {
                    ...n,
                    flag: 'U'
                  }
                }).sort((a: rsltIdxIem, b: rsltIdxIem) => {
                  return a.sortOrder - b.sortOrder
                }) : m.rsltIdxIemCnList
              }
            })
          }

          if (value == 0) {
            setData(update)
            setAttachmentFileList(res.attachFileList)
          } else if (value == 1 && update.rsltSttusCd == "RC") {
            setData2(update)
            setAttachmentFileList2(res.attachFileList)
          }
          // setAttachmentFileList(res.attachFileList);
          setRsltIdxIemCnList(res.rsltIdxIemList[0].rsltIdxIemCnList);

          if (res.rsltIdxIemList[0].prufFile) {
            setRsltIdxFileList([res.rsltIdxIemList[0].prufFile]);
          }
        })
        // await fetchPerformancePresentnGet(rsltId).then((res: any) => {
        //   setHistList(res.list);
        //   setHistId(res[0].rsltHistId);
        //   getData2(res.list[0].rsltHistId)
        // })
      } catch (e) {
        setLoading(false)
      }
    }

    setLoading(false)
  }

  //제출이력조회용 데이터
  const getData2 = (histId: string) => {
    if (histId.length > 0 && rsltId) {

      setLoading(true)
      fetchPerformanceHistGet(rsltId, histId).then((res: any) => {
        setData2({
          ...res,
          rsltIdxIemList: res.rsltIdxIemList.map((m: any) => {
            const isList = m.rsltIdxTypeCd == "LIST"
            return {
              ...m,
              rsltIdxIemCnList: isList ? m.rsltIdxIemCnList.sort((a: rsltIdxIem, b: rsltIdxIem) => {
                return a.sortOrder - b.sortOrder
              }) : m.rsltIdxIemCnList
            }
          })
        })

        setAttachmentFileList2(res.attachFileList);
        setRsltIdxIemCnList2(res.rsltIdxIemList[0]?.rsltIdxIemCnList)
        if (res.rsltIdxIemList[0]?.prufFile) {
          setRsltIdxFileList2([res.rsltIdxIemList[0]?.prufFile]);
        }

        setLoading(false)
      })
    }
  }

  useEffect(() => {
    getData();
  }, [rsltId, value])

  useEffect(() => {
    getRsltId()
  }, [movin.data, year, month, year2, month2])

  const monthSetting = () => {
    if (!!movin.data) {
      const today = new Date()
      const begin = new Date(movin.data?.mvnBeginDay.slice(0, 4), movin.data?.mvnBeginDay.slice(4, 6))
      const end = new Date(movin.data?.mvnEndDay.slice(0, 4), movin.data?.mvnEndDay.slice(4, 6))

      const y = value == 0 ? year : year2
      let st = Number(y) > begin.getFullYear() ? 1 : begin.getMonth()
      let ed = today.getMonth() + 1
      if (Number(y) > today.getFullYear()) {
        ed = 0
      } else if (Number(y) < today.getFullYear()) {
        ed = 12
      }
      let m = []
      for (; st <= ed; st++) {
        if (Number(y) <= end.getFullYear()) {
          if (Number(y) < end.getFullYear()) m.push(st)
          else if (end.getMonth() >= st) m.push(st)
        }
      }
      // const st = begin.getMonth()
      setmonthList(m.map(m => {
        return {
          code: m.toString().padStart(2, '0'),
          codeNm: m.toString().padStart(2, '0')
        }
      }))
    }

  }
  useEffect(monthSetting, [year, month, year2, month2, value])
  // useEffect(() => {
  //   getRsltId()
  // }, [movin.data, year2, month2])

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };
  const checkIemUnit = (item: string | null) => {
    if (item === "WON") {
      return "원"
    } else if (item === "PT") {
      return "%"
    } else if (item === "NM") {
      return "명"
    } else if (item === "CO") {
      return "개"
    } else if (item === "POINT") {
      return "점"
    } else if (item == "TEXT") {
      return ""
    }
  }

  //조회된 첨부파일 삭제
  const deleteAttach1 = (attachmentId: string, i: number) => {
    const update = [...deleteAttachFileList]
    update.push({
      attachmentId: attachmentId
    })
    setDeleteAttachFileList(update);
    const update1 = [...attachmentFileList]
    update1.splice(i, 1)
    setAttachmentFileList(update1);
  }

  //파일첨부 삭제
  const handleDelete = (i: number) => {
    const update = [...files]
    update.splice(i, 1)
    setFiles(update);
  };

  //파일첨부
  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    let upfile: any = e.target.files;
    const update = [...files]
    for (var i = 0; i < upfile.length; i++) {
      update.push(upfile[i]);
    }
    setFiles(update)
  }

  const submit = () => {
    try {
      const form = new FormData();
      if (data) {
        let a = 0;
        form.append("deleteAttachFileList", new Blob([JSON.stringify(deleteAttachFileList)], {type: "application/json"}));

        for (let i = 0; i < files.length; i++) {
          form.append("attachFileList", files[i])
        }

        fileList.map(m => form.append("rsltIdxFileList", m.file[0]))

        const infoList = data.rsltIdxIemList.map(m => {
          const attachfileIndx = fileList.flatMap(m => m.rsltIdxIemId).indexOf(m.rsltIdxIemId)
          return {
            rsltIdxIemId: m.rsltIdxIemId,
            rsltIdxIemCnList: m.rsltIdxIemCnList,
            attachFileOrder: attachfileIndx,
            deleteAttachmentId: deleteAttachmentId,
          }
        })

        form.append("infoList", new Blob([JSON.stringify(infoList)], {type: "application/json"}));
        fetchPerformanceSubmit(rsltId, form).then(() => {
          window.scrollTo(0, 10);
          if (movin.data?.mvnId) {
            fetchCompanyResult(rsltId, movin.data.mvnId, year + month)
          }
          getData()
          addModal({
            open: true,
            content: '제출이 완료되었습니다.'
          });
          // navigate('../biz/TaskManagement/PerformanceMgt')
          // getData();
          // getData2();
        }).catch((e: { response: { data: { message: any; }; }; }) => {
          addModal({
            open: true,
            content: e.response.data.message
          });
        })
      }
    } catch (e: any) {
      if (!!e.response && e.response.data) return alert(e.response.data.message);
    }
  }

  //다운로드
  const download = async (attachmentId: string) => {
    fetchDownload(`${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/rslt/${rsltId}/hist/atchmnfl/${attachmentId}?rsltHistId=${histId}`)
      .then()
      .catch((e) => {
        let status = e.response.status;

        if (status === 400) {
          addModal({
            open: true,
            content: "파일이 없습니다."
          })
        }
      });
  }

  const downloadAll = async (rsltId: string) => {
    fetchDownload(`${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/rslt/${rsltId}/hist/atchmnfl?rsltHistId=${histId}`)
      .then()
      .catch((e) => {
        let status = e.response.status;

        if (status === 400) {
          addModal({
            open: true,
            content: "파일이 없습니다."
          })
        }
      });
  }

  return <Banner
    title={'입주성과 상세'} loading={loading}
    summary={'입주성과를 제출하고 이력을 조회할 수 있습니다.'}
    tabContent={
      <Tabs value={value} variant="scrollable"
            scrollButtons="auto" onChange={handleChange}>
        <Tab label="제출" {...a11yProps(0)} />
        <Tab label="제출이력" {...a11yProps(1)} />
      </Tabs>
    }>
    <div css={comstyles.container}>
      <ModalComponents open={open} type={'normal'} content={error}
                       onConfirm={() => {
                         setOpen(false);
                         navigate(-1);
                       }}
                       onClose={() => {
                         setOpen(false);
                         navigate(-1);
                       }}>
      </ModalComponents>
      <Box>
        <div className='content_body'>
          <div className="content">
            <div className="ai_startup">
              <TabPanel value={value} index={0}>
                <h4 className="tbl_title">제출년월</h4>
                <Box css={styles.table}>
                  <div className="detail_table">
                    <dl>
                      <dt>제출년월</dt>
                      <dd>
                        <div className='select_set'>
                          <CustomSelect
                            value={year}
                            data={bsns_box ? bsns_box : []}
                            onClick={(selected) => {
                              setYear(selected)
                            }}/>
                          <CustomSelect
                            value={month}
                            data={monthList}
                            onClick={(selected) => {
                              setMonth(selected)
                            }}/>
                        </div>
                      </dd>
                      <dt>상태</dt>
                      <dd>{data?.rsltSttus || ''}</dd>
                    </dl>
                  </div>
                </Box>
                {
                  data && !loading && data.rsltSttusCd != 'RC' ? <Fragment>
                      {
                        data.rsltIdxIemList.map((m: rsltIdxIemList, index: number) => {
                          const itemNm = m.rsltIdxIemCnList.flatMap(m => m.stdIemNm)
                            .reduce((ac: string[], v: string) => ac.includes(v) ? ac : [...ac, v], [])
                          const detailIemNm = m.rsltIdxIemCnList.flatMap(m => m.detailIemNm)
                            .reduce((ac: string[], v: string) => ac.includes(v) ? ac : [...ac, v], [])

                          // 목록형 여부
                          const isStandard = itemNm.filter(f => f != null).length > 0

                          if (m.rsltIdxTypeCd == "LIST") {
                            return <TableListType
                              data={m}
                              stdIemNm={itemNm}
                              detailIemNm={detailIemNm}
                              checkIemUnit={checkIemUnit}
                              onUpdateFiles={(id: string, file: any) => {
                                if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                                if (!!file) {
                                  if (fileList.flatMap(m => m.rsltIdxIemId).includes(id)) {
                                    setFileList(fileList.map(m => {
                                      const update = m.rsltIdxIemId == id ? file : m.file
                                      return {
                                        ...m,
                                        file: update
                                      }
                                    }))
                                  } else {
                                    setFileList(fileList.concat({rsltIdxIemId: id, file: file}))
                                  }
                                } else {
                                  setFileList(fileList.filter(f => f.rsltIdxIemId != id))
                                }
                              }}
                              onDeletePreufFile={(attachmentFileId: string) => {
                                if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                                setDeleteAttachmentId(attachmentFileId);
                              }}
                              onRemoveRow={(removeRow: number[]) => {
                                if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                                const update = m.rsltIdxIemCnList.filter((f) => !removeRow.includes(f.sortOrder - 1))
                                const deleteItem = m.rsltIdxIemCnList.filter(f => removeRow.includes(f.sortOrder - 1) && f.flag == 'U').map(m => {
                                  return {
                                    ...m,
                                    sortOrder: -1,
                                    flag: 'D'
                                  }
                                })

                                const newItem = [...data?.rsltIdxIemList]
                                newItem[index] = {
                                  ...newItem[index],
                                  rsltIdxIemCnList: [...update, ...deleteItem]
                                }

                                setData({
                                  ...data,
                                  rsltIdxIemList: newItem
                                })
                              }}
                              onAddRow={() => {
                                if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                                const addRow = detailIemNm.map((detailNm) => {
                                  const count = m.rsltIdxIemCnList.flatMap(m => m.sortOrder).sort((a, b) => {
                                    return b - a
                                  }).shift() || -1
                                  // const totalRow = m.rsltIdxIemCnList.filter(f => f.flag != 'D')
                                  //   .filter(f => f.detailIemNm == detailIemNm.at(0)).length
                                  const item = m.rsltIdxIemCnList.find(f => f.detailIemNm == detailNm)
                                  return {
                                    rsltIdxIemCnId: '',
                                    rsltIdxDetailIemId: item?.rsltIdxDetailIemId || '',
                                    detailIemNm: detailNm,
                                    iemUnitCd: item?.iemUnitCd || '',
                                    rsltIdxIemCn: '',
                                    rsltIdxStdIemId: '',
                                    stdIemNm: '',
                                    sortOrder: count + 1,
                                    flag: 'I'
                                  }
                                })
                                const update = m.rsltIdxIemCnList.concat(addRow).sort((a, b) => {
                                  return a.sortOrder - b.sortOrder
                                });

                                const newItem = [...data?.rsltIdxIemList]
                                newItem[index] = {
                                  ...newItem[index],
                                  rsltIdxIemCnList: update
                                }

                                setData({
                                  ...data,
                                  rsltIdxIemList: newItem
                                })
                              }}
                              onChange={(e: any, i: number) => {
                                if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                                if (m.rsltIdxIemCnList) {
                                  const update = [...m.rsltIdxIemCnList.filter(f => f.flag != 'D')];
                                  update[i] = {
                                    ...update[i],
                                    [e.currentTarget.name]: e.currentTarget.value
                                  }

                                  const newItem = [...data?.rsltIdxIemList]
                                  newItem[index] = {
                                    ...newItem[index],
                                    rsltIdxIemCnList: [...update, ...m.rsltIdxIemCnList.filter(f => f.flag == 'D')]
                                  }

                                  setData({
                                    ...data,
                                    rsltIdxIemList: newItem
                                  })
                                }
                              }}
                            />
                          }

                          if (isStandard) {
                            return <TableStandardType
                              data={m}
                              stdIemNm={itemNm}
                              detailIemNm={detailIemNm}
                              checkIemUnit={checkIemUnit}
                              onUpdateFiles={(id: string, file: any) => {
                                if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                                if (!!file) {
                                  if (fileList.flatMap(m => m.rsltIdxIemId).includes(id)) {
                                    setFileList(fileList.map(m => {
                                      const update = m.rsltIdxIemId == id ? file : m.file
                                      return {
                                        ...m,
                                        file: update
                                      }
                                    }))
                                  } else {
                                    setFileList(fileList.concat({rsltIdxIemId: id, file: file}))
                                  }
                                } else {
                                  setFileList(fileList.filter(f => f.rsltIdxIemId != id))
                                }
                              }}
                              onDeletePreufFile={(attachmentFileId: string) => {
                                if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                                setDeleteAttachmentId(attachmentFileId);
                              }}
                              onChange={(e: any, i: number) => {
                                if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                                if (m.rsltIdxIemCnList) {
                                  const update = [...m.rsltIdxIemCnList];
                                  update[i] = {
                                    ...update[i],
                                    [e.currentTarget.name]: e.currentTarget.value
                                  }

                                  const newItem = [...data?.rsltIdxIemList]
                                  newItem[index] = {
                                    ...newItem[index],
                                    rsltIdxIemCnList: update
                                  }

                                  setData({
                                    ...data,
                                    rsltIdxIemList: newItem
                                  })
                                }
                              }}
                            />
                          } else {
                            return <TableNotStandardType
                              data={m}
                              checkIemUnit={checkIemUnit}
                              onUpdateFiles={(id: string, file: any) => {
                                if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                                if (!!file) {
                                  if (fileList.flatMap(m => m.rsltIdxIemId).includes(id)) {
                                    setFileList(fileList.map(m => {
                                      const update = m.rsltIdxIemId == id ? file : m.file
                                      return {
                                        ...m,
                                        file: update
                                      }
                                    }))
                                  } else {
                                    setFileList(fileList.concat({rsltIdxIemId: id, file: file}))
                                  }
                                } else {
                                  setFileList(fileList.filter(f => f.rsltIdxIemId != id))
                                }
                              }}
                              onDeletePreufFile={(attachmentFileId: string) => {
                                if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                                setDeleteAttachmentId(attachmentFileId);
                              }}
                              onChange={(e: any, id: string) => {
                                if (data.rsltSttusCd != 'SR' && data.rsltSttusCd != 'PR') return
                                if (m.rsltIdxIemCnList) {
                                  const update = m.rsltIdxIemCnList.map((item: rsltIdxIem) => {
                                    if (item.rsltIdxIemCnId === id) {
                                      return {
                                        ...item,
                                        [e.currentTarget.name]: e.currentTarget.value
                                      }
                                    }
                                    return item
                                  })
                                  const newItem = [...data?.rsltIdxIemList]
                                  newItem[index] = {
                                    ...newItem[index],
                                    rsltIdxIemCnList: update
                                  }

                                  setData({
                                    ...data,
                                    rsltIdxIemList: newItem
                                  })
                                }
                              }}
                            />
                          }
                        })
                      }
                      <h4 className='tbl_title' style={{marginTop: '40px'}}>파일첨부</h4>
                      <Box css={styles.fileupload}>
                        <FileUpload1
                          keyValue={'attachment'}
                          files={files}
                          handleDelete={handleDelete}
                          handleUpload={handleUpload}
                          files1={attachmentFileList}
                          handleDelete2={deleteAttach1}
                        />
                      </Box>
                      {
                        data && (data.rsltSttusCd == 'SR' || data.rsltSttusCd == 'PR') &&
                        <Stack spacing={2} direction="row" justifyContent="center" css={styles.signbtn}>
                          <Button fullWidth variant="contained" type="button" className="primary" onClick={submit}>
                            {data.rsltSttusCd == 'PR' ? '제출' : '수정'}
                          </Button>
                        </Stack>
                      }
                    </Fragment>
                    : data && data.rsltSttusCd == 'RC' ? <CompleteData message={'입주 성과 제출를 완료했습니다.'}/> :
                      <NoData message={'입주 성과 이력이 없습니다.'}/>
                }

              </TabPanel>

              <TabPanel value={value} index={1}>
                <h4 className="tbl_title">제출년월</h4>
                <Box css={styles.table}>
                  <div className="detail_table">
                    <dl>
                      <dt>제출년월</dt>
                      <dd>
                        <div className='select_set'>
                          <CustomSelect
                            value={year2}
                            data={bsns_box ? bsns_box : []}
                            onClick={(selected) => {
                              setYear2(selected)
                            }}/>
                          <CustomSelect
                            value={month2}
                            data={monthList}
                            onClick={(selected) => {
                              setMonth2(selected)
                            }}/>
                        </div>
                      </dd>
                      <dt>상태</dt>
                      <dd>{data2?.rsltSttus || ''}</dd>
                    </dl>
                  </div>
                </Box>
                {/*<Stack css={styles.submission_date}>*/}
                {/*  <div className='tit'>제출일</div>*/}
                {/*  <div >*/}
                {/*    <CustomSelectSubmitDay*/}
                {/*      value={histId ? histId : ''}*/}
                {/*      data={histList}*/}
                {/*      onClick={(selected) => {*/}
                {/*        setHistId(selected)*/}
                {/*        getData2(selected)*/}
                {/*      }}*/}
                {/*    />*/}
                {/*    /!*<CustomButton type={'modalBtn'} label={'선택'} onClick={() => getData2(histId)}/>*!/*/}
                {/*  </div>*/}
                {/*</Stack>*/}
                {
                  data2 ? <Fragment>
                    {
                      data2.rsltIdxIemList.map((m: rsltIdxIemList, index: number) => {
                        const itemNm = m.rsltIdxIemCnList.flatMap(m => m.stdIemNm)
                          .reduce((ac: string[], v: string) => ac.includes(v) ? ac : [...ac, v], [])
                        const detailIemNm = m.rsltIdxIemCnList.flatMap(m => m.detailIemNm)
                          .reduce((ac: string[], v: string) => ac.includes(v) ? ac : [...ac, v], [])

                        // 목록형 여부
                        const isStandard = itemNm.filter(f => f != null).length > 0

                        if (m.rsltIdxTypeCd == "LIST") {
                          return <TableListType
                            isHistory data={m}
                            stdIemNm={itemNm}
                            detailIemNm={detailIemNm}
                            checkIemUnit={checkIemUnit}
                            onDownload={download}
                          />
                        }

                        if (isStandard) {
                          return <TableStandardType
                            isHistory data={m}
                            stdIemNm={itemNm}
                            detailIemNm={detailIemNm}
                            checkIemUnit={checkIemUnit}
                            onDownload={download}
                          />
                        } else {
                          return <TableNotStandardType
                            isHistory data={m}
                            checkIemUnit={checkIemUnit}
                            onDownload={download}
                          />
                        }
                      })
                    }
                    <Stack flexDirection={'row'} justifyContent={'space-between'} alignItems={'center'}
                           className='tbl_title'
                           sx={{marginBottom: '10px'}}>
                      <h4>파일첨부</h4>
                      {!(Array.isArray(attachmentFileList2) && attachmentFileList2.length === 0) ?
                        <Stack css={styles.btnDown}>
                          <Button onClick={() => downloadAll(rsltId)}>
                            <span>일괄다운로드</span>
                          </Button>
                        </Stack>
                        : null}
                    </Stack>
                    <Stack css={styles.attatchedFile}>
                      <Stack css={styles.btnDown}>
                        {!(Array.isArray(attachmentFileList2) && attachmentFileList2.length === 0) ?
                          attachmentFileList2?.map((item: any, i: number) => (
                            <Button key={i} onClick={() => download(item.attachmentId)}>
                              <span>{item.fileNm}</span>
                            </Button>
                          ))
                          : "첨부파일 없습니다."}
                      </Stack>
                    </Stack>
                  </Fragment> : <NoData message={'입주 성과 제출이력이 없습니다.'}/>
                }
              </TabPanel>
            </div>
          </div>
        </div>
      </Box>
    </div>
  </Banner>
}

export default TenantCompPerforMgt;


interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const {children, value, index, ...other} = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{p: 3}}>
          {children}
        </Box>
      )}
    </div>
  );
}

function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

export const inputPriceFormat = (str: any) => {
  const comma = (str: any) => {
    str = String(str);
    return str.replace(/(\d)(?=(?:\d{3})+(?!\d))/g, "$1,");
  };
  const uncomma = (str: any) => {
    str = String(str);
    return str.replace(/[^\d]+/g, "");
  };
  return comma(uncomma(str));
};

export const uncomma2 = (str: any) => {
  str = String(str);
  return str.replace(/[^\d]+/g, "");
};