// 입주현황관리 -> 입주현황관리
// import React from "react"
import React, {Fragment, useEffect, useRef, useState} from 'react';
import * as styles from './styles';
import BreadCrumb from '~/components/BreadCrumb';
import {Tabs, Tab, Stack, Box, Link, TextField} from '@mui/material';
import {CustomButton, FileUpload} from "shared/components/ButtonComponents";
import {questsType} from '~/fetches/fetchQnaQuest';
import dayjs from 'dayjs';
import DatePicker from '~/components/DatePicker';
// import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import {useQuery} from "react-query";
import {
  fetchCheckOut,
  fetchCheckOutDetailGet, fetchExtendAttachDelete,
  fetchExtendAttachmentListGet,
  fetchExtendDetailGet,
  fetchExtendModifyState,
  fetchMovinExtend,
  fetchMovinExtendModify,
  fetchMovinGet,
  fetchMovinModifyState
} from '~/fetches/fetchMoveIn';
import {useGlobalModalStore} from '~/pages/store/GlobalModalStore';
import {FileUpload1} from '~/pages/EventNews/FileUpload';
import {fetchCheckOutModify} from "./../../../fetches/fetchMoveIn";
import {ModalComponents} from '~/components/ModalComponents';
import {CustomLoadingButton} from "~/components/ButtonComponents";
import {BennerCont} from "~/styles/styledConst";
import {useScrollStore} from "shared/store/ScrollStore";
import {Banner} from "~/components/Banner";
import NoData from "~/components/Loading/NoData";

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const {children, value, index, ...other} = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{p: 3}}>
          {children}
        </Box>
      )}
    </div>
  );
}

function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

function MoveInStatusMgt() {
  const [open, setOpen] = useState(false);
  const [error, setError] = useState("");
  const {addModal} = useGlobalModalStore();
  const today = new Date();
  const [value, setValue] = useState(0);
  const [files, setFiles] = useState<any>([]);
  const [changeNumber, setChangeNumber] = useState(0);
  const [extendData, setExtendData] = useState<any>();
  const [checkOutData, setCheckOutData]: any = useState();
  const [deleteAttach, setDeleteAttach] = useState<any[]>([]);
  const [attachmentFileList, setAttachmentFileList]: any = useState([]);
  const [loading, setLoading] = useState(true)

  const [additionApply, setAdditionApply] = useState(false)

  const getExtendDetail = async (mvnId: string) => {
    let mvnEtReqId = ''
    //사용자 입주연장신청 조회
    await fetchExtendDetailGet(mvnId).then((item) => {
      console.log('연장 - ' + JSON.stringify(item))
      if (!!item) {
        console.log('set')
        setExtendData(item);
        mvnEtReqId = item.mvnEtReqId
      } else {
        setExtendData({
          mvnEtReqSt: "",
          mvnEtReqCn: "",
          mvnEtEndDay: userMovein.mvnEndDay
        })
      }
    })

    if (mvnEtReqId != '') {
      await fetchExtendAttachmentListGet(mvnEtReqId).then((List: any) => {
        setFiles([])
        setAttachmentFileList(List.list)
      })
    }
  }

  const getCheckOutDetail = async (mvnId: string) => {
    await fetchCheckOutDetailGet(mvnId).then((item) => {
      console.log('퇴실 - ' + JSON.stringify(item))
      if (!!item) {
        setCheckOutData(item)
      } else {
        setCheckOutData({
          checkoutReqSt: "",
          checkoutReqStNm: "",
          makeupReqCn: ""
        })
      }
    })
  }
  //사용자 입주현황 상세조회
  const {data: userMovein, refetch: reUserMoveIn, isFetching, isLoading} = useQuery("fetchMovinGet1",
    async () => await fetchMovinGet(false), {
      onError: (e: any) => {
        setOpen(true);
        setError(e.response.data.message)
        setLoading(false)
      }
    });

  useEffect(() => {
    if (!isLoading && !isFetching) {
      if (!!userMovein) {
        // setMvnEtReq({mvnEtReqCn: "", mvnEtEndDay: userMovein.mvnEndDay})
        // setCheckOutInput({...checkOutInput, mvnId: userMovein.mvnId})
        console.log('userMovein - ' + JSON.stringify(userMovein))
        getExtendDetail(userMovein.mvnId)
        getCheckOutDetail(userMovein.mvnId)
      }
      setLoading(false)
    }
  }, [userMovein, isLoading, isFetching])

  useEffect(() => {
    if (!isLoading) window.scrollTo(0, 5)
  }, [value])

  //연장신청
  const moveExtend = async (event: any) => {
    // if(!validate()){
    //   return;
    // };
    try {
      const form = new FormData();
      form.append("mvnEtReq", new Blob([JSON.stringify({
        mvnEtEndDay: extendData.mvnEtEndDay,
        mvnEtReqCn: extendData.mvnEtReqCn
      })], {type: "application/json"}));

      console.log('files - ', files)
      for (let i = 0; i < files.length; i++) {
        form.append("attachments", files[i])
      }

      if (extendData.mvnEtReqStNm === "보완" || extendData.mvnEtReqStNm === "취소") {
        if (deleteAttach.length > 0 && extendData.mvnEtReqId) {
          await Promise.all(deleteAttach.map(m => {
            return fetchExtendAttachDelete(extendData.mvnEtReqId, m.attachmentId)
          }))

          setDeleteAttach([])
        }

        await fetchMovinExtendModify(userMovein.mvnId, extendData.mvnEtReqId, form).then().catch((e) => {
          setOpen(true);
          setError(e.response.data.message)
        })
      } else {
        await fetchMovinExtend(userMovein.mvnId, form).then().catch((e) => {
          setOpen(true);
          setError(e.response.data.message)
        })
      }
      setAdditionApply(false)

    } catch (e: any) {
      if (!!e.response && e.response.data) return alert(e.response.data.message);
    } finally {
      // reUserMoveIn();

      await getExtendDetail(userMovein.mvnId)
    }
  }
  //퇴실신청
  const checkOut = async () => {
    if (checkOutData.checkoutReqStNm === "신청취소") {
      const params = {
        checkoutReqId: checkOutData.checkoutReqId,
        checkoutPlanDay: checkOutData.checkoutPlanDay,
        checkoutReason: checkOutData.checkoutReason
      }
      await fetchCheckOutModify(params).then(() => {
        // reUserMoveIn();
      }).catch((e) => {
        setOpen(true);
        setError(e.response.data.message)
      })
    } else {
      await fetchCheckOut({
        mvnId: checkOutData.mvnId,
        checkoutPlanDay: checkOutData.checkoutPlanDay,
        checkoutReason: checkOutData.checkoutReason,
      }).then(() => {
        // reUserMoveIn();
      }).catch((e) => {
        setOpen(true);
        setError(e.response.data.message)
      })
    }

    await getCheckOutDetail(userMovein.mvnId)
  }

  //연장신청취소
  const extendCut = async () => {
    const param = {
      mvnEtReqId: extendData.mvnEtReqId,
      mvnEtReqSt: "RTRCN"
    }
    await fetchExtendModifyState(param).then(() => {
      // reUserMoveIn();
    })
    await getExtendDetail(userMovein.mvnId)
  }
  //퇴실신청취소
  const checkoutCut = async () => {
    const param = {
      checkoutReqId: checkOutData.checkoutReqId,
      checkoutReqSt: "RTRCN"
    }
    await fetchMovinModifyState(param).then(() => {
      // reUserMoveIn();
    })

    await getCheckOutDetail(userMovein.mvnId)
  }
  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };

  const handleDelete = (i: number) => {
    if (extendData?.mvnEtReqSt == 'RCPT' || extendData?.mvnEtReqSt == 'APLY') return
    files.splice(i, 1)
    setFiles(files);
    setChangeNumber(changeNumber + 1);
  };

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (extendData?.mvnEtReqSt == 'RCPT' || extendData?.mvnEtReqSt == 'APLY') return
    let upfile: any = e.target.files;
    const update = [...files]
    for (var i = 0; i < upfile.length; i++) {
      update.push(upfile[i]);
    }
    setFiles(update)
    setChangeNumber(changeNumber + 1);
  }

  const handleDelete2 = (attachmentId: string, i: number) => {
    if (extendData?.mvnEtReqSt == 'RCPT' || extendData?.mvnEtReqSt == 'APLY') return
    const update = [...deleteAttach]
    update.push({
      attachmentId: attachmentId
    })
    setDeleteAttach(update);
    const update1 = [...attachmentFileList]
    update1.splice(i, 1)
    setAttachmentFileList(update1);
  }

  const extendButtonLabel = () => {
    if (extendData) {
      switch (extendData.mvnEtReqStNm) {
        case "신청":
          return '연장신청'
        case "보완":
        case "취소":
          return "수정"
        case "연장반려":
        case "연장승인":
          return "추가신청"
      }
    }
    return '연장신청';
  }

  return <Banner
    title={'입주현황 관리'} loading={loading}
    summary={<p>현재 입주하고 있는 입주실 정보를 확인하고<br className='mo'/> 기간연장 및 퇴실처리할 수 있습니다.</p>}
    tabContent={<Tabs value={value} onChange={handleChange} variant="scrollable" scrollButtons="auto"
                      aria-label="basic tabs example">
      <Tab label="입주현황" {...a11yProps(0)} />
      <Tab label="연장신청" {...a11yProps(1)} />
      <Tab label="퇴실신청" {...a11yProps(2)} />
    </Tabs>}>
    <div css={styles.container}>
      <ModalComponents open={open} type={'normal'} content={error}
                       onConfirm={() => {
                         setOpen(false)
                       }}
                       onClose={() => {
                         setOpen(false)
                       }}>
      </ModalComponents>
      <Box className='content_body'>
        <div className="content">
          <div className="ai_startup">
            <TabPanel value={value} index={0}>
              {userMovein ? <Fragment>
                  <h4 className="tbl_title">입주현황</h4>
                  <Box css={styles.table}>

                    <div className="detail_table">
                      <dl>
                        <dt>입주상태</dt>
                        <dd>{userMovein.mvnStNm}</dd>
                        <dt>입주호실</dt>
                        <dd>{userMovein.bnoNm + " " + userMovein.roomNo}</dd>
                      </dl>
                      <dl>
                        <dt>입주일</dt>
                        <dd>{userMovein.fmtMvnBeginDay}</dd>
                        <dt>입주종료일</dt>
                        <dd>{userMovein.fmtMvnEndDay}</dd>
                      </dl>
                      <dl>
                        <dt>입주연장여부</dt>
                        <dd>{userMovein.mvnEtNum ? userMovein.mvnEtNum + "회연장" : 0 + "회연장"}</dd>
                      </dl>
                    </div>
                  </Box>
                  <Stack direction="row" justifyContent="center" spacing={2} sx={{marginTop: '40px'}}
                         css={styles.btn_next}>
                    <CustomButton label={'연장신청'} type={'listBack'} color={'outlined'} onClick={() => setValue(1)}/>
                    <CustomButton label={'퇴실신청'} type={'listBack'} color={'primary'} onClick={() => setValue(2)}/>
                  </Stack>
                </Fragment>
                : <NoData message={'입주 정보가 없습니다.'}/>
              }
            </TabPanel>
            <TabPanel value={value} index={1}>
              {extendData ?
                <Fragment>
                  <h4 className="tbl_title none"></h4>
                  <Box className="box_guide">
                    <ul>
                      <li>입주연장은 최대 3년까지 가능합니다.</li>
                      <li>연장신청 시 내용 검토 후 1차 접수처리가 진행되며, ‘접수완료’가 되면 연장평가를 통해 최종 승인여부를 결정합니다.</li>
                      <li><span className="must">*</span> 표시는 필수입력 항목입니다.</li>
                    </ul>
                  </Box>
                  {
                    extendData.mvnEtReqSt != '' && <Box css={styles.table} sx={{marginTop: '40px'}}>
                      <div className="detail_table status">
                        <dl>
                          <dt>상태</dt>
                          <dd className="withLink">
                            <Stack direction='row' justifyContent={'space-between'} sx={{width: '100%'}}
                                   alignItems={'center'}>
                              <div>
                                {extendData.mvnEtReqStNm}
                                {
                                  (extendData.mvnEtReqStNm == "보완") &&
                                  <Link underline="hover" className="home" key="1" color="inherit"
                                        onClick={() => {
                                          setError(extendData.makeupReqCn)
                                          setOpen(true)
                                        }}>사유확인</Link>
                                }
                              </div>
                              {
                                extendData.mvnEtReqStNm === "신청" ?
                                  <CustomLoadingButton label={'신청취소'} type={'modalBtn2'} color={'outlined'}
                                                       onClick={extendCut}/>
                                  : null
                              }
                            </Stack>
                          </dd>
                        </dl>
                      </div>
                    </Box>
                  }
                  {
                    additionApply && <h3 className='tbl_title type2'>추가신청</h3>
                  }

                  <h4 className="tbl_title type2">연장기간 <span className='must'>*</span></h4>
                  <div className='datepicker' style={{display: 'inline-block'}}>
                    <DatePicker
                      pickerType='two'
                      questBeginDay={userMovein ? dayjs(userMovein.mvnBeginDay, 'YYYYMMDD').toString() : dayjs(new Date(), 'YYYYMMDD').toString()}
                      questBeginDisable
                      questEndDay={extendData ? dayjs(extendData.mvnEtEndDay, 'YYYYMMDD').toString() : dayjs(userMovein.mvnEndDay, 'YYYYMMDD').toString()}
                      questEndDisable={extendData ? (extendData.mvnEtReqSt == 'RCPT' || extendData.mvnEtReqSt == 'APLY' || extendData.mvnEtReqSt == 'APRV') : false}
                      changeEnd={(endNewTime: Date | null) => {
                        setExtendData({
                          ...extendData,
                          mvnEtEndDay: dayjs(endNewTime).format('YYYYMMDD').toString()
                        })
                      }}
                    />
                  </div>
                  <h4 className='tbl_title type2'>신청내용 <span className='must'>*</span></h4>
                  <Box css={styles.textfieldBox}>
                    <TextField
                      id="outlined-multiline-static"
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                        if (extendData.mvnEtReqSt == 'RCPT' || extendData.mvnEtReqSt == 'APLY' || extendData.mvnEtReqSt == 'APRV') return
                        const {name, value} = e.currentTarget;
                        setExtendData((state: any) => ({...state, [name]: value}));
                      }}
                      name="mvnEtReqCn"
                      value={extendData?.mvnEtReqCn}
                      multiline rows={4}
                      className="scrollBox"
                      inputProps={{
                        maxLength: 1000,
                      }}
                    />
                    <div className='tf_count'>{extendData?.mvnEtReqCn?.length}/1000</div>
                  </Box>
                  {
                    extendData?.mvnEtReqStNm == "연장승인" ? attachmentFileList.length > 0 ?
                        <h4 className='tbl_title type2'>파일첨부</h4> : null :
                      <h4 className='tbl_title type2'>파일첨부</h4>
                  }
                  {/*<h4 className='tbl_title type2'>파일첨부</h4>*/}
                  <div className='fileupload'>
                    <FileUpload1
                      files={files}
                      disabledAddtion={extendData?.mvnEtReqStNm == "연장승인"}
                      handleDelete={handleDelete}
                      handleUpload={handleUpload}
                      files1={attachmentFileList}
                      handleDelete2={handleDelete2}
                    />
                  </div>
                  {
                    extendData?.mvnEtReqStNm == "연장승인" ?
                      <Stack direction="row" justifyContent="center" spacing={2} sx={{marginTop: '40px'}}
                             css={styles.btn_next}>
                        <CustomLoadingButton
                          label={extendButtonLabel()} type={'listBack'} color={'primary'}
                          onClick={async (event: React.MouseEvent<HTMLElement>) => {
                            setExtendData({
                              ...extendData,
                              mvnEtEndDay: userMovein?.mvnEndDay || extendData?.mvnEtEndDay,
                              mvnEtReqSt: '',
                              mvnEtReqStNm: '',
                              mvnEtReqCn: '',
                            })
                            setAttachmentFileList([])
                            setAdditionApply(true)
                            // addModal({
                            //   open: true,
                            //   content: '추가신청해 주세요'
                            // })
                            window.scrollTo(0, 10);
                          }}/>
                      </Stack>
                      : extendData?.mvnEtReqStNm !== "접수완료" && extendData?.mvnEtReqStNm !== "신청" ?
                        <Stack direction="row" justifyContent="center" spacing={2} sx={{marginTop: '40px'}}
                               css={styles.btn_next}>
                          <CustomLoadingButton label={extendButtonLabel()} type={'listBack'} color={'primary'}
                                               onClick={moveExtend}/>
                        </Stack>
                        : null
                  }
                  {/*{*/}
                  {/*  extendData?.mvnEtReqStNm !== "접수완료" && extendData?.mvnEtReqStNm !== "신청" ?*/}
                  {/*    <Stack direction="row" justifyContent="center" spacing={2} sx={{marginTop: '40px'}}*/}
                  {/*           css={styles.btn_next}>*/}
                  {/*      <CustomLoadingButton label={extendButtonLabel()} type={'listBack'} color={'primary'}*/}
                  {/*                           onClick={moveExtend}/>*/}
                  {/*    </Stack>*/}
                  {/*    : null*/}
                  {/*}*/}
                </Fragment> : <NoData message={'입주 정보가 없습니다.'}/>
              }
            </TabPanel>
            <TabPanel value={value} index={2}>
              {
                checkOutData ?
                  <Fragment>
                    <h4 className="tbl_title none"></h4>
                    <Box className="box_guide">
                      <ul>
                        <li>입주연장은 최대 3년까지 가능합니다.</li>
                        <li>연장신청 시 내용 검토 후 1차 접수처리가 진행되며, ‘접수완료’가 되면 연장평가를 통해 최종 승인여부를 결정합니다.</li>
                        <li><span className="must">*</span> 표시는 필수입력 항목입니다.</li>
                      </ul>
                    </Box>
                    {
                      checkOutData.checkoutReqSt != "" &&
                      <Box css={styles.table} sx={{marginTop: '40px'}}>
                        <div className="detail_table status">
                          <dl>
                            <dt>상태</dt>
                            <dd className="withLink">
                              <Stack direction='row' justifyContent={'space-between'} sx={{width: '100%'}}
                                     alignItems={'center'}>
                                <div>
                                  {checkOutData.checkoutReqStNm}
                                  {
                                    checkOutData.checkoutReqStNm == "보완" &&
                                    <Link underline="hover" className="home" key="1" color="inherit"
                                          onClick={() => {
                                            setError(checkOutData.makeupReqCn)
                                            setOpen(true)
                                          }}>사유확인
                                    </Link>
                                  }
                                </div>
                                {checkOutData.checkoutReqStNm === "신청" ?
                                  <CustomLoadingButton label={'신청취소'} type={'modalBtn2'} color={'outlined'}
                                                       onClick={checkoutCut}/>
                                  : null}
                              </Stack>
                            </dd>
                          </dl>
                        </div>
                      </Box>
                    }
                    <h4 className="tbl_title type2">퇴실예정일 <span className='must'>*</span></h4>
                    <div className='ipt_datepicker'>
                      <DatePicker
                        pickerType='one'
                        questDay={checkOutData ? dayjs(checkOutData.checkoutPlanDay, 'YYYYMMDD').toString() : dayjs(userMovein.mvnEndDay, 'YYYYMMDD').toString()}
                        questDayDisable={checkOutData ? checkOutData.checkoutReqSt == 'APLY' || checkOutData.checkoutReqSt == 'APRV' : false}
                        changeNowDate={(startNewTime: Date | null) => {
                          setCheckOutData((checkOutInput: any) => ({
                            ...checkOutInput,
                            checkoutPlanDay: dayjs(startNewTime).format('YYYYMMDD').toString()
                          }))
                        }}/>
                    </div>
                    <h4 className='tbl_title type2'>퇴실사유 <span className='must'>*</span></h4>
                    <Box css={styles.textfieldBox}>
                      <TextField
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                          if (checkOutData.checkoutReqSt == 'APLY' || checkOutData.checkoutReqSt == 'APRV') return
                          const {name, value} = e.currentTarget;
                          setCheckOutData((state: any) => ({...state, [name]: value}));
                        }}
                        id="outlined-multiline-static"
                        name="checkoutReason"
                        value={checkOutData.checkoutReason}
                        multiline rows={4}
                        className="scrollBox"
                        inputProps={{
                          maxLength: 1000,
                        }}
                      />
                      <div className='tf_count'>{checkOutData?.checkoutReason?.length || 0}/1000</div>
                    </Box>
                    {
                      checkOutData && (checkOutData.checkoutReqSt == '' || checkOutData.checkoutReqSt == 'SPLMNT' || checkOutData.checkoutReqSt == 'RTRCN') &&
                      <Stack direction="row" justifyContent="center" sx={{marginTop: '40px'}} css={styles.btn_next}>
                        <CustomLoadingButton
                          label={checkOutData.checkoutReqSt == 'SPLMNT' || checkOutData.checkoutReqSt == 'RTRCN' ? '수정' : '퇴실신청'}
                          type={'listBack'} color={'primary'} onClick={checkOut}/>
                      </Stack>
                    }
                  </Fragment> : <NoData message={'입주 정보가 없습니다.'}/>
              }
            </TabPanel>
          </div>
        </div>
      </Box>
      {/*</Box>*/}
    </div>
  </Banner>
}

export default MoveInStatusMgt;