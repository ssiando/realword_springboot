export const breakpoint = {
  mobile: '767px',
  desk1200: '1200px',
  desk1280: '1280px',
  desk1920: '1920px',
};

export const color = {
  red: '#ee1a1a',
  azul: '#4063ec',
  topaz: '#1ccdcc',
  white: '#ffffff',
  black: '#222222',
  darkbg: '#1f2437',
  line: '#e0e0e0',
  pinkish_grey: '#cccccc',
  brownish_gray: '#666',
  warm_grey: '#707070',
  purple: '#6e58ff',
  dim: '#000000',
  bg_grey: '#f5f5f5',
};
