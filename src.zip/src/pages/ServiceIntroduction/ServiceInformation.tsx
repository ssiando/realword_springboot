// 서비스 소개/ ->  서비스 안내 페이지
// import React from "react"
// import * as styles from './styles';
import {CssBaseline,Container} from '@mui/material';
function HonsaEvent() {

  return (
      <Container component="main" maxWidth="xs">
        <CssBaseline />
        <h1>서비스 안내</h1>
      </Container>
  );
}

export default HonsaEvent;
