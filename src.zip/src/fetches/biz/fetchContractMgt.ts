import api from '~/api';
import { TypeReqMgnt } from '~/models/biz/BusinessAppMgt';
import {FrontBsnsPlanType, UsptTaskTaxitmWctPop} from '~/models/biz/ContractMgt';
import { BsnsPlanDocInfo, planInput } from '~/models/ModelBizPlanMgt';


export type BsnsPlanDocInfo1 = {
  bsnsPlanDocId:string,
  planPresentnSttusCd:string
  
}
export type ResnInfo = {
  bsnsPlanDocId:string,
  bsnsSlctnId:string
  
}

//사업계획서 목록조회
export const fetchPlanList = (params:planInput) =>
  api({
    url: `${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/bsns-plan`,
    method:'get',
    params: params
})

// 사업계획서 사유 확인팝업
export const fetchResnInfo = (params: ResnInfo) =>
  api({
    url: `${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/bsns-plan/resn`,
    method:'get',
    params: params
})

// 전자협약 목록조회
export const fetchCnvnList= (params: any) =>
  api({
    url: `${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/cnvn-cncls`,
    method:'get',
    params: params
  })

// 전자협약 상세조회
export const fetchCnvnCnclsDocInfo = (params: { bsnsCnvnId: string, applyId: string}) =>
  api({
    url: `${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/cnvn-cncls/detail-info`,
    method:'get',
    params: params
  })

// /사업계획서 상세 조회  
export const fetchBsnsPlanDocInfo = (params: ResnInfo) =>
  api({
    url: `${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/bsns-plan/detail-info`,
    method:'get',
    params: params
})

//사업계획서 사유 확인팝업-파일 전체 다운
export const fetchGrpFileDwln = (params: FrontBsnsPlanType) =>
  api({
    url: `${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/bsns-plan/resn/grp-file-dwln`,
    method:'get',
})

// 사업계획서 비목별 사업비 구성팝업_조회
export const fetchTaxitmWct = (params: {bsnsPlanDocId: string, bsnsYear: string }) =>
  api({
    url: `${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/bsns-plan/taxitm-wct`,
    method:'get',
    params: params
})

// 사업계획서 비목별 사업비 구성팝업_저장
export const fetchAddTaxitmWct = (data: any) =>
  api({
    url: `${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/bsns-plan/taxitm-wct/save`,
    method:'post',
    data:data
})
// 사업계획서 임시저장
export const fetchModifyPlanTmp = (data: FormData,planPresentnSttusCd:string) =>
  api({
    url: `${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/bsns-plan/${planPresentnSttusCd}/tmp-save`,
    method:'put',
    data
},true)

// 사업계획서 저장
export const fetchModifyPlan = (data: FormData,planPresentnSttusCd:string) =>
  api({
    url: `${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/bsns-plan/${planPresentnSttusCd}/save`,
    method:'put',
    data
},true)


// 사업계획서 상세 기업검색
export const fetchGetBizList = (params: any) =>
  api({
      url: `${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/bsns-plan/bizList`,
      method:'get',
      params: params
  })

// 사업계획서 서명
export const fetchSign = (params: any) =>
  api({
    url: `${process.env.REACT_APP_DOMAIN_PMS_BNET}/pms/api/front/cnvn-cncls/sign`,
    method:'put',
    data: params
  })

