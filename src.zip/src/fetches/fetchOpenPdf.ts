import api from "~/api";

export default async (url: string, attachmentId: string) => {
  try {
    const res = await api({
      url: url,
      method: 'get',
      params: {attachmentId: attachmentId},
    });

    if (!!res && res.alink){
      window.open(res.alink, '_blank')
    }
  } catch (e:any) {
    if(e.response.status == 400 && e.response.data){
      alert(e.response.data.message)
      // return Promise.reject({...e,message:'파일이 없습니다.'});
    }
  }
};