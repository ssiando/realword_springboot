import api from "~/api";

// 설문 목록 조회 (PRG-COM-SVA-01)
export const fetchSurveyList = (params: any) =>
  api({
    method: 'get',
    url: `${process.env.REACT_APP_DOMAIN_COMMON_BNET}/common/api/survey`,
    params: params
  });

//설문 답변용-질문 답변 저장 (PRG-COM-SVA-03)
export const fetchSurveySave = (surveyAnsParam:any) =>
  api({
    method: 'post',
    url: `${process.env.REACT_APP_DOMAIN_COMMON_BNET}/common/api/survey-ans/${surveyAnsParam.surveyId}/ans`,  
    data:surveyAnsParam 
  })

// 설문 기본정보 조회 (PRG-COM-SVM-03)
export const fetchSurveyInfo = (surveyId: string) =>
  api({
    method: 'get',
    url: `${process.env.REACT_APP_DOMAIN_COMMON_BNET}/common/api/survey/${surveyId}`,
  });

// 설문 기본정보 조회 (PRG-COM-SVM-06)
export const fetchSurveyQuestions = (surveyId: string) =>
  api({
    method: 'get',
    url: `${process.env.REACT_APP_DOMAIN_COMMON_BNET}/common/api/survey/${surveyId}/questions`,
  });

// 설문결과 답변 목록 조회 (PRG-COM-SVR-01)
export const fetchSurveyResult = (surveyId: string) =>
  api({
    method: 'get',
    url: `${process.env.REACT_APP_DOMAIN_COMMON_BNET}/common/api/survey-ans/${surveyId}`,
  });

