
export interface codeType {
    codeGroup: String,
    code: String,
    codeNm: String,
    remark: String,
    codeType: String,
    enabled: boolean,
    sortOrder: number,
    
}

export type ErrorsType = {open: boolean,title:string,content: string}