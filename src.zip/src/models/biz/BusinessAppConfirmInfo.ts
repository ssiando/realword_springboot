export interface taskPartcptsList{
    partcptsNm : string, //참여자이름
    chrgRealmNm : string, //담당분야
    mbtlnum : string, //휴대폰번호
    brthdy : string, //생년월일
    partcptnRate : string, //참여율
  }