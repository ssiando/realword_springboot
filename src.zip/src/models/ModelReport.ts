//보고서 제출 목록 조회 (PRG-USP-FBG-01)
export interface reportListInput {
    presentnStartDate : string ,
    presentnEndDate : string ,
    reprtTypeCd : string//"I"|"F",
    reprtSttusCd : string,
    keyword : string ,
    keywordDiv : string
    page : number,
    itemsPerPage : number ,
}

//보고서 제출 (PRG-USP-FBG-06)
export interface reportSubmitInput {
    reprtId : string,
    reprtSumryCn : string,
}