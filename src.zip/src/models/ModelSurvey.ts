export interface surveyInput {
    surveyId: string
    beginDay: string
    endDay: string
    surveyNm: string
    page: number
    surveySt: string
    itemsPerPage: number
}

export interface questions {
    questionId : string,
    answers : answer[]
}

export interface answer {
    answerId:string|null
    shortAnswer:string|null
}

export const initSurveyInput:surveyInput = {
    surveyId: "",
    beginDay: "",
    endDay: "",
    surveyNm: "",
    surveySt: "",
    page: 1,
    itemsPerPage: 10,
}