import dayjs from 'dayjs';

export interface ResourceInput {
  alrsrcBgngDay: string,
  alrsrcEndDay: string,
  alrsrcSt: string,
  page: number,
  itemsPerPage: number,
}

export interface planInput {
  presentnDtStart: string,
  presentnDtEnd: string,
  planPresentnSttusCd: string,
  keywordDiv: string
  keyword: string
  pblancNm: string
  taskNmKo: string
  page: number,
  itemsPerPage: number,
}

export interface ElectronicInput {
  cnvnDeStart : string
  cnvnDeEnd : string
  cnvnSttusCd : string
  keywordDiv: string
  pblancNm: string
  taskNmKo: string
  keyword: string
  page: number,
  itemsPerPage: number
}

export const initPlanInput: planInput = {
  presentnDtStart: '',
  presentnDtEnd: '',
  planPresentnSttusCd: '',
  keywordDiv: '',
  keyword: '',
  taskNmKo: '',
  pblancNm: '',
  page: 1,
  itemsPerPage: 5,
}

export const initResourceInput: ResourceInput = {
  alrsrcBgngDay: '',
  alrsrcEndDay: '',
  alrsrcSt: '',
  page: 1,
  itemsPerPage: 5,
}

export const initElectronicInput: ElectronicInput = {
  cnvnDeStart: '',//dayjs(new Date()).format('YYYY-MM-DD'),
  cnvnDeEnd: '',//dayjs(new Date()).format('YYYY-MM-DD'),
  cnvnSttusCd: '',
  keyword: '',
  keywordDiv: 'pblancNm',
  taskNmKo: '',
  pblancNm: '',
  page: 1,
  itemsPerPage: 5,
}

export interface BsnsPlanDoc {
  bsnsPlanDocId: string,            // 	사업계획서ID
  bsnsSlctnId: string,          // 	사업선정대상ID
  taskNmKo: string,             // 	과제명(한글)
  taskNmEn: string,             // 	과제명(영문)
  applyFieNm: string            // 지원명
  applyField: string,           // 	지원분야
  prsentrAttachmentGroupId: string,             // 	제출첨부파일그룹ID
  planPresentnSttusCd: string,           // 	사업계획제출상태코드
  bsnsNm: string,               // 	사업명
  bsnsYear: string,              // 	사업년도
  receiptNo: string,            // 	접수번호
  pblancNm: string,             // 	공고명
  bsnsBgnde: string,            // 	사업시작일
  bsnsEndde: string,            // 	사업종료일
  bsnsPd: string,               // 	사업기간
  bsnsPdAll: string,            // 	사업기간(전체
  bsnsPdYw: string,             // 	사업기간(당해)
  partcptnCompanyCnt: number,   // 	참여기업수
  smlpzCnt: number,             // 	중소기업수
  mspzCnt: number,              // 	중견기업수
  etcCnt: number               // 	기타수
  totalWct: number              //  총 사업비
  cnsrtm: boolean               // 컨소시엄 여부
  presentnDt: number             // 제출일
  planPresentnSttusNm: string   // 제출상태명
}

export interface TaskRspnber {
  rspnberNm: string,       //	책임자명
  encBrthdy: string,       //	생년월일
  encMbtlnum: string,      //	휴대폰번호
  encEmail: string,        //	이메일
  deptNm: string,          //	부서명
  clsfNm: string,          //	직급명
  adres: string,           //	주소
  encTelno: string,        //	유선번호
  encFxnum: string,        //	팩스번호
  tlsyRegistNo: string,    //	과학기술인등록번호
}

export interface TaskPrtcmpny {
  entrpsNm: string,    //	업체명
  rspnberNm: string,   //	책임자명
  clsfNm: string,  //	직급명
  regTelno: string,    //	전화번호
  regMbtlnum: string,  //	휴대폰번호
  regEmail: string    //	이메일
    memberId: string //회원ID(업체ID)
}

export interface TaskPartcpts {
  partcptsNm: string,   //	참여자명
  chrgRealmNm: string,  //	담당분야명
  encMbtlnum: string,   //	휴대폰번호
  encBrthdy: string,    //	생년월일
  partcptnRate: number, //	참여율
  memberId: string,     //	회원ID
  memberNm: string     //	회원명
}

export interface TaskReqstWct {
  bsnsYear: string,     //	사업년도
  tot_bsns_pd: number,   //	종사업년도(년)
  sportBudget: number,  //	지원예산
  alotmCash: number,    //	부담금현금
  alotmActhng: number,  //	부담금현물
  alotmSum: number,     //	부담금소계
  alotmSumTot: number      //	부담금합계
}

export interface ApplyRealmList {
  applyRealmId: string
  applyRealmNm: string
}

// 사업계획서 관리상세
export interface BsnsPlanDocInfo {
  applyRealmList: ApplyRealmList[],
  usptBsnsPlanDoc: BsnsPlanDoc,
  usptTaskRspnber: TaskRspnber,
  usptTaskPrtcmpny: TaskPrtcmpny[],
  usptTaskPartcpts: TaskPartcpts[],
  usptTaskReqstWct: TaskReqstWct[],
}

// 사업시 합계
export type sumType = {
  sum1: number
  sum2: number
  sum3: number
  sum4: number
  sum5: number
}

// 비목별 사업비 합계 및 소계
export interface TaskReqstWctSum {
  ReqstWctSum1: sumType,         //	인건비 소계
  ReqstWctSum2: sumType,         //	운용비 소계
  ReqstWctSum3: sumType,        //	합계
}

export const BsnsPlanDocInfoData: BsnsPlanDocInfo = {
  usptBsnsPlanDoc: {
    bsnsPlanDocId: '',
    bsnsSlctnId: '',
    taskNmKo: '',
    taskNmEn: '',
    applyFieNm: '',
    applyField: '',
    prsentrAttachmentGroupId: '',
    planPresentnSttusCd: '',
    bsnsNm: '',
    bsnsYear: '',
    receiptNo: '',
    pblancNm: '',
    bsnsBgnde: '',
    bsnsEndde: '',
    bsnsPd: '',
    bsnsPdAll: '',
    bsnsPdYw: '',
    partcptnCompanyCnt: 0,
    smlpzCnt: 0,
    mspzCnt: 0,
    etcCnt: 0,
    totalWct: 0,
    cnsrtm: false,
    presentnDt: 0,
    planPresentnSttusNm: '미제출'
  },
  usptTaskRspnber: {
    rspnberNm: 'dasdasd',
    encBrthdy: 'asda',
    encMbtlnum: 'adsd',
    encEmail: 'dasad',
    deptNm: 'dasda',
    clsfNm: 'adsdasd',
    adres: '',
    encTelno: 'adsdasd',
    encFxnum: '',
    tlsyRegistNo: 'asdasdasd',
  },
  usptTaskPrtcmpny: [
  ],
  usptTaskPartcpts: [
  ],
  usptTaskReqstWct: [
  ],
  applyRealmList: []
}
