// 성과관리 목록 조회 (PRG-USP-SGF-01)
export interface performanceListInput {
  bsnsYear: string,
  rsltSttusCd: string,
  keyword: string,
  keywordDiv: string,
  page: number,
  itemsPerPage: number,
}

// 성과관리 목록 조회 (PRG-USP-SGF-01)
export const initPerformanceInput: performanceListInput = {
  bsnsYear: '',
  rsltSttusCd: '',
  keyword: '',
  keywordDiv: "pblancNm", //키워드검색 구분
  page: 1,
  itemsPerPage: 10
}

export interface infoList {
  rsltIdxIemId: string,
  attachFileOrder: number,
  rsltIdxIemCnList: rsltIdxIemCnList[],
}

export interface rsltIdxIemCnList {
  rsltIdxIemCnId: string,
  rsltIdxIemCn: string
}

export interface deleteAttachFileList {
  attachmentId: string,
}

// 성과 제출 (PRG-USP-SGF-05)
export interface performanceSubmitInput {
  infoList: infoList[],
  deleteAttachFileList: deleteAttachFileList[],
}

export interface basicInfo {
  applyId: string,
  bsnsCd: string,
  bsnsNm: string,
  bsnsYear: string,
  pblancNm: string,
  taskNm: string,
  receiptNo: string,
  memberNm: string,
  bsnsBgnde: string,
  bsnsEndde: string
}

export interface rsltIdxIem {
  rsltHistId?: string
  rsltIdxIemCnId: string,
  rsltIdxDetailIemId: string,
  detailIemNm: string,
  rsltIdxStdIemId: string,
  stdIemNm: string,
  rsltIdxIemCn: string,
  iemUnitCd: string,
  sortOrder: number
  flag: string | null
}

export interface rsltIdxIemList {
  rsltIdxIemId: string,
  rsltIdxId: string,
  rsltIdxNm: string,
  rsltIdxTypeCd: string,
  prufFile: {
    attachmentId: string,
    fileNm: string,
    fileSize: string
  } | null,
  rsltIdxIemCnList: rsltIdxIem[]
}

export interface resultList {
  rsltYear: string
  rsltSttusCd: string,
  rsltSttus: string | null,
  basicInfo: basicInfo,
  rsltIdxIemList: rsltIdxIemList[]
  attachFileList: {
    attachmentId: string
    attachmentGroupId: string
    contentType: string
    fileNm: string
    fileSize: string
    downloadCnt: number
  }[]
}

export interface resultHistoryList {
  basicInfo: basicInfo,
  rsltIdxIemList: rsltIdxIemList[]
  attachFileList: {
    attachmentId: string
    attachmentGroupId: string
    contentType: string
    fileNm: string
    fileSize: string
  }[]
}
