export interface checkOutInput {
    mvnId: String,
    checkoutPlanDay: String,
    checkoutReason: String
}
