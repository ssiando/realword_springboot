export const intialErrorExpert = {
    errorLastUnivNm:false,
    helperLastUnivNm:"",
    errorUnivDeptNm:false,
    helperUnivDeptNm:"",
}
