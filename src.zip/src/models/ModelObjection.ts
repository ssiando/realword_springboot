//결과이의신청 목록 조회 (PRG-USP-RDS-01)
export interface objectionInput {
    objcReqstStartDate : string ,
    objcReqstEndDate : string ,
    lastSlctnObjcProcessSttusCd : string ,
    keyword : string,
    keywordDiv : string
    page : number,
    itemsPerPage : number ,
}

export const initObjectionInput:objectionInput = {
    objcReqstStartDate: '',
    objcReqstEndDate: '',
    lastSlctnObjcProcessSttusCd: '',
    keyword: '',
    keywordDiv: 'pblancNm',
    page: 1,
    itemsPerPage: 10
}