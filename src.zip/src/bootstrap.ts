import 'shared/styles/global.scss';
import { setup } from 'shared/libs/axios';
const api = {
  baseURL: process.env.REACT_APP_API
  // baseURL: 'http://125.6.36.170'
};
setup(api);
export default { config: { api } };
